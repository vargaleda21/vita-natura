# DaleDay — handoff for Claude Code (read this first)

State on 2026-10-25. This file says what DaleDay is, what was built, where things are, how to run it, the
rules, the known limits and good next steps. After this file, read `AGENTS.md` (Expo rules) and
`docs/BRIEF.md` (design language and copy rules).

## What DaleDay is

A phone app idea by Léda: scan a product's barcode in the shop and see at once whether it suits what *you*
chose to avoid (palm oil, added sugar, sweeteners, allergens …), with a better, often cheaper alternative.
The verdict is personal ("fits your settings: 3/4"), never a global "this is bad" score.

- React Native with Expo SDK 58, built web-first: a web export (`output: single`) that runs in Safari on an
  iPhone, installable as a PWA. The same code compiles for iOS and Android (not yet tested on a device).
- Live demo (temporary): https://daleday.digital1.one
- No backend and no accounts. Settings, family profiles and scan history stay on the device (AsyncStorage).
- Hungarian by default, English as a toggle. Light and dark theme.

## Two modes in one app

1. **The demo products (fictional).** 26 made-up products, brands, shops and prices in
   `src/data/products.ts`, `src/data/stores.ts` and `src/data/demo.ts`. They show the full vision: recipe
   history ("got smaller, same price"), dual quality (another recipe in Austria), shop prices, partner-shop
   alternatives, the Wrapped-style monthly story. The scanner's demo strip opens them. The "mystery
   product" (`MYSTERY_EAN = '2000000007700'`) shows the AI label-reading flow, which is **mocked**
   (`aiReadLabel` in `src/data/api.ts`, UI in `src/features/scanner/LabelReader.tsx`).
2. **The real lookup (real data).** Any other barcode is looked up live in open databases
   (`src/data/lookup/`). Real products may show real brand names; nothing is invented for a real code.

`src/features/scanner/ScanScreen.tsx` decides: a demo code goes to `getProduct()`, anything else to
`lookupCode()`.

## Where things are

```
src/app/                 expo-router routes, thin wrappers: (tabs)/ index, discover, insights, profile;
                         product/[ean], member/[id], scan, onboarding, wrapped
src/features/<feature>/  the screens; each feature keeps its HU+EN texts in strings.ts
  brand/                 logo, glow, confetti
  onboarding/            the first-run pages (avoid list, family)
  home/ discover/ insights/ (Wrapped story) profile/ (avoid picker, family members)
  scanner/               camera + @zxing barcode reading, demo strip, mocked label reader
  product/               the product screen: score card, ingredients, alternatives, prices, history
  lookup/                the real-data UI: source checklist, real facts, where sold, maker card, not found
src/data/
  types.ts               the data contract (Product, Settings, AvoidKey …)
  api.ts                 the one import point for screens: evaluate(), alternatives, insights, demo data
  criteria.ts            the 14 avoid criteria with calm, sourced explanations
  products.ts stores.ts demo.ts   the fictional demo data
  lookup/                the real lookup, pure TypeScript (no React), so Node can run it in tests
src/state/store.ts       settings + history, persisted under the AsyncStorage key `tuda.v1`
src/theme/tokens.ts      colours, gradients, spacing, radii, type scale, springs
src/ui/                  Txt, Card, Chip, Icon (lucide), PackArt, VerdictBadge, PressableScale
src/i18n/                useT(strings) and useTr() for {hu, en} values
scripts/build-web.mjs    web build with the phone/PWA head tags
scripts/deploy.sh        deploy to the live server (needs access, see "Hosting")
tools/serve.mjs          local static server + the same API proxies as the live server
tools/lookup-test.mjs    look real barcodes up from Node and print what the app would show
tools/shot.mjs           390×844 phone screenshot with Playwright, prints console errors
tools/make-icons.mjs     generates the app icons
infra/nginx/             the live nginx vhost and its security headers (CSP)
```

## The real lookup (`src/data/lookup/`)

`lookup.ts` runs the sources in parallel, each with a timeout, and reports progress to the UI's source
checklist:

| Source | File | How the browser reaches it |
|---|---|---|
| Open Food Facts (+ Beauty, Products, Pet Food) | `off.ts` | directly (CORS allowed) |
| GVH Árfigyelő (Hungarian shelf prices per chain, by EAN; undocumented API) | `arfigyelo.ts` | proxy `/api/arfigyelo/*` |
| Open Prices | `openprices.ts` | directly |
| UPCitemdb (general goods, last resort; 100 calls a day per IP) | `upc.ts` | proxy `/api/upc/lookup` |
| OFF search index (alternatives) | `off.ts`, `alternatives.ts` | proxy `/api/off/sal` |
| OFF classic search (alternatives, fallback; often 503 at peak) | `off.ts` | proxy `/api/off/search` |
| OFF OCR text of the pack photos | `ocr.ts` | directly (`images.openfoodfacts.org`) |

- The **proxies** exist because those services send no CORS headers. On the web the app calls them on its own
  origin (`/api/...`); on iOS/Android it calls the live site (`proxyBase` in `http.ts`). They are read-only
  (GET, fixed paths, no client headers sent upstream). The live versions are in
  `infra/nginx/daleday.digital1.one.conf`; `tools/serve.mjs` mirrors them for local work. Any new host the
  browser calls must also go into the CSP `connect-src` in `infra/nginx/daleday.digital1.one-security-headers.conf`.
- `map.ts` turns the raw data into the app's `Product`: names (Latin-script names first; a name in the wrong
  language field is skipped; an unnamed product gets its category as a title), ingredients, flags.
- `flags.ts` decides which avoid criteria an ingredient or additive hits (Hungarian and English patterns,
  E-numbers).
- `maker.ts` + `gs1.ts`: for a code no source has, the likely maker from the GS1 company prefix (other OFF
  products with the same first 7–9 digits).
- `alternatives.ts`: candidates from the same category, sold in the same country, ranked by the user's
  settings.
- `cache.ts`: products under `daleday.lookup.v3.p:` (older prefixes are moved over as stale), prices under
  `daleday.lookup.v1.$:`. Change the product prefix when the product shape changes.
- `ocr.ts` (the newest feature): when a found product has no name or no ingredient list, the app reads them off
  the pack photos with the Google Vision text that OFF publishes for every photo. The name comes from the
  largest text on the front photo; the ingredients from the Hungarian or English list on the back photo
  (`Összetevők:` / `Ingredients:`). The UI marks both as machine reading, links the photo and asks the user to
  check the pack if they are allergic.

## Run it

```bash
npm install
npx expo start                        # dev server; press w for the web
npx tsc --noEmit                      # typecheck
npx expo lint                         # lint
node scripts/build-web.mjs /tmp/dd    # web build into /tmp/dd (default: dist/)
node tools/serve.mjs /tmp/dd 8787     # serve it with the API proxies; CSP=1 adds the production CSP
node tools/lookup-test.mjs 5993330000176 --proxy http://127.0.0.1:8787   # a real code from Node
node tools/shot.mjs /scan /tmp/scan.png --base http://127.0.0.1:8787     # phone screenshot
```

The Expo dev server has no `/api/*` proxies, so in it the Árfigyelő prices, UPCitemdb and the alternatives
search fail. To test those, use a web build with `tools/serve.mjs`. Open Food Facts and Open Prices work
everywhere.

Good test barcodes: `5993330000176` (Coca-Cola Zero; name and ingredients come from the photo OCR), any
Hungarian supermarket product, and the demo codes in the scanner's demo strip.

## Rules that keep it consistent

- Every visible text exists in Hungarian **and** English (`strings.ts` per feature, `{hu, en}` values in data).
- Hungarian copy: warm, informal ("te"), correct accents, „…” quotes, "1 890 Ft". Say **"AI"**, never "MI".
- Wording: "you asked to avoid this", never "bad" or "dangerous". Red means only "against what you chose".
- The demo data stays fictional: no real brand or chain names in `products.ts`, `stores.ts`, `demo.ts`.
  Real data from the lookup may show real names.
- Machine-read or guessed data is always marked as such in the UI.
- No new dependencies without a good reason; add Expo packages with `npx expo install`.
- Read the Expo SDK 58 docs before touching Expo APIs (see `AGENTS.md`). Do not create `ios/` or `android/` by
  hand.
- Animate only `transform` and `opacity`; no blur on scrolling layers (phones pay per frame).
- Never put an API key in the app: anything secret belongs on a server.
- `docs/BRIEF.md` was written for the first build, when several agents worked in parallel. Its file-ownership
  section no longer applies; its design, copy and quality rules do.

## What was built (2026-10-24)

1. The foundation: tokens, the data contract, state, i18n, the UI kit, routes, tools, the brief.
2. The full demo: brand, onboarding, home, scanner, product screen, discover, basket insights, the monthly
   story, profile and family, PWA icons, deploy.
3. Read-only proxies for GVH Árfigyelő and UPCitemdb; the CSP for the open product databases.
4. QA, a Hungarian and English proofread, the DaleDay name everywhere (it was "tuda" first; the repo name, the
   package name and the storage key `tuda.v1` keep the old name).
5. The real barcode lookup in open sources, with where it is sold and real alternatives.
6. Alternatives through OFF's search index first, then the classic search.
7. Latin-script names first, unnamed products titled by category, the likely maker of an unknown code.
8. Name and ingredients read off the pack photos (OCR) when nobody typed them in.

## Known limits

- The AI label reader for an unknown product is a mock (the mystery product). No photo is sent anywhere.
- OCR: the name is right on about half of the tested products; ingredient lists only in Hungarian or English,
  only when a back photo exists; single words can be wrong or missing.
- GVH Árfigyelő covers only some categories (no mayonnaise, for example), and its API is undocumented, so it can
  change without notice.
- UPCitemdb allows 100 lookups a day per IP. Local tests can use up your own quota.
- The OFF classic search often refuses anonymous calls at peak times; the search index goes first for that
  reason.
- Recipe history, dual quality and partner-shop commissions exist only for the fictional demo products.
- Tested as a web app (iPhone Safari size, light and dark, HU and EN). Native builds were not run on a device.
- No automated test suite; `tools/lookup-test.mjs` and Playwright screenshots were the checks.

## Next steps (ideas, roughly by value)

1. **Real AI label reading**: photograph the ingredient list of an unknown product and read it with a vision
   model. This needs a small server (the API key must stay there). Then offer to send the photo and the text to
   Open Food Facts, so the next person finds the product.
2. **Native app test**: an EAS development build on a real iPhone and Android phone (camera scanning, haptics,
   safe areas), then TestFlight / internal testing.
3. **Add a missing product**: a guided "help others" flow that sends name, photos and ingredients to Open Food
   Facts (it has a write API; needs an OFF user for the app).
4. **Better OCR**: more label languages (German, Slovak, Romanian, Czech …), better name picking, maybe on a
   server.
5. **Prices**: price history from Árfigyelő, "cheapest near me", a shopping list that checks the whole basket.
6. **Tests**: unit tests for `flags.ts`, `ocr.ts` and `map.ts` (would add a test runner as a dev dependency).
7. **Before a public launch**: own domain and hosting, privacy policy (GDPR), cookie-free analytics, an honest
   commission policy if partner shops pay, an accessibility pass, performance on low-end Android.

## Hosting

The demo runs on Digital One's server, at a temporary address. `scripts/deploy.sh` deploys there and needs
Digital One's SSH access (`DEPLOY_HOST`, `DEPLOY_KEY`, or a gitignored `scripts/deploy.env`). To host it
yourself: any static host works for `dist/` (the SPA falls back to `index.html`), plus the four read-only
proxies from `infra/nginx/daleday.digital1.one.conf` (or a serverless function per proxy), plus the security
headers. On iOS/Android, change `proxyBase` in `src/data/lookup/http.ts` to your own host.

## Licence

`LICENSE` is the MIT licence that came with the Expo starter template. Agree on the licence and ownership you
want before you publish the code.
