import { View } from 'react-native';

import { palette, radius, space } from '@/theme/tokens';
import { Icon, type IconName } from './Icon';
import { PressableScale } from './PressableScale';
import { Txt } from './Txt';
import { useTheme } from './theme';

type Props = {
  label: string;
  icon?: IconName;
  selected?: boolean;
  onPress?: () => void;
  tint?: string;
  size?: 'sm' | 'md';
};

export function Chip({ label, icon, selected, onPress, tint = palette.lime, size = 'md' }: Props) {
  const { c, isDark } = useTheme();
  const bg = selected ? tint : isDark ? c.surfaceAlt : c.surface;
  const fg = selected ? palette.ink : c.text;
  const pad = size === 'sm' ? { paddingHorizontal: space.md, paddingVertical: 6 } : { paddingHorizontal: space.lg, paddingVertical: 10 };
  const body = (
    <View
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          gap: 6,
          borderRadius: radius.pill,
          backgroundColor: bg,
          borderWidth: 1,
          borderColor: selected ? 'transparent' : c.border,
        },
        pad,
      ]}
    >
      {icon ? <Icon name={icon} size={size === 'sm' ? 14 : 16} color={fg} /> : null}
      <Txt variant={size === 'sm' ? 'small' : 'bodyStrong'} color={fg}>
        {label}
      </Txt>
    </View>
  );
  if (!onPress) return body;
  return (
    <PressableScale onPress={onPress} accessibilityRole="button" accessibilityState={{ selected }}>
      {body}
    </PressableScale>
  );
}
