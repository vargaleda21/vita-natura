import { LinearGradient } from 'expo-linear-gradient';
import { useId, type ReactNode } from 'react';
import { Text, View, type ViewStyle } from 'react-native';
import Svg, { Defs, Ellipse, RadialGradient, Stop } from 'react-native-svg';

import type { PackArt as Art } from '@/data/types';

// A drawn pack instead of a brand photo, in a soft "clay 3D" style: a body with a cylinder or box
// shading, a label band with the emoji, a sheen, a glint, a lid or cap, and a shadow on the ground.
// Pure Views and gradients, cheap enough for long lists. Fine at sizes 40–220. Props stay {art, size}.
type Props = { art: Art; size?: number };

type Geo = { w: number; h: number; round: 'cyl' | 'flat' };

const GEO: Record<Art['shape'], Geo> = {
  jar: { w: 0.7, h: 0.76, round: 'cyl' },
  bottle: { w: 0.46, h: 0.74, round: 'cyl' },
  can: { w: 0.56, h: 0.86, round: 'cyl' },
  cup: { w: 0.64, h: 0.72, round: 'cyl' },
  tub: { w: 0.86, h: 0.56, round: 'cyl' },
  bag: { w: 0.74, h: 0.9, round: 'flat' },
  box: { w: 0.66, h: 0.92, round: 'flat' },
  bar: { w: 0.96, h: 0.44, round: 'flat' },
};

function rgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  const v = h.length === 3 ? h.split('').map((ch) => ch + ch).join('') : h.slice(0, 6);
  const n = parseInt(v, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function mix(a: string, b: string, t: number): string {
  const [r1, g1, b1] = rgb(a);
  const [r2, g2, b2] = rgb(b);
  const ch = (x: number, y: number) => Math.round(x + (y - x) * t).toString(16).padStart(2, '0');
  return `#${ch(r1, r2)}${ch(g1, g2)}${ch(b1, b2)}`;
}

const WHITE = '#FFFFFF';
const BLACK = '#000000';
const SILVER = ['#F4F6F7', '#C9CFD4', '#959DA5'] as const;


/** Vertical lines for lid ribs and crimped seals. */
function Lines({ count, color, vertical = true, thickness }: { count: number; color: string; vertical?: boolean; thickness: number }) {
  return (
    <View
      style={{
        ...absFill,
        flexDirection: vertical ? 'row' : 'column',
        justifyContent: 'space-evenly',
      }}
    >
      {Array.from({ length: count }, (_, i) => (
        <View key={i} style={vertical ? { width: thickness, height: '100%', backgroundColor: color } : { height: thickness, width: '100%', backgroundColor: color }} />
      ))}
    </View>
  );
}

const absFill: ViewStyle = { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 };

export function PackArt({ art, size = 88 }: Props) {
  const S = size;
  const g = GEO[art.shape] ?? GEO.box;
  const [c0, c1] = art.colors;
  const w = S * g.w;
  const h = S * g.h;
  const detail = S >= 64;
  const shadowId = `pack${useId().replace(/[^a-zA-Z0-9_-]/g, '')}`;
  const sw = w * 1.25;
  const sh = Math.max(6, S * 0.1);
  const hair = Math.max(1, S * 0.007);

  // Body corner radii per shape.
  const radii: ViewStyle = (() => {
    switch (art.shape) {
      case 'jar':
        return { borderRadius: S * 0.09, borderTopLeftRadius: S * 0.05, borderTopRightRadius: S * 0.05 };
      case 'bottle':
        return { borderTopLeftRadius: w * 0.42, borderTopRightRadius: w * 0.42, borderBottomLeftRadius: S * 0.07, borderBottomRightRadius: S * 0.07 };
      case 'can':
        return { borderRadius: S * 0.035 };
      case 'cup':
        return { borderTopLeftRadius: S * 0.02, borderTopRightRadius: S * 0.02, borderBottomLeftRadius: S * 0.14, borderBottomRightRadius: S * 0.14 };
      case 'tub':
        return { borderTopLeftRadius: S * 0.02, borderTopRightRadius: S * 0.02, borderBottomLeftRadius: S * 0.1, borderBottomRightRadius: S * 0.1 };
      case 'bag':
        return { borderTopLeftRadius: S * 0.03, borderTopRightRadius: S * 0.03, borderBottomLeftRadius: S * 0.11, borderBottomRightRadius: S * 0.11 };
      case 'bar':
        return { borderRadius: S * 0.035 };
      default:
        return { borderRadius: S * 0.035 };
    }
  })();

  const cyl = g.round === 'cyl';
  const bandH = art.shape === 'bar' ? h * 0.56 : art.shape === 'tub' ? h * 0.52 : h * 0.42;
  const bandTop = art.shape === 'bar' ? (h - bandH) / 2 : art.shape === 'tub' ? h * 0.24 : h * 0.3;
  const bandInset = art.shape === 'bar' ? w * 0.16 : 0;
  const emoji = Math.min(bandH * 0.68, w * 0.5);

  let top: ReactNode = null;
  if (art.shape === 'jar' || art.shape === 'tub') {
    const lw = art.shape === 'jar' ? w * 0.9 : w * 1.04;
    const lh = art.shape === 'jar' ? S * 0.12 : S * 0.1;
    top = (
      <LinearGradient
        colors={[mix(c0, WHITE, 0.28), c0, mix(c0, BLACK, 0.28)]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={{ width: lw, height: lh, borderRadius: S * 0.035, marginBottom: -hair, overflow: 'hidden' }}
      >
        {detail && art.shape === 'jar' ? <Lines count={11} color="rgba(0,0,0,0.14)" thickness={hair} /> : null}
        <View style={{ position: 'absolute', left: lw * 0.08, right: lw * 0.08, top: lh * 0.14, height: hair * 1.5, borderRadius: hair, backgroundColor: 'rgba(255,255,255,0.45)' }} />
      </LinearGradient>
    );
  } else if (art.shape === 'bottle') {
    top = (
      <View style={{ alignItems: 'center' }}>
        <LinearGradient
          colors={[mix(c0, WHITE, 0.25), c0, mix(c0, BLACK, 0.35)]}
          start={{ x: 0, y: 0.5 }}
          end={{ x: 1, y: 0.5 }}
          style={{ width: w * 0.5, height: S * 0.085, borderRadius: S * 0.02 }}
        />
        <LinearGradient
          colors={[mix(c1, WHITE, 0.2), c1, mix(c1, BLACK, 0.2)]}
          start={{ x: 0, y: 0.5 }}
          end={{ x: 1, y: 0.5 }}
          style={{ width: w * 0.36, height: S * 0.1, marginBottom: -hair * 2 }}
        />
      </View>
    );
  } else if (art.shape === 'can' || art.shape === 'cup') {
    top = (
      <LinearGradient
        colors={SILVER}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={{
          width: art.shape === 'cup' ? w * 1.08 : w * 0.96,
          height: S * 0.05,
          borderRadius: S * 0.025,
          marginBottom: -hair,
        }}
      />
    );
  }

  return (
    <View style={{ width: S, height: S, alignItems: 'center', justifyContent: 'flex-end', paddingBottom: S * 0.035 }}>
      {/* A soft contact shadow on the ground: a radial gradient, no blur. */}
      <Svg width={sw} height={sh} style={{ position: 'absolute', bottom: S * 0.035 - sh / 2 }}>
        <Defs>
          <RadialGradient id={shadowId} cx="50%" cy="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor="#10231C" stopOpacity={0.34} />
            <Stop offset="0.55" stopColor="#10231C" stopOpacity={0.12} />
            <Stop offset="1" stopColor="#10231C" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Ellipse cx={sw / 2} cy={sh / 2} rx={sw / 2} ry={sh / 2} fill={`url(#${shadowId})`} />
      </Svg>
      {top}
      <View style={[{ width: w, height: h, overflow: 'hidden' }, radii]}>
        <LinearGradient
          colors={[mix(c1, WHITE, 0.22), c1, c0]}
          start={cyl ? { x: 0, y: 0.35 } : { x: 0, y: 0 }}
          end={cyl ? { x: 1, y: 0.65 } : { x: 1, y: 1 }}
          style={absFill}
        />
        {/* Crimped seals for bags and bars. */}
        {art.shape === 'bag' ? (
          <View style={{ position: 'absolute', left: 0, right: 0, top: 0, height: S * 0.08, backgroundColor: mix(c0, BLACK, 0.12) }}>
            {detail ? <Lines count={14} color="rgba(255,255,255,0.18)" thickness={hair} /> : null}
          </View>
        ) : null}
        {art.shape === 'bar'
          ? [0, 1].map((side) => (
              <View
                key={side}
                style={{
                  position: 'absolute',
                  top: 0,
                  bottom: 0,
                  width: w * 0.07,
                  ...(side ? { right: 0 } : { left: 0 }),
                  backgroundColor: mix(c0, BLACK, 0.12),
                }}
              >
                {detail ? <Lines count={6} vertical={false} color="rgba(255,255,255,0.2)" thickness={hair} /> : null}
              </View>
            ))
          : null}
        {art.shape === 'can' ? (
          <LinearGradient colors={SILVER} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: S * 0.03 }} />
        ) : null}
        {/* The label band with the emoji. */}
        <View
          style={{
            position: 'absolute',
            left: bandInset,
            right: bandInset,
            top: bandTop,
            height: bandH,
            backgroundColor: mix(c1, WHITE, 0.8),
            borderTopWidth: hair,
            borderBottomWidth: hair,
            borderLeftWidth: bandInset ? hair : 0,
            borderRightWidth: bandInset ? hair : 0,
            borderColor: mix(c0, WHITE, 0.25),
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Text style={{ fontSize: emoji, lineHeight: emoji * 1.18, textAlign: 'center' }} allowFontScaling={false}>
            {art.emoji}
          </Text>
        </View>
        {/* Light from the top left: a sheen, a rim shade, a darker foot and a glint. */}
        <LinearGradient
          colors={['rgba(255,255,255,0)', 'rgba(255,255,255,0.42)', 'rgba(255,255,255,0)']}
          start={{ x: 0, y: 0.5 }}
          end={{ x: 1, y: 0.5 }}
          style={{ position: 'absolute', top: 0, bottom: 0, left: w * (cyl ? 0.1 : 0.06), width: w * (cyl ? 0.24 : 0.18) }}
        />
        <LinearGradient
          colors={['rgba(0,0,0,0)', cyl ? 'rgba(0,0,0,0.24)' : 'rgba(0,0,0,0.16)']}
          start={{ x: 0, y: 0.5 }}
          end={{ x: 1, y: 0.5 }}
          style={{ position: 'absolute', top: 0, bottom: 0, right: 0, width: w * (cyl ? 0.34 : 0.16) }}
        />
        {art.shape === 'bag' ? (
          <LinearGradient
            colors={['rgba(0,0,0,0.14)', 'rgba(0,0,0,0)']}
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: w * 0.1 }}
          />
        ) : null}
        {art.shape === 'box' ? <View style={{ position: 'absolute', left: 0, right: 0, top: 0, height: S * 0.045, backgroundColor: 'rgba(255,255,255,0.26)' }} /> : null}
        <LinearGradient
          colors={['rgba(0,0,0,0)', 'rgba(0,0,0,0.16)']}
          style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: h * 0.22 }}
        />
        {detail ? (
          <View
            style={{
              position: 'absolute',
              left: w * 0.15,
              top: art.shape === 'bag' ? S * 0.11 : h * 0.07,
              width: Math.max(3, w * 0.07),
              height: Math.max(6, (art.shape === 'bar' ? h : bandTop) * 0.5),
              borderRadius: 999,
              backgroundColor: 'rgba(255,255,255,0.55)',
            }}
          />
        ) : null}
      </View>
    </View>
  );
}
