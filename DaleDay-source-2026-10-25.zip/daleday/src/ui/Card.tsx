import { LinearGradient } from 'expo-linear-gradient';
import type { ReactNode } from 'react';
import { View, type StyleProp, type ViewStyle } from 'react-native';

import { radius, shadow, space } from '@/theme/tokens';
import { useTheme } from './theme';

type Props = {
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
  /** Two or more colours: the card gets a gradient fill instead of the surface colour. */
  gradient?: readonly [string, string, ...string[]];
  padded?: boolean;
  flat?: boolean;
};

export function Card({ children, style, gradient, padded = true, flat }: Props) {
  const { c, isDark } = useTheme();
  const base: ViewStyle = {
    borderRadius: radius.lg,
    backgroundColor: gradient ? undefined : c.surface,
    borderWidth: isDark && !gradient ? 1 : 0,
    borderColor: c.border,
    overflow: 'hidden',
    ...(flat || isDark ? null : shadow.card),
  };
  if (gradient) {
    return (
      <View style={[base, style]}>
        <LinearGradient
          colors={gradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[{ flex: 1, borderRadius: radius.lg }, padded && { padding: space.lg }]}
        >
          {children}
        </LinearGradient>
      </View>
    );
  }
  return <View style={[base, padded && { padding: space.lg }, style]}>{children}</View>;
}
