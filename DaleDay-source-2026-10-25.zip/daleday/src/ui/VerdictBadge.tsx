import { View } from 'react-native';

import type { Verdict } from '@/data/types';
import { useLang } from '@/i18n';
import { palette, radius, verdictColor } from '@/theme/tokens';
import { Txt } from './Txt';

export const VERDICT_LABEL: Record<Verdict, { hu: string; en: string }> = {
  great: { hu: 'Neked való', en: 'Fits you' },
  okay: { hu: 'Elmegy', en: 'Mostly fine' },
  avoid: { hu: 'Keress mást', en: 'Try another' },
};

/** A small coloured pill with the score, for lists and cards. */
export function VerdictBadge({ verdict, score, compact }: { verdict: Verdict; score?: number; compact?: boolean }) {
  const lang = useLang();
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        alignSelf: 'flex-start',
        backgroundColor: verdictColor[verdict],
        borderRadius: radius.pill,
        paddingHorizontal: compact ? 8 : 10,
        paddingVertical: compact ? 3 : 5,
      }}
    >
      {score !== undefined ? (
        <Txt variant="tiny" color={palette.ink}>
          {score}
        </Txt>
      ) : null}
      {!compact ? (
        <Txt variant="tiny" color={palette.ink}>
          {VERDICT_LABEL[verdict][lang]}
        </Txt>
      ) : null}
    </View>
  );
}
