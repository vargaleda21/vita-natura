import { useColorScheme } from 'react-native';

import { colors, type Scheme, type ThemeColors } from '@/theme/tokens';
import { isNightHour, useHour } from '@/state/clock';
import { useSettings } from '@/state/store';

export function useScheme(): Scheme {
  const system = useColorScheme();
  const pref = useSettings().theme;
  const hour = useHour();
  if (pref === 'light' || pref === 'dark') return pref;
  if (pref === 'auto') return isNightHour(hour) ? 'dark' : 'light';
  return system === 'dark' ? 'dark' : 'light';
}

export function useTheme(): { scheme: Scheme; isDark: boolean; c: ThemeColors } {
  const scheme = useScheme();
  return { scheme, isDark: scheme === 'dark', c: colors[scheme] };
}
