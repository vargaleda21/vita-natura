import {
  ArrowLeftRight,
  ArrowRight,
  Atom,
  Baby,
  BadgePercent,
  BeanOff,
  Beef,
  Camera,
  Candy,
  ChartPie,
  Check,
  ChevronLeft,
  ChevronRight,
  CircleAlert,
  CircleQuestionMark,
  CloudHail,
  Coins,
  Coffee,
  EggOff,
  Factory,
  Flame,
  FlaskConical,
  Flashlight,
  Globe,
  Heart,
  History,
  House,
  Image,
  Info,
  Keyboard,
  Languages,
  Leaf,
  type LucideIcon,
  MilkOff,
  Moon,
  NutOff,
  Pause,
  Pencil,
  PiggyBank,
  Play,
  Package,
  Palette,
  Plus,
  RefreshCw,
  Scale,
  ScanBarcode,
  ScanText,
  Settings,
  Share2,
  ShieldCheck,
  ShoppingBasket,
  Sparkles,
  Sprout,
  Store,
  Sun,
  Tag,
  Trash2,
  TreePalm,
  TrendingDown,
  TriangleAlert,
  Trophy,
  UserRound,
  Users,
  WheatOff,
  X,
  Zap,
} from 'lucide-react-native';
import type { ComponentType } from 'react';
import Svg, { Path } from 'react-native-svg';

type IconComponent = ComponentType<{ size?: number; color?: string; strokeWidth?: number }>;

/** Lucide has no salt icon: a salt shaker drawn in Lucide's style (24 grid, round stroke). */
function SaltShaker({ size = 24, color = '#10231C', strokeWidth = 2 }: { size?: number; color?: string; strokeWidth?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
      <Path d="M7.5 10h9l-1 11h-7z" />
      <Path d="M7.5 10a4.5 4.5 0 0 1 9 0" />
      <Path d="M8.3 15h7.4" />
      <Path d="M10.4 7.6h.01M12 6.6h.01M13.6 7.6h.01" />
    </Svg>
  );
}

const ICONS = {
  'arrow-left-right': ArrowLeftRight,
  'arrow-right': ArrowRight,
  atom: Atom,
  baby: Baby,
  'badge-percent': BadgePercent,
  'bean-off': BeanOff,
  beef: Beef,
  camera: Camera,
  candy: Candy,
  'chart-pie': ChartPie,
  check: Check,
  'chevron-left': ChevronLeft,
  'chevron-right': ChevronRight,
  'circle-alert': CircleAlert,
  'circle-question-mark': CircleQuestionMark,
  'cloud-hail': CloudHail,
  coins: Coins,
  coffee: Coffee,
  'egg-off': EggOff,
  factory: Factory,
  flame: Flame,
  'flask-conical': FlaskConical,
  flashlight: Flashlight,
  globe: Globe,
  heart: Heart,
  history: History,
  house: House,
  image: Image,
  info: Info,
  keyboard: Keyboard,
  languages: Languages,
  leaf: Leaf,
  'milk-off': MilkOff,
  moon: Moon,
  'nut-off': NutOff,
  pause: Pause,
  pencil: Pencil,
  'piggy-bank': PiggyBank,
  play: Play,
  package: Package,
  palette: Palette,
  plus: Plus,
  'refresh-cw': RefreshCw,
  'salt-shaker': SaltShaker,
  scale: Scale,
  'scan-barcode': ScanBarcode,
  'scan-text': ScanText,
  settings: Settings,
  'share-2': Share2,
  'shield-check': ShieldCheck,
  'shopping-basket': ShoppingBasket,
  sparkles: Sparkles,
  sprout: Sprout,
  store: Store,
  sun: Sun,
  tag: Tag,
  'trash-2': Trash2,
  'tree-palm': TreePalm,
  'trending-down': TrendingDown,
  'triangle-alert': TriangleAlert,
  trophy: Trophy,
  'user-round': UserRound,
  users: Users,
  'wheat-off': WheatOff,
  x: X,
  zap: Zap,
} satisfies Record<string, IconComponent | LucideIcon>;

export type IconName = keyof typeof ICONS;

export function isIconName(name: string): name is IconName {
  return name in ICONS;
}

type Props = { name: IconName | string; size?: number; color?: string; strokeWidth?: number };

/** Lucide icons by kebab-case name. Unknown names fall back to a sparkle. Add new ones to ICONS. */
export function Icon({ name, size = 20, color = '#10231C', strokeWidth = 2 }: Props) {
  const C = isIconName(name) ? ICONS[name] : Sparkles;
  return <C size={size} color={color} strokeWidth={strokeWidth} />;
}
