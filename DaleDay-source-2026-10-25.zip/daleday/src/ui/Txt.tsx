import { Text, type TextProps } from 'react-native';

import { type, type TypeVariant } from '@/theme/tokens';
import { useTheme } from './theme';

type Props = TextProps & {
  variant?: TypeVariant;
  color?: string;
  muted?: boolean;
  faint?: boolean;
  center?: boolean;
  upper?: boolean;
};

export function Txt({ variant = 'body', color, muted, faint, center, upper, style, ...rest }: Props) {
  const { c } = useTheme();
  const tint = color ?? (faint ? c.textFaint : muted ? c.textMuted : c.text);
  return (
    <Text
      {...rest}
      style={[
        type[variant],
        { color: tint },
        center && { textAlign: 'center' },
        upper && { textTransform: 'uppercase' },
        style,
      ]}
    />
  );
}
