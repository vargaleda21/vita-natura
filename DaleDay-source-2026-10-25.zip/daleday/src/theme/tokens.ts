// DaleDay design tokens. "Fresh market at golden hour": oat cream, deep forest ink,
// a lime sprout for the brand, warm fruit accents. Every screen reads colours from here.

export const palette = {
  ink: '#10231C',
  forest: '#1E4D3A',
  oat: '#F7F4EC',
  oat2: '#EFEADF',
  white: '#FFFFFF',
  night: '#0B1612',
  night2: '#13221C',
  night3: '#1B2E26',
  lime: '#C6F36B',
  limeDeep: '#8FD13B',
  mint: '#7BE0B5',
  sky: '#7FD3FF',
  lilac: '#B9A4FF',
  tangerine: '#FF8A3D',
  sun: '#FFC93D',
  coral: '#FF5D5D',
  great: '#2FCB74',
  okay: '#F5B92E',
  avoid: '#F2555A',
} as const;

export type Scheme = 'light' | 'dark';

export const colors = {
  light: {
    bg: palette.oat,
    bgAlt: palette.oat2,
    surface: palette.white,
    surfaceAlt: '#F9F7F1',
    text: palette.ink,
    textMuted: '#55675F',
    textFaint: '#8A9A92',
    border: 'rgba(16,35,28,0.09)',
    brand: palette.lime,
    brandInk: palette.ink,
    accent: palette.tangerine,
    tabBar: palette.ink,
    tabBarText: '#CFE3D8',
    overlay: 'rgba(16,35,28,0.55)',
  },
  dark: {
    bg: palette.night,
    bgAlt: palette.night2,
    surface: palette.night2,
    surfaceAlt: palette.night3,
    text: '#EEF6EF',
    textMuted: '#A8BDB2',
    textFaint: '#6F857A',
    border: 'rgba(238,246,239,0.08)',
    brand: palette.lime,
    brandInk: palette.ink,
    accent: palette.tangerine,
    tabBar: '#1A2C25',
    tabBarText: '#CFE3D8',
    overlay: 'rgba(0,0,0,0.6)',
  },
} as const;

export type ThemeColors = { [K in keyof (typeof colors)['light']]: string };

/** Verdict colours. Red only means "this goes against what YOU asked to avoid". */
export const verdictColor = {
  great: palette.great,
  okay: palette.okay,
  avoid: palette.avoid,
} as const;

export const gradients = {
  sprout: [palette.lime, palette.mint] as const,
  sunrise: [palette.sun, palette.tangerine] as const,
  dusk: [palette.lilac, palette.sky] as const,
  forest: [palette.forest, palette.ink] as const,
  hero: ['#D7F79A', '#A6EBC9', '#BFE6FF'] as const,
  heroDark: ['#1E4D3A', '#123327', '#0B1612'] as const,
};

export const space = { xxs: 2, xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 28, xxxl: 40 } as const;
export const radius = { sm: 10, md: 16, lg: 22, xl: 28, pill: 999 } as const;

export const font = {
  display: 'BricolageGrotesque_800ExtraBold',
  displayBold: 'BricolageGrotesque_700Bold',
  displaySemi: 'BricolageGrotesque_600SemiBold',
  body: 'Inter_400Regular',
  bodyMedium: 'Inter_500Medium',
  bodySemi: 'Inter_600SemiBold',
  bodyBold: 'Inter_700Bold',
} as const;

export const type = {
  hero: { fontFamily: font.display, fontSize: 40, lineHeight: 42, letterSpacing: -1.2 },
  h1: { fontFamily: font.display, fontSize: 30, lineHeight: 34, letterSpacing: -0.8 },
  h2: { fontFamily: font.displayBold, fontSize: 22, lineHeight: 27, letterSpacing: -0.4 },
  h3: { fontFamily: font.displaySemi, fontSize: 18, lineHeight: 23, letterSpacing: -0.2 },
  body: { fontFamily: font.body, fontSize: 15, lineHeight: 22 },
  bodyStrong: { fontFamily: font.bodySemi, fontSize: 15, lineHeight: 22 },
  small: { fontFamily: font.bodyMedium, fontSize: 13, lineHeight: 18 },
  tiny: { fontFamily: font.bodySemi, fontSize: 11, lineHeight: 14, letterSpacing: 0.6 },
  number: { fontFamily: font.display, fontSize: 34, lineHeight: 36, letterSpacing: -1 },
} as const;

export type TypeVariant = keyof typeof type;

/** Soft shadow that works on web and native. Never a blur filter: phones pay per frame. */
export const shadow = {
  card: {
    shadowColor: '#10231C',
    shadowOpacity: 0.08,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 8 },
    elevation: 3,
  },
  float: {
    shadowColor: '#10231C',
    shadowOpacity: 0.22,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 12 },
    elevation: 8,
  },
} as const;

/** Spring presets for Reanimated. */
export const springs = {
  snappy: { damping: 16, stiffness: 220, mass: 0.7 },
  soft: { damping: 20, stiffness: 120, mass: 1 },
  bouncy: { damping: 9, stiffness: 160, mass: 0.8 },
} as const;
