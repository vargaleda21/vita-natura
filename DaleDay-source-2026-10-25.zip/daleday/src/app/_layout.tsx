import {
  BricolageGrotesque_600SemiBold,
  BricolageGrotesque_700Bold,
  BricolageGrotesque_800ExtraBold,
} from '@expo-google-fonts/bricolage-grotesque';
import { Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold } from '@expo-google-fonts/inter';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFonts } from 'expo-font';
import { DarkTheme, DefaultTheme, Stack, ThemeProvider } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import '@/global.css';
import { ThemeCrossfade } from '@/components/ThemeCrossfade';
import { configureLookup, hydrateLookupCache } from '@/data/api';
import { demoHistory } from '@/data/demo';
import { getHistory, hydrate, replaceHistory, useHydrated } from '@/state/store';
import { useTheme } from '@/ui';

void SplashScreen.preventAutoHideAsync();

// Real products looked up by barcode are kept on the device (identity ~7 days, prices ~1 hour).
configureLookup({ storage: AsyncStorage });

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    BricolageGrotesque_600SemiBold,
    BricolageGrotesque_700Bold,
    BricolageGrotesque_800ExtraBold,
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });
  const hydrated = useHydrated();
  const [cacheReady, setCacheReady] = useState(false);
  const { isDark, c } = useTheme();

  useEffect(() => {
    void hydrate().then(() => {
      // A first visit gets a believable past, so the home screen and the monthly story have life.
      if (getHistory().length === 0) replaceHistory(demoHistory());
    });
    // Real products from earlier scans, so the history and a reloaded product page show at once.
    void hydrateLookupCache().then(() => setCacheReady(true));
  }, []);

  const ready = fontsLoaded && hydrated && cacheReady;
  useEffect(() => {
    if (!ready) return;
    void SplashScreen.hideAsync();
    // The web build's static boot screen (scripts/build-web.mjs): fade it out, then remove it.
    const boot = typeof document !== 'undefined' ? document.getElementById('boot') : null;
    if (boot) {
      boot.classList.add('out');
      setTimeout(() => boot.remove(), 400);
    }
  }, [ready]);
  if (!ready) return null;

  const nav = isDark ? DarkTheme : DefaultTheme;
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <ThemeProvider value={{ ...nav, colors: { ...nav.colors, background: c.bg, card: c.surface, text: c.text } }}>
          <StatusBar style={isDark ? 'light' : 'dark'} />
          <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: c.bg } }}>
            <Stack.Screen name="index" />
            <Stack.Screen name="onboarding" options={{ animation: 'fade' }} />
            <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
            <Stack.Screen name="scan" options={{ presentation: 'fullScreenModal', animation: 'fade' }} />
            <Stack.Screen name="product/[ean]" options={{ animation: 'slide_from_bottom' }} />
            <Stack.Screen name="member/[id]" options={{ presentation: 'modal', animation: 'slide_from_bottom' }} />
            <Stack.Screen name="wrapped" options={{ presentation: 'fullScreenModal', animation: 'fade' }} />
          </Stack>
          <ThemeCrossfade />
        </ThemeProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
