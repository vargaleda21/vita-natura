import { Redirect } from 'expo-router';

/** A link to a page that does not exist lands on the home screen, not on the router's debug page. */
export default function NotFound() {
  return <Redirect href="/" />;
}
