export { WrappedScreen as default } from '@/features/insights/WrappedScreen';
