// A code no open source knows: say so plainly, show where we looked, and offer the next steps.
// Used as a sheet on the scanner and as a full screen for a deep link.

import { router } from 'expo-router';
import { Linking, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { gs1Info, SOURCE_ORDER, type Gs1Info, type Progress, type SourceKey } from '@/data/api';
import { useT, useTr } from '@/i18n';
import { Barcode } from '@/features/scanner/Barcode';
import { GhostButton, PrimaryButton } from '@/features/scanner/buttons';
import { palette, radius, space } from '@/theme/tokens';
import { Icon, Txt, useTheme } from '@/ui';
import { MakerCard } from './MakerCard';
import { SourceRow } from './SourceChecklist';
import { strings, type LookupStrings } from './strings';

export function addToOffUrl(code: string): string {
  return `https://world.openfoodfacts.org/cgi/product.pl?type=add&code=${encodeURIComponent(code)}`;
}

/** "Barcode registered in Hungary. Not where it was made." */
export function gs1Line(info: Gs1Info, t: LookupStrings, tr: (v: { hu: string; en: string }) => string): string | null {
  switch (info.kind) {
    case 'country':
      return `${t.gs1Country(tr(info.country))} ${t.gs1Note}`;
    case 'instore':
      return t.gs1Instore;
    case 'coupon':
      return t.gs1Coupon;
    case 'book':
      return t.gs1Book;
    default:
      return null;
  }
}

type BodyProps = {
  code: string;
  progress: Progress;
  unreachable: SourceKey[];
  reduced: boolean;
  onRetry: () => void;
  onType?: () => void;
  onDismiss: () => void;
  dismissLabel?: string;
  /** Open one of the likely maker's products instead (a similar product, another barcode). */
  onPick?: (code: string) => void;
  /** Tighter, for the scanner's sheet. */
  compact?: boolean;
};

export function RealNotFoundBody({ code, progress, unreachable, reduced, onRetry, onType, onDismiss, dismissLabel, onPick, compact }: BodyProps) {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const offline = unreachable.includes('off') && unreachable.includes('arfigyelo');
  const partial = !offline && unreachable.length > 0;
  const gs1 = gs1Line(gs1Info(code), t, tr);
  const drawable = /^\d{13}$|^\d{8}$/.test(code);

  return (
    <View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
        <View
          style={{
            width: 44,
            height: 44,
            borderRadius: 14,
            backgroundColor: offline ? palette.sun : isDark ? c.surfaceAlt : c.surface,
            borderWidth: offline ? 0 : 1,
            borderColor: c.border,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name={offline ? 'circle-alert' : 'circle-question-mark'} size={22} color={offline ? palette.ink : c.text} />
        </View>
        <Txt variant="tiny" upper muted>
          {t.nfEyebrow}
        </Txt>
      </View>
      <Txt variant={compact ? 'h2' : 'h1'} accessibilityRole="header" style={{ marginTop: compact ? space.md : space.lg }}>
        {offline ? t.nfOfflineTitle : t.nfTitle}
      </Txt>
      <Txt variant="body" muted style={{ marginTop: space.sm }}>
        {offline ? t.nfOfflineBody : t.nfBody}
      </Txt>
      {partial ? (
        <Txt variant="small" style={{ marginTop: space.sm }}>
          {t.nfPartial(unreachable.map((k) => t.source[k].name).join(', '))}
        </Txt>
      ) : null}

      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md, marginTop: space.lg }}>
        {drawable ? (
          <View
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: radius.md,
              paddingHorizontal: space.md,
              paddingTop: space.sm,
              paddingBottom: 4,
              borderWidth: isDark ? 0 : 1,
              borderColor: c.border,
            }}
          >
            <Barcode code={code} width={compact ? 124 : 150} height={compact ? 44 : 52} />
          </View>
        ) : (
          <Txt variant="h3">{code}</Txt>
        )}
        {gs1 ? (
          <Txt variant="small" muted style={{ flex: 1 }}>
            {gs1}
          </Txt>
        ) : null}
      </View>

      {onPick && !offline ? <MakerCard code={code} reduced={reduced} onPick={onPick} compact={compact} /> : null}

      <View
        style={{
          marginTop: compact ? space.md : space.lg,
          gap: compact ? 8 : 10,
          padding: space.md,
          borderRadius: radius.md,
          backgroundColor: isDark ? c.surfaceAlt : c.surface,
          borderWidth: 1,
          borderColor: c.border,
        }}
      >
        <Txt variant="tiny" upper muted>
          {t.nfTried}
        </Txt>
        {SOURCE_ORDER.map((k) => (
          <SourceRow key={k} k={k} status={progress[k]} t={t} reduced={reduced} dark={isDark} compact={compact} />
        ))}
      </View>

      <View style={{ marginTop: compact ? space.lg : space.xl, gap: space.xs }}>
        {offline ? (
          <PrimaryButton label={t.tryAgain} icon="refresh-cw" onPress={onRetry} />
        ) : (
          <PrimaryButton label={t.addToOff} icon="plus" onPress={() => void Linking.openURL(addToOffUrl(code))} />
        )}
        <View style={{ flexDirection: 'row', gap: space.xs }}>
          {!offline ? (
            <View style={{ flex: 1 }}>
              <GhostButton label={t.tryAgain} icon="refresh-cw" onPress={onRetry} />
            </View>
          ) : null}
          {onType ? (
            <View style={{ flex: 1 }}>
              <GhostButton label={t.typeCode} icon="keyboard" onPress={onType} />
            </View>
          ) : null}
        </View>
        <GhostButton label={dismissLabel ?? t.scanAnother} onPress={onDismiss} />
      </View>
    </View>
  );
}

/** The full-screen version, for a product link nobody can resolve. */
export function RealNotFoundScreen(props: { code: string; progress: Progress; unreachable: SourceKey[]; reduced: boolean; onRetry: () => void }) {
  const t = useT(strings);
  const { c } = useTheme();
  const insets = useSafeAreaInsets();
  return (
    <View style={{ flex: 1, backgroundColor: c.bg, alignItems: 'center' }}>
      <ScrollView
        style={{ flex: 1, width: '100%', maxWidth: 480 }}
        contentContainerStyle={{ paddingTop: insets.top + space.xxl, paddingBottom: insets.bottom + space.xl, paddingHorizontal: space.xl }}
      >
        <RealNotFoundBody
          {...props}
          onPick={(pick) => router.replace({ pathname: '/product/[ean]', params: { ean: pick, from: props.code } })}
          onType={() => router.replace('/scan?keypad=1')}
          onDismiss={() => router.replace('/scan')}
        />
        <View style={{ marginTop: space.xs }}>
          <GhostButton label={t.goHome} icon="house" onPress={() => router.replace('/')} />
        </View>
      </ScrollView>
    </View>
  );
}
