// Small shared pieces for real products: the photo (with the drawn pack as fallback), Nutri-Score,
// skeleton blocks while something loads, and an external link line.

import { useEffect, useState } from 'react';
import { Image, Linking, View, type StyleProp, type ViewStyle } from 'react-native';
import Animated, { cancelAnimation, useAnimatedStyle, useSharedValue, withRepeat, withSequence, withTiming } from 'react-native-reanimated';

import type { PackArt as Art } from '@/data/types';
import { font, radius, space } from '@/theme/tokens';
import { Icon, PackArt, PressableScale, Txt, useTheme } from '@/ui';

/** The product photo from the open database, on a white card. Falls back to the drawn pack. */
export function ProductPhoto({ uri, art, size, label }: { uri?: string; art: Art; size: number; label: string }) {
  const [failed, setFailed] = useState<string | null>(null);
  if (!uri || failed === uri) return <PackArt art={art} size={size} />;
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: Math.max(14, size * 0.12),
        backgroundColor: '#FFFFFF',
        padding: Math.round(size * 0.07),
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
      }}
    >
      <Image
        source={{ uri }}
        style={{ width: '100%', height: '100%' }}
        resizeMode="contain"
        accessibilityLabel={label}
        onError={() => setFailed(uri)}
      />
    </View>
  );
}

const NUTRI = { a: '#038141', b: '#85BB2F', c: '#FECB02', d: '#EE8100', e: '#E63E11' } as const;
type Grade = keyof typeof NUTRI;

/** The five-letter Nutri-Score strip with the product's grade lifted. */
export function NutriScore({ grade, small }: { grade: Grade; small?: boolean }) {
  const h = small ? 20 : 30;
  const w = small ? 16 : 24;
  return (
    <View
      style={{ flexDirection: 'row', alignItems: 'center', gap: small ? 1 : 2 }}
      accessible
      accessibilityLabel={`Nutri-Score ${grade.toUpperCase()}`}
    >
      {(Object.keys(NUTRI) as Grade[]).map((g) => {
        const on = g === grade;
        return (
          <View
            key={g}
            style={{
              width: on ? w * 1.35 : w,
              height: on ? h * 1.3 : h,
              borderRadius: on ? (small ? 6 : 9) : small ? 4 : 6,
              backgroundColor: NUTRI[g],
              opacity: on ? 1 : 0.35,
              alignItems: 'center',
              justifyContent: 'center',
              borderWidth: on ? 2 : 0,
              borderColor: '#FFFFFF',
            }}
          >
            <Txt
              style={{ fontFamily: font.display, fontSize: on ? (small ? 13 : 19) : small ? 9 : 13, lineHeight: on ? (small ? 16 : 23) : small ? 12 : 16 }}
              color={g === 'c' ? '#3A3000' : '#FFFFFF'}
            >
              {g.toUpperCase()}
            </Txt>
          </View>
        );
      })}
    </View>
  );
}

/** A grey block that breathes while its data loads. */
export function Skeleton({ width, height = 12, style, reduced }: { width: number | `${number}%`; height?: number; style?: StyleProp<ViewStyle>; reduced?: boolean }) {
  const { c, isDark } = useTheme();
  const p = useSharedValue(0.55);
  useEffect(() => {
    if (reduced) return;
    p.set(withRepeat(withSequence(withTiming(1, { duration: 650 }), withTiming(0.55, { duration: 650 })), -1));
    return () => cancelAnimation(p);
  }, [p, reduced]);
  const anim = useAnimatedStyle(() => ({ opacity: p.get() }));
  return (
    <Animated.View
      style={[{ width, height, borderRadius: Math.min(8, height / 2), backgroundColor: isDark ? 'rgba(255,255,255,0.09)' : c.bgAlt }, style, anim]}
    />
  );
}

/** A few skeleton lines inside a card-like box. */
export function SkeletonRows({ rows = 3, reduced }: { rows?: number; reduced?: boolean }) {
  return (
    <View style={{ gap: space.md }}>
      {Array.from({ length: rows }, (_, i) => (
        <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
          <Skeleton width="38%" height={14} reduced={reduced} />
          <View style={{ flex: 1 }} />
          <Skeleton width={64} height={14} reduced={reduced} />
        </View>
      ))}
    </View>
  );
}

/** An underlined link that opens outside the app. */
export function ExtLink({ label, url, a11y, icon = 'arrow-right' }: { label: string; url: string; a11y?: string; icon?: string }) {
  const { c } = useTheme();
  return (
    <PressableScale
      onPress={() => void Linking.openURL(url)}
      accessibilityRole="link"
      accessibilityLabel={a11y ?? label}
      hitSlop={8}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
    >
      <Txt variant="small" muted style={{ textDecorationLine: 'underline' }}>
        {label}
      </Txt>
      <Icon name={icon} size={13} color={c.textMuted} />
    </PressableScale>
  );
}

/** A small rounded tag. */
export function Tag({ label, bg, fg }: { label: string; bg: string; fg: string }) {
  return (
    <View style={{ paddingHorizontal: 7, paddingVertical: 2, borderRadius: radius.pill, backgroundColor: bg }}>
      <Txt variant="tiny" color={fg}>
        {label}
      </Txt>
    </View>
  );
}
