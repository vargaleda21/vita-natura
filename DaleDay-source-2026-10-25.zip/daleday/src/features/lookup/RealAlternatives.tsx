// Better choices for a real product: Open Food Facts products from the same shelf, without what you
// avoid and with a better Nutri-Score (or NOVA group). Never mixed with the demo products.

import { View } from 'react-native';

import type { Alternative } from '@/data/types';
import { Alternatives } from '@/features/product/Alternatives';
import { useT } from '@/i18n';
import { radius, space } from '@/theme/tokens';
import { Card, Icon, PressableScale, Txt, useTheme } from '@/ui';
import { Skeleton } from './bits';
import type { AlternativesView } from './hooks';
import { strings } from './strings';

function LoadingCards({ reduced }: { reduced: boolean }) {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  return (
    <View style={{ gap: space.md }}>
      <View style={{ flexDirection: 'row', gap: 12 }}>
        {[0, 1].map((i) => (
          <View key={i} style={{ flex: 1, borderRadius: radius.xl, backgroundColor: c.surface, borderWidth: isDark ? 1 : 0, borderColor: c.border, overflow: 'hidden' }}>
            <Skeleton width="100%" height={120} reduced={reduced} style={{ borderRadius: 0 }} />
            <View style={{ padding: space.md, gap: 8 }}>
              <Skeleton width="85%" height={14} reduced={reduced} />
              <Skeleton width="55%" height={12} reduced={reduced} />
              <Skeleton width="70%" height={12} reduced={reduced} />
            </View>
          </View>
        ))}
      </View>
      <Txt variant="small" muted center>
        {t.altLoading}
      </Txt>
    </View>
  );
}

export function RealAlternatives({ view, onSwap, reduced }: { view: AlternativesView; onSwap: (alt: Alternative) => void; reduced: boolean }) {
  const t = useT(strings);
  const { c, isDark } = useTheme();

  if (view.loading) return <LoadingCards reduced={reduced} />;

  if (view.alternatives.length === 0) {
    return (
      <Card style={{ gap: space.md }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
          <View
            style={{ width: 46, height: 46, borderRadius: 16, backgroundColor: isDark ? c.surfaceAlt : c.bgAlt, alignItems: 'center', justifyContent: 'center' }}
          >
            <Icon name={view.failed ? 'circle-alert' : 'leaf'} size={22} color={c.textMuted} />
          </View>
          <View style={{ flex: 1 }}>
            <Txt variant="h3">{view.failed ? t.altFailed : view.unchecked ? t.altUnchecked : t.altNone}</Txt>
            {view.failed ? null : (
              <Txt variant="small" muted>
                {view.unchecked ? t.altUncheckedBody : t.altNoneBody}
              </Txt>
            )}
          </View>
        </View>
        {view.failed ? (
          <PressableScale
            onPress={view.retry}
            accessibilityRole="button"
            accessibilityLabel={t.altRetry}
            style={{
              alignSelf: 'flex-start',
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              paddingHorizontal: space.lg,
              minHeight: 40,
              borderRadius: radius.pill,
              borderWidth: 1,
              borderColor: c.border,
            }}
          >
            <Icon name="refresh-cw" size={15} color={c.text} />
            <Txt variant="bodyStrong">{t.altRetry}</Txt>
          </PressableScale>
        ) : null}
      </Card>
    );
  }

  return <Alternatives alternatives={view.alternatives} onSwap={onSwap} real />;
}
