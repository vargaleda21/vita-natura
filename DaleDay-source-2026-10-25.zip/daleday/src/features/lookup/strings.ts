// Texts for real products looked up by barcode (scanner checklist, product page, not-found).
// Hungarian first. Informal "te", „…” quotes, spaced en dash, decimal comma, no-break spaces before units.

import type { SourceKey, SourceStatus } from '@/data/api';

const NB = ' ';

type Strings = {
  // Scanner
  checking: string;
  checkingSub: string;
  source: Record<SourceKey, { name: string; sub: string }>;
  status: Record<SourceStatus, string>;
  cancel: string;
  foundReal: string;

  // Not found
  nfEyebrow: string;
  nfTitle: string;
  nfBody: string;
  nfOfflineTitle: string;
  nfOfflineBody: string;
  nfPartial: (names: string) => string;
  nfTried: string;
  tryAgain: string;
  typeCode: string;
  addToOff: string;
  scanAnother: string;
  goHome: string;
  invalidTitle: string;
  invalidBody: string;
  loading: string;

  // Verdict
  noVerdictTitle: string;
  noVerdictNotFoodTitle: string;
  noVerdictNoIngredients: string;
  noVerdictNotFood: string;
  noVerdictHint: string;
  partHeadline: string;
  partSub: (what: string) => string;
  unknownLine: (n: number) => string;
  unsure: string;
  mayContain: string;
  traceNote: string;

  // Ingredients and nutrition
  noIngredients: string;
  completeOnOff: string;
  declaredAllergens: string;
  traces: string;
  noNutrition: string;
  unknownValue: string;
  novaUnknown: string;
  nutriScore: string;
  nutriScoreNote: string;

  // Where it is sold
  whereTitle: string;
  whereSub: string;
  arTitle: string;
  arNote: string;
  arNone: string;
  arError: string;
  onOffer: string;
  regular: (price: string) => string;
  sameEverywhere: string;
  upTo: (price: string) => string;
  shops: (n: number) => string;
  perUnit: (price: string, unit: string) => string;
  opTitle: string;
  opNote: string;
  opNone: string;
  opError: string;
  opDiscounted: string;
  offTitle: string;
  offCountries: string;
  offStores: string;
  searchTitle: string;
  searchNote: string;
  searchOn: (site: string) => string;
  refreshing: string;
  checkedAt: (when: string) => string;

  // Alternatives
  altLoading: string;
  altNone: string;
  altNoneBody: string;
  altFailed: string;
  altUnchecked: string;
  altUncheckedBody: string;
  altRetry: string;
  altSource: string;
  altChain: (chain: string, price: string) => string;
  altSaving: (chain: string, amount: string) => string;
  altHungary: string;
  altOpen: (name: string) => string;

  // Sources and attribution
  openDataTitle: string;
  openDataBody: string;
  sourcesTitle: string;
  attrOff: string;
  attrAr: string;
  attrOp: string;
  attrUpc: string;
  sourceNames: Record<'off' | 'obf' | 'opf' | 'opff' | 'arfigyelo' | 'open_prices' | 'upcitemdb', string>;
  gs1Country: (country: string) => string;
  gs1Instore: string;
  gs1Coupon: string;
  gs1Book: string;
  gs1Note: string;
  fetched: (date: string) => string;
  photoAlt: (name: string) => string;
  descriptionTitle: string;

  // A found product without a usable name
  nameMissing: (db: string) => string;
  nameMissingBare: (db: string) => string;
  nameForeign: (original: string, category: boolean) => string;
  namePhoto: (db: string) => string;

  // Name or ingredients read off a photo of the pack (Open Food Facts' text recognition)
  photoTitle: string;
  photoBody: string;
  photoOpen: string;
  scoreFromPhoto: string;

  // The likely maker of an unknown code (its company prefix)
  makerLoading: string;
  makerEyebrow: string;
  makerTitle: (brand: string) => string;
  makerBody: (count: number, atLeast: boolean, prefix: string, branded: number) => string;
  makerAsk: string;
  makerPlaceholder: string;
  makerTop: string;
  makerNone: (q: string) => string;
  makerNote: string;
  makerOpen: (name: string) => string;
  similarTitle: string;
  similarBody: (code: string) => string;
};

const hu: Strings = {
  checking: 'Keresem a nyílt adatbázisokban…',
  checkingSub: 'Csak azt mutatjuk, amit a források tényleg tudnak.',
  source: {
    off: { name: 'Open Food Facts', sub: 'élelmiszerek, összetevők' },
    sisters: { name: 'Testvér-adatbázisok', sub: 'kozmetikum, háztartás, állateledel' },
    arfigyelo: { name: 'GVH Árfigyelő', sub: 'hivatalos bolti árak' },
    open_prices: { name: 'Open Prices', sub: 'vásárlók által beküldött árak' },
    upcitemdb: { name: 'UPCitemdb', sub: 'végső esetben' },
  },
  status: {
    waiting: 'vár',
    checking: 'keresem…',
    found: 'megvan',
    none: 'nincs benne',
    skipped: 'nem kellett',
    error: 'nem válaszolt',
  },
  cancel: 'Mégse',
  foundReal: 'Megtaláltuk!',

  nfEyebrow: 'Nem találtuk',
  nfTitle: 'Ezt a kódot még egyik nyílt adatbázis sem ismeri',
  nfBody:
    'Nem találunk ki semmit: amit nem tudunk, azt nem mutatjuk. Ha kéznél van a termék, felveheted az Open Food Factsbe, és utána mindenki látja.',
  nfOfflineTitle: 'Most nem érjük el az adatbázisokat',
  nfOfflineBody: 'Lehet, hogy nincs internet, vagy lassan válaszolnak. Próbáld újra egy kicsit később.',
  nfPartial: (names) => `Nem válaszolt: ${names}. Lehet, hogy ott megvan, érdemes újra megnézni.`,
  nfTried: 'Itt kerestük',
  tryAgain: 'Újra megnézem',
  typeCode: 'Beírom a kódot',
  addToOff: 'Felveszem az Open Food Factsbe',
  scanAnother: 'Inkább mást szkennelek',
  goHome: 'Vissza a főoldalra',
  invalidTitle: 'Ez nem érvényes vonalkód',
  invalidBody: 'A számjegyek nem adnak ki egy valódi EAN- vagy UPC-kódot. Szkenneld be újra, vagy írd be kézzel.',
  loading: 'Keresem a terméket…',

  noVerdictTitle: 'Ehhez nincs elég adat',
  noVerdictNotFoodTitle: 'Ezt nem pontozzuk',
  noVerdictNoIngredients: 'A források nem sorolják fel az összetevőit, ezért nem tudjuk összevetni azzal, amit kerülsz.',
  noVerdictNotFood: 'Ez nem élelmiszer, ezért nem vetjük össze az étkezési beállításaiddal.',
  noVerdictHint: 'Nézd meg a csomagolást, vagy egészítsd ki az adatait az Open Food Factsben.',
  partHeadline: 'Részben tudjuk ellenőrizni',
  partSub: (what) => `Amit látunk, abban nincs, amit kerülsz. Erről viszont nincs adat: ${what}.`,
  unknownLine: (n) => `${n} nem ellenőrizhető`,
  unsure: 'Nem derül ki',
  mayContain: 'Nyomokban tartalmazhat:',
  traceNote: 'Csak „nyomokban tartalmazhat” – nem összetevő, de jelezzük, mert kerülöd.',

  noIngredients: 'Egyik forrás sem sorolja fel az összetevőit.',
  completeOnOff: 'Kiegészítem az Open Food Factsben',
  declaredAllergens: 'Allergének a forrás szerint',
  traces: 'Nyomokban tartalmazhat',
  noNutrition: 'Egyik forrás sem adja meg a tápértékét.',
  unknownValue: '—',
  novaUnknown: 'Nincs adat',
  nutriScore: 'Nutri-Score',
  nutriScoreNote: 'Az Open Food Facts számítása, A a legjobb, E a leggyengébb.',

  whereTitle: 'Hol kapható?',
  whereSub: 'Valódi árak, ahol vannak. Ami nem ismert, azt nem mutatjuk.',
  arTitle: 'Bolti árak – GVH Árfigyelő',
  arNote: 'A láncok által a GVH-nak jelentett hivatalos árak.',
  arNone: 'Az Árfigyelőben nem szerepel.',
  arError: 'Az Árfigyelő most nem válaszolt.',
  onOffer: 'akciós',
  regular: (price) => `rendes ár: ${price}`,
  sameEverywhere: 'minden boltban ugyanennyi',
  upTo: (price) => `boltonként legfeljebb ${price}`,
  shops: (n) => `${n}${NB}boltban`,
  perUnit: (price, unit) => `${price}/${unit}`,
  opTitle: 'Vásárlók által látott árak – Open Prices',
  opNote: 'Fotóval beküldött árak, a legfrissebb elöl.',
  opNone: 'Még senki nem küldött be hozzá árat.',
  opError: 'Az Open Prices most nem válaszolt.',
  opDiscounted: 'akciós',
  offTitle: 'Az Open Food Facts szerint',
  offCountries: 'Ezekben az országokban látták',
  offStores: 'Ezekben a boltokban látták',
  searchTitle: 'Keress rá',
  searchNote: 'Ezek csak keresések: nem jelentik, hogy ott biztosan kapható.',
  searchOn: (site) => `Keresés: ${site}`,
  refreshing: 'Frissítem az árakat…',
  checkedAt: (when) => `Lekérdezve: ${when}`,

  altLoading: 'Keresek hasonlót ugyanazon a polcon…',
  altNone: 'Most nem találtunk jobbat',
  altNoneBody: 'Ugyanebben a kategóriában nem volt olyan, amiben nincs, amit kerülsz, és legalább ilyen jó a Nutri-Score-ja.',
  altFailed: 'Az Open Food Facts keresője most nem válaszolt.',
  altUnchecked: 'Most nem tudtuk ellenőrizni a többit',
  altUncheckedBody: 'Találtunk termékeket ugyanebben a kategóriában, de összetevőlista nélkül, így nem mondhatjuk róluk, hogy nincs bennük, amit kerülsz.',
  altRetry: 'Újrapróbálom',
  altSource: 'Open Food Facts-termékek ugyanebben a kategóriában. Csak valódi termékek, a sorrendet nem befolyásolja senki.',
  altChain: (chain, price) => `${chain}: ${price}`,
  altSaving: (chain, amount) => `Ugyanott olcsóbb: ${chain}, ${amount}-tal`,
  altHungary: 'Itthon is kapható',
  altOpen: (name) => `Megnyitom: ${name}`,

  openDataTitle: 'Nyílt adatbázisokból',
  openDataBody: 'A vonalkód alapján kerestük ki. Amit egyik forrás sem tud, azt üresen hagyjuk, nem találjuk ki.',
  sourcesTitle: 'Források',
  attrOff: 'Open Food Facts közreműködői (ODbL; képek: CC BY-SA)',
  attrAr: 'GVH Árfigyelő',
  attrOp: 'Open Prices (ODbL)',
  attrUpc: 'UPCitemdb',
  sourceNames: {
    off: 'Open Food Facts',
    obf: 'Open Beauty Facts',
    opf: 'Open Products Facts',
    opff: 'Open Pet Food Facts',
    arfigyelo: 'GVH Árfigyelő',
    open_prices: 'Open Prices',
    upcitemdb: 'UPCitemdb',
  },
  gs1Country: (country) => `A vonalkódot ${country} regisztrálták.`,
  gs1Instore: 'Bolti belső kód: nem egyedi termékazonosító.',
  gs1Coupon: 'Kupon- vagy utalványkód.',
  gs1Book: 'Könyv vagy időszaki kiadvány kódja.',
  gs1Note: 'Ez nem a gyártás helye.',
  fetched: (date) => `Lekérdezve: ${date}`,
  photoAlt: (name) => `${name} – fotó az Open Food Factsből`,
  descriptionTitle: 'Leírás',

  // Every database's name ends in "Facts": "az Open Food Factsbe", "az Open Beauty Factsbe" …
  nameMissing: (db) => `A nevét még senki nem írta be az ${db}be, ezért a kategóriáját mutatjuk.`,
  nameMissingBare: (db) => `A nevét még senki nem írta be az ${db}be.`,
  nameForeign: (original, category) =>
    `Az adatbázisban csak más írásrendszerrel (pl. cirill betűkkel) szerepel a neve: „${original}”${category ? ', ezért a kategóriáját mutatjuk' : ''}.`,
  namePhoto: (db) =>
    `A nevét még senki nem írta be az ${db}be, ezért a csomagolás fotójáról olvastuk ki, gépi szövegfelismeréssel. Lehet benne hiba.`,

  photoTitle: 'Gépi olvasás a fotóról',
  photoBody:
    'Az összetevőit még senki nem gépelte be, ezért a csomagolás fotójáról olvastuk ki, szövegfelismeréssel. Egy-egy szó hibás lehet vagy hiányozhat: ha allergiás vagy, nézd meg a csomagoláson is.',
  photoOpen: 'A fotó megnyitása',
  scoreFromPhoto: 'Az összetevőket gépi olvasással vettük a csomagolás fotójáról.',

  makerLoading: 'A vonalkód eleje alapján keressük a gyártót…',
  makerEyebrow: 'A vonalkód eleje alapján',
  makerTitle: (brand) => `Valószínű márka: ${brand}`,
  makerBody: (count, atLeast, prefix, branded) =>
    `Az Open Food Facts ${atLeast ? 'legalább ' : ''}${count} olyan terméket ismer, amelynek a kódja ugyanígy kezdődik (${prefix}…), és közülük legalább ${branded} ennek a márkának a terméke.`,
  makerAsk: 'Melyik termékük van a kezedben?',
  makerPlaceholder: 'pl. majonéz',
  makerTop: 'A legtöbbször beolvasott termékeik',
  makerNone: (q) => `Erre nincs találat a termékeik között: „${q}”.`,
  makerNote: 'Amit itt választasz, annak más a vonalkódja, ezért az összetétele eltérhet attól, ami a kezedben van.',
  makerOpen: (name) => `${name} megnyitása`,
  similarTitle: 'Hasonló terméket nézel',
  similarBody: (code) =>
    `A beolvasott kódot (${code}) egyik adatbázis sem ismeri. Ez valószínűleg ugyanattól a cégtől származik, de más a vonalkódja, ezért az összetétele eltérhet.`,
};

const en: Strings = {
  checking: 'Looking it up in open databases…',
  checkingSub: 'We only show what the sources really know.',
  source: {
    off: { name: 'Open Food Facts', sub: 'food and ingredients' },
    sisters: { name: 'Sister databases', sub: 'beauty, household, pet food' },
    arfigyelo: { name: 'GVH Árfigyelő', sub: 'official shop prices' },
    open_prices: { name: 'Open Prices', sub: 'prices shared by shoppers' },
    upcitemdb: { name: 'UPCitemdb', sub: 'last resort' },
  },
  status: {
    waiting: 'waiting',
    checking: 'checking…',
    found: 'found',
    none: 'not listed',
    skipped: 'not needed',
    error: 'no answer',
  },
  cancel: 'Cancel',
  foundReal: 'Found it!',

  nfEyebrow: 'Not found',
  nfTitle: 'No open database knows this code yet',
  nfBody:
    'We don’t make anything up: what we don’t know, we don’t show. If you have the product to hand, you can add it to Open Food Facts, and then everyone can see it.',
  nfOfflineTitle: 'We can’t reach the databases right now',
  nfOfflineBody: 'You may be offline, or they are slow to answer. Try again in a little while.',
  nfPartial: (names) => `No answer from ${names}. It may be listed there, so it’s worth another try.`,
  nfTried: 'Where we looked',
  tryAgain: 'Try again',
  typeCode: 'Type the code',
  addToOff: 'Add it to Open Food Facts',
  scanAnother: 'Scan something else',
  goHome: 'Back to home',
  invalidTitle: 'This isn’t a valid barcode',
  invalidBody: 'The digits don’t make a real EAN or UPC code. Scan it again, or type it in.',
  loading: 'Looking the product up…',

  noVerdictTitle: 'Not enough data to judge',
  noVerdictNotFoodTitle: 'We don’t score this',
  noVerdictNoIngredients: 'The sources don’t list its ingredients, so we can’t check it against what you avoid.',
  noVerdictNotFood: 'This isn’t food, so we don’t check it against your food settings.',
  noVerdictHint: 'Check the pack, or help complete it on Open Food Facts.',
  partHeadline: 'We can only check part of it',
  partSub: (what) => `Nothing you avoid in what we can see. But no source has data on: ${what}.`,
  unknownLine: (n) => `${n} can’t be checked`,
  unsure: 'Can’t tell',
  mayContain: 'May contain:',
  traceNote: 'Only “may contain” – not an ingredient, but we flag it because you avoid it.',

  noIngredients: 'No source lists its ingredients.',
  completeOnOff: 'Complete it on Open Food Facts',
  declaredAllergens: 'Allergens, as the source declares them',
  traces: 'May contain',
  noNutrition: 'No source gives its nutrition values.',
  unknownValue: '—',
  novaUnknown: 'No data',
  nutriScore: 'Nutri-Score',
  nutriScoreNote: 'Worked out by Open Food Facts: A is best, E is weakest.',

  whereTitle: 'Where is it sold?',
  whereSub: 'Real prices where they exist. What isn’t known isn’t shown.',
  arTitle: 'Shop prices – GVH Árfigyelő',
  arNote: 'Official prices the chains report to the GVH.',
  arNone: 'Not listed in the Árfigyelő.',
  arError: 'The Árfigyelő didn’t answer just now.',
  onOffer: 'on offer',
  regular: (price) => `regular price ${price}`,
  sameEverywhere: 'same price in every shop',
  upTo: (price) => `up to ${price}, by shop`,
  shops: (n) => (n === 1 ? `in 1${NB}shop` : `in ${n}${NB}shops`),
  perUnit: (price, unit) => `${price}/${unit}`,
  opTitle: 'Prices seen by shoppers – Open Prices',
  opNote: 'Prices shared with a photo, newest first.',
  opNone: 'Nobody has shared a price for it yet.',
  opError: 'Open Prices didn’t answer just now.',
  opDiscounted: 'on offer',
  offTitle: 'According to Open Food Facts',
  offCountries: 'Seen in these countries',
  offStores: 'Seen in these shops',
  searchTitle: 'Search for it',
  searchNote: 'These are only searches: they don’t mean it’s sold there.',
  searchOn: (site) => `Search: ${site}`,
  refreshing: 'Refreshing the prices…',
  checkedAt: (when) => `Checked: ${when}`,

  altLoading: 'Looking for something similar on the same shelf…',
  altNone: 'Nothing better right now',
  altNoneBody: 'Nothing in the same category was free of what you avoid with a Nutri-Score at least as good.',
  altFailed: 'The Open Food Facts search didn’t answer just now.',
  altUnchecked: 'We couldn’t check the others just now',
  altUncheckedBody: 'The search found products in the same category, but without ingredient lists, so we can’t say they’re free of what you avoid.',
  altRetry: 'Try again',
  altSource: 'Open Food Facts products in the same category. Real products only, and nobody pays to change the order.',
  altChain: (chain, price) => `${chain}: ${price}`,
  altSaving: (chain, amount) => `${amount} cheaper at ${chain}`,
  altHungary: 'Sold in Hungary',
  altOpen: (name) => `Open ${name}`,

  openDataTitle: 'From open databases',
  openDataBody: 'Looked up by its barcode. What no source knows, we leave blank – we never make it up.',
  sourcesTitle: 'Sources',
  attrOff: 'Open Food Facts contributors (ODbL; images CC BY-SA)',
  attrAr: 'GVH Árfigyelő',
  attrOp: 'Open Prices (ODbL)',
  attrUpc: 'UPCitemdb',
  sourceNames: {
    off: 'Open Food Facts',
    obf: 'Open Beauty Facts',
    opf: 'Open Products Facts',
    opff: 'Open Pet Food Facts',
    arfigyelo: 'GVH Árfigyelő',
    open_prices: 'Open Prices',
    upcitemdb: 'UPCitemdb',
  },
  gs1Country: (country) => `Barcode registered in ${country}.`,
  gs1Instore: 'An in-store code: not a unique product code.',
  gs1Coupon: 'A coupon or voucher code.',
  gs1Book: 'A book or periodical code.',
  gs1Note: 'Not where it was made.',
  fetched: (date) => `Checked: ${date}`,
  photoAlt: (name) => `${name} – photo from Open Food Facts`,
  descriptionTitle: 'Description',

  nameMissing: (db) => `Nobody has entered its name in ${db} yet, so we show its category.`,
  nameMissingBare: (db) => `Nobody has entered its name in ${db} yet.`,
  nameForeign: (original, category) =>
    `The database has its name only in another script (such as Cyrillic): “${original}”${category ? ', so we show its category' : ''}.`,
  namePhoto: (db) => `Nobody has entered its name in ${db} yet, so we read it off the photo of the pack with text recognition. It may contain mistakes.`,

  photoTitle: 'Machine-read from a photo',
  photoBody:
    'Nobody has typed in its ingredients yet, so we read them off the photo of the pack with text recognition. A word may be misread or missing: if you have an allergy, check the pack too.',
  photoOpen: 'Open the photo',
  scoreFromPhoto: 'The ingredients were machine-read from a photo of the pack.',

  makerLoading: 'Looking for the maker from the start of the barcode…',
  makerEyebrow: 'From the start of the barcode',
  makerTitle: (brand) => `Likely brand: ${brand}`,
  makerBody: (count, atLeast, prefix, branded) =>
    `Open Food Facts knows ${atLeast ? 'at least ' : ''}${count} products whose barcode starts the same way (${prefix}…), and at least ${branded} of them are from this brand.`,
  makerAsk: 'Which of their products are you holding?',
  makerPlaceholder: 'e.g. mayonnaise',
  makerTop: 'Their most scanned products',
  makerNone: (q) => `None of their products matches “${q}”.`,
  makerNote: 'What you pick here has a different barcode, so its recipe may differ from the one in your hand.',
  makerOpen: (name) => `Open ${name}`,
  similarTitle: 'You are looking at a similar product',
  similarBody: (code) =>
    `No database knows the code you scanned (${code}). This product is probably from the same company, but it has another barcode, so its recipe may differ.`,
};

export const strings = { hu, en };
export type LookupStrings = Strings;
