// "Where is it sold?" for a real product, in a fixed order:
//  1. the chains' official prices from the GVH Árfigyelő (lowest first),
//  2. prices shoppers shared on Open Prices (newest first),
//  3. the countries and shops Open Food Facts contributors saw it in,
//  4. search links, labelled as searches: they never claim the product is sold there.

import { View } from 'react-native';

import { countryFromIso } from '@/data/api';
import type { Product } from '@/data/types';
import { fullDate } from '@/features/product/format';
import { formatHuf, useLang, useT, useTr } from '@/i18n';
import { font, palette, radius, space } from '@/theme/tokens';
import { Card, Icon, PressableScale, Txt, useTheme } from '@/ui';
import { ExtLink, SkeletonRows, Tag } from './bits';
import { fetchedAt, flag, money, searchQuery } from './format';
import { useRealPrices } from './hooks';
import { strings } from './strings';

const AR_URL = 'https://arfigyelo.gvh.hu/';
const OP_URL = (ean: string) => `https://prices.openfoodfacts.org/products/${ean}`;

function Head({ icon, title, note }: { icon: string; title: string; note?: string }) {
  const { c } = useTheme();
  return (
    <View style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-start' }}>
      <View style={{ marginTop: 2 }}>
        <Icon name={icon} size={17} color={c.textMuted} />
      </View>
      <View style={{ flex: 1 }}>
        <Txt variant="bodyStrong">{title}</Txt>
        {note ? (
          <Txt variant="small" muted>
            {note}
          </Txt>
        ) : null}
      </View>
    </View>
  );
}

function Retry({ label, onPress }: { label: string; onPress: () => void }) {
  const { c } = useTheme();
  return (
    <PressableScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={8}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        alignSelf: 'flex-start',
        paddingVertical: 4,
      }}
    >
      <Icon name="refresh-cw" size={14} color={c.textMuted} />
      <Txt variant="small" muted style={{ textDecorationLine: 'underline' }}>
        {label}
      </Txt>
    </PressableScale>
  );
}

function ChainPrices({ product, reduced }: { product: Product; reduced: boolean }) {
  const t = useT(strings);
  const lang = useLang();
  const { c, isDark } = useTheme();
  const { prices, arLoading, refresh } = useRealPrices(product);
  const ar = prices?.arfigyelo;
  const when = fetchedAt(prices?.arfigyeloAt, lang, fullDate);

  let body;
  if (ar === undefined) {
    body = arLoading ? (
      <SkeletonRows rows={3} reduced={reduced} />
    ) : (
      <View style={{ gap: 4 }}>
        <Txt variant="small" muted>
          {t.arError}
        </Txt>
        <Retry label={t.altRetry} onPress={refresh} />
      </View>
    );
  } else if (ar === null || ar.chains.length === 0) {
    body = (
      <Txt variant="small" muted>
        {t.arNone}
      </Txt>
    );
  } else {
    body = (
      <View style={{ gap: 2 }}>
        {ar.chains.map((ch, i) => (
          <View
            key={ch.chain}
            style={{
              flexDirection: 'row',
              alignItems: 'flex-start',
              gap: space.md,
              paddingVertical: 10,
              borderTopWidth: i === 0 ? 0 : 1,
              borderTopColor: c.border,
            }}
          >
            <View style={{ flex: 1, gap: 2 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                <Txt variant="bodyStrong">{ch.chain}</Txt>
                {ch.discounted ? <Tag label={t.onOffer} bg={palette.sun} fg={palette.ink} /> : null}
              </View>
              <Txt variant="small" muted>
                {[
                  ch.sameEverywhere ? t.sameEverywhere : ch.maxHuf ? t.upTo(formatHuf(ch.maxHuf, lang)) : null,
                  ch.shops > 0 ? t.shops(ch.shops) : null,
                ]
                  .filter(Boolean)
                  .join(' · ')}
              </Txt>
              {ch.discounted && ch.regularHuf ? (
                <Txt variant="small" faint>
                  {t.regular(formatHuf(ch.regularHuf, lang))}
                </Txt>
              ) : null}
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Txt
                variant="h3"
                style={{ fontFamily: font.displayBold }}
                color={i === 0 ? (isDark ? palette.lime : palette.forest) : undefined}
              >
                {formatHuf(ch.priceHuf, lang)}
              </Txt>
              {ch.unitPriceHuf && ch.unit ? (
                <Txt variant="tiny" muted>
                  {t.perUnit(formatHuf(ch.unitPriceHuf, lang), ch.unit)}
                </Txt>
              ) : null}
            </View>
          </View>
        ))}
      </View>
    );
  }

  return (
    <Card style={{ gap: space.md }}>
      <Head icon="store" title={t.arTitle} note={t.arNote} />
      {body}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md, flexWrap: 'wrap' }}>
        <ExtLink label={t.attrAr} url={AR_URL} />
        {when && ar !== undefined ? (
          <Txt variant="tiny" faint>
            {arLoading ? t.refreshing : t.checkedAt(when)}
          </Txt>
        ) : null}
      </View>
    </Card>
  );
}

function Sightings({ product, reduced }: { product: Product; reduced: boolean }) {
  const t = useT(strings);
  const tr = useTr();
  const lang = useLang();
  const { c } = useTheme();
  const { prices, opLoading, refresh } = useRealPrices(product);
  const op = prices?.openPrices;

  let body;
  if (op === undefined) {
    body = opLoading ? (
      <SkeletonRows rows={2} reduced={reduced} />
    ) : (
      <View style={{ gap: 4 }}>
        <Txt variant="small" muted>
          {t.opError}
        </Txt>
        <Retry label={t.altRetry} onPress={refresh} />
      </View>
    );
  } else if (op === null || op.length === 0) {
    body = (
      <Txt variant="small" muted>
        {t.opNone}
      </Txt>
    );
  } else {
    const list = [...op].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8);
    body = (
      <View>
        {list.map((s, i) => {
          const known = countryFromIso(s.iso2, s.country);
          const country = known ? tr(known.name) : undefined;
          return (
            <View
              key={`${s.date}-${s.price}-${i}`}
              style={{
                flexDirection: 'row',
                alignItems: 'flex-start',
                gap: space.md,
                paddingVertical: 10,
                borderTopWidth: i === 0 ? 0 : 1,
                borderTopColor: c.border,
              }}
            >
              <Txt style={{ fontSize: 18, lineHeight: 22 }}>{flag(s.iso2) || '🏷️'}</Txt>
              <View style={{ flex: 1, gap: 2 }}>
                <Txt variant="bodyStrong" numberOfLines={1}>
                  {[s.shop, s.city].filter(Boolean).join(', ') || country || '—'}
                </Txt>
                <Txt variant="small" muted>
                  {[fullDate(s.date, lang), s.shop && country ? country : null].filter(Boolean).join(' · ')}
                </Txt>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 2 }}>
                <Txt variant="bodyStrong">{money(s.price, s.currency, lang)}</Txt>
                {s.discounted ? <Tag label={t.opDiscounted} bg={palette.sun} fg={palette.ink} /> : null}
              </View>
            </View>
          );
        })}
      </View>
    );
  }

  return (
    <Card style={{ gap: space.md }}>
      <Head icon="coins" title={t.opTitle} note={t.opNote} />
      {body}
      <ExtLink label={t.attrOp} url={OP_URL(product.ean)} />
    </Card>
  );
}

function OffSeen({ product }: { product: Product }) {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const real = product.real;
  if (!real || (real.countries.length === 0 && real.stores.length === 0)) return null;
  const chip = (key: string, label: string) => (
    <View
      key={key}
      style={{
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: radius.pill,
        backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
      }}
    >
      <Txt variant="small">{label}</Txt>
    </View>
  );
  return (
    <Card style={{ gap: space.md }}>
      <Head icon="globe" title={t.offTitle} />
      {real.countries.length > 0 ? (
        <View style={{ gap: 6 }}>
          <Txt variant="tiny" muted upper>
            {t.offCountries}
          </Txt>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {real.countries.map((co) => chip(co.iso2 ?? co.name.en, `${flag(co.iso2)} ${tr(co.name)}`.trim()))}
          </View>
        </View>
      ) : null}
      {real.stores.length > 0 ? (
        <View style={{ gap: 6 }}>
          <Txt variant="tiny" muted upper>
            {t.offStores}
          </Txt>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>{real.stores.map((s) => chip(s, s))}</View>
        </View>
      ) : null}
      {real.sourceUrl ? <ExtLink label={t.attrOff} url={real.sourceUrl} /> : null}
    </Card>
  );
}

function Searches({ product }: { product: Product }) {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const q = encodeURIComponent(searchQuery(tr(product.name), product.brand));
  const sites = [
    { name: 'Árukereső', url: `https://www.arukereso.hu/CategorySearch.php?st=${q}` },
    { name: 'Google Shopping', url: `https://www.google.com/search?tbm=shop&q=${q}` },
    { name: 'Kifli', url: `https://www.kifli.hu/kereses?q=${q}` },
  ];
  return (
    <View
      style={{
        gap: space.sm,
        padding: space.md,
        borderRadius: radius.md,
        borderWidth: 1,
        borderColor: c.border,
        backgroundColor: isDark ? c.surfaceAlt : 'transparent',
      }}
    >
      <Head icon="shopping-basket" title={t.searchTitle} note={t.searchNote} />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.md, marginTop: 2 }}>
        {sites.map((s) => (
          <ExtLink key={s.name} label={t.searchOn(s.name)} url={s.url} />
        ))}
      </View>
    </View>
  );
}

/** The whole "Where is it sold?" block. */
export function WhereSold({ product, reduced }: { product: Product; reduced: boolean }) {
  return (
    <View style={{ gap: space.md }}>
      <ChainPrices product={product} reduced={reduced} />
      <Sightings product={product} reduced={reduced} />
      <OffSeen product={product} />
      <Searches product={product} />
    </View>
  );
}
