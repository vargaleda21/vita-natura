// React hooks over the lookup store: the product, its prices and its alternatives, kept fresh.
// Data arrives in promise callbacks (never a synchronous setState inside an effect).

import { useCallback, useEffect, useState, useSyncExternalStore } from 'react';

import {
  canonical,
  ensureChainPrices,
  fetchAlternativeCandidates,
  getProduct,
  lookupCode,
  lookupEnded,
  lookupVersion,
  pricePending,
  pricesFresh,
  realAlternativesFor,
  realPrices,
  refreshPrices,
  subscribeLookup,
  type Candidates,
  type Progress,
  type SourceKey,
} from '@/data/api';
import type { Alternative, Product, RealPrices, Settings } from '@/data/types';

/** Re-render whenever a real product or a price arrives. */
export function useLookupVersion(): number {
  return useSyncExternalStore(subscribeLookup, lookupVersion, lookupVersion);
}

function readAt<T>(_version: number, read: () => T): T {
  return read();
}

/**
 * Read the lookup store during render. The store changes outside React, so the read is tied to the
 * store's version: the React Compiler then runs it again whenever a product or a price arrives,
 * instead of keeping the first answer.
 */
export function useLookupRead<T>(read: () => T): T {
  const version = useLookupVersion();
  return readAt(version, read);
}

export type ProductState =
  | { kind: 'ready'; product: Product }
  | { kind: 'loading'; product?: Product }
  | { kind: 'not_found'; key: string; progress: Progress; unreachable: SourceKey[] }
  | { kind: 'invalid' };

type Outcome = { code: string; attempt: number } & (
  | { kind: 'not_found'; key: string; progress: Progress; unreachable: SourceKey[] }
  | { kind: 'invalid' }
  | { kind: 'done' }
);

/**
 * A product by its code: a demo product, a real one from the device cache, or a fresh lookup (a cold
 * deep link, or a light search-result copy that still needs its full data).
 */
export function useProductByCode(code: string): { state: ProductState; retry: () => void } {
  const key = canonical(code)?.key ?? code;
  const product = useLookupRead(() => getProduct(code) ?? getProduct(key));
  const needsLookup = !product || !!product.real?.preview;
  const [attempt, setAttempt] = useState(0);
  const [outcome, setOutcome] = useState<Outcome | null>(null);

  useEffect(() => {
    if (!needsLookup) return;
    // No abort: the lookup is cheap, its result is cached, and the product it brings is what turns
    // this effect off, so aborting here would also cut off the prices still loading in the background.
    let alive = true;
    void lookupCode(code, { force: attempt > 0 }).then((r) => {
      if (!alive || r.kind === 'aborted') return;
      if (r.kind === 'found') setOutcome({ code, attempt, kind: 'done' });
      else if (r.kind === 'invalid') setOutcome({ code, attempt, kind: 'invalid' });
      else setOutcome({ code, attempt, kind: 'not_found', key: r.key, progress: r.progress, unreachable: r.unreachable });
    });
    return () => {
      alive = false;
    };
  }, [code, attempt, needsLookup]);

  const retry = useCallback(() => setAttempt((a) => a + 1), []);
  const current = outcome && outcome.code === code && outcome.attempt === attempt ? outcome : null;

  if (product && !product.real?.preview) return { state: { kind: 'ready', product }, retry };
  if (current?.kind === 'invalid') return { state: { kind: 'invalid' }, retry };
  if (current?.kind === 'not_found' && !product) {
    return { state: { kind: 'not_found', key: current.key, progress: current.progress, unreachable: current.unreachable }, retry };
  }
  // A preview whose full lookup failed is still worth showing.
  if (product && current) return { state: { kind: 'ready', product }, retry };
  return { state: { kind: 'loading', product }, retry };
}

export type PriceView = {
  prices: RealPrices | undefined;
  arLoading: boolean;
  opLoading: boolean;
  refresh: () => void;
};

/** A real product's prices; anything older than an hour is fetched again in the background. */
export function useRealPrices(product: Product): PriceView {
  const ean = product.ean;
  const real = !!product.real && !product.real.preview;
  const prices = useLookupRead(() => (product.real ? realPrices(ean) : undefined));
  const arPending = useLookupRead(() => pricePending(ean, 'arfigyelo'));
  const opPending = useLookupRead(() => pricePending(ean, 'openPrices'));
  // A search-result copy is on screen while its full lookup runs: that lookup brings the prices. When it
  // has ended without them (it failed), the prices end too, as "no answer" with a retry.
  const ended = useLookupRead(() => lookupEnded(ean));
  const preview = !!product.real?.preview && !ended;
  useEffect(() => {
    if (!real) return;
    const fresh = pricesFresh(ean);
    if (fresh.arfigyelo && fresh.openPrices) return;
    if (pricePending(ean, 'arfigyelo') || pricePending(ean, 'openPrices')) return;
    void refreshPrices(ean);
  }, [ean, real]);
  return {
    prices,
    arLoading: preview || (real && arPending),
    opLoading: preview || (real && opPending),
    refresh: () => void refreshPrices(ean),
  };
}

export type AlternativesView = {
  /** False when there is nothing to compare with (not food, no category, a demo product). */
  enabled: boolean;
  loading: boolean;
  failed: boolean;
  /** The search found products in the category, but none with an ingredient list to check. */
  unchecked: boolean;
  alternatives: Alternative[];
  retry: () => void;
};

/** Better choices for a real product, from an Open Food Facts search in the same category. */
export function useRealAlternatives(product: Product, settings: Settings): AlternativesView {
  const enabled = !!product.real && !product.real.preview && product.real.kind === 'food' && product.real.categoryTags.length > 0;
  const [attempt, setAttempt] = useState(0);
  const [result, setResult] = useState<{ ean: string; attempt: number; candidates: Candidates } | null>(null);

  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    void fetchAlternativeCandidates(product).then((candidates) => {
      if (alive) setResult({ ean: product.ean, attempt, candidates });
    });
    return () => {
      alive = false;
    };
  }, [enabled, product, attempt]);

  const current = result && result.ean === product.ean && result.attempt === attempt ? result.candidates : null;
  // The chain prices inside arrive later: read through the store's version.
  const alternatives = useLookupRead(() => (current ? realAlternativesFor(product, settings, current.products) : []));
  const keys = alternatives.map((a) => a.product.ean).join(',');

  // The chains' prices for the alternatives on show (from the GVH Árfigyelő).
  useEffect(() => {
    if (!keys) return;
    void ensureChainPrices(keys.split(','));
  }, [keys]);

  return {
    enabled,
    loading: enabled && !current,
    failed: !!current?.failed,
    unchecked: !!current?.unchecked,
    alternatives,
    retry: () => setAttempt((a) => a + 1),
  };
}
