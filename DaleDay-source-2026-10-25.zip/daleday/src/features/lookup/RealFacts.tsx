// Pieces of the product page that only real products have: where the data came from (with the
// attribution each source asks for), the GS1 line, the "not enough data" verdict card, and a description.

import { View } from 'react-native';

import { CRITERIA } from '@/data/api';
import type { MatchResult, Product, RealSource } from '@/data/types';
import { fullDate } from '@/features/product/format';
import { useLang, useT, useTr } from '@/i18n';
import { radius, shadow, space } from '@/theme/tokens';
import { Card, Icon, Txt, useTheme } from '@/ui';
import { ExtLink, NutriScore } from './bits';
import { gs1Line } from './RealNotFound';
import { strings } from './strings';

export function offEditUrl(ean: string): string {
  return `https://world.openfoodfacts.org/cgi/product.pl?type=edit&code=${encodeURIComponent(ean)}`;
}

function sourceLink(src: RealSource, product: Product): string | undefined {
  switch (src) {
    case 'off':
    case 'obf':
    case 'opf':
    case 'opff':
      return product.real?.sourceUrl;
    case 'arfigyelo':
      return 'https://arfigyelo.gvh.hu/';
    case 'open_prices':
      return `https://prices.openfoodfacts.org/products/${product.ean}`;
    case 'upcitemdb':
      return `https://www.upcitemdb.com/upc/${product.ean}`;
  }
}

/** The sources that answered for this product, each linked, with the licence lines. */
export function RealSources({ product }: { product: Product }) {
  const t = useT(strings);
  const tr = useTr();
  const lang = useLang();
  const { c, isDark } = useTheme();
  const real = product.real;
  if (!real) return null;
  const gs1 = gs1Line(real.gs1, t, tr);
  const label = (s: RealSource) => (s === 'off' || s === 'obf' || s === 'opf' || s === 'opff' ? `${t.sourceNames[s]} – ${t.attrOff}` : s === 'open_prices' ? t.attrOp : t.sourceNames[s]);

  return (
    <View style={{ gap: space.sm, padding: space.md, borderRadius: radius.md, backgroundColor: isDark ? c.surfaceAlt : c.bgAlt }}>
      <Txt variant="tiny" muted upper>
        {t.sourcesTitle}
      </Txt>
      {real.sources.map((s) => {
        const url = sourceLink(s, product);
        return url ? (
          <ExtLink key={s} label={label(s)} url={url} />
        ) : (
          <Txt key={s} variant="small" muted>
            {label(s)}
          </Txt>
        );
      })}
      <Txt variant="small" faint style={{ marginTop: 4 }}>
        {t.fetched(fullDate(real.fetchedAt.slice(0, 10), lang))}
      </Txt>
      {gs1 ? (
        <View style={{ flexDirection: 'row', gap: 6, alignItems: 'flex-start' }}>
          <View style={{ marginTop: 2 }}>
            <Icon name="scan-barcode" size={14} color={c.textMuted} />
          </View>
          <Txt variant="small" muted style={{ flex: 1 }}>
            {gs1}
          </Txt>
        </View>
      ) : null}
    </View>
  );
}

/** Instead of a score when nothing on the list can be checked: no ingredients, or not food. */
export function NoVerdictCard({ product }: { product: Product }) {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const notFood = product.real && product.real.kind !== 'food' && product.real.kind !== 'petfood' && product.real.kind !== 'unknown';
  return (
    <View
      style={[
        { borderRadius: radius.xl, backgroundColor: c.surface, borderWidth: isDark ? 1 : 0, borderColor: c.border, padding: space.lg, gap: space.md },
        isDark ? null : shadow.card,
      ]}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
        <View style={{ width: 52, height: 52, borderRadius: 18, backgroundColor: isDark ? c.surfaceAlt : c.bgAlt, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="circle-question-mark" size={26} color={c.textMuted} />
        </View>
        <Txt variant="h2" accessibilityRole="header" style={{ flex: 1 }}>
          {notFood ? t.noVerdictNotFoodTitle : t.noVerdictTitle}
        </Txt>
      </View>
      <Txt variant="body" muted>
        {notFood ? t.noVerdictNotFood : t.noVerdictNoIngredients}
      </Txt>
      {!notFood ? (
        <View style={{ gap: 6 }}>
          <Txt variant="small" faint>
            {t.noVerdictHint}
          </Txt>
          <ExtLink label={t.completeOnOff} url={offEditUrl(product.ean)} />
        </View>
      ) : null}
    </View>
  );
}

/** The criteria no source lets us check, by name: "NOVA processing, salt". */
export function unknownNames(result: MatchResult, tr: (v: { hu: string; en: string }) => string): string {
  return (result.unknown ?? []).map((k) => tr(CRITERIA[k].label).toLowerCase()).join(', ');
}

/** The Nutri-Score card under the nutrition values. */
export function NutriScoreCard({ grade }: { grade: 'a' | 'b' | 'c' | 'd' | 'e' }) {
  const t = useT(strings);
  return (
    <Card style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg }}>
      <NutriScore grade={grade} />
      <View style={{ flex: 1 }}>
        <Txt variant="bodyStrong">
          {t.nutriScore} {grade.toUpperCase()}
        </Txt>
        <Txt variant="small" muted>
          {t.nutriScoreNote}
        </Txt>
      </View>
    </Card>
  );
}

/** A short description (UPCitemdb, for things that are not food). */
export function Description({ text }: { text: string }) {
  const { c } = useTheme();
  return (
    <Card style={{ gap: space.sm }}>
      <View style={{ flexDirection: 'row', gap: space.sm }}>
        <Icon name="info" size={16} color={c.textMuted} />
        <Txt variant="body" style={{ flex: 1 }}>
          {text}
        </Txt>
      </View>
    </Card>
  );
}

