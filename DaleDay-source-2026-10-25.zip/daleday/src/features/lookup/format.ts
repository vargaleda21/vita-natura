import type { Lang } from '@/data/types';
import { formatHuf } from '@/i18n';

const NB = ' ';

const SYMBOL: Record<string, string> = { EUR: '€', GBP: '£', USD: '$' };

function decimals(n: number, lang: Lang): string {
  const s = Number.isInteger(n) ? String(n) : n.toFixed(2);
  return lang === 'hu' ? s.replace('.', ',') : s;
}

/** A price in its own currency: "339 Ft" / "HUF 339", "94,90 NOK" / "NOK 94.90", "2,49 €" / "€2.49". */
export function money(amount: number, currency: string, lang: Lang): string {
  const cur = currency.toUpperCase();
  if (cur === 'HUF') return formatHuf(amount, lang);
  const sym = SYMBOL[cur];
  const n = decimals(amount, lang);
  if (lang === 'hu') return `${n}${NB}${sym ?? cur}`;
  return sym ? `${sym}${n}` : `${cur}${NB}${n}`;
}

/** 🇭🇺 from "HU". */
export function flag(iso2: string | undefined): string {
  if (!iso2 || !/^[A-Za-z]{2}$/.test(iso2)) return '';
  const base = 0x1f1e6;
  const up = iso2.toUpperCase();
  return String.fromCodePoint(base + up.charCodeAt(0) - 65, base + up.charCodeAt(1) - 65);
}

/** "14:05" today, else the date: when a price was fetched. */
export function fetchedAt(ms: number | undefined, lang: Lang, fullDate: (iso: string, lang: Lang) => string): string | undefined {
  if (!ms) return undefined;
  const d = new Date(ms);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) {
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }
  return fullDate(d.toISOString().slice(0, 10), lang);
}

/** "Magyar Tej ESL tej 2,8%" → a search query: name and brand, without the pack size. */
export function searchQuery(name: string, brand: string): string {
  const n = name.trim();
  return brand && !n.toLowerCase().includes(brand.toLowerCase()) ? `${brand} ${n}` : n;
}
