// The likely maker of a code no database knows, from the start of the barcode, and their products to
// pick the closest one from. Shown on the not-found sheet; nothing appears when the maker is unclear.

import { useEffect, useState } from 'react';
import { Image, View } from 'react-native';

import { filterMakerProducts, findMaker, makerEligible, type Maker, type MakerProduct } from '@/data/api';
import { useT, useTr } from '@/i18n';
import { Field } from '@/features/profile/Cards';
import { radius, space } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { Skeleton } from './bits';
import { strings } from './strings';

const SHOWN = 5;

export function MakerCard(props: { code: string; reduced: boolean; onPick: (code: string) => void; compact?: boolean }) {
  // Nothing to look for (an EAN-8, an in-store or coupon code): no "looking…" flash either.
  return makerEligible(props.code) ? <MakerLookup key={props.code} {...props} /> : null;
}

function MakerLookup({ code, reduced, onPick, compact }: { code: string; reduced: boolean; onPick: (code: string) => void; compact?: boolean }) {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const [found, setFound] = useState<{ code: string; maker: Maker | null } | null>(null);
  const [q, setQ] = useState('');

  useEffect(() => {
    let alive = true;
    void findMaker(code).then((maker) => {
      if (alive) setFound({ code, maker });
    });
    return () => {
      alive = false;
    };
  }, [code]);

  const current = found?.code === code ? found : null;
  if (current && !current.maker) return null;

  const box = {
    marginTop: compact ? space.md : space.lg,
    padding: space.md,
    borderRadius: radius.md,
    backgroundColor: isDark ? c.surfaceAlt : c.surface,
    borderWidth: 1,
    borderColor: c.border,
  } as const;

  if (!current) {
    return (
      <View style={box} accessibilityLiveRegion="polite">
        <Txt variant="small" muted>
          {t.makerLoading}
        </Txt>
        <View style={{ marginTop: space.sm, gap: 8 }}>
          <Skeleton width="70%" height={14} reduced={reduced} />
          <Skeleton width="45%" height={12} reduced={reduced} />
        </View>
      </View>
    );
  }

  const maker = current.maker as Maker;
  const typed = q.trim();
  const matches = filterMakerProducts(maker.products, typed);

  return (
    <View style={box}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Icon name="factory" size={15} color={c.textMuted} />
        <Txt variant="tiny" upper muted style={{ flexShrink: 1 }}>
          {t.makerEyebrow}
        </Txt>
      </View>
      <Txt variant="h3" style={{ marginTop: space.sm }}>
        {t.makerTitle(maker.brand)}
      </Txt>
      <Txt variant="small" muted style={{ marginTop: 4 }}>
        {t.makerBody(maker.count, maker.atLeast, maker.prefix, maker.branded)}
      </Txt>

      <Txt variant="bodyStrong" style={{ marginTop: space.md, marginBottom: space.xs }}>
        {t.makerAsk}
      </Txt>
      <Field value={q} onChangeText={setQ} placeholder={t.makerPlaceholder} label={t.makerAsk} maxLength={40} autoCapitalize="none" returnKeyType="search" />

      {typed ? null : (
        <Txt variant="tiny" upper muted style={{ marginTop: space.md }}>
          {t.makerTop}
        </Txt>
      )}
      {matches.length === 0 ? (
        <Txt variant="small" style={{ marginTop: space.sm }}>
          {t.makerNone(typed)}
        </Txt>
      ) : (
        <View style={{ marginTop: typed ? space.sm : space.xs, gap: 6 }}>
          {matches.slice(0, SHOWN).map((p) => (
            <MakerRow key={p.code} p={p} onPick={onPick} />
          ))}
        </View>
      )}
      <Txt variant="small" faint style={{ marginTop: space.sm }}>
        {t.makerNote}
      </Txt>
    </View>
  );
}

function MakerRow({ p, onPick }: { p: MakerProduct; onPick: (code: string) => void }) {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const [broken, setBroken] = useState(false);
  const name = tr(p.name);
  return (
    <PressableScale
      onPress={() => onPick(p.code)}
      accessibilityRole="button"
      accessibilityLabel={t.makerOpen(name)}
      scaleTo={0.98}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: space.sm,
        padding: 8,
        borderRadius: radius.sm,
        backgroundColor: isDark ? c.surface : c.bg,
        borderWidth: 1,
        borderColor: c.border,
      }}
    >
      <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
        {p.imageUrl && !broken ? (
          <Image source={{ uri: p.imageUrl }} style={{ width: 36, height: 36 }} resizeMode="contain" onError={() => setBroken(true)} />
        ) : (
          <Icon name="package" size={18} color="#55675F" />
        )}
      </View>
      <View style={{ flex: 1 }}>
        <Txt variant="bodyStrong" numberOfLines={2}>
          {name}
        </Txt>
        {p.quantity ? (
          <Txt variant="small" muted>
            {p.quantity}
          </Txt>
        ) : null}
      </View>
      <Icon name="chevron-right" size={18} color={c.textMuted} />
    </PressableScale>
  );
}
