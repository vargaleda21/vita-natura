// The live checklist on the scanner while a code is looked up: one row per open source, with a tick
// that springs in as each one answers.

import { useEffect } from 'react';
import { View } from 'react-native';
import Animated, { cancelAnimation, useAnimatedStyle, useSharedValue, withRepeat, withSequence, withSpring, withTiming } from 'react-native-reanimated';

import { SOURCE_ORDER, type Progress, type SourceStatus } from '@/data/api';
import { palette, radius, space, springs } from '@/theme/tokens';
import { Icon, PressableScale, Txt } from '@/ui';
import type { LookupStrings } from './strings';

const MARK = 22;

/** The status dot or tick for one source. Remounts on every change (keyed by status), so each tick springs in. */
export function StatusMark({ status, reduced, dark = true }: { status: SourceStatus; reduced: boolean; dark?: boolean }) {
  const s = useSharedValue(reduced || status === 'waiting' ? 1 : 0.3);
  const pulse = useSharedValue(1);
  useEffect(() => {
    if (!reduced && status !== 'waiting') s.set(withSpring(1, springs.bouncy));
    if (status === 'checking' && !reduced) {
      pulse.set(withRepeat(withSequence(withTiming(0.35, { duration: 520 }), withTiming(1, { duration: 520 })), -1));
      return () => cancelAnimation(pulse);
    }
  }, [s, pulse, status, reduced]);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: s.get() }], opacity: pulse.get() }));

  const faint = dark ? 'rgba(255,255,255,0.28)' : 'rgba(16,35,28,0.22)';
  let body;
  switch (status) {
    case 'found':
      body = (
        <View style={{ width: MARK, height: MARK, borderRadius: MARK / 2, backgroundColor: palette.lime, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="check" size={14} color={palette.ink} strokeWidth={3.2} />
        </View>
      );
      break;
    case 'checking':
      body = (
        <View style={{ width: MARK, height: MARK, alignItems: 'center', justifyContent: 'center' }}>
          <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: dark ? palette.mint : palette.forest }} />
        </View>
      );
      break;
    case 'error':
      body = (
        <View style={{ width: MARK, height: MARK, borderRadius: MARK / 2, backgroundColor: 'rgba(255,201,61,0.2)', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="circle-alert" size={15} color={dark ? palette.sun : '#9A6A00'} />
        </View>
      );
      break;
    case 'none':
      body = (
        <View style={{ width: MARK, height: MARK, borderRadius: MARK / 2, borderWidth: 1.5, borderColor: faint, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="x" size={12} color={dark ? 'rgba(255,255,255,0.6)' : 'rgba(16,35,28,0.5)'} strokeWidth={2.6} />
        </View>
      );
      break;
    case 'skipped':
      body = (
        <View style={{ width: MARK, height: MARK, alignItems: 'center', justifyContent: 'center' }}>
          <View style={{ width: 10, height: 2, borderRadius: 1, backgroundColor: faint }} />
        </View>
      );
      break;
    default:
      body = <View style={{ width: MARK, height: MARK, borderRadius: MARK / 2, borderWidth: 1.5, borderColor: faint, borderStyle: 'dashed' }} />;
  }
  return <Animated.View style={anim}>{body}</Animated.View>;
}

/** One row: the mark, the source and what it holds, and its state in words. */
export function SourceRow({
  k,
  status,
  t,
  reduced,
  dark = true,
  compact,
}: {
  k: keyof Progress;
  status: SourceStatus;
  t: LookupStrings;
  reduced: boolean;
  dark?: boolean;
  /** Without the "what it holds" line. */
  compact?: boolean;
}) {
  const strong = dark ? '#FFFFFF' : undefined;
  const soft = dark ? 'rgba(255,255,255,0.55)' : undefined;
  const dim = status === 'skipped' || status === 'waiting';
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md, opacity: dim ? 0.6 : 1 }}>
      <StatusMark key={status} status={status} reduced={reduced} dark={dark} />
      <View style={{ flex: 1 }}>
        <Txt variant="bodyStrong" color={strong} numberOfLines={1}>
          {t.source[k].name}
        </Txt>
        {compact ? null : (
          <Txt variant="tiny" color={soft} muted={!dark} numberOfLines={1} style={{ letterSpacing: 0.2 }}>
            {t.source[k].sub}
          </Txt>
        )}
      </View>
      <Txt
        variant="small"
        color={dark ? (status === 'found' ? palette.lime : status === 'error' ? palette.sun : 'rgba(255,255,255,0.6)') : undefined}
        muted={!dark}
      >
        {t.status[status]}
      </Txt>
    </View>
  );
}

type Props = { progress: Progress; t: LookupStrings; reduced: boolean; onCancel: () => void };

/** The dark glass card over the scanner's bottom panel. */
export function SourceChecklist({ progress, t, reduced, onCancel }: Props) {
  const p = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    if (!reduced) p.set(withSpring(1, springs.soft));
  }, [p, reduced]);
  const enter = useAnimatedStyle(() => ({ opacity: p.get(), transform: [{ translateY: (1 - p.get()) * 40 }] }));

  return (
    <Animated.View
      accessibilityLiveRegion="polite"
      style={[
        {
          borderRadius: radius.xl,
          backgroundColor: palette.night2,
          borderWidth: 1,
          borderColor: 'rgba(255,255,255,0.12)',
          padding: space.lg,
          gap: space.md,
        },
        enter,
      ]}
    >
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.md }}>
        <View style={{ flex: 1 }}>
          <Txt variant="h3" color="#FFFFFF">
            {t.checking}
          </Txt>
          <Txt variant="small" color="rgba(255,255,255,0.6)" style={{ marginTop: 2 }}>
            {t.checkingSub}
          </Txt>
        </View>
        <PressableScale
          onPress={onCancel}
          accessibilityRole="button"
          accessibilityLabel={t.cancel}
          hitSlop={8}
          style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: radius.pill, backgroundColor: 'rgba(255,255,255,0.1)' }}
        >
          <Txt variant="small" color="#FFFFFF">
            {t.cancel}
          </Txt>
        </PressableScale>
      </View>
      <View style={{ gap: 10 }}>
        {SOURCE_ORDER.map((k) => (
          <SourceRow key={k} k={k} status={progress[k]} t={t} reduced={reduced} />
        ))}
      </View>
    </Animated.View>
  );
}
