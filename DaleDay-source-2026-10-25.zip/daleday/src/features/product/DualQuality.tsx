import { View } from 'react-native';

import type { DualQuality as DQ, Product } from '@/data/types';
import { useT, useTr } from '@/i18n';
import { palette, radius, space } from '@/theme/tokens';
import { Card, Icon, PackArt, Txt, useTheme } from '@/ui';
import { alpha } from './format';
import { strings } from './strings';

type Tone = 'better' | 'worse' | 'neutral';

function toneOf(verdict: DQ['verdict'], side: 'here' | 'there'): Tone {
  if (verdict === 'worse_here') return side === 'here' ? 'worse' : 'better';
  if (verdict === 'better_here') return side === 'here' ? 'better' : 'worse';
  return 'neutral';
}

const TONE_COLOR: Record<Tone, string> = { better: palette.great, worse: palette.tangerine, neutral: palette.sky };

function Side({ code, label, status, tone, product }: { code: string; label: string; status: string; tone: Tone; product: Product }) {
  const { c, isDark } = useTheme();
  const color = TONE_COLOR[tone];
  return (
    <View
      style={{
        flex: 1,
        alignItems: 'center',
        gap: space.sm,
        paddingVertical: space.lg,
        paddingHorizontal: space.sm,
        backgroundColor: alpha(color, isDark ? 0.14 : 0.1),
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        <View style={{ paddingHorizontal: 6, paddingVertical: 1, borderRadius: 6, backgroundColor: c.text }}>
          <Txt variant="tiny" color={c.bg}>
            {code}
          </Txt>
        </View>
        <Txt variant="bodyStrong">{label}</Txt>
      </View>
      <PackArt art={product.art} size={86} />
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 5,
          paddingHorizontal: 10,
          paddingVertical: 4,
          borderRadius: radius.pill,
          backgroundColor: color,
        }}
      >
        <Icon name={tone === 'better' ? 'check' : tone === 'worse' ? 'triangle-alert' : 'arrow-left-right'} size={13} color={palette.ink} />
        <Txt variant="tiny" color={palette.ink}>
          {status}
        </Txt>
      </View>
    </View>
  );
}

/** Same brand, same pack, different recipe abroad: a split card. */
export function DualQuality({ product }: { product: Product }) {
  const t = useT(strings);
  const tr = useTr();
  const { c } = useTheme();
  const dq = product.dualQuality;
  if (!dq) return null;
  const country = t.country[dq.country];

  return (
    <Card padded={false}>
      <View style={{ padding: space.lg, paddingBottom: space.md, gap: 6 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
          <Icon name="globe" size={18} color={c.textMuted} />
          <Txt variant="tiny" muted upper>
            {t.dualVerdict[dq.verdict]}
          </Txt>
        </View>
        <Txt variant="h2" accessibilityRole="header">
          {t.dualTitle(country)}
        </Txt>
      </View>
      <View style={{ flexDirection: 'row' }}>
        <Side code="HU" label={t.home} status={t.sideHere[dq.verdict]} tone={toneOf(dq.verdict, 'here')} product={product} />
        <View style={{ width: 2, backgroundColor: c.surface }} />
        <Side code={dq.country} label={country} status={t.sideThere[dq.verdict]} tone={toneOf(dq.verdict, 'there')} product={product} />
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            left: '50%',
            top: '50%',
            marginLeft: -20,
            marginTop: -20,
            width: 40,
            height: 40,
            borderRadius: 20,
            backgroundColor: c.text,
            alignItems: 'center',
            justifyContent: 'center',
            borderWidth: 3,
            borderColor: c.surface,
          }}
        >
          <Txt variant="tiny" color={c.bg}>
            VS
          </Txt>
        </View>
      </View>
      <View style={{ padding: space.lg, gap: space.md }}>
        {dq.diffs.map((d) => (
          <View key={d.hu} style={{ flexDirection: 'row', gap: space.md, alignItems: 'flex-start' }}>
            <View style={{ marginTop: 2 }}>
              <Icon name="arrow-left-right" size={18} color={palette.tangerine} />
            </View>
            <Txt variant="bodyStrong" style={{ flex: 1 }}>
              {tr(d)}
            </Txt>
          </View>
        ))}
        <View style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-start' }}>
          <View style={{ marginTop: 1 }}>
            <Icon name="info" size={15} color={c.textFaint} />
          </View>
          <Txt variant="small" faint style={{ flex: 1 }}>
            {t.dualNote}
          </Txt>
        </View>
      </View>
    </Card>
  );
}
