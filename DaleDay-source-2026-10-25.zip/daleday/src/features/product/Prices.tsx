import { View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedReaction,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withTiming,
} from 'react-native-reanimated';

import { getStore } from '@/data/api';
import type { Product, StorePrice } from '@/data/types';
import { formatHuf, useLang, useT } from '@/i18n';
import { palette, radius, space, type as typeScale } from '@/theme/tokens';
import { Card, Icon, Txt, useTheme } from '@/ui';
import { useReduced, useSectionProgress } from './reveal';
import { strings } from './strings';

function Tag({ label, bg, fg = palette.ink }: { label: string; bg: string; fg?: string }) {
  return (
    <View style={{ paddingHorizontal: 7, paddingVertical: 2, borderRadius: radius.pill, backgroundColor: bg }}>
      <Txt variant="tiny" color={fg}>
        {label}
      </Txt>
    </View>
  );
}

function PriceRow({ price, max, cheapest, index }: { price: StorePrice; max: number; cheapest: boolean; index: number }) {
  const t = useT(strings);
  const lang = useLang();
  const { c, isDark } = useTheme();
  const reduced = useReduced();
  const section = useSectionProgress();
  const store = getStore(price.store);
  const g = useSharedValue(reduced ? 1 : 0);
  const fw = useSharedValue(0);
  const started = useSharedValue(reduced);

  useAnimatedReaction(
    () => section.value > 0.05,
    (go) => {
      if (!go || started.value) return;
      started.value = true;
      g.value = withDelay(160 + index * 110, withTiming(1, { duration: 700, easing: Easing.out(Easing.cubic) }));
    },
  );
  const fill = useAnimatedStyle(() => ({
    opacity: fw.value > 0 ? 1 : 0,
    transform: [{ translateX: (g.value - 1) * fw.value }],
  }));

  const pct = Math.max(0.04, price.priceHuf / max);
  return (
    <View
      style={{
        gap: 8,
        padding: space.md,
        marginHorizontal: -space.sm,
        borderRadius: radius.md,
        backgroundColor: cheapest ? (isDark ? 'rgba(198,243,107,0.08)' : 'rgba(198,243,107,0.22)') : 'transparent',
        borderWidth: cheapest ? 1 : 0,
        borderColor: cheapest ? 'rgba(143,209,59,0.45)' : 'transparent',
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
        <View style={{ width: 12, height: 12, borderRadius: 4, backgroundColor: store.color }} />
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 6 }}>
          <Txt variant="bodyStrong">{store.name}</Txt>
          {cheapest ? <Tag label={t.cheapest} bg={palette.lime} /> : null}
          {price.promo ? <Tag label={t.promo} bg={palette.sun} /> : null}
          {store.online ? <Tag label={t.online} bg={palette.lilac} /> : null}
        </View>
        <Txt variant={cheapest ? 'h3' : 'bodyStrong'} style={cheapest ? { fontFamily: typeScale.h2.fontFamily } : undefined}>
          {formatHuf(price.priceHuf, lang)}
        </Txt>
      </View>
      <View style={{ height: 6, borderRadius: 3, backgroundColor: isDark ? 'rgba(255,255,255,0.07)' : c.bgAlt, overflow: 'hidden' }}>
        <Animated.View
          onLayout={(e) => fw.set(e.nativeEvent.layout.width)}
          style={[
            {
              position: 'absolute',
              left: 0,
              top: 0,
              bottom: 0,
              width: `${pct * 100}%`,
              borderRadius: 3,
              backgroundColor: cheapest ? palette.limeDeep : isDark ? 'rgba(238,246,239,0.32)' : 'rgba(16,35,28,0.28)',
            },
            fill,
          ]}
        />
      </View>
    </View>
  );
}

/** Shelf prices per shop, cheapest first and highlighted. Demo prices standing in for the GVH feed. */
export function Prices({ product }: { product: Product }) {
  const t = useT(strings);
  const lang = useLang();
  const { c, isDark } = useTheme();
  const sorted = [...product.prices].sort((a, b) => a.priceHuf - b.priceHuf);
  if (sorted.length === 0) return null;
  const max = sorted[sorted.length - 1].priceHuf;
  const min = sorted[0].priceHuf;
  const save = max - min;

  return (
    <Card style={{ gap: space.xs }}>
      {sorted.map((p, i) => (
        <PriceRow key={p.store} price={p} max={max} cheapest={i === 0 && sorted.length > 1} index={i} />
      ))}
      {save > 0 ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm, marginTop: space.sm }}>
          <Icon name="trending-down" size={17} color={palette.great} />
          <Txt variant="bodyStrong" style={{ flex: 1 }}>
            {t.saveLine(formatHuf(save, lang), getStore(sorted[0].store).name)}
          </Txt>
        </View>
      ) : null}
      <View
        style={{
          flexDirection: 'row',
          gap: space.sm,
          marginTop: space.md,
          padding: space.md,
          borderRadius: radius.md,
          backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
        }}
      >
        <View style={{ marginTop: 1 }}>
          <Icon name="info" size={15} color={c.textMuted} />
        </View>
        <Txt variant="small" muted style={{ flex: 1 }}>
          {t.priceNote}
        </Txt>
      </View>
    </Card>
  );
}
