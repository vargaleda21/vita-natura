import { router } from 'expo-router';
import { ScrollView, Text, View } from 'react-native';

import type { AvoidKey, MatchResult, Member } from '@/data/types';
import { strings as lookupStrings } from '@/features/lookup/strings';
import { useT } from '@/i18n';
import { palette, space, verdictColor } from '@/theme/tokens';
import { Card, Icon, PressableScale, Txt, useTheme } from '@/ui';
import { strings } from './strings';

type Person = { id: string; name: string; avatar?: string; color: string; ok: boolean; unsure: boolean; isMe: boolean };

const AV = 56;

function Avatar({ person }: { person: Person }) {
  const { c } = useTheme();
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const status = !person.ok ? (person.isMe ? t.notForMe : t.notForThem) : person.unsure ? lt.unsure : person.isMe ? t.fitsMe : t.fitsThem;
  const mark = !person.ok ? verdictColor.avoid : person.unsure ? c.textFaint : verdictColor.great;
  return (
    <View
      style={{ width: 76, alignItems: 'center', gap: 6 }}
      accessible
      accessibilityLabel={`${person.name}: ${status}`}
    >
      <View style={{ width: AV, height: AV }}>
        <View
          style={{
            width: AV,
            height: AV,
            borderRadius: AV / 2,
            backgroundColor: person.color,
            alignItems: 'center',
            justifyContent: 'center',
            borderWidth: 2,
            borderColor: person.ok ? 'transparent' : verdictColor.avoid,
          }}
        >
          {person.avatar ? (
            <Text style={{ fontSize: 26, lineHeight: 32 }} allowFontScaling={false}>
              {person.avatar}
            </Text>
          ) : (
            <Icon name="user-round" size={26} color={palette.ink} />
          )}
        </View>
        <View
          style={{
            position: 'absolute',
            right: -3,
            bottom: -3,
            width: 24,
            height: 24,
            borderRadius: 12,
            backgroundColor: mark,
            borderWidth: 2.5,
            borderColor: c.surface,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {person.ok && person.unsure ? (
            <Text style={{ color: palette.white, fontSize: 13, lineHeight: 15, fontWeight: '800' }} allowFontScaling={false}>
              ?
            </Text>
          ) : (
            <Icon name={person.ok ? 'check' : 'x'} size={13} color={palette.white} strokeWidth={3.2} />
          )}
        </View>
      </View>
      <View style={{ alignItems: 'center' }}>
        <Txt variant="bodyStrong" numberOfLines={1}>
          {person.name}
        </Txt>
        <Txt variant="tiny" muted numberOfLines={1}>
          {status}
        </Txt>
      </View>
    </View>
  );
}

/** "One scan checks for everyone": the owner and each family member, with a tick or a cross. */
export function WhoFor({ result, members, avoid = [] }: { result: MatchResult; members: Member[]; avoid?: AvoidKey[] }) {
  const t = useT(strings);
  const { c } = useTheme();
  const blocked = (id: string) => result.hits.some((h) => h.who.includes(id));
  // Real products: someone whose list includes a criterion no source lets us check gets a "?".
  const unsure = (keys: AvoidKey[]) => keys.some((k) => result.unknown?.includes(k));
  const people: Person[] = [
    { id: 'me', name: t.me, color: palette.lime, ok: !blocked('me'), unsure: unsure(avoid), isMe: true },
    ...members.map((m) => ({ id: m.id, name: m.name, avatar: m.avatar, color: m.color, ok: !blocked(m.id), unsure: unsure(m.avoid), isMe: false })),
  ];

  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm, marginBottom: space.lg }}>
        <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: c.bgAlt, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="users" size={17} color={c.text} />
        </View>
        <View style={{ flex: 1 }}>
          <Txt variant="h3">{t.whoTitle}</Txt>
          <Txt variant="small" muted>
            {t.whoSub}
          </Txt>
        </View>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: space.sm, paddingRight: space.sm }}>
        {people.map((p) => (
          <Avatar key={p.id} person={p} />
        ))}
        {members.length === 0 ? (
          <PressableScale
            onPress={() => router.push('/(tabs)/profile')}
            accessibilityRole="button"
            accessibilityLabel={t.addFamily}
            style={{ width: 76, alignItems: 'center', gap: 6 }}
          >
            <View
              style={{
                width: AV,
                height: AV,
                borderRadius: AV / 2,
                borderWidth: 1.5,
                borderStyle: 'dashed',
                borderColor: c.textFaint,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="plus" size={22} color={c.textMuted} />
            </View>
            <Txt variant="bodyStrong" muted>
              {t.addFamily}
            </Txt>
          </PressableScale>
        ) : null}
      </ScrollView>
    </Card>
  );
}
