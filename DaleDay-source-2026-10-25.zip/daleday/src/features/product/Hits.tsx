import { Linking, View } from 'react-native';

import { CRITERIA } from '@/data/api';
import type { Hit, Ingredient, L10n, Member, Product } from '@/data/types';
import { strings as lookupStrings } from '@/features/lookup/strings';
import { useLang, useT, useTr } from '@/i18n';
import { palette, radius, space, verdictColor } from '@/theme/tokens';
import { Card, Icon, PressableScale, Txt, useTheme } from '@/ui';
import { alpha, num } from './format';
import { strings } from './strings';

function WhoPills({ who, members }: { who: string[]; members: Member[] }) {
  const t = useT(strings);
  const { c } = useTheme();
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 6 }}>
      <Txt variant="small" faint>
        {t.forWhom}
      </Txt>
      {who.map((id) => {
        const m = members.find((x) => x.id === id);
        return (
          <View
            key={id}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 4,
              paddingLeft: 3,
              paddingRight: 9,
              paddingVertical: 2,
              borderRadius: radius.pill,
              backgroundColor: c.bgAlt,
            }}
          >
            <View
              style={{
                width: 18,
                height: 18,
                borderRadius: 9,
                backgroundColor: m?.color ?? palette.lime,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              {m ? (
                <Txt style={{ fontSize: 10, lineHeight: 13 }}>{m.avatar}</Txt>
              ) : (
                <Icon name="user-round" size={11} color={palette.ink} />
              )}
            </View>
            <Txt variant="small">{m?.name ?? t.me}</Txt>
          </View>
        );
      })}
    </View>
  );
}

/** An ingredient by its Hungarian name, also inside compound ones. */
function findIngredient(list: Ingredient[], hu: string): Ingredient | undefined {
  for (const i of list) {
    if (i.name.hu === hu) return i;
    const inner = i.sub ? findIngredient(i.sub, hu) : undefined;
    if (inner) return inner;
  }
  return undefined;
}

function HitCard({ hit, product, members }: { hit: Hit; product: Product; members: Member[] }) {
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const tr = useTr();
  const lang = useLang();
  const { c, isDark } = useTheme();
  const crit = CRITERIA[hit.key];
  const tint = verdictColor.avoid;
  const reasons: string[] = [
    ...new Set(
      hit.ingredients.map((i: L10n) => {
        const ing = findIngredient(product.ingredients, i.hu);
        return ing?.percent ? `${tr(i)} ${num(ing.percent, lang)}%` : tr(i);
      }),
    ),
  ];
  const salt = product.nutrition.saltG;
  if (reasons.length === 0 && hit.key === 'ultra_processed') reasons.push(t.novaReason);
  if (reasons.length === 0 && hit.key === 'high_salt' && salt !== undefined) reasons.push(t.saltReason(num(salt, lang)));

  return (
    <Card style={{ gap: space.md }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
        <View
          style={{
            width: 46,
            height: 46,
            borderRadius: 16,
            backgroundColor: alpha(tint, isDark ? 0.2 : 0.12),
            borderWidth: 1,
            borderColor: alpha(tint, 0.28),
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name={crit.icon} size={22} color={tint} />
        </View>
        <View style={{ flex: 1, gap: 4 }}>
          <Txt variant="h3">{tr(crit.label)}</Txt>
          <WhoPills who={hit.who} members={members} />
        </View>
      </View>

      {reasons.length > 0 ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 6 }}>
          <Txt variant="small" faint>
            {hit.trace ? lt.mayContain : t.foundIn}
          </Txt>
          {reasons.map((r) => (
            <View
              key={r}
              style={{
                paddingHorizontal: 10,
                paddingVertical: 4,
                borderRadius: radius.pill,
                backgroundColor: alpha(tint, isDark ? 0.18 : 0.1),
              }}
            >
              <Txt variant="small">{r}</Txt>
            </View>
          ))}
        </View>
      ) : null}

      {hit.trace ? (
        <Txt variant="small" style={{ fontStyle: 'italic' }}>
          {lt.traceNote}
        </Txt>
      ) : null}

      <Txt variant="body" muted>
        {tr(crit.short)}
      </Txt>

      {crit.source.url ? (
        <PressableScale
          onPress={() => void Linking.openURL(crit.source.url ?? '')}
          accessibilityRole="link"
          accessibilityLabel={t.openSource(crit.source.name)}
          hitSlop={10}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
        >
          <Txt variant="small" faint style={{ textDecorationLine: 'underline' }}>
            {t.source(crit.source.name)}
          </Txt>
          <Icon name="arrow-right" size={13} color={c.textFaint} />
        </PressableScale>
      ) : (
        <Txt variant="small" faint>
          {t.source(crit.source.name)}
        </Txt>
      )}
    </Card>
  );
}

/** One calm card per thing you asked to avoid. Never "this is bad". */
export function Hits({ hits, product, members }: { hits: Hit[]; product: Product; members: Member[] }) {
  return (
    <View style={{ gap: space.md }}>
      {hits.map((h) => (
        <HitCard key={h.key} hit={h} product={product} members={members} />
      ))}
    </View>
  );
}

/** Shown instead of the hits when nothing matched, with the product's positives. */
export function AllClear({ positives }: { positives: L10n[] }) {
  const t = useT(strings);
  const tr = useTr();
  const { isDark } = useTheme();
  return (
    <Card gradient={isDark ? ['#183C2C', '#13221C'] : ['#E4F8C8', '#D3F2E4']} style={{ gap: space.md }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
        <View style={{ width: 46, height: 46, borderRadius: 16, backgroundColor: verdictColor.great, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="shield-check" size={24} color={palette.white} />
        </View>
        <View style={{ flex: 1 }}>
          <Txt variant="h3">{t.noHitsTitle}</Txt>
          <Txt variant="small" muted>
            {t.noHitsBody}
          </Txt>
        </View>
      </View>
      {positives.length > 0 ? (
        <View style={{ marginTop: space.md, gap: space.sm }}>
          <Txt variant="tiny" muted upper>
            {t.positivesTitle}
          </Txt>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
            {positives.map((p) => (
              <View
                key={p.hu}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 6,
                  paddingHorizontal: 12,
                  paddingVertical: 7,
                  borderRadius: radius.pill,
                  backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.75)',
                }}
              >
                <Icon name="leaf" size={14} color={verdictColor.great} />
                <Txt variant="small">{tr(p)}</Txt>
              </View>
            ))}
          </View>
        </View>
      ) : null}
    </Card>
  );
}

/** The product's good notes, when there are also hits. */
export function Positives({ positives }: { positives: L10n[] }) {
  const t = useT(strings);
  const tr = useTr();
  const { c } = useTheme();
  if (positives.length === 0) return null;
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: space.sm, marginTop: space.md }}>
      <Txt variant="small" faint>
        {t.positivesTitle}:
      </Txt>
      {positives.map((p) => (
        <View
          key={p.hu}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            paddingHorizontal: 12,
            paddingVertical: 6,
            borderRadius: radius.pill,
            backgroundColor: c.surface,
            borderWidth: 1,
            borderColor: c.border,
          }}
        >
          <Icon name="leaf" size={14} color={verdictColor.great} />
          <Txt variant="small">{tr(p)}</Txt>
        </View>
      ))}
    </View>
  );
}
