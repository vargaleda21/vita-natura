import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { Platform, Share, useWindowDimensions, View } from 'react-native';
import Animated, { useAnimatedScrollHandler, useReducedMotion, useSharedValue } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  activeKeys,
  alternativesFor,
  cannotJudge,
  cheapestPrice,
  evaluate,
  getProduct,
  getStore,
  localSize,
  lowestChainPrice,
  MYSTERY_EAN,
} from '@/data/api';
import type { Alternative, Product } from '@/data/types';
import { Skeleton } from '@/features/lookup/bits';
import { useLookupRead, useProductByCode, useRealAlternatives } from '@/features/lookup/hooks';
import { RealAlternatives } from '@/features/lookup/RealAlternatives';
import { Description, NoVerdictCard } from '@/features/lookup/RealFacts';
import { RealNotFoundScreen } from '@/features/lookup/RealNotFound';
import { strings as lookupStrings } from '@/features/lookup/strings';
import { WhereSold } from '@/features/lookup/WhereSold';
import { formatHuf, useLang, useT, useTr } from '@/i18n';
import { addScan, markSwapped, useSettings } from '@/state/store';
import { radius, space } from '@/theme/tokens';
import { Icon, PackArt, Txt, useTheme } from '@/ui';
import { Alternatives } from './Alternatives';
import { DataSource } from './DataSource';
import { DualQuality } from './DualQuality';
import { AllClear, Hits, Positives } from './Hits';
import { Ingredients } from './Ingredients';
import { NotFound } from './NotFound';
import { isLiquid, Nutrition } from './Nutrition';
import { Prices } from './Prices';
import { RecipeHistory } from './RecipeHistory';
import { Reveal, RevealProvider } from './reveal';
import { ScoreCard } from './ScoreCard';
import { Section } from './Section';
import { Stage } from './Stage';
import { strings } from './strings';
import { clearToast, makeToast, peekToast, queueToast, Toast, type ToastMsg } from './toast';
import { TopBar } from './TopBar';
import { WhoFor } from './WhoFor';

const MAX_W = 480;
const SHEET_R = 32;
const BAR = 56;

export function ProductScreen() {
  const { ean, from } = useLocalSearchParams<{ ean: string; from?: string }>();
  const code = String(ean ?? '');
  // Opened from the maker's list on the not-found sheet: the code the person actually scanned.
  const scanned = typeof from === 'string' && /^\d{8,14}$/.test(from) && from !== code ? from : undefined;
  // The AI-read mystery product lives only in memory: after a reload it is gone, and it is never looked up.
  if (code === MYSTERY_EAN && !getProduct(code)) return <NotFound />;
  return <ProductByCode key={code} code={code} scanned={scanned} />;
}

/** A demo product, a real one from the device, or a fresh lookup (a cold deep link). */
function ProductByCode({ code, scanned }: { code: string; scanned?: string }) {
  const reduced = useReducedMotion();
  const { state, retry } = useProductByCode(code);
  switch (state.kind) {
    case 'ready':
      return <ProductView key={state.product.ean} product={state.product} scanned={scanned} />;
    case 'loading':
      return state.product ? <ProductView key={state.product.ean} product={state.product} scanned={scanned} /> : <Loading reduced={reduced} />;
    case 'not_found':
      return <RealNotFoundScreen code={state.key} progress={state.progress} unreachable={state.unreachable} reduced={reduced} onRetry={retry} />;
    default:
      return <NotFound />;
  }
}

function Loading({ reduced }: { reduced: boolean }) {
  const lt = useT(lookupStrings);
  const { c } = useTheme();
  return (
    <View style={{ flex: 1, backgroundColor: c.bg, alignItems: 'center', justifyContent: 'center', padding: space.xxl }}>
      <View style={{ width: '100%', maxWidth: 360, alignItems: 'center', gap: space.lg }} accessibilityLiveRegion="polite">
        <View style={{ width: 160, height: 160, borderRadius: 80, backgroundColor: c.bgAlt, alignItems: 'center', justifyContent: 'center' }}>
          <PackArt art={{ colors: ['#8A9A92', '#D9E2DC'], emoji: '🔎', shape: 'box' }} size={104} />
        </View>
        <Txt variant="h2" center>
          {lt.loading}
        </Txt>
        <View style={{ width: '100%', gap: space.sm, alignItems: 'center' }}>
          <Skeleton width="80%" height={14} reduced={reduced} />
          <Skeleton width="60%" height={14} reduced={reduced} />
        </View>
      </View>
    </View>
  );
}

function ProductView({ product, scanned }: { product: Product; scanned?: string }) {
  const settings = useSettings();
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const tr = useTr();
  const lang = useLang();
  const { c, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { height: winH, width: winW } = useWindowDimensions();
  const reduced = useReducedMotion();
  const scrollY = useSharedValue(0);
  const scrollRef = useRef<Animated.ScrollView>(null);
  const [altY, setAltY] = useState<number | null>(null);
  // A swap queues its toast before navigating here: show it once, then clear the queue.
  const [toast, setToast] = useState<ToastMsg | null>(peekToast);
  const realAlts = useRealAlternatives(product, settings);
  const chain = useLookupRead(() => (product.real ? lowestChainPrice(product.ean) : undefined));

  const onScroll = useAnimatedScrollHandler((e) => {
    scrollY.value = e.contentOffset.y;
  });

  useEffect(() => {
    clearToast();
  }, []);

  const real = product.real;
  const result = evaluate(product, settings);
  const noVerdict = !!real && cannotJudge(result);
  const alternatives = real ? realAlts.alternatives : alternativesFor(product, settings);
  const active = activeKeys(settings);
  const cheapest = real ? undefined : cheapestPrice(product);
  const name = tr(product.name);
  const size = localSize(product.size, lang);
  const showAlts = !real || realAlts.enabled;
  const showIngredients = !real || real.ingredientsKnown || real.kind === 'food' || real.kind === 'petfood' || real.kind === 'unknown';
  const showNutrition =
    !real || real.kind === 'food' || real.kind === 'petfood' || Object.values(product.nutrition).some((v) => v !== undefined);

  const stageH = insets.top + 360;
  const sheetTop = stageH - SHEET_R;
  const barBottom = insets.top + BAR;
  const altsEarly = showAlts && !noVerdict && result.verdict !== 'great' && (alternatives.length > 0 || realAlts.loading);

  const onBack = () => {
    if (router.canGoBack()) router.back();
    else router.replace('/');
  };

  const onShare = async () => {
    const text = t.shareText(name);
    if (Platform.OS === 'web') {
      const url = typeof window !== 'undefined' ? window.location.href : '';
      if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
        try {
          await navigator.share({ title: `DaleDay · ${name}`, text, url });
        } catch {
          // The person closed the share sheet.
        }
        return;
      }
      try {
        await navigator.clipboard.writeText(url);
        setToast(makeToast(t.linkCopied, 'check'));
      } catch {
        // No clipboard access: nothing to do.
      }
      return;
    }
    try {
      await Share.share({ message: text });
    } catch {
      // Ignore: the sheet was dismissed.
    }
  };

  const onSwap = (alt: Alternative) => {
    // A product we could not judge has no verdict to put in the history.
    if (!noVerdict) markSwapped({ ean: product.ean, verdict: result.verdict, score: result.score }, alt.product.ean);
    addScan({ ean: alt.product.ean, at: new Date().toISOString(), verdict: alt.result.verdict, score: alt.result.score });
    queueToast(makeToast(t.swapToast, 'sparkles'));
    router.push(`/product/${alt.product.ean}`);
  };

  const seeBetter = () => {
    if (altY === null) return;
    scrollRef.current?.scrollTo({ y: Math.max(0, altY - barBottom - space.lg), animated: true });
  };

  const alternativesSection = showAlts ? (
    <Section index={4} title={t.altTitle} subtitle={alternatives.length > 0 ? t.altSub : undefined} icon="sparkles" onY={setAltY}>
      {real ? <RealAlternatives view={realAlts} onSwap={onSwap} reduced={reduced} /> : <Alternatives alternatives={alternatives} onSwap={onSwap} />}
    </Section>
  ) : null;

  return (
    <View style={{ flex: 1, backgroundColor: winW > MAX_W ? c.bgAlt : c.bg, alignItems: 'center' }}>
      <View style={{ flex: 1, width: '100%', maxWidth: MAX_W, backgroundColor: c.bg, overflow: 'hidden' }}>
        <Stage
          art={product.art}
          imageUrl={real?.imageUrl}
          photoLabel={lt.photoAlt(name)}
          scrollY={scrollY}
          height={stageH}
          top={barBottom}
          bottom={sheetTop}
          reduced={reduced}
        />

        <RevealProvider value={{ scrollY, viewportH: winH, offsetTop: sheetTop, reduced }}>
          <Animated.ScrollView
            ref={scrollRef}
            onScroll={onScroll}
            scrollEventThrottle={16}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingTop: sheetTop }}
          >
            <View
              style={{
                backgroundColor: c.bg,
                borderTopLeftRadius: SHEET_R,
                borderTopRightRadius: SHEET_R,
                paddingHorizontal: space.xl,
                paddingTop: space.md,
                paddingBottom: insets.bottom + space.xxxl,
                minHeight: winH - barBottom,
              }}
            >
              <View style={{ alignSelf: 'center', width: 40, height: 5, borderRadius: 3, backgroundColor: c.border, marginBottom: space.lg }} />

              <Reveal index={0}>
                {product.brand || size ? (
                  <Txt variant="tiny" muted>
                    {product.brand ? (
                      <Txt variant="tiny" muted upper>
                        {product.brand}
                      </Txt>
                    ) : null}
                    {product.brand && size ? ' · ' : ''}
                    {size}
                  </Txt>
                ) : null}
                <Txt variant="h1" accessibilityRole="header" style={{ marginTop: 6 }}>
                  {name}
                </Txt>
                {real?.nameNote ? (
                  <Txt variant="small" muted style={{ marginTop: 6 }}>
                    {real.nameNote === 'photo'
                      ? lt.namePhoto(lt.sourceNames[real.sources[0] ?? 'off'])
                      : real.nameNote === 'foreign_script' && real.nameOriginal
                        ? lt.nameForeign(real.nameOriginal, !!real.nameIsCategory)
                        : real.nameIsCategory
                          ? lt.nameMissing(lt.sourceNames[real.sources[0] ?? 'off'])
                          : lt.nameMissingBare(lt.sourceNames[real.sources[0] ?? 'off'])}
                  </Txt>
                ) : null}
                {cheapest ? (
                  <Txt variant="small" muted style={{ marginTop: 6 }}>
                    {t.fromPrice(formatHuf(cheapest.priceHuf, lang))} · {getStore(cheapest.store).name}
                  </Txt>
                ) : chain ? (
                  <Txt variant="small" muted style={{ marginTop: 6 }}>
                    {t.fromPrice(formatHuf(chain.priceHuf, lang))} · {chain.chain}
                  </Txt>
                ) : null}
              </Reveal>

              {scanned ? (
                <View
                  style={{
                    marginTop: space.lg,
                    flexDirection: 'row',
                    gap: space.sm,
                    padding: space.md,
                    borderRadius: radius.md,
                    backgroundColor: isDark ? c.surfaceAlt : c.surface,
                    borderWidth: 1,
                    borderColor: c.border,
                  }}
                >
                  <Icon name="info" size={18} color={c.text} />
                  <View style={{ flex: 1 }}>
                    <Txt variant="bodyStrong">{lt.similarTitle}</Txt>
                    <Txt variant="small" muted style={{ marginTop: 2 }}>
                      {lt.similarBody(scanned)}
                    </Txt>
                  </View>
                </View>
              ) : null}

              <Section index={1} style={{ marginTop: space.xl, zIndex: 5 }}>
                {noVerdict ? <NoVerdictCard product={product} /> : <ScoreCard
                    result={result}
                    fromPhoto={!!real?.ingredientsPhoto}
                    onSeeBetter={altsEarly && alternatives.length > 0 ? seeBetter : undefined}
                  />}
              </Section>

              {noVerdict ? null : (
                <Section index={2} style={{ marginTop: space.lg }}>
                  <WhoFor result={result} members={settings.members} avoid={settings.avoid} />
                </Section>
              )}

              {result.hits.length > 0 ? (
                <Section index={3} title={t.hitsTitle} subtitle={t.hitsSub}>
                  <Hits hits={result.hits} product={product} members={settings.members} />
                  <Positives positives={result.positives} />
                </Section>
              ) : !noVerdict && !result.unknown ? (
                <Section index={3}>
                  <AllClear positives={result.positives} />
                </Section>
              ) : result.positives.length > 0 ? (
                <Section index={3}>
                  <Positives positives={result.positives} />
                </Section>
              ) : null}

              {real?.description ? (
                <Section index={3} title={lt.descriptionTitle}>
                  <Description text={real.description} />
                </Section>
              ) : null}

              {altsEarly ? alternativesSection : null}

              {product.history && product.history.length > 0 ? (
                <Section index={5}>
                  <RecipeHistory product={product} cheapestHuf={cheapest?.priceHuf} />
                </Section>
              ) : null}

              {product.dualQuality ? (
                <Section index={6}>
                  <DualQuality product={product} />
                </Section>
              ) : null}

              {showIngredients ? (
                <Section index={7} title={t.ingredientsTitle}>
                  <Ingredients product={product} active={active} hits={result.hits} members={settings.members} />
                </Section>
              ) : null}

              {showNutrition ? (
                <Section index={8} title={t.nutritionTitle} subtitle={isLiquid(product) ? t.per100ml : t.per100}>
                  <Nutrition product={product} />
                </Section>
              ) : null}

              {real ? (
                <Section index={9} title={lt.whereTitle} subtitle={lt.whereSub} icon="store">
                  <WhereSold product={product} reduced={reduced} />
                </Section>
              ) : (
                <Section index={9} title={t.pricesTitle} subtitle={t.pricesSub}>
                  <Prices product={product} />
                </Section>
              )}

              {altsEarly ? null : alternativesSection}

              <Section index={10} title={t.sourceTitle}>
                <DataSource product={product} />
              </Section>
            </View>
          </Animated.ScrollView>
        </RevealProvider>

        <TopBar
          title={name}
          result={noVerdict ? undefined : result}
          scrollY={scrollY}
          inset={insets.top}
          solidAt={sheetTop - barBottom}
          onBack={onBack}
          onShare={() => void onShare()}
        />
        <Toast msg={toast} reduced={reduced} onDone={() => setToast(null)} />
      </View>
    </View>
  );
}
