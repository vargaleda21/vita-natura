import { View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedReaction,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withTiming,
} from 'react-native-reanimated';

import type { Nutrition as N, Product } from '@/data/types';
import { NutriScoreCard } from '@/features/lookup/RealFacts';
import { strings as lookupStrings } from '@/features/lookup/strings';
import { groupDigits, useLang, useT } from '@/i18n';
import { palette, radius, space } from '@/theme/tokens';
import { Card, Icon, Txt, useTheme } from '@/ui';
import { alpha, num } from './format';
import { useReduced, useSectionProgress } from './reveal';
import { strings } from './strings';

type Row = {
  key: keyof N;
  label: string;
  /** Undefined: no source gives it. Shown as a dash, never as zero. */
  value: number | undefined;
  max: number;
  ref: number | undefined;
  /** 'limit': above the mark is "high". 'good': above the mark is a plus. */
  kind: 'limit' | 'good';
  goodTag?: string;
};

function Bar({ row, index }: { row: Row; index: number }) {
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const lang = useLang();
  const { c, isDark } = useTheme();
  const reduced = useReduced();
  const section = useSectionProgress();
  const g = useSharedValue(reduced ? 1 : 0);
  const fw = useSharedValue(0);
  const started = useSharedValue(reduced);

  useAnimatedReaction(
    () => section.value > 0.05,
    (go) => {
      if (!go || started.value) return;
      started.value = true;
      g.value = withDelay(180 + index * 90, withTiming(1, { duration: 760, easing: Easing.out(Easing.cubic) }));
    },
  );

  const fill = useAnimatedStyle(() => ({
    opacity: fw.value > 0 ? 1 : 0,
    transform: [{ translateX: (g.value - 1) * fw.value }],
  }));

  const value = row.value ?? 0;
  const known = row.value !== undefined;
  const pct = known ? Math.max(value > 0 ? 0.025 : 0, Math.min(1, value / row.max)) : 0;
  const refPct = row.ref !== undefined ? Math.min(1, row.ref / row.max) : null;
  const over = known && row.ref !== undefined && value >= row.ref;
  const color = row.kind === 'limit' ? (over ? palette.tangerine : palette.mint) : over ? palette.great : palette.sky;
  const tag = over ? (row.kind === 'limit' ? t.tagHigh : row.goodTag) : undefined;

  return (
    <View style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
        <Txt variant="bodyStrong" style={{ flex: 1 }}>
          {row.label}
        </Txt>
        {tag ? (
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 4,
              paddingHorizontal: 8,
              paddingVertical: 2,
              borderRadius: radius.pill,
              backgroundColor: alpha(color, isDark ? 0.24 : 0.2),
            }}
          >
            <Icon name={row.kind === 'limit' ? 'triangle-alert' : 'leaf'} size={11} color={c.text} />
            <Txt variant="tiny">{tag}</Txt>
          </View>
        ) : null}
        <Txt variant="bodyStrong" muted={!known} style={{ minWidth: 52, textAlign: 'right' }}>
          {known ? `${num(value, lang)}\u00a0g` : lt.unknownValue}
        </Txt>
      </View>
      <View style={{ height: 16, justifyContent: 'center' }}>
        <View style={{ height: 10, borderRadius: 5, backgroundColor: isDark ? 'rgba(255,255,255,0.07)' : c.bgAlt, overflow: 'hidden' }}>
          <Animated.View
            onLayout={(e) => fw.set(e.nativeEvent.layout.width)}
            style={[{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${pct * 100}%`, borderRadius: 5, backgroundColor: color }, fill]}
          />
        </View>
        {refPct !== null ? (
        <View
          style={{
            position: 'absolute',
            left: `${refPct * 100}%`,
            top: 0,
            bottom: 0,
            width: 2,
            marginLeft: -1,
            borderRadius: 1,
            backgroundColor: c.text,
            opacity: 0.55,
          }}
        />
        ) : null}
      </View>
    </View>
  );
}

const NOVA_COLORS = [palette.great, palette.limeDeep, palette.sun, palette.tangerine] as const;

function NovaTile({ nova }: { nova: 1 | 2 | 3 | 4 | undefined }) {
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const { c, isDark } = useTheme();
  if (nova === undefined) {
    return (
      <Card style={{ flex: 1, gap: space.sm }}>
        <Txt variant="tiny" muted upper>
          {t.novaTitle}
        </Txt>
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 5, height: 40 }}>
          {[1, 2, 3, 4].map((n) => (
            <View
              key={n}
              style={{ flex: 1, height: 16 + n * 6, borderRadius: 8, borderWidth: 1.5, borderStyle: 'dashed', borderColor: c.textFaint, opacity: 0.6 }}
            />
          ))}
        </View>
        <View>
          <Txt variant="bodyStrong">NOVA ?</Txt>
          <Txt variant="small" muted numberOfLines={2}>
            {lt.novaUnknown}
          </Txt>
        </View>
      </Card>
    );
  }
  return (
    <Card style={{ flex: 1, gap: space.sm }}>
      <Txt variant="tiny" muted upper>
        {t.novaTitle}
      </Txt>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 5, height: 40 }} accessible accessibilityLabel={`NOVA ${nova}: ${t.nova[nova]}`}>
        {[1, 2, 3, 4].map((n) => {
          const on = n <= nova;
          const current = n === nova;
          return (
            <View
              key={n}
              style={{
                flex: 1,
                height: 16 + n * 6,
                borderRadius: 8,
                backgroundColor: on ? NOVA_COLORS[n - 1] : isDark ? 'rgba(255,255,255,0.07)' : c.bgAlt,
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: current ? 2 : 0,
                borderColor: c.text,
              }}
            >
              <Txt variant="tiny" color={on ? palette.ink : c.textFaint}>
                {n}
              </Txt>
            </View>
          );
        })}
      </View>
      <View>
        <Txt variant="bodyStrong">NOVA {nova}</Txt>
        <Txt variant="small" muted numberOfLines={2}>
          {t.nova[nova]}
        </Txt>
      </View>
    </Card>
  );
}

const LIQUID_TAGS = /^en:(beverages|milks|cow-milks|goat-milks|plant-based-milk-alternatives|waters|juices|fruit-juices|sodas|drinks|.*-drinks|.*-beverages)$/;

/** True when the values are per 100 ml: a pack in l/ml/cl/dl, a drink, or a milk. */
export function isLiquid(product: Product): boolean {
  if (/\d\s*(?:ml|cl|dl|l)\b/i.test(product.size)) return true;
  if (/\d\s*(?:kg|g)\b/i.test(product.size)) return false;
  return product.category === 'drinks' || (product.real?.categoryTags ?? []).some((c) => LIQUID_TAGS.test(c));
}

/** Per 100 g (or 100 ml): energy as a big number, the NOVA group as a stepper, and five bars with a reference mark. */
export function Nutrition({ product }: { product: Product }) {
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const lang = useLang();
  const n = product.nutrition;
  const kcal = n.energyKcal;
  const kj = kcal !== undefined ? Math.round(kcal * 4.184) : undefined;
  // EU "source of protein": at least 12% of the energy from protein (4 kcal per gram).
  const proteinRef = kcal !== undefined ? Math.max(1, Math.round(((kcal * 0.12) / 4) * 10) / 10) : undefined;
  const nothing = Object.values(n).every((v) => v === undefined);
  const grade = product.real?.nutriscore;
  const per100 = isLiquid(product) ? t.per100ml : t.per100;
  const rows: Row[] = [
    { key: 'sugarG', label: t.nutrient.sugar, value: n.sugarG, max: 50, ref: 22.5, kind: 'limit' },
    { key: 'satFatG', label: t.nutrient.satFat, value: n.satFatG, max: 20, ref: 5, kind: 'limit' },
    { key: 'saltG', label: t.nutrient.salt, value: n.saltG, max: 3, ref: 1.5, kind: 'limit' },
    { key: 'fiberG', label: t.nutrient.fiber, value: n.fiberG, max: 15, ref: 6, kind: 'good', goodTag: t.tagRich },
    { key: 'proteinG', label: t.nutrient.protein, value: n.proteinG, max: 30, ref: proteinRef, kind: 'good', goodTag: t.tagSource },
  ];

  return (
    <View style={{ gap: space.md }}>
      <View style={{ flexDirection: 'row', gap: space.md }}>
        <Card style={{ flex: 1, gap: 2 }}>
          <Txt variant="tiny" muted upper>
            {t.energy}
          </Txt>
          <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 4, marginTop: 4 }}>
            <Txt variant="hero" muted={kcal === undefined}>
              {kcal !== undefined ? num(kcal, lang) : lt.unknownValue}
            </Txt>
            <Txt variant="bodyStrong" muted>
              kcal
            </Txt>
          </View>
          <Txt variant="small" faint>
            {kj !== undefined ? `${groupDigits(kj, lang === 'hu' ? '\u00a0' : ',')}\u00a0kJ · ${per100}` : per100}
          </Txt>
        </Card>
        <NovaTile nova={product.nova} />
      </View>
      {grade ? <NutriScoreCard grade={grade} /> : null}
      {nothing ? (
        <Card>
          <Txt variant="body" muted>
            {lt.noNutrition}
          </Txt>
        </Card>
      ) : (
        <Card style={{ gap: space.lg }}>
          {rows.map((r, i) => (
            <Bar key={r.key} row={r} index={i} />
          ))}
          <Txt variant="small" faint>
            {t.nutritionLegend}
          </Txt>
        </Card>
      )}
    </View>
  );
}
