import { useEffect, useId, useState } from 'react';
import { View } from 'react-native';
import Svg, { Circle, Defs, LinearGradient, Stop } from 'react-native-svg';

import { Txt, useTheme } from '@/ui';
import { alpha, mix } from './format';

type Props = {
  score: number;
  color: string;
  size?: number;
  stroke?: number;
  /** Start after this many ms. */
  delay?: number;
  reduced?: boolean;
  onDone?: () => void;
};

/** A ring that fills and counts up to the score. Driven by one short rAF loop, cheap on every platform. */
export function ScoreRing({ score, color, size = 124, stroke = 12, delay = 350, reduced = false, onDone }: Props) {
  const { c } = useTheme();
  const gradId = `ring${useId().replace(/[^a-zA-Z0-9_-]/g, '')}`;
  const [value, setValue] = useState(reduced ? score : 0);

  useEffect(() => {
    if (reduced) {
      onDone?.();
      return;
    }
    let raf = 0;
    let start = 0;
    const timer = setTimeout(() => {
      const step = (now: number) => {
        if (!start) start = now;
        const t = Math.min(1, (now - start) / 1150);
        const eased = 1 - Math.pow(1 - t, 3);
        setValue(score * eased);
        if (t < 1) raf = requestAnimationFrame(step);
        else onDone?.();
      };
      raf = requestAnimationFrame(step);
    }, delay);
    return () => {
      clearTimeout(timer);
      cancelAnimationFrame(raf);
    };
    // onDone is a fire-and-forget callback; restarting the count for a new identity would replay it.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [score, reduced, delay]);

  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const shown = reduced ? score : value;
  const offset = circ * (1 - Math.max(0, Math.min(100, shown)) / 100);

  return (
    <View style={{ width: size, height: size }} accessible accessibilityLabel={`${score}/100`}>
      <View style={{ position: 'absolute', inset: 0, transform: [{ rotate: '-90deg' }] }}>
        <Svg width={size} height={size}>
          <Defs>
            <LinearGradient id={gradId} x1="0" y1="0" x2="1" y2="1">
              <Stop offset="0" stopColor={mix(color, '#FFFFFF', 0.35)} />
              <Stop offset="1" stopColor={color} />
            </LinearGradient>
          </Defs>
          <Circle cx={size / 2} cy={size / 2} r={r} stroke={alpha(color, 0.16)} strokeWidth={stroke} fill="none" />
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={r - stroke / 2 - 5}
            stroke={c.border}
            strokeWidth={1}
            strokeDasharray="2 5"
            fill="none"
          />
          {shown > 0.5 ? (
            <Circle
              cx={size / 2}
              cy={size / 2}
              r={r}
              stroke={`url(#${gradId})`}
              strokeWidth={stroke}
              strokeLinecap="round"
              strokeDasharray={`${circ} ${circ}`}
              strokeDashoffset={offset}
              fill="none"
            />
          ) : null}
        </Svg>
      </View>
      <View style={{ position: 'absolute', inset: 0, alignItems: 'center', justifyContent: 'center' }}>
        <Txt variant="number" style={{ fontSize: size * 0.3, lineHeight: size * 0.32 }}>
          {Math.round(shown)}
        </Txt>
        <Txt variant="tiny" faint>
          /100
        </Txt>
      </View>
    </View>
  );
}
