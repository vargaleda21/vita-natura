import { LinearGradient } from 'expo-linear-gradient';
import { useState } from 'react';
import { View } from 'react-native';

import type { MatchResult } from '@/data/types';
import { unknownNames } from '@/features/lookup/RealFacts';
import { strings as lookupStrings } from '@/features/lookup/strings';
import { useT, useTr } from '@/i18n';
import { palette, radius, shadow, space, verdictColor } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme, VerdictBadge } from '@/ui';
import { Burst } from './Burst';
import { alpha } from './format';
import { useReduced } from './reveal';
import { ScoreRing } from './ScoreRing';
import { strings } from './strings';

type Props = {
  result: MatchResult;
  /** The ingredients were read off a photo by machine (no source typed them). */
  fromPhoto?: boolean;
  onSeeBetter?: () => void;
};

/** The heart of the page: the score ring, the personal verdict, and "3/4 fine by your settings". */
export function ScoreCard({ result, fromPhoto, onSeeBetter }: Props) {
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const reduced = useReduced();
  const [done, setDone] = useState(false);
  const color = verdictColor[result.verdict];
  const unknown = result.unknown?.length ?? 0;
  // Nothing found, but part of the list could not be checked: say exactly which part.
  const partial = result.hits.length === 0 && unknown > 0;
  const failing = result.total - result.matched - unknown;

  return (
    <View
      style={[
        {
          borderRadius: radius.xl,
          backgroundColor: c.surface,
          borderWidth: isDark ? 1 : 0,
          borderColor: c.border,
          padding: space.lg,
          zIndex: 5,
        },
        isDark ? null : shadow.card,
      ]}
    >
      <LinearGradient
        colors={[alpha(color, isDark ? 0.2 : 0.16), alpha(color, 0)]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0.8, y: 0.9 }}
        style={{ position: 'absolute', inset: 0, borderRadius: radius.xl }}
        pointerEvents="none"
      />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg }}>
        <View>
          <ScoreRing score={result.score} color={color} reduced={reduced} onDone={() => setDone(true)} />
          <Burst fire={done && result.verdict === 'great'} reduced={reduced} />
        </View>
        <View style={{ flex: 1, gap: 6 }}>
          <VerdictBadge verdict={result.verdict} />
          <Txt variant="h2" accessibilityRole="header">
            {partial ? lt.partHeadline : t.headline[result.verdict]}
          </Txt>
          <Txt variant="small" muted>
            {partial ? lt.partSub(unknownNames(result, tr)) : t.verdictSub(result.verdict, result.hits.length)}
          </Txt>
        </View>
      </View>

      <View style={{ height: 1, backgroundColor: c.border, marginVertical: space.lg }} />

      <View style={{ gap: space.sm }}>
        <View style={{ flexDirection: 'row', gap: 4 }}>
          {Array.from({ length: result.total }, (_, i) => (
            <View
              key={i}
              style={{
                flex: 1,
                height: 8,
                borderRadius: 4,
                backgroundColor: i < result.matched ? verdictColor.great : i < result.matched + failing ? verdictColor.avoid : c.textFaint,
                opacity: i < result.matched ? 1 : i < result.matched + failing ? 0.85 : 0.35,
              }}
            />
          ))}
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Icon name="shield-check" size={16} color={c.textMuted} />
          <Txt variant="bodyStrong" style={{ flex: 1 }}>
            {t.matched(result.matched, result.total)}
            {unknown > 0 ? (
              <Txt variant="small" muted>
                {` · ${lt.unknownLine(unknown)}`}
              </Txt>
            ) : null}
          </Txt>
        </View>
        {fromPhoto ? (
          <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 6 }}>
            <Icon name="scan-text" size={16} color={c.textMuted} />
            <Txt variant="small" muted style={{ flex: 1 }}>
              {lt.scoreFromPhoto}
            </Txt>
          </View>
        ) : null}
      </View>

      {onSeeBetter ? (
        <PressableScale
          onPress={onSeeBetter}
          accessibilityRole="button"
          accessibilityLabel={t.seeBetter}
          style={{
            marginTop: space.lg,
            minHeight: 48,
            borderRadius: radius.pill,
            backgroundColor: palette.lime,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: space.sm,
            paddingHorizontal: space.lg,
          }}
        >
          <Icon name="sparkles" size={18} color={palette.ink} />
          <Txt variant="bodyStrong" color={palette.ink}>
            {t.seeBetter}
          </Txt>
          <Icon name="arrow-right" size={18} color={palette.ink} />
        </PressableScale>
      ) : null}
    </View>
  );
}
