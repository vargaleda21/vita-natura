import { router } from 'expo-router';
import { View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useT } from '@/i18n';
import { palette, radius, space } from '@/theme/tokens';
import { Icon, PackArt, PressableScale, Txt, useTheme } from '@/ui';
import { strings } from './strings';

/** A friendly empty state, e.g. after a reload on an AI-read product that was only kept in memory. */
export function NotFound() {
  const t = useT(strings);
  const { c } = useTheme();
  const insets = useSafeAreaInsets();
  return (
    <View style={{ flex: 1, backgroundColor: c.bg, alignItems: 'center' }}>
      <View
        style={{
          flex: 1,
          width: '100%',
          maxWidth: 480,
          paddingTop: insets.top + space.xxxl,
          paddingBottom: insets.bottom + space.xl,
          paddingHorizontal: space.xxl,
          alignItems: 'center',
          justifyContent: 'center',
          gap: space.lg,
        }}
      >
        <View style={{ width: 180, height: 180, borderRadius: 90, backgroundColor: c.bgAlt, alignItems: 'center', justifyContent: 'center' }}>
          <PackArt art={{ colors: ['#8A9A92', '#D9E2DC'], emoji: '❔', shape: 'box' }} size={120} />
        </View>
        <Txt variant="h1" center accessibilityRole="header">
          {t.notFoundTitle}
        </Txt>
        <Txt variant="body" muted center>
          {t.notFoundBody}
        </Txt>
        <PressableScale
          onPress={() => router.replace('/scan')}
          accessibilityRole="button"
          accessibilityLabel={t.rescan}
          haptic="medium"
          style={{
            marginTop: space.md,
            minHeight: 54,
            alignSelf: 'stretch',
            borderRadius: radius.pill,
            backgroundColor: palette.lime,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: space.sm,
          }}
        >
          <Icon name="scan-barcode" size={20} color={palette.ink} />
          <Txt variant="bodyStrong" color={palette.ink}>
            {t.rescan}
          </Txt>
        </PressableScale>
        <PressableScale
          onPress={() => router.replace('/')}
          accessibilityRole="button"
          accessibilityLabel={t.goHome}
          style={{ minHeight: 44, justifyContent: 'center', paddingHorizontal: space.lg }}
        >
          <Txt variant="bodyStrong" muted>
            {t.goHome}
          </Txt>
        </PressableScale>
      </View>
    </View>
  );
}
