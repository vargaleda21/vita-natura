import { createContext, use, type ReactNode } from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import Animated, {
  Easing,
  useAnimatedReaction,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';

// Sections fade and rise in when they enter the viewport. The ones visible on mount stagger in.
// Children can read the section's progress (0 → 1) to start their own animations (bars, rings).

type Ctx = {
  scrollY: SharedValue<number>;
  viewportH: number;
  /** Where the sheet starts inside the scroll content. */
  offsetTop: number;
  reduced: boolean;
};

const RevealCtx = createContext<Ctx | null>(null);
const ProgressCtx = createContext<SharedValue<number> | null>(null);

export function RevealProvider({ value, children }: { value: Ctx; children: ReactNode }) {
  return <RevealCtx value={value}>{children}</RevealCtx>;
}

export function useReduced(): boolean {
  return use(RevealCtx)?.reduced ?? false;
}

/** The enclosing section's reveal progress. Outside a section it is already 1. */
export function useSectionProgress(): SharedValue<number> {
  const fallback = useSharedValue(1);
  return use(ProgressCtx) ?? fallback;
}

type Props = {
  index: number;
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
  /** Reports the block's top inside the scroll content (for scroll-to). */
  onY?: (y: number) => void;
};

export function Reveal({ index, children, style, onY }: Props) {
  const ctx = use(RevealCtx);
  const reduced = ctx?.reduced ?? false;
  const scrollY = useSharedValue(0);
  const sy = ctx?.scrollY ?? scrollY;
  const viewportH = ctx?.viewportH ?? 800;
  const offsetTop = ctx?.offsetTop ?? 0;
  const y = useSharedValue(-1);
  const p = useSharedValue(reduced ? 1 : 0);
  const started = useSharedValue(reduced);

  useAnimatedReaction(
    () => y.value >= 0 && sy.value + viewportH > y.value + 24,
    (visible) => {
      if (!visible || started.value) return;
      started.value = true;
      const delay = sy.value < 8 ? 90 + index * 80 : 0;
      p.value = withDelay(delay, withTiming(1, { duration: 520, easing: Easing.out(Easing.cubic) }));
    },
  );

  const anim = useAnimatedStyle(() => ({
    opacity: p.value,
    transform: [{ translateY: (1 - p.value) * 26 }],
  }));

  return (
    <ProgressCtx value={p}>
      <Animated.View
        onLayout={(e) => {
          const top = offsetTop + e.nativeEvent.layout.y;
          y.set(top);
          onY?.(top);
        }}
        style={[style, anim]}
      >
        {children}
      </Animated.View>
    </ProgressCtx>
  );
}
