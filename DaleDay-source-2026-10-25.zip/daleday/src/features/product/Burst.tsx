import { useEffect } from 'react';
import { View } from 'react-native';
import Animated, { Easing, useAnimatedStyle, useSharedValue, withDelay, withTiming, type SharedValue } from 'react-native-reanimated';

import { palette } from '@/theme/tokens';

const COLORS = [palette.lime, palette.sun, palette.tangerine, palette.lilac, palette.sky, palette.mint, palette.great];
const N = 26;

function Piece({ p, i }: { p: SharedValue<number>; i: number }) {
  // Deterministic "random" spread, so renders stay pure.
  const angle = (i / N) * Math.PI * 2 + ((i * 7) % 5) * 0.09;
  const dist = 64 + ((i * 37) % 58);
  const spin = ((i * 53) % 540) - 270;
  const kind = i % 3; // 0 dot, 1 strip, 2 square
  const w = kind === 1 ? 5 : 8;
  const h = kind === 1 ? 12 : 8;
  const color = COLORS[i % COLORS.length];
  const style = useAnimatedStyle(() => {
    const t = p.value;
    const x = Math.cos(angle) * dist * t;
    const y = Math.sin(angle) * dist * t + 46 * t * t;
    return {
      opacity: t <= 0.01 ? 0 : t < 0.65 ? 1 : Math.max(0, 1 - (t - 0.65) / 0.35),
      transform: [{ translateX: x }, { translateY: y }, { rotate: `${spin * t}deg` }, { scale: 1.1 - 0.5 * t }],
    };
  });
  return (
    <Animated.View
      style={[
        { position: 'absolute', left: -w / 2, top: -h / 2, width: w, height: h, borderRadius: kind === 0 ? 4 : 2, backgroundColor: color },
        style,
      ]}
    />
  );
}

/** A one-shot confetti burst from a point. Transforms and opacity only. Renders nothing when `fire` is false. */
export function Burst({ fire, reduced }: { fire: boolean; reduced: boolean }) {
  const p = useSharedValue(0);
  const ring = useSharedValue(0);

  useEffect(() => {
    if (!fire || reduced) return;
    p.set(withTiming(1, { duration: 1400, easing: Easing.out(Easing.quad) }));
    ring.set(withDelay(40, withTiming(1, { duration: 700, easing: Easing.out(Easing.cubic) })));
  }, [fire, reduced, p, ring]);

  const ringStyle = useAnimatedStyle(() => ({
    opacity: ring.value <= 0.01 ? 0 : 0.7 * (1 - ring.value),
    transform: [{ scale: 0.6 + ring.value * 0.9 }],
  }));

  if (!fire || reduced) return null;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: '50%', top: '50%', width: 0, height: 0 }}>
      <Animated.View
        style={[
          { position: 'absolute', left: -70, top: -70, width: 140, height: 140, borderRadius: 70, borderWidth: 3, borderColor: palette.great },
          ringStyle,
        ]}
      />
      {Array.from({ length: N }, (_, i) => (
        <Piece key={i} p={p} i={i} />
      ))}
    </View>
  );
}
