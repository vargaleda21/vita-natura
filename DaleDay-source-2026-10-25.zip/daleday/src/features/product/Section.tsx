import type { ReactNode } from 'react';
import { View, type StyleProp, type ViewStyle } from 'react-native';

import { space } from '@/theme/tokens';
import { Icon, Txt, useTheme } from '@/ui';
import { Reveal } from './reveal';

type Props = {
  index: number;
  title?: string;
  subtitle?: string;
  icon?: string;
  right?: ReactNode;
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
  onY?: (y: number) => void;
};

/** A titled block of the product page that reveals itself as it scrolls into view. */
export function Section({ index, title, subtitle, icon, right, children, style, onY }: Props) {
  const { c } = useTheme();
  return (
    <Reveal index={index} onY={onY} style={[{ marginTop: space.xxl }, style]}>
      {title ? (
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: space.md, marginBottom: space.md }}>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
              {icon ? <Icon name={icon} size={18} color={c.textMuted} /> : null}
              <Txt variant="h2" accessibilityRole="header">
                {title}
              </Txt>
            </View>
            {subtitle ? (
              <Txt variant="small" muted style={{ marginTop: 4 }}>
                {subtitle}
              </Txt>
            ) : null}
          </View>
          {right}
        </View>
      ) : null}
      {children}
    </Reveal>
  );
}
