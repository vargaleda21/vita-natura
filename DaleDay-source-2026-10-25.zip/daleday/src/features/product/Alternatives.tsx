import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Linking, Platform, ScrollView, View, type ViewStyle } from 'react-native';

import { cheapestPrice, getStore, localSize } from '@/data/api';
import type { Alternative } from '@/data/types';
import { ExtLink, NutriScore, ProductPhoto } from '@/features/lookup/bits';
import { strings as lookupStrings } from '@/features/lookup/strings';
import { formatHuf, useLang, useT, useTr } from '@/i18n';
import { font, palette, radius, shadow, space } from '@/theme/tokens';
import { Card, Icon, PressableScale, Txt, useTheme, VerdictBadge } from '@/ui';
import { mix } from './format';
import { strings } from './strings';

const CARD_W = 256;
const GAP = 12;
const PAD = space.xl;

// CSS scroll snapping for the web; native uses snapToInterval.
const webSnap = (Platform.OS === 'web' ? { scrollSnapType: 'x mandatory', scrollPaddingInline: `${PAD}px` } : {}) as ViewStyle;
const webSnapItem = (Platform.OS === 'web' ? { scrollSnapAlign: 'start' } : {}) as ViewStyle;

function AltCard({ alt, onSwap }: { alt: Alternative; onSwap: (alt: Alternative) => void }) {
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const tr = useTr();
  const lang = useLang();
  const { c, isDark } = useTheme();
  const p = alt.product;
  const [c0, c1] = p.art.colors;
  const saving = alt.sameStore && alt.savingHuf && alt.savingHuf > 0 ? alt.savingHuf : 0;
  const affiliate = p.affiliate ? getStore(p.affiliate.store) : undefined;
  const cheapest = cheapestPrice(p);
  const sub = [p.brand, localSize(p.size, lang)].filter(Boolean).join(' · ');
  const inHungary = p.real?.countries.some((x) => x.iso2 === 'HU');

  return (
    <View
      style={[
        {
          width: CARD_W,
          borderRadius: radius.xl,
          backgroundColor: c.surface,
          borderWidth: isDark ? 1 : 0,
          borderColor: c.border,
        },
        isDark ? null : shadow.card,
        webSnapItem,
      ]}
    >
      <PressableScale
        onPress={() => router.push(`/product/${p.ean}`)}
        accessibilityRole="button"
        accessibilityLabel={`${tr(p.name)}, ${p.brand}`}
        scaleTo={0.98}
      >
        <LinearGradient
          colors={isDark ? [mix(c1, palette.night, 0.55), mix(c0, palette.night, 0.7)] : [mix(c1, palette.white, 0.7), mix(c0, palette.white, 0.55)]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            height: 140,
            borderTopLeftRadius: radius.xl,
            borderTopRightRadius: radius.xl,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <ProductPhoto uri={p.real?.imageSmallUrl ?? p.real?.imageUrl} art={p.art} size={112} label={lt.photoAlt(tr(p.name))} />
          <View style={{ position: 'absolute', top: space.md, left: space.md }}>
            <VerdictBadge verdict={alt.result.verdict} score={alt.result.score} />
          </View>
          {p.real?.nutriscore ? (
            <View style={{ position: 'absolute', bottom: space.sm, right: space.sm }}>
              <NutriScore grade={p.real.nutriscore} small />
            </View>
          ) : null}
        </LinearGradient>
        <View style={{ paddingHorizontal: space.lg, paddingTop: space.md, gap: 4 }}>
          <Txt variant="bodyStrong" numberOfLines={2} style={{ minHeight: 44 }}>
            {tr(p.name)}
          </Txt>
          {sub ? (
            <Txt variant="small" muted numberOfLines={1}>
              {sub}
            </Txt>
          ) : null}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 }}>
            <Icon name="check" size={14} color={palette.great} strokeWidth={3} />
            <Txt variant="small" muted style={{ flex: 1 }} numberOfLines={3}>
              {tr(alt.reason)}
            </Txt>
          </View>
          {inHungary ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <Icon name="store" size={14} color={c.textMuted} />
              <Txt variant="small" muted>
                {lt.altHungary}
              </Txt>
            </View>
          ) : null}
        </View>
      </PressableScale>

      <View style={{ marginTop: 'auto', paddingHorizontal: space.lg, paddingBottom: space.lg, paddingTop: space.md, gap: space.sm }}>
        {alt.chainSaving ? (
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              paddingHorizontal: 10,
              paddingVertical: 6,
              borderRadius: radius.md,
              backgroundColor: isDark ? 'rgba(198,243,107,0.1)' : 'rgba(198,243,107,0.35)',
            }}
          >
            <Icon name="trending-down" size={15} color={isDark ? palette.lime : palette.forest} />
            <View style={{ flex: 1 }}>
              <Txt variant="small" style={{ fontFamily: font.bodyBold }}>
                {lt.altSaving(alt.chainSaving.chain, formatHuf(alt.chainSaving.savingHuf, lang))}
              </Txt>
              <Txt variant="tiny" muted>
                {lt.attrAr}
              </Txt>
            </View>
          </View>
        ) : alt.chainPrice ? (
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              paddingHorizontal: 10,
              paddingVertical: 6,
              borderRadius: radius.md,
              backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
            }}
          >
            <Icon name="tag" size={15} color={c.textMuted} />
            <View style={{ flex: 1 }}>
              <Txt variant="small" style={{ fontFamily: font.bodyBold }}>
                {t.fromPrice(formatHuf(alt.chainPrice.priceHuf, lang))}
              </Txt>
              <Txt variant="tiny" muted>
                {alt.chainPrice.chain} · {lt.attrAr}
              </Txt>
            </View>
          </View>
        ) : saving > 0 && alt.sameStore ? (
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              paddingHorizontal: 10,
              paddingVertical: 6,
              borderRadius: radius.md,
              backgroundColor: isDark ? 'rgba(198,243,107,0.1)' : 'rgba(198,243,107,0.35)',
            }}
          >
            <Icon name="trending-down" size={15} color={isDark ? palette.lime : palette.forest} />
            <View style={{ flex: 1 }}>
              <Txt variant="small" style={{ fontFamily: font.bodyBold }}>
                {t.sameStoreCheaper(formatHuf(saving, lang))}
              </Txt>
              <Txt variant="tiny" muted>
                {getStore(alt.sameStore).name}
              </Txt>
            </View>
          </View>
        ) : cheapest ? (
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              paddingHorizontal: 10,
              paddingVertical: 6,
              borderRadius: radius.md,
              backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
            }}
          >
            <Icon name="tag" size={15} color={c.textMuted} />
            <View style={{ flex: 1 }}>
              <Txt variant="small" style={{ fontFamily: font.bodyBold }}>
                {t.fromPrice(formatHuf(cheapest.priceHuf, lang))}
              </Txt>
              <Txt variant="tiny" muted>
                {getStore(cheapest.store).name}
              </Txt>
            </View>
          </View>
        ) : null}
        {affiliate && p.affiliate ? (
          <PressableScale
            onPress={() => void Linking.openURL(p.affiliate?.url ?? '')}
            accessibilityRole="link"
            accessibilityLabel={t.orderable(affiliate.name)}
            hitSlop={8}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', paddingVertical: 4 }}
          >
            <Icon name="shopping-basket" size={14} color={c.textMuted} />
            <Txt variant="small" muted style={{ textDecorationLine: 'underline' }}>
              {t.orderable(affiliate.name)}
            </Txt>
          </PressableScale>
        ) : null}
        <PressableScale
          onPress={() => onSwap(alt)}
          haptic="medium"
          accessibilityRole="button"
          accessibilityLabel={t.swapA11y(tr(p.name))}
          style={{
            minHeight: 48,
            borderRadius: radius.pill,
            backgroundColor: palette.lime,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: space.sm,
          }}
        >
          <Icon name="arrow-left-right" size={18} color={palette.ink} />
          <Txt variant="bodyStrong" color={palette.ink}>
            {t.swap}
          </Txt>
        </PressableScale>
      </View>
    </View>
  );
}

/** "A better choice": a snap carousel ranked by score only, with the commission disclosure under it. */
export function Alternatives({ alternatives, onSwap, real }: { alternatives: Alternative[]; onSwap: (alt: Alternative) => void; real?: boolean }) {
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const { c, isDark } = useTheme();

  if (alternatives.length === 0) {
    return (
      <Card gradient={isDark ? ['#183C2C', '#13221C'] : ['#E4F8C8', '#D3F2E4']}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
          <View style={{ width: 46, height: 46, borderRadius: 16, backgroundColor: palette.sun, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="trophy" size={22} color={palette.ink} />
          </View>
          <View style={{ flex: 1 }}>
            <Txt variant="h3">{t.noAltTitle}</Txt>
            <Txt variant="small" muted>
              {t.noAltBody}
            </Txt>
          </View>
        </View>
      </Card>
    );
  }

  return (
    <View>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        snapToInterval={CARD_W + GAP}
        snapToAlignment="start"
        decelerationRate="fast"
        style={[{ marginHorizontal: -PAD }, webSnap]}
        contentContainerStyle={{ paddingHorizontal: PAD, paddingTop: 4, paddingBottom: space.xl, gap: GAP }}
      >
        {alternatives.map((a) => (
          <AltCard key={a.product.ean} alt={a} onSwap={onSwap} />
        ))}
      </ScrollView>
      <View
        style={{
          flexDirection: 'row',
          gap: space.sm,
          padding: space.md,
          borderRadius: radius.md,
          borderWidth: 1,
          borderColor: c.border,
          backgroundColor: isDark ? c.surfaceAlt : 'transparent',
        }}
      >
        <View style={{ marginTop: 1 }}>
          <Icon name={real ? 'globe' : 'badge-percent'} size={16} color={c.textMuted} />
        </View>
        <View style={{ flex: 1, gap: 4 }}>
          <Txt variant="small" muted>
            {real ? lt.altSource : t.disclosure}
          </Txt>
          {real ? <ExtLink label={lt.attrOff} url="https://world.openfoodfacts.org/" /> : null}
        </View>
      </View>
    </View>
  );
}
