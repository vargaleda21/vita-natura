import { LinearGradient } from 'expo-linear-gradient';
import type { ReactNode } from 'react';
import { View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedReaction,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withSpring,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';

import { localSize } from '@/data/api';
import type { Lang, Product, RecipeChange, RecipeChangeKind } from '@/data/types';
import { formatHuf, useLang, useT, useTr } from '@/i18n';
import { palette, radius, space, springs } from '@/theme/tokens';
import { Icon, PackArt, Txt, useTheme } from '@/ui';
import { monthYear, num, quantity } from './format';
import { useReduced, useSectionProgress } from './reveal';
import { strings } from './strings';

const KIND: Record<RecipeChangeKind, { color: string; icon: string }> = {
  size_down: { color: palette.sun, icon: 'scale' },
  recipe_worse: { color: palette.tangerine, icon: 'flask-conical' },
  recipe_better: { color: palette.lime, icon: 'sparkles' },
  price_up: { color: palette.lilac, icon: 'tag' },
};

const INK_SOFT = 'rgba(238,246,239,0.78)';
const INK_FAINT = 'rgba(238,246,239,0.5)';
const RAIL = 40;
const NODE = 36;

/** Each row slides in after the previous one once the section is revealed. */
function useStep(index: number) {
  const reduced = useReduced();
  const section = useSectionProgress();
  const s = useSharedValue(reduced ? 1 : 0);
  const started = useSharedValue(reduced);
  useAnimatedReaction(
    () => section.value > 0.1,
    (go) => {
      if (!go || started.value) return;
      started.value = true;
      s.value = withDelay(220 + index * 260, withSpring(1, springs.soft));
    },
  );
  return s;
}

function Pill({ text, bg, fg = palette.ink, strike }: { text: string; bg: string; fg?: string; strike?: boolean }) {
  return (
    <View style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: radius.pill, backgroundColor: bg }}>
      <Txt variant="small" color={fg} style={strike ? { textDecorationLine: 'line-through' } : undefined}>
        {text}
      </Txt>
    </View>
  );
}

function pct(x: number, lang: 'hu' | 'en'): string {
  return num(Math.round(x * 10) / 10, lang);
}

/** The new pack starts at the old size and shrinks to the new one: shrinkflation you can see. */
function Shrink({ product, size, ratio, delay }: { product: Product; size: number; ratio: number; delay: number }) {
  const reduced = useReduced();
  const section = useSectionProgress();
  const k = useSharedValue(reduced ? ratio : 1);
  const started = useSharedValue(reduced);
  useAnimatedReaction(
    () => section.value > 0.1,
    (go) => {
      if (!go || started.value) return;
      started.value = true;
      k.value = withDelay(delay, withSpring(ratio, springs.bouncy));
    },
  );
  const style = useAnimatedStyle(() => ({ transform: [{ scale: k.value }] }));
  return (
    <Animated.View style={[{ transformOrigin: 'bottom' }, style]}>
      <PackArt art={product.art} size={size} />
    </Animated.View>
  );
}

/** Before and after in the current language: the bilingual `values` when set, else the plain strings (a pack size). */
function sides(change: RecipeChange, lang: Lang): { was?: string; now?: string } {
  if (change.values) return { was: change.values.before[lang], now: change.values.after[lang] };
  return { was: change.before && localSize(change.before, lang), now: change.after && localSize(change.after, lang) };
}

function ChangeVisual({ change, product, index }: { change: RecipeChange; product: Product; index: number }) {
  const lang = useLang();
  const t = useT(strings);
  const { was, now } = sides(change, lang);
  const before = quantity(was);
  const after = quantity(now);

  if (change.kind === 'size_down' && before && after && before.unit === after.unit && after.value < before.value) {
    const ratio = after.value / before.value;
    const big = 78;
    const less = (1 - ratio) * 100;
    const perUnit = (before.value / after.value - 1) * 100;
    return (
      <View style={{ gap: space.md }}>
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: space.md }}>
          <View style={{ alignItems: 'center', gap: 4 }}>
            <View style={{ opacity: 0.5 }}>
              <PackArt art={product.art} size={big} />
            </View>
            <Txt variant="bodyStrong" color={INK_FAINT} style={{ textDecorationLine: 'line-through' }}>
              {was}
            </Txt>
          </View>
          <View style={{ paddingBottom: 34 }}>
            <Icon name="arrow-right" size={22} color={palette.sun} />
          </View>
          <View style={{ alignItems: 'center', gap: 4 }}>
            <Shrink product={product} size={big} ratio={ratio} delay={900 + index * 260} />
            <Txt variant="bodyStrong" color={palette.sun}>
              {now}
            </Txt>
          </View>
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
          <Pill text={t.shrinkStat(num(Math.round(less), lang))} bg={palette.sun} />
          {before.unit === 'g' || before.unit === 'ml' ? (
            <Pill text={t.perUnitStat(pct(perUnit, lang), before.unit === 'g' ? 'g' : 'ml')} bg="rgba(255,255,255,0.1)" fg={palette.white} />
          ) : null}
        </View>
      </View>
    );
  }

  // Words, decimals and prices come in both languages (`values`), so both sides show in Hungarian and English.
  if (!was || !now) return null;
  const color = KIND[change.kind].color;
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: space.sm }}>
      <Pill text={was} bg="rgba(255,255,255,0.1)" fg={INK_FAINT} strike />
      <Icon name="arrow-right" size={18} color={color} />
      <Pill text={now} bg={color} />
    </View>
  );
}

function Step({
  index,
  last,
  color,
  icon,
  children,
}: {
  index: number;
  last: boolean;
  color: string;
  icon?: string;
  children: ReactNode;
}) {
  const s = useStep(index);
  const row = useAnimatedStyle(() => ({ opacity: s.value, transform: [{ translateX: (1 - s.value) * -14 }] }));
  const node = useAnimatedStyle(() => ({ transform: [{ scale: 0.4 + 0.6 * s.value }] }));
  return (
    <Animated.View style={[{ flexDirection: 'row', gap: space.md }, row]}>
      <View style={{ width: RAIL, alignItems: 'center' }}>
        <Animated.View
          style={[
            {
              width: icon ? NODE : 18,
              height: icon ? NODE : 18,
              marginTop: icon ? 0 : 9,
              borderRadius: NODE / 2,
              backgroundColor: color,
              alignItems: 'center',
              justifyContent: 'center',
              borderWidth: 3,
              borderColor: 'rgba(255,255,255,0.18)',
            },
            node,
          ]}
        >
          {icon ? <Icon name={icon} size={17} color={palette.ink} /> : null}
        </Animated.View>
      </View>
      <View style={{ flex: 1, paddingBottom: last ? 0 : space.xxl, gap: space.sm }}>{children}</View>
    </Animated.View>
  );
}

function Rail({ progress }: { progress: SharedValue<number> }) {
  const style = useAnimatedStyle(() => ({ transform: [{ scaleY: progress.value }] }));
  return (
    <Animated.View
      style={[
        { position: 'absolute', left: RAIL / 2 - 1.5, top: NODE / 2, bottom: 18, width: 3, transformOrigin: 'top' },
        style,
      ]}
    >
      <LinearGradient colors={[palette.sun, palette.tangerine, palette.lime]} style={{ flex: 1, borderRadius: 2 }} />
    </Animated.View>
  );
}

/** The recipe's diary: shrinkflation and skimpflation, as a glowing timeline. */
export function RecipeHistory({ product, cheapestHuf }: { product: Product; cheapestHuf?: number }) {
  const t = useT(strings);
  const tr = useTr();
  const lang = useLang();
  const { isDark } = useTheme();
  const reduced = useReduced();
  const section = useSectionProgress();
  const rail = useSharedValue(reduced ? 1 : 0);
  const started = useSharedValue(reduced);
  const changes = [...(product.history ?? [])].sort((a, b) => a.date.localeCompare(b.date));

  useAnimatedReaction(
    () => section.value > 0.1,
    (go) => {
      if (!go || started.value) return;
      started.value = true;
      rail.value = withDelay(200, withTiming(1, { duration: 300 + changes.length * 260, easing: Easing.inOut(Easing.cubic) }));
    },
  );

  return (
    <View
      style={{
        borderRadius: radius.xl,
        overflow: 'hidden',
        borderWidth: isDark ? 1 : 0,
        borderColor: 'rgba(198,243,107,0.16)',
      }}
    >
      <LinearGradient
        colors={isDark ? ['#1A3A2C', '#0F2019'] : [palette.forest, palette.ink]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ padding: space.xl, gap: space.xl }}
      >
        {/* Soft glows, drawn with plain circles: no blur. */}
        <View style={{ position: 'absolute', right: -70, top: -80, width: 220, height: 220, borderRadius: 110, backgroundColor: 'rgba(255,201,61,0.10)' }} />
        <View style={{ position: 'absolute', right: -30, top: -40, width: 130, height: 130, borderRadius: 65, backgroundColor: 'rgba(255,201,61,0.08)' }} />
        <View style={{ position: 'absolute', left: -60, bottom: -90, width: 200, height: 200, borderRadius: 100, backgroundColor: 'rgba(198,243,107,0.06)' }} />

        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
          <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: palette.lime, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="history" size={22} color={palette.ink} />
          </View>
          <View style={{ flex: 1 }}>
            <Txt variant="h2" color={palette.white} accessibilityRole="header">
              {t.historyTitle}
            </Txt>
            <Txt variant="small" color={INK_SOFT}>
              {t.historySub}
            </Txt>
          </View>
        </View>

        <View>
          <Rail progress={rail} />
          {changes.map((ch, i) => (
            <Step key={`${ch.date}-${i}`} index={i} last={false} color={KIND[ch.kind].color} icon={KIND[ch.kind].icon}>
              <Txt variant="tiny" upper color={palette.lime}>
                {monthYear(ch.date, lang)}
              </Txt>
              <Txt variant="h3" color={palette.white}>
                {t.historyKind[ch.kind]}
              </Txt>
              <ChangeVisual change={ch} product={product} index={i} />
              <Txt variant="body" color={INK_SOFT}>
                {tr(ch.text)}
              </Txt>
            </Step>
          ))}
          <Step index={changes.length} last color={palette.lime}>
            <Txt variant="tiny" upper color={palette.lime} style={{ marginTop: 10 }}>
              {t.now}
            </Txt>
            <Txt variant="bodyStrong" color={palette.white}>
              {cheapestHuf !== undefined ? t.nowLine(localSize(product.size, lang), formatHuf(cheapestHuf, lang)) : localSize(product.size, lang)}
            </Txt>
          </Step>
        </View>
      </LinearGradient>
    </View>
  );
}
