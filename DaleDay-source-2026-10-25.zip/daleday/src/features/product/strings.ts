import type { DualQuality, RecipeChangeKind, Verdict } from '@/data/types';

type Strings = {
  back: string;
  share: string;
  shareText: (name: string) => string;
  linkCopied: string;
  notFoundTitle: string;
  notFoundBody: string;
  rescan: string;
  goHome: string;
  fromPrice: (price: string) => string;

  headline: Record<Verdict, string>;
  verdictSub: (verdict: Verdict, hits: number) => string;
  matched: (m: number, t: number) => string;
  seeBetter: string;

  whoTitle: string;
  whoSub: string;
  me: string;
  fitsMe: string;
  notForMe: string;
  fitsThem: string;
  notForThem: string;
  addFamily: string;

  hitsTitle: string;
  hitsSub: string;
  forWhom: string;
  foundIn: string;
  novaReason: string;
  saltReason: (grams: string) => string;
  source: (name: string) => string;
  openSource: (name: string) => string;
  noHitsTitle: string;
  noHitsBody: string;
  positivesTitle: string;

  ingredientsTitle: string;
  ingredientsHint: string;
  ingredientsAllClear: string;
  allergens: string;
  whyFlagged: string;

  nutritionTitle: string;
  per100: string;
  per100ml: string;
  energy: string;
  nutrient: { sugar: string; satFat: string; salt: string; fiber: string; protein: string };
  tagHigh: string;
  tagRich: string;
  tagSource: string;
  nutritionLegend: string;
  novaTitle: string;
  nova: Record<1 | 2 | 3 | 4, string>;

  historyTitle: string;
  historySub: string;
  historyKind: Record<RecipeChangeKind, string>;
  shrinkStat: (pct: string) => string;
  perUnitStat: (pct: string, unit: string) => string;
  now: string;
  nowLine: (size: string, price: string) => string;

  dualTitle: (country: string) => string;
  home: string;
  country: Record<DualQuality['country'], string>;
  dualVerdict: Record<DualQuality['verdict'], string>;
  sideHere: Record<DualQuality['verdict'], string>;
  sideThere: Record<DualQuality['verdict'], string>;
  dualNote: string;

  pricesTitle: string;
  pricesSub: string;
  cheapest: string;
  promo: string;
  online: string;
  saveLine: (amount: string, store: string) => string;
  priceNote: string;

  altTitle: string;
  altSub: string;
  sameStoreCheaper: (amount: string) => string;
  swap: string;
  swapA11y: (name: string) => string;
  orderable: (store: string) => string;
  disclosure: string;
  noAltTitle: string;
  noAltBody: string;
  swapToast: string;

  sourceTitle: string;
  sourceKind: Record<'community' | 'brand' | 'ai_label' | 'open_data', { title: string; body: string }>;
  updated: (date: string) => string;
  barcode: (ean: string) => string;
  allergenNote: string;
};

const hu: Strings = {
  back: 'Vissza',
  share: 'Megosztás',
  shareText: (name) => `Nézd, mit mond a DaleDay erről: ${name}`,
  linkCopied: 'Kimásoltuk a linket',
  notFoundTitle: 'Ezt a terméket most nem találjuk',
  notFoundBody:
    'Ha az AI olvasta le a címkéjét, és közben újratöltötted az oldalt, az adatai elvesztek. Szkenneld be újra, egy pillanat az egész.',
  rescan: 'Szkenneld be újra',
  goHome: 'Vissza a főoldalra',
  fromPrice: (price) => `${price}-tól`,

  headline: {
    great: 'Ez neked való!',
    okay: 'Majdnem neked való',
    avoid: 'Ebben van, amit kerülnél',
  },
  verdictSub: (verdict, hits) =>
    verdict === 'great'
      ? 'Semmi nincs benne abból, amit kerülni szeretnél.'
      : hits === 1
        ? 'Egy dolog van benne a listádról. Lent megmutatjuk, mi az.'
        : `A listádról ${hits} dolog is van benne. Lent megmutatjuk őket.`,
  matched: (m, t) => `A beállításaid szerint: ${m}/${t} rendben`,
  seeBetter: 'Mutasd a jobb választást',

  whoTitle: 'Kinek való?',
  whoSub: 'Egy szkennelés, az egész családnak.',
  me: 'Te',
  fitsMe: 'Rendben',
  notForMe: 'Kerülnéd',
  fitsThem: 'Rendben',
  notForThem: 'Kerülné',
  addFamily: 'Család',

  hitsTitle: 'Amit kerülni szeretnél',
  hitsSub: 'Nem mondjuk, hogy rossz. Csak jelezzük, mert ezt kérted.',
  forWhom: 'Kinek:',
  foundIn: 'Ebben találtuk:',
  novaReason: 'NOVA 4-es csoport',
  saltReason: (g) => `${g}\u00A0g só 100\u00A0g-ban`,
  source: (name) => `Forrás: ${name}`,
  openSource: (name) => `Forrás megnyitása: ${name}`,
  noHitsTitle: 'Nincs benne semmi, amit kerülnél',
  noHitsBody: 'Minden összetevőt átnéztünk a beállításaid szerint.',
  positivesTitle: 'Ami jó benne',

  ingredientsTitle: 'Összetevők',
  ingredientsHint: 'Koppints a kiemeltekre, és megmutatjuk, miért jelöltük.',
  ingredientsAllClear: 'Egyik összetevő sincs a listádon.',
  allergens: 'Allergének',
  whyFlagged: 'Miért jelöltük?',

  nutritionTitle: 'Tápérték',
  per100: '100\u00A0g-ban',
  per100ml: '100\u00A0ml-ben',
  energy: 'Energia',
  nutrient: { sugar: 'Cukor', satFat: 'Telített zsír', salt: 'Só', fiber: 'Rost', protein: 'Fehérje' },
  tagHigh: 'sok',
  tagRich: 'magas',
  tagSource: 'jó forrás',
  nutritionLegend:
    'A függőleges vonal a határérték. Cukor, telített zsír és só: a brit FSA „sok” szintje. Rost és fehérje: az uniós „magas rosttartalmú” és „fehérjeforrás” állítás küszöbe.',
  novaTitle: 'Feldolgozottság',
  nova: {
    1: 'Natúr, alig feldolgozott',
    2: 'Konyhai alapanyag',
    3: 'Feldolgozott',
    4: 'Ultrafeldolgozott',
  },

  historyTitle: 'Receptnapló',
  historySub: 'Amit a csomagolás nem mond el: így változott a termék.',
  historyKind: {
    size_down: 'Kisebb lett',
    recipe_worse: 'Más lett a recept',
    recipe_better: 'Jobb lett a recept',
    price_up: 'Drágább lett',
  },
  shrinkStat: (pct) => `${pct}%-kal kevesebb, ugyanannyiért`,
  perUnitStat: (pct, unit) => `${unit === 'g' ? 'Kilóra' : 'Literre'} vetítve ${pct}%-kal drágább`,
  now: 'Ma',
  nowLine: (size, price) => `Így kapod most: ${size}, ${price}-tól`,

  dualTitle: (country) => `Itthon vs. ${country}`,
  home: 'Itthon',
  country: { AT: 'Ausztria', DE: 'Németország', SK: 'Szlovákia', CZ: 'Csehország' },
  dualVerdict: {
    worse_here: 'Itthon gyengébb a recept',
    better_here: 'Itthon jobb a recept',
    different: 'Más a recept',
    same: 'Ugyanaz a recept',
  },
  sideHere: { worse_here: 'Gyengébb', better_here: 'Jobb', different: 'Más recept', same: 'Ugyanaz' },
  sideThere: { worse_here: 'Jobb', better_here: 'Gyengébb', different: 'Más recept', same: 'Ugyanaz' },
  dualNote: 'Ha ugyanaz a csomagolás indokolatlanul más receptet takar, az 2022 óta tilos az EU-ban.',

  pricesTitle: 'Hol mennyi?',
  pricesSub: 'A mai polcárak boltonként.',
  cheapest: 'legolcsóbb',
  promo: 'akciós',
  online: 'online',
  saveLine: (amount, store) => `${store}: ${amount}-tal olcsóbb, mint a legdrágább bolt.`,
  priceNote: 'A kész alkalmazásban az árak naponta frissülnek a GVH Árfigyelőből. Itt demóárakat látsz.',

  altTitle: 'Jobb választás',
  altSub: 'A sorrendet csak az dönti el, mennyire illik hozzád.',
  sameStoreCheaper: (amount) => `Ugyanott ${amount}-tal olcsóbb`,
  swap: 'Lecserélem',
  swapA11y: (name) => `Csere erre: ${name}`,
  orderable: (store) => `Rendelhető: ${store}`,
  disclosure: 'Ha partnerboltban vásárolsz, jutalékot kaphatunk. Ez soha nem befolyásolja a sorrendet.',
  noAltTitle: 'Ennél jobbat nem találtunk',
  noAltBody: 'Ebben a kategóriában ez illik hozzád a legjobban. Jó választás!',
  swapToast: 'Szép csere! Bekerült a havi történetedbe.',

  sourceTitle: 'Honnan tudjuk?',
  sourceKind: {
    community: { title: 'Közösségi adat', body: 'A DaleDay közössége vitte fel és ellenőrizte.' },
    brand: { title: 'Gyártói adat', body: 'Közvetlenül a gyártótól kaptuk.' },
    ai_label: { title: 'AI-címkeolvasás', body: 'Az AI olvasta le a címkéről. Érdemes a csomagolásra is rápillantani.' },
    open_data: {
      title: 'Nyílt adatbázisokból',
      body: 'A vonalkódja alapján kerestük ki. Amit egyik forrás sem tud, azt üresen hagyjuk, nem találjuk ki.',
    },
  },
  updated: (date) => `Frissítve: ${date}`,
  barcode: (ean) => `Vonalkód: ${ean}`,
  allergenNote: 'Allergéneknél mindig nézd meg a csomagolást is.',
};

const en: Strings = {
  back: 'Back',
  share: 'Share',
  shareText: (name) => `See what DaleDay says about ${name}`,
  linkCopied: 'Link copied',
  notFoundTitle: 'We can’t find this product right now',
  notFoundBody:
    'If AI read its label and you reloaded the page since, its data was lost. Scan it again; it only takes a moment.',
  rescan: 'Scan again',
  goHome: 'Back to home',
  fromPrice: (price) => `from ${price}`,

  headline: {
    great: 'This one’s for you!',
    okay: 'Mostly fine for you',
    avoid: 'It has something you avoid',
  },
  verdictSub: (verdict, hits) =>
    verdict === 'great'
      ? 'Nothing in it you asked to avoid.'
      : hits === 1
        ? 'It contains one thing from your list. See below.'
        : `It contains ${hits} things from your list. See below.`,
  matched: (m, t) => `Fits your settings: ${m}/${t}`,
  seeBetter: 'Show the better choice',

  whoTitle: 'Who is it for?',
  whoSub: 'One scan checks for the whole family.',
  me: 'You',
  fitsMe: 'Fine',
  notForMe: 'You avoid it',
  fitsThem: 'Fine',
  notForThem: 'Avoids it',
  addFamily: 'Family',

  hitsTitle: 'What you asked to avoid',
  hitsSub: 'We’re not saying it’s bad. You asked us to flag it.',
  forWhom: 'For:',
  foundIn: 'Found in:',
  novaReason: 'NOVA group 4',
  saltReason: (g) => `${g}\u00A0g of salt per 100\u00A0g`,
  source: (name) => `Source: ${name}`,
  openSource: (name) => `Open source: ${name}`,
  noHitsTitle: 'Nothing you avoid',
  noHitsBody: 'We checked every ingredient against your settings.',
  positivesTitle: 'The good bits',

  ingredientsTitle: 'Ingredients',
  ingredientsHint: 'Tap a highlighted one to see why we flagged it.',
  ingredientsAllClear: 'None of the ingredients is on your list.',
  allergens: 'Allergens',
  whyFlagged: 'Why flagged?',

  nutritionTitle: 'Nutrition',
  per100: 'per 100\u00A0g',
  per100ml: 'per 100\u00A0ml',
  energy: 'Energy',
  nutrient: { sugar: 'Sugar', satFat: 'Saturated fat', salt: 'Salt', fiber: 'Fibre', protein: 'Protein' },
  tagHigh: 'high',
  tagRich: 'rich',
  tagSource: 'good source',
  nutritionLegend:
    'The vertical line marks the threshold. Sugar, saturated fat and salt: the UK FSA “high” level. Fibre and protein: the EU “high fibre” and “source of protein” claim levels.',
  novaTitle: 'Processing',
  nova: {
    1: 'Minimally processed',
    2: 'Culinary ingredient',
    3: 'Processed',
    4: 'Ultra-processed',
  },

  historyTitle: 'Recipe history',
  historySub: 'What the pack won’t tell you: how this product changed.',
  historyKind: {
    size_down: 'Got smaller',
    recipe_worse: 'Recipe changed',
    recipe_better: 'Recipe improved',
    price_up: 'Price went up',
  },
  shrinkStat: (pct) => `${pct}% less for the same price`,
  perUnitStat: (pct, unit) => `${pct}% dearer per ${unit === 'g' ? 'kilo' : 'litre'}`,
  now: 'Today',
  nowLine: (size, price) => `What you get now: ${size}, from ${price}`,

  dualTitle: (country) => `Hungary vs. ${country}`,
  home: 'Hungary',
  country: { AT: 'Austria', DE: 'Germany', SK: 'Slovakia', CZ: 'Czechia' },
  dualVerdict: {
    worse_here: 'Weaker recipe here',
    better_here: 'Better recipe here',
    different: 'Different recipe',
    same: 'Same recipe',
  },
  sideHere: { worse_here: 'Weaker', better_here: 'Better', different: 'Different', same: 'Same' },
  sideThere: { worse_here: 'Better', better_here: 'Weaker', different: 'Different', same: 'Same' },
  dualNote: 'Since 2022, the EU has banned selling a different recipe in the same packaging without good reason.',

  pricesTitle: 'Compare prices',
  pricesSub: 'Today’s shelf prices, shop by shop.',
  cheapest: 'cheapest',
  promo: 'on offer',
  online: 'online',
  saveLine: (amount, store) => `${store}: ${amount} less than the dearest shop.`,
  priceNote: 'In the finished app, prices update daily from the GVH Árfigyelő price monitor. These are demo prices.',

  altTitle: 'A better choice',
  altSub: 'Ranked only by how well each one suits you.',
  sameStoreCheaper: (amount) => `${amount} cheaper in the same shop`,
  swap: 'Swap',
  swapA11y: (name) => `Swap for ${name}`,
  orderable: (store) => `Order from ${store}`,
  disclosure: 'If you buy from a partner shop, we may earn a commission. It never changes the ranking.',
  noAltTitle: 'Nothing better found',
  noAltBody: 'In this category, this one fits you best. Good pick!',
  swapToast: 'Nice swap! It’s in your monthly story now.',

  sourceTitle: 'How do we know?',
  sourceKind: {
    community: { title: 'Community data', body: 'Added and checked by the DaleDay community.' },
    brand: { title: 'From the brand', body: 'We got it straight from the maker.' },
    ai_label: { title: 'AI label reading', body: 'AI read it from the label. It’s worth a glance at the pack too.' },
    open_data: {
      title: 'From open databases',
      body: 'Looked up by its barcode. What no source knows, we leave blank – we never make it up.',
    },
  },
  updated: (date) => `Updated: ${date}`,
  barcode: (ean) => `Barcode: ${ean}`,
  allergenNote: 'For allergens, always check the pack too.',
};

export const strings = { hu, en };
