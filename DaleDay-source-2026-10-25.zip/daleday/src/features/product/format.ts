import type { Lang } from '@/data/types';

/** 10,6 in Hungarian, 10.6 in English; small values keep two decimals (0,05). */
export function num(n: number, lang: Lang): string {
  const digits = Math.abs(n) < 1 && n !== 0 ? 2 : 1;
  const s = Number.isInteger(n) ? String(n) : n.toFixed(digits).replace(/\.?0+$/, '');
  return lang === 'hu' ? s.replace('.', ',') : s;
}

const MONTHS: Record<Lang, string[]> = {
  hu: ['január', 'február', 'március', 'április', 'május', 'június', 'július', 'augusztus', 'szeptember', 'október', 'november', 'december'],
  en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
};

function parts(iso: string): { y: number; m: number; d: number } {
  const [y, m, d] = iso.split('-').map((x) => Number(x));
  return { y: y || 2026, m: Math.max(0, Math.min(11, (m || 1) - 1)), d: d || 1 };
}

/** "2025. március" / "March 2025". */
export function monthYear(iso: string, lang: Lang): string {
  const { y, m } = parts(iso);
  return lang === 'hu' ? `${y}. ${MONTHS.hu[m]}` : `${MONTHS.en[m]} ${y}`;
}

/** "2026. október 12." / "12 October 2026". */
export function fullDate(iso: string, lang: Lang): string {
  const { y, m, d } = parts(iso);
  return lang === 'hu' ? `${y}. ${MONTHS.hu[m]} ${d}.` : `${d} ${MONTHS.en[m]} ${y}`;
}

/** "450 g" → { value: 450, unit: 'g' }; undefined if it is not a quantity. */
export function quantity(s: string | undefined): { value: number; unit: string } | undefined {
  if (!s) return undefined;
  const m = /^\s*(\d+(?:[.,]\d+)?)\s*([a-zA-Z]+)\s*$/.exec(s);
  if (!m) return undefined;
  return { value: Number(m[1].replace(',', '.')), unit: m[2].toLowerCase() };
}

// Colour helpers for the stage gradients (illustration colours, derived from the pack art).
function rgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  const v = h.length === 3 ? h.split('').map((ch) => ch + ch).join('') : h.slice(0, 6);
  const n = parseInt(v, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function mix(a: string, b: string, t: number): string {
  const [r1, g1, b1] = rgb(a);
  const [r2, g2, b2] = rgb(b);
  const ch = (x: number, y: number) => Math.round(x + (y - x) * t).toString(16).padStart(2, '0');
  return `#${ch(r1, r2)}${ch(g1, g2)}${ch(b1, b2)}`;
}

export function alpha(hex: string, a: number): string {
  const [r, g, b] = rgb(hex);
  return `rgba(${r},${g},${b},${a})`;
}

/** Relative luminance, 0 (black) … 1 (white). */
export function luminance(hex: string): number {
  const [r, g, b] = rgb(hex).map((x) => {
    const s = x / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
