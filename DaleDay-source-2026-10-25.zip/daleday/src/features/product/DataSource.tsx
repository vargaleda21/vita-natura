import { View } from 'react-native';

import type { Product } from '@/data/types';
import { useLang, useT } from '@/i18n';
import { palette, radius, space } from '@/theme/tokens';
import { RealSources } from '@/features/lookup/RealFacts';
import { Icon, Txt, useTheme } from '@/ui';
import { alpha, fullDate } from './format';
import { strings } from './strings';

const KIND_ICON = {
  community: 'users',
  brand: 'factory',
  ai_label: 'sparkles',
  open_data: 'globe',
} as const;

/** Where the data came from, when it was checked, and the allergen reminder. */
export function DataSource({ product }: { product: Product }) {
  const t = useT(strings);
  const lang = useLang();
  const { c, isDark } = useTheme();
  const kind = product.dataSource.kind;
  const copy = t.sourceKind[kind];
  const real = product.real;
  // For a real product, "updated" is the source's last edit; when no source says, the fetch date shows below.
  const updated = real ? real.updated : product.dataSource.updated;

  return (
    <View style={{ gap: space.md }}>
      <View style={{ flexDirection: 'row', gap: space.md, alignItems: 'flex-start' }}>
        <View
          style={{
            width: 40,
            height: 40,
            borderRadius: 14,
            backgroundColor: kind === 'ai_label' ? palette.lilac : isDark ? c.surfaceAlt : c.bgAlt,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name={KIND_ICON[kind]} size={19} color={kind === 'ai_label' ? palette.ink : c.text} />
        </View>
        <View style={{ flex: 1, gap: 2 }}>
          <Txt variant="bodyStrong">{copy.title}</Txt>
          <Txt variant="small" muted>
            {copy.body}
          </Txt>
          {updated ? (
            <Txt variant="small" faint style={{ marginTop: 4 }}>
              {t.updated(fullDate(updated, lang))}
            </Txt>
          ) : null}
          <Txt variant="small" faint style={updated ? undefined : { marginTop: 4 }}>
            {t.barcode(product.ean)}
          </Txt>
        </View>
      </View>
      {real ? <RealSources product={product} /> : null}
      {real?.kind === 'product' ? null : (
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: space.sm,
            paddingHorizontal: space.md,
            paddingVertical: space.md,
            borderRadius: radius.md,
            backgroundColor: alpha(palette.sun, isDark ? 0.12 : 0.22),
          }}
        >
          <Icon name="triangle-alert" size={17} color={isDark ? palette.sun : '#9A6A00'} />
          <Txt variant="small" style={{ flex: 1 }}>
            {t.allergenNote}
          </Txt>
        </View>
      )}
    </View>
  );
}
