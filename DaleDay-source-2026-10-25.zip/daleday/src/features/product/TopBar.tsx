import { View } from 'react-native';
import Animated, { Extrapolation, interpolate, useAnimatedStyle, type SharedValue } from 'react-native-reanimated';

import type { MatchResult } from '@/data/types';
import { useT } from '@/i18n';
import { palette, radius, space, verdictColor } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { strings } from './strings';

const BAR = 56;
const CLAMP = Extrapolation.CLAMP;

type Props = {
  title: string;
  /** Left out when there is no verdict (a real product with too little data). */
  result?: MatchResult;
  scrollY: SharedValue<number>;
  inset: number;
  /** Scroll offset where the sheet reaches the bar: the bar turns solid there. */
  solidAt: number;
  onBack: () => void;
  onShare: () => void;
};

function RoundButton({ icon, label, onPress }: { icon: string; label: string; onPress: () => void }) {
  const { c, isDark } = useTheme();
  return (
    <PressableScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={6}
      style={{
        width: 44,
        height: 44,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: isDark ? 'rgba(19,34,28,0.82)' : 'rgba(255,255,255,0.86)',
        borderWidth: 1,
        borderColor: isDark ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.9)',
      }}
    >
      <Icon name={icon} size={21} color={c.text} />
    </PressableScale>
  );
}

/** Back and share over the stage; once scrolled, a compact solid bar with the title and score (no blur). */
export function TopBar({ title, result, scrollY, inset, solidAt, onBack, onShare }: Props) {
  const t = useT(strings);
  const { c } = useTheme();

  const bgStyle = useAnimatedStyle(() => ({
    opacity: interpolate(scrollY.value, [solidAt - 70, solidAt], [0, 1], CLAMP),
  }));
  const titleStyle = useAnimatedStyle(() => {
    const p = interpolate(scrollY.value, [solidAt + 10, solidAt + 60], [0, 1], CLAMP);
    return { opacity: p, transform: [{ translateY: (1 - p) * 10 }] };
  });

  return (
    <View style={{ position: 'absolute', left: 0, right: 0, top: 0, height: inset + BAR, zIndex: 20 }}>
      <Animated.View
        pointerEvents="none"
        style={[{ position: 'absolute', inset: 0, backgroundColor: c.bg, borderBottomWidth: 1, borderBottomColor: c.border }, bgStyle]}
      />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md, marginTop: inset, height: BAR, paddingHorizontal: space.md }}>
        <RoundButton icon="chevron-left" label={t.back} onPress={onBack} />
        <Animated.View style={[{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: space.sm }, titleStyle]} pointerEvents="none">
          <Txt variant="h3" numberOfLines={1} style={{ flexShrink: 1 }}>
            {title}
          </Txt>
          {result ? (
            <View style={{ minWidth: 30, paddingHorizontal: 7, paddingVertical: 3, borderRadius: radius.pill, backgroundColor: verdictColor[result.verdict], alignItems: 'center' }}>
              <Txt variant="tiny" color={palette.ink}>
                {result.score}
              </Txt>
            </View>
          ) : null}
        </Animated.View>
        <RoundButton icon="share-2" label={t.share} onPress={onShare} />
      </View>
    </View>
  );
}
