import { useEffect } from 'react';
import { View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring, withTiming } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { palette, radius, shadow, space, springs } from '@/theme/tokens';
import { Icon, Txt, useTheme } from '@/ui';

export type ToastMsg = { id: number; text: string; icon: string };

// A toast queued before a navigation is shown by the next product screen (the swap lands there).
let pending: ToastMsg | null = null;
let seq = 0;

export function makeToast(text: string, icon = 'sparkles'): ToastMsg {
  seq += 1;
  return { id: seq, text, icon };
}

export function queueToast(msg: ToastMsg): void {
  pending = msg;
}

/** Read the queued toast without consuming it (safe in a state initializer). */
export function peekToast(): ToastMsg | null {
  return pending;
}

export function clearToast(): void {
  pending = null;
}

/** A small celebratory pill that springs up from the bottom and leaves on its own. */
export function Toast({ msg, reduced, onDone }: { msg: ToastMsg | null; reduced: boolean; onDone: () => void }) {
  const insets = useSafeAreaInsets();
  const { isDark } = useTheme();
  const v = useSharedValue(0);

  useEffect(() => {
    if (!msg) return;
    v.set(reduced ? withTiming(1, { duration: 150 }) : withSpring(1, springs.bouncy));
    const hide = setTimeout(() => v.set(withTiming(0, { duration: 260 })), 2600);
    const done = setTimeout(onDone, 2950);
    return () => {
      clearTimeout(hide);
      clearTimeout(done);
    };
    // A new toast restarts the timers; onDone only clears it.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [msg?.id]);

  const style = useAnimatedStyle(() => ({
    opacity: v.value,
    transform: [{ translateY: (1 - v.value) * 40 }, { scale: 0.92 + 0.08 * v.value }],
  }));

  if (!msg) return null;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, bottom: insets.bottom + space.xl, alignItems: 'center' }}>
      <Animated.View
        accessibilityLiveRegion="polite"
        style={[
          {
            flexDirection: 'row',
            alignItems: 'center',
            gap: space.sm,
            maxWidth: 360,
            marginHorizontal: space.xl,
            paddingLeft: 8,
            paddingRight: space.lg,
            paddingVertical: 8,
            borderRadius: radius.pill,
            backgroundColor: isDark ? palette.forest : palette.ink,
            borderWidth: 1,
            borderColor: isDark ? 'rgba(198,243,107,0.35)' : 'rgba(255,255,255,0.12)',
          },
          shadow.float,
          style,
        ]}
      >
        <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: palette.lime, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name={msg.icon} size={17} color={palette.ink} />
        </View>
        <Txt variant="bodyStrong" color={palette.white} style={{ flexShrink: 1 }}>
          {msg.text}
        </Txt>
      </Animated.View>
    </View>
  );
}
