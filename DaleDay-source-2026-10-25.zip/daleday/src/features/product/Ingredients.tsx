import { useState } from 'react';
import { View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

import { CRITERIA } from '@/data/api';
import type { AvoidKey, Hit, Ingredient, Member, Product } from '@/data/types';
import { useLang, useT, useTr } from '@/i18n';
import { palette, radius, space, verdictColor } from '@/theme/tokens';
import { ExtLink } from '@/features/lookup/bits';
import { offEditUrl } from '@/features/lookup/RealFacts';
import { strings as lookupStrings } from '@/features/lookup/strings';
import { Card, Icon, PressableScale, Txt, useTheme } from '@/ui';
import { alpha, num } from './format';
import { strings } from './strings';

function ENumber({ code, inverse }: { code: string; inverse?: boolean }) {
  const { c } = useTheme();
  return (
    <View
      style={{
        paddingHorizontal: 5,
        paddingVertical: 1,
        borderRadius: 6,
        borderWidth: 1,
        borderColor: inverse ? 'rgba(255,255,255,0.6)' : c.border,
        backgroundColor: inverse ? 'transparent' : c.bgAlt,
      }}
    >
      <Txt variant="tiny" color={inverse ? palette.white : c.textMuted} style={{ letterSpacing: 0.2 }}>
        {code}
      </Txt>
    </View>
  );
}

type TokenProps = {
  ing: Ingredient;
  keys: AvoidKey[];
  last: boolean;
  selected: boolean;
  onPress: () => void;
};

function Token({ ing, keys, last, selected, onPress }: TokenProps) {
  const tr = useTr();
  const lang = useLang();
  const { c, isDark } = useTheme();
  const pct = ing.percent !== undefined ? `${num(ing.percent, lang)}%` : null;
  const comma = last ? null : (
    <Txt variant="body" muted style={{ marginLeft: -4 }}>
      ,
    </Txt>
  );

  if (keys.length === 0) {
    return (
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
        <Txt variant="body">{tr(ing.name)}</Txt>
        {pct ? (
          <Txt variant="small" muted>
            {pct}
          </Txt>
        ) : null}
        {ing.eNumber ? <ENumber code={ing.eNumber} /> : null}
        {comma}
      </View>
    );
  }

  const tint = verdictColor.avoid;
  const fg = selected ? palette.white : c.text;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
      <PressableScale
        onPress={onPress}
        accessibilityRole="button"
        accessibilityState={{ expanded: selected }}
        accessibilityLabel={`${tr(ing.name)}: ${keys.map((k) => tr(CRITERIA[k].label)).join(', ')}`}
        hitSlop={6}
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 5,
          paddingLeft: 8,
          paddingRight: 10,
          paddingVertical: 4,
          borderRadius: radius.pill,
          backgroundColor: selected ? tint : alpha(tint, isDark ? 0.2 : 0.12),
          borderWidth: 1,
          borderColor: selected ? tint : alpha(tint, 0.45),
        }}
      >
        <Icon name={CRITERIA[keys[0]].icon} size={14} color={selected ? palette.white : tint} />
        <Txt variant="bodyStrong" color={fg}>
          {tr(ing.name)}
        </Txt>
        {pct ? (
          <Txt variant="small" color={selected ? 'rgba(255,255,255,0.85)' : c.textMuted}>
            {pct}
          </Txt>
        ) : null}
        {ing.eNumber ? <ENumber code={ing.eNumber} inverse={selected} /> : null}
      </PressableScale>
      {comma}
    </View>
  );
}

/** One ingredient and, for a compound one, its parts in brackets: "margarin (pálmaolaj, víz)". */
function Group({
  ing,
  path,
  last,
  keysOf,
  open,
  onToggle,
}: {
  ing: Ingredient;
  path: string;
  last: boolean;
  keysOf: (ing: Ingredient) => AvoidKey[];
  open: string | null;
  onToggle: (path: string) => void;
}) {
  if (!ing.sub?.length) {
    return <Token ing={ing} keys={keysOf(ing)} last={last} selected={open === path} onPress={() => onToggle(path)} />;
  }
  return (
    <>
      <Token ing={ing} keys={keysOf(ing)} last selected={open === path} onPress={() => onToggle(path)} />
      <Txt variant="body" muted style={{ marginLeft: -4, marginRight: -6 }}>
        (
      </Txt>
      {ing.sub.map((s, j) => (
        <Group
          key={`${path}.${j}`}
          ing={s}
          path={`${path}.${j}`}
          last={j === (ing.sub?.length ?? 0) - 1}
          keysOf={keysOf}
          open={open}
          onToggle={onToggle}
        />
      ))}
      <Txt variant="body" muted style={{ marginLeft: -6 }}>
        {last ? ')' : '),'}
      </Txt>
    </>
  );
}

function atPath(list: Ingredient[], path: string): Ingredient | undefined {
  let level: Ingredient[] | undefined = list;
  let found: Ingredient | undefined;
  for (const part of path.split('.')) {
    found = level?.[Number(part)];
    level = found?.sub;
  }
  return found;
}

function flatten(list: Ingredient[]): Ingredient[] {
  return list.flatMap((i) => [i, ...flatten(i.sub ?? [])]);
}

/** The list was read off a photo by machine: say so, and link the photo and the page to type it in. */
function FromPhoto({ url, ean }: { url: string; ean: string }) {
  const lt = useT(lookupStrings);
  const { isDark } = useTheme();
  const ink = isDark ? palette.sun : '#9A6A00';
  return (
    <View style={{ gap: space.sm, padding: space.md, borderRadius: radius.md, backgroundColor: alpha(palette.sun, isDark ? 0.12 : 0.22) }}>
      <View style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-start' }}>
        <Icon name="scan-text" size={17} color={ink} />
        <View style={{ flex: 1, gap: 2 }}>
          <Txt variant="bodyStrong">{lt.photoTitle}</Txt>
          <Txt variant="small">{lt.photoBody}</Txt>
        </View>
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', columnGap: space.lg, rowGap: space.sm, paddingLeft: 17 + space.sm }}>
        <ExtLink label={lt.photoOpen} url={url} />
        <ExtLink label={lt.completeOnOff} url={offEditUrl(ean)} />
      </View>
    </View>
  );
}

/** The full list as flowing text; what you avoid is a tappable chip that tells you why. */
export function Ingredients({ product, active, hits, members }: { product: Product; active: AvoidKey[]; hits: Hit[]; members: Member[] }) {
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const [open, setOpen] = useState<string | null>(null);
  const real = product.real;

  const keysOf = (ing: Ingredient) => (ing.flags ?? []).filter((k) => active.includes(k));
  const all = flatten(product.ingredients);
  const anyFlagged = all.some((i) => keysOf(i).length > 0);
  const allergens = real ? [] : [...new Set(all.flatMap((i) => i.flags ?? []))].filter((k) => CRITERIA[k].group === 'allergy');
  const openIng = open !== null ? atPath(product.ingredients, open) : undefined;
  const openKeys = openIng ? keysOf(openIng) : [];
  // A declared allergen is "yours" when it raised one of your criteria.
  const mine = (name: { hu: string }) => (product.flags ?? []).some((f) => f.reason.hu === name.hu && active.includes(f.key));

  if (real && !real.ingredientsKnown) {
    return (
      <Card style={{ gap: space.md }}>
        <View style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-start' }}>
          <Icon name="circle-question-mark" size={18} color={c.textMuted} />
          <Txt variant="body" muted style={{ flex: 1 }}>
            {lt.noIngredients}
          </Txt>
        </View>
        {real.kind === 'food' || real.kind === 'unknown' ? <ExtLink label={lt.completeOnOff} url={offEditUrl(product.ean)} /> : null}
        <RealAllergens product={product} mine={mine} />
      </Card>
    );
  }

  return (
    <Card style={{ gap: space.lg }}>
      {real?.ingredientsPhoto ? <FromPhoto url={real.ingredientsPhoto} ean={product.ean} /> : null}
      <Txt variant="small" muted>
        {anyFlagged ? t.ingredientsHint : t.ingredientsAllClear}
      </Txt>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', rowGap: 10, columnGap: 8 }}>
        {product.ingredients.map((ing, i) => (
          <Group
            key={`${ing.name.hu}-${i}`}
            ing={ing}
            path={String(i)}
            last={i === product.ingredients.length - 1}
            keysOf={keysOf}
            open={open}
            onToggle={(p) => setOpen(open === p ? null : p)}
          />
        ))}
      </View>

      {openIng && openKeys.length > 0 ? (
        <Animated.View
          key={open}
          entering={FadeInDown.duration(220)}
          style={{
            borderRadius: radius.md,
            padding: space.md,
            gap: space.md,
            backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
          }}
        >
          <Txt variant="tiny" muted upper>
            {t.whyFlagged}
          </Txt>
          {openKeys.map((k) => {
            const crit = CRITERIA[k];
            const who = hits.find((h) => h.key === k)?.who ?? [];
            return (
              <View key={k} style={{ flexDirection: 'row', gap: space.md }}>
                <View
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: 12,
                    backgroundColor: alpha(verdictColor.avoid, 0.14),
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name={crit.icon} size={17} color={verdictColor.avoid} />
                </View>
                <View style={{ flex: 1, gap: 2 }}>
                  <Txt variant="bodyStrong">
                    {tr(crit.label)}
                    {who.length > 0 ? (
                      <Txt variant="small" muted>
                        {'  ·  '}
                        {who.map((id) => (id === 'me' ? t.me : (members.find((m) => m.id === id)?.name ?? ''))).join(', ')}
                      </Txt>
                    ) : null}
                  </Txt>
                  <Txt variant="small" muted>
                    {tr(crit.short)}
                  </Txt>
                </View>
              </View>
            );
          })}
        </Animated.View>
      ) : null}

      {real ? <RealAllergens product={product} mine={mine} /> : null}

      {allergens.length > 0 ? (
        <View style={{ gap: space.sm, borderTopWidth: 1, borderTopColor: c.border, paddingTop: space.md }}>
          <Txt variant="tiny" muted upper>
            {t.allergens}
          </Txt>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
            {allergens.map((k) => {
              const isMine = active.includes(k);
              return (
                <View
                  key={k}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 6,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    borderRadius: radius.pill,
                    borderWidth: 1,
                    borderColor: isMine ? alpha(verdictColor.avoid, 0.45) : c.border,
                    backgroundColor: isMine ? alpha(verdictColor.avoid, isDark ? 0.18 : 0.08) : 'transparent',
                  }}
                >
                  <Icon name={CRITERIA[k].icon} size={14} color={isMine ? verdictColor.avoid : c.textMuted} />
                  <Txt variant="small">{tr(CRITERIA[k].label)}</Txt>
                </View>
              );
            })}
          </View>
        </View>
      ) : null}
    </Card>
  );
}

/** A real product's declared allergens and "may contain" traces, as the source lists them. */
function RealAllergens({ product, mine }: { product: Product; mine: (name: { hu: string }) => boolean }) {
  const lt = useT(lookupStrings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const real = product.real;
  if (!real || (real.allergens.length === 0 && real.traces.length === 0)) return null;
  const pill = (name: { hu: string; en: string }, trace: boolean) => {
    const hot = mine(name);
    return (
      <View
        key={`${trace ? 't' : 'a'}-${name.hu}`}
        style={{
          paddingHorizontal: 10,
          paddingVertical: 5,
          borderRadius: radius.pill,
          borderWidth: 1,
          borderStyle: trace ? 'dashed' : 'solid',
          borderColor: hot ? alpha(verdictColor.avoid, 0.45) : c.border,
          backgroundColor: hot ? alpha(verdictColor.avoid, isDark ? 0.18 : 0.08) : 'transparent',
        }}
      >
        <Txt variant="small">{tr(name)}</Txt>
      </View>
    );
  };
  return (
    <View style={{ gap: space.md, borderTopWidth: 1, borderTopColor: c.border, paddingTop: space.md }}>
      {real.allergens.length > 0 ? (
        <View style={{ gap: space.sm }}>
          <Txt variant="tiny" muted upper>
            {lt.declaredAllergens}
          </Txt>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>{real.allergens.map((a) => pill(a, false))}</View>
        </View>
      ) : null}
      {real.traces.length > 0 ? (
        <View style={{ gap: space.sm }}>
          <Txt variant="tiny" muted upper>
            {lt.traces}
          </Txt>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>{real.traces.map((a) => pill(a, true))}</View>
        </View>
      ) : null}
    </View>
  );
}
