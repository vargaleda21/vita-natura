import { LinearGradient } from 'expo-linear-gradient';
import { useEffect, useId } from 'react';
import { View } from 'react-native';
import Animated, {
  Easing,
  Extrapolation,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import Svg, { Defs, Ellipse, RadialGradient, Rect, Stop } from 'react-native-svg';

import type { PackArt as Art } from '@/data/types';
import { ProductPhoto } from '@/features/lookup/bits';
import { palette } from '@/theme/tokens';
import { useTheme } from '@/ui';
import { mix } from './format';

const OVERSCROLL = 240;
const CLAMP = Extrapolation.CLAMP;

type Props = {
  art: Art;
  scrollY: SharedValue<number>;
  /** Stage height, including the top inset. */
  height: number;
  /** Where the visible stage starts (below the top bar) and ends (above the sheet). */
  top: number;
  bottom: number;
  reduced: boolean;
  /** A real product's photo (Open Food Facts). The drawn pack stays as the fallback. */
  imageUrl?: string;
  photoLabel?: string;
};

/** The big gradient stage behind the content: the pack floats, bobs, and drifts slower than the scroll. */
export function Stage({ art, scrollY, height, top, bottom, reduced, imageUrl, photoLabel = '' }: Props) {
  const { isDark } = useTheme();
  const [c0, c1] = art.colors;
  const bob = useSharedValue(0.5);
  const uid = useId().replace(/[^a-zA-Z0-9_-]/g, '');
  const glowId = `glow${uid}`;
  const shadowId = `shadow${uid}`;

  useEffect(() => {
    if (reduced) return;
    bob.set(withRepeat(withTiming(1, { duration: 1900, easing: Easing.inOut(Easing.sin) }), -1, true));
  }, [reduced, bob]);

  const bg: [string, string, string] = isDark
    ? [mix(c1, palette.night, 0.5), mix(c0, palette.night, 0.6), mix(c0, palette.night, 0.82)]
    : [mix(c1, palette.white, 0.66), mix(c1, palette.oat, 0.42), mix(c0, palette.white, 0.42)];
  const glow = isDark ? mix(c1, palette.white, 0.25) : palette.white;
  const room = bottom - top;
  const pack = Math.min(220, Math.max(150, room - 40));
  const cy = top + room / 2;

  const stageStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: interpolate(scrollY.value, [0, height], [0, -height * 0.5], CLAMP) }],
  }));
  const decoStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: interpolate(scrollY.value, [-200, 0, height], [40, 0, height * 0.18], CLAMP) }],
  }));
  const packStyle = useAnimatedStyle(() => {
    const y = scrollY.value;
    const b = bob.value - 0.5;
    return {
      opacity: interpolate(y, [height * 0.3, height * 0.8], [1, 0], CLAMP),
      transform: [
        { translateY: interpolate(y, [-200, 0, height], [70, 0, -height * 0.2], CLAMP) + b * 12 },
        { scale: interpolate(y, [-200, 0, height], [1.22, 1, 0.7], CLAMP) },
        { rotate: `${b * 3.2}deg` },
      ],
    };
  });
  const groundStyle = useAnimatedStyle(() => {
    const b = bob.value - 0.5;
    return {
      opacity: interpolate(scrollY.value, [0, height * 0.5], [1, 0], CLAMP) * (0.85 + b * 0.3),
      transform: [{ scaleX: 1 + b * 0.16 }],
    };
  });

  return (
    <Animated.View
      pointerEvents="none"
      style={[{ position: 'absolute', left: 0, right: 0, top: -OVERSCROLL, height: height + OVERSCROLL }, stageStyle]}
    >
      <LinearGradient colors={bg} locations={[0, 0.55, 1]} start={{ x: 0.1, y: 0 }} end={{ x: 0.9, y: 1 }} style={{ position: 'absolute', inset: 0 }} />
      <View style={{ position: 'absolute', left: 0, right: 0, top: OVERSCROLL, height }}>
        {/* Bokeh circles drifting at their own pace: depth without blur. */}
        <Animated.View style={[{ position: 'absolute', inset: 0 }, decoStyle]}>
          <View style={{ position: 'absolute', left: -60, top: top + 10, width: 180, height: 180, borderRadius: 90, backgroundColor: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(255,255,255,0.35)' }} />
          <View style={{ position: 'absolute', right: -40, top: cy - 20, width: 130, height: 130, borderRadius: 65, backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(255,255,255,0.28)' }} />
          <View style={{ position: 'absolute', right: 46, top: top + 18, width: 22, height: 22, borderRadius: 11, backgroundColor: mix(c1, palette.white, 0.3), opacity: 0.55 }} />
          <View style={{ position: 'absolute', left: 52, top: cy + 70, width: 14, height: 14, borderRadius: 7, backgroundColor: palette.lime, opacity: isDark ? 0.5 : 0.8 }} />
          <View style={{ position: 'absolute', right: 70, top: cy + 84, width: 9, height: 9, borderRadius: 5, backgroundColor: palette.sun, opacity: 0.85 }} />
        </Animated.View>
        {/* A soft radial glow behind the pack. */}
        <View style={{ position: 'absolute', left: 0, right: 0, top: cy - 170, height: 340, alignItems: 'center' }}>
          <Svg width={340} height={340}>
            <Defs>
              <RadialGradient id={glowId} cx="50%" cy="50%" r="50%">
                <Stop offset="0" stopColor={glow} stopOpacity={isDark ? 0.32 : 0.85} />
                <Stop offset="0.55" stopColor={glow} stopOpacity={isDark ? 0.1 : 0.3} />
                <Stop offset="1" stopColor={glow} stopOpacity={0} />
              </RadialGradient>
            </Defs>
            <Rect x={0} y={0} width={340} height={340} fill={`url(#${glowId})`} />
          </Svg>
        </View>
        <View style={{ position: 'absolute', left: 0, right: 0, top: cy + pack / 2 - 22, alignItems: 'center' }}>
          <Animated.View style={groundStyle}>
            <Svg width={pack * 1.1} height={44}>
              <Defs>
                <RadialGradient id={shadowId} cx="50%" cy="50%" rx="50%" ry="50%">
                  <Stop offset="0" stopColor={isDark ? '#000000' : palette.ink} stopOpacity={isDark ? 0.55 : 0.22} />
                  <Stop offset="0.6" stopColor={isDark ? '#000000' : palette.ink} stopOpacity={isDark ? 0.2 : 0.07} />
                  <Stop offset="1" stopColor={isDark ? '#000000' : palette.ink} stopOpacity={0} />
                </RadialGradient>
              </Defs>
              <Ellipse cx={pack * 0.55} cy={22} rx={pack * 0.55} ry={22} fill={`url(#${shadowId})`} />
            </Svg>
          </Animated.View>
        </View>
        <View style={{ position: 'absolute', left: 0, right: 0, top: cy - pack / 2, alignItems: 'center' }}>
          <Animated.View style={packStyle}>
            <ProductPhoto uri={imageUrl} art={art} size={pack} label={photoLabel} />
          </Animated.View>
        </View>
      </View>
    </Animated.View>
  );
}
