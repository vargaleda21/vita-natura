import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Platform, StyleSheet, View, type ViewStyle } from 'react-native';
import Animated, {
  cancelAnimation,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Rect } from 'react-native-svg';

import {
  aiReadLabel,
  cannotJudge,
  demoProducts,
  emptyProgress,
  evaluate,
  getProduct,
  lookupCode,
  MYSTERY_EAN,
  rememberProduct,
  type Progress,
  type SourceKey,
} from '@/data/api';
import type { PackArt, Product } from '@/data/types';
import { RealNotFoundBody } from '@/features/lookup/RealNotFound';
import { SourceChecklist } from '@/features/lookup/SourceChecklist';
import { strings as lookupStrings } from '@/features/lookup/strings';
import { useT, useTr } from '@/i18n';
import { addScan, getSettings } from '@/state/store';
import { palette, radius, space, springs } from '@/theme/tokens';
import { Icon, type IconName, Txt } from '@/ui';
import { GlassIconButton, GlassPill } from './buttons';
import { CameraFeed } from './CameraFeed';
import type { Box, CameraStatus } from './cameraTypes';
import { DemoStrip } from './DemoStrip';
import { eanBars, lookupCandidates } from './ean';
import { Glows } from './Glows';
import { HelpSheet, UnknownSheet } from './InfoSheets';
import { KeypadSheet } from './KeypadSheet';
import { LabelReader } from './LabelReader';
import { FRAME_RADIUS, ScanOverlay } from './ScanOverlay';
import { Sheet } from './Sheet';
import { strings } from './strings';
import { VirtualLabel, virtualGeometry } from './VirtualLabel';

/** The "mystery product" (MYSTERY_EAN) shows the mock AI label flow, clearly labelled as a demo.
 *  The mock AI reads it as a biscuit with palm fat, sugar and two E numbers, a rich demo.
 *  Every other code that is not a demo product is looked up in the real open databases. */
const MYSTERY_ART: PackArt = { colors: ['#3B3F63', '#8D8FD6'], emoji: '❔', shape: 'box' };

type Phase =
  | { kind: 'scanning' }
  | { kind: 'presenting'; code: string; art?: PackArt }
  | { kind: 'found'; code: string; product?: Product; box: Box; art?: PackArt; virtual: boolean }
  | { kind: 'looking'; code: string; box: Box; art?: PackArt; virtual: boolean; progress: Progress }
  | { kind: 'notfound'; code: string; progress: Progress; unreachable: SourceKey[] }
  | { kind: 'unknown'; code: string }
  | { kind: 'reading'; code: string };

/** A demo product or an AI-read one (this session). Real products are never answered from here. */
function lookup(code: string): Product | undefined {
  for (const c of lookupCandidates(code)) {
    const p = getProduct(c);
    if (p && !p.real) return p;
  }
  return undefined;
}

function record(product: Product) {
  const r = evaluate(product, getSettings());
  // A real product with too little data has no verdict: it stays out of the history and the insights.
  if (product.real && cannotJudge(r)) return;
  addScan({ ean: product.ean, at: new Date().toISOString(), verdict: r.verdict, score: r.score });
}

function computeFrame(w: number, h: number, top: number, panelH: number): Box {
  const fw = Math.min(w - 60, 336);
  const fh = Math.round(fw * 0.68);
  const topLimit = top + 64;
  const bottomLimit = h - panelH;
  const block = fh + 70;
  const y = Math.max(topLimit + 6, topLimit + (bottomLimit - topLimit - block) * 0.5);
  return { x: Math.round((w - fw) / 2), y: Math.round(y), width: fw, height: fh };
}

function buzz() {
  if (Platform.OS !== 'web') {
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    return;
  }
  try {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator && navigator.userActivation?.hasBeenActive) navigator.vibrate(28);
  } catch {
    // no vibration on this browser
  }
}

// On web, `clip` (unlike `hidden`) cannot be scrolled by focus or scrollIntoView, so the column never slides sideways.
const COLUMN_CLIP = (Platform.OS === 'web' ? { overflow: 'clip' } : { overflow: 'hidden' }) as unknown as ViewStyle;

export function ScanScreen() {
  const t = useT(strings);
  const lt = useT(lookupStrings);
  const tr = useTr();
  const insets = useSafeAreaInsets();
  const reduced = useReducedMotion();
  // "Type the code" from a not-found page opens the keypad straight away.
  const { keypad } = useLocalSearchParams<{ keypad?: string }>();
  const [size, setSize] = useState({ w: 390, h: 844 });
  const [panelH, setPanelH] = useState(300);
  const [status, setStatus] = useState<CameraStatus>('starting');
  const [retryKey, setRetryKey] = useState(0);
  const [torch, setTorch] = useState(false);
  const [phase, setPhase] = useState<Phase>({ kind: 'scanning' });
  const [sheet, setSheet] = useState<'keypad' | 'help' | null>(keypad === '1' ? 'keypad' : null);
  const busy = useRef(false);
  // The running real lookup. Cleared once it answers, so leaving the screen never cuts off the
  // prices that are still loading for the product page.
  const looking = useRef<AbortController | null>(null);
  // The AI read starts the moment a code turns out to be new, so the label is usually ready by the
  // time the reader opens and it shows what the AI actually read.
  const [aiRead, setAiRead] = useState<{ code: string; product: Product } | null>(null);
  const readFor = useRef<string | null>(null);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const shutter = useSharedValue(0);

  const later = useCallback((fn: () => void, ms: number) => {
    timers.current.push(setTimeout(fn, ms));
  }, []);
  useEffect(
    () => () => {
      timers.current.forEach(clearTimeout);
      readFor.current = null;
      looking.current?.abort();
      looking.current = null;
    },
    [],
  );
  // Load the product page's code now, while the camera warms up, so a slow network never shows a blank
  // page after the lookup: the route's chunk is the same one expo-router loads on navigation.
  useEffect(() => {
    import('@/app/product/[ean]').catch(() => undefined);
  }, []);

  const startRead = (code: string) => {
    if (readFor.current === code) return;
    readFor.current = code;
    setAiRead(null);
    void aiReadLabel(code).then((product) => {
      if (readFor.current === code) setAiRead({ code, product });
    });
  };

  const frame = computeFrame(size.w, size.h, insets.top, panelH);

  const close = () => {
    if (router.canGoBack()) router.back();
    else router.replace('/(tabs)');
  };

  const open = (product: Product) => {
    record(product);
    router.replace(`/product/${product.ean}`);
  };

  /** A real code: ask the open sources, tick them off as they answer, then open the product. */
  const look = (code: string, lockBox: Box, virtual: boolean, art?: PackArt, force = false) => {
    looking.current?.abort();
    const ctrl = new AbortController();
    looking.current = ctrl;
    setPhase({ kind: 'looking', code, box: lockBox, virtual, art, progress: emptyProgress() });
    const onProgress = (progress: Progress) => {
      if (looking.current !== ctrl) return;
      setPhase((ph) => (ph.kind === 'looking' && ph.code === code ? { ...ph, progress } : ph));
    };
    void lookupCode(code, { signal: ctrl.signal, onProgress, force }).then((r) => {
      if (looking.current !== ctrl) return;
      looking.current = null;
      if (r.kind === 'found') {
        buzz();
        setPhase({ kind: 'found', code: r.product.ean, product: r.product, box: lockBox, art, virtual });
        later(() => open(r.product), reduced ? 500 : 900);
      } else if (r.kind === 'not_found') {
        setPhase({ kind: 'notfound', code: r.key, progress: r.progress, unreachable: r.unreachable });
      } else {
        busy.current = false;
        setPhase({ kind: 'scanning' });
      }
    });
  };

  const cancelLook = () => {
    looking.current?.abort();
    looking.current = null;
    busy.current = false;
    setPhase({ kind: 'scanning' });
  };

  const found = (code: string, box: Box | undefined, virtual: boolean, art?: PackArt) => {
    const product = lookup(code);
    const lockBox = box ?? virtualGeometry(frame).sticker;
    if (!product && code !== MYSTERY_EAN) {
      look(code, lockBox, virtual, art);
      return;
    }
    setPhase({ kind: 'found', code: product?.ean ?? code, product, box: lockBox, art, virtual });
    buzz();
    if (!product) startRead(code);
    later(
      () => {
        if (product) open(product);
        else setPhase({ kind: 'unknown', code });
      },
      reduced ? 700 : 1250,
    );
  };

  /** Demo chips and typed codes: a pack "held up" to the camera, then the same detection moment. */
  const present = (code: string, art?: PackArt) => {
    if (busy.current) return;
    busy.current = true;
    setSheet(null);
    setPhase({ kind: 'presenting', code, art });
    later(() => found(code, undefined, true, art), reduced ? 260 : 720);
  };

  const onCode = (code: string, box?: Box) => {
    if (busy.current) return;
    busy.current = true;
    found(code, box, false);
  };

  const resume = () => {
    busy.current = false;
    readFor.current = null;
    looking.current?.abort();
    looking.current = null;
    setAiRead(null);
    setPhase({ kind: 'scanning' });
  };

  const photograph = (code: string) => {
    shutter.set(withSequence(withTiming(1, { duration: 70 }), withTiming(0, { duration: 420 })));
    later(() => setPhase({ kind: 'reading', code }), 90);
  };

  const readerDone = (product: Product) => {
    rememberProduct(product);
    open(product);
  };

  const shutterStyle = useAnimatedStyle(() => ({ opacity: shutter.value }));

  const live = status === 'live';
  const scanning = phase.kind === 'scanning' && sheet === null;
  const lock = phase.kind === 'found' || phase.kind === 'looking' ? phase.box : null;
  const products = demoProducts();
  const lookingNow = phase.kind === 'looking';
  const showVirtual = phase.kind === 'presenting' || ((phase.kind === 'found' || phase.kind === 'looking') && phase.virtual);
  const virtualCode = phase.kind === 'presenting' || phase.kind === 'found' || phase.kind === 'looking' ? phase.code : '';
  const virtualArt =
    phase.kind === 'presenting' || phase.kind === 'found' || phase.kind === 'looking'
      ? phase.kind === 'found' && phase.product
        ? phase.product.art
        : phase.art
      : undefined;

  return (
    <View style={{ flex: 1, backgroundColor: palette.night, alignItems: 'center' }}>
      <StatusBar style="light" />
      <View
        style={[{ flex: 1, width: '100%', maxWidth: 480 }, COLUMN_CLIP]}
        onLayout={(e) => setSize({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}
      >
        {/* Standby light, seen until (or instead of) the camera picture. */}
        <LinearGradient colors={['#0E1F18', palette.night, '#050B08']} style={StyleSheet.absoluteFill} />
        <Glows
          width={size.w}
          height={size.h}
          spots={[
            {
              x: size.w * 0.5,
              y: frame.y + frame.height / 2,
              rx: size.w * 0.7,
              ry: 260,
              color: palette.forest,
              opacity: 0.9,
            },
            {
              x: size.w * 0.15,
              y: frame.y - 40,
              rx: 200,
              ry: 160,
              color: palette.lime,
              opacity: 0.14,
            },
            {
              x: size.w * 0.9,
              y: frame.y + frame.height + 60,
              rx: 220,
              ry: 180,
              color: palette.mint,
              opacity: 0.12,
            },
          ]}
        />
        {!live && phase.kind === 'scanning' ? <StandbyBars frame={frame} /> : null}

        <CameraFeed onCode={onCode} active={scanning} torch={torch} onStatus={setStatus} retryKey={retryKey} region={frame} />

        {showVirtual ? <VirtualLabel key={virtualCode} frame={frame} code={virtualCode} art={virtualArt} reduced={reduced} /> : null}

        <ScanOverlay width={size.w} height={size.h} frame={frame} lock={lock} scanning={scanning} reduced={reduced} />

        {phase.kind === 'scanning' && !live ? (
          <CameraMessage
            frame={frame}
            status={status}
            t={t}
            onRetry={status === 'denied' || status === 'error' ? () => setRetryKey((k) => k + 1) : undefined}
          />
        ) : null}

        {/* Under the frame: the hint, or the "got it" pill. */}
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: frame.y + frame.height + 22,
            alignItems: 'center',
          }}
        >
          {phase.kind === 'found' ? (
            <FoundPill key={phase.code} label={t.found} sub={phase.product ? tr(phase.product.name) : phase.code} reduced={reduced} />
          ) : phase.kind === 'scanning' ? (
            <>
              <Txt variant="bodyStrong" color="#FFFFFF" center>
                {t.hint}
              </Txt>
              <Txt variant="small" color="rgba(255,255,255,0.55)" center style={{ marginTop: 2 }}>
                {t.hintSub}
              </Txt>
            </>
          ) : null}
        </View>

        {/* Top bar */}
        <View
          style={{
            position: 'absolute',
            top: insets.top + 8,
            left: space.lg,
            right: space.lg,
            flexDirection: 'row',
            alignItems: 'center',
            gap: space.sm,
          }}
        >
          <GlassIconButton icon="x" label={t.close} onPress={close} />
          <View style={{ flex: 1, alignItems: 'center' }}>
            <LiveTag label={t.title} live={live} reduced={reduced} />
          </View>
          {Platform.OS !== 'web' ? (
            <GlassIconButton icon="flashlight" label={torch ? t.torchOff : t.torchOn} active={torch} onPress={() => setTorch((v) => !v)} />
          ) : null}
          <GlassIconButton icon="info" glyph="?" label={t.help} onPress={() => setSheet('help')} />
        </View>

        {/* Bottom: "no product to hand?" (it hides while a real code is looked up, so the checklist reads cleanly; its height stays). */}
        <View
          onLayout={(e) => setPanelH(e.nativeEvent.layout.height)}
          pointerEvents={lookingNow ? 'none' : 'auto'}
          style={{ position: 'absolute', left: 0, right: 0, bottom: 0, opacity: lookingNow ? 0 : 1 }}
        >
          <LinearGradient
            colors={['rgba(5,11,8,0)', 'rgba(5,11,8,0.88)', '#050B08']}
            locations={[0, 0.28, 1]}
            style={StyleSheet.absoluteFill}
          />
          <View
            style={{
              paddingTop: space.xxl,
              paddingBottom: Math.max(insets.bottom, space.lg) + space.sm,
            }}
          >
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'flex-end',
                paddingHorizontal: space.xl,
                gap: space.md,
              }}
            >
              <View style={{ flex: 1 }}>
                <Txt variant="h3" color="#FFFFFF">
                  {t.demoTitle}
                </Txt>
                <Txt variant="small" color="rgba(255,255,255,0.6)" style={{ marginTop: 2 }}>
                  {t.demoSub}
                </Txt>
              </View>
              <GlassPill label={t.typeCode} icon="keyboard" a11y={t.typeCodeLabel} onPress={() => setSheet('keypad')} />
            </View>
            <View style={{ marginTop: space.md }}>
              <DemoStrip
                products={products}
                disabled={phase.kind !== 'scanning'}
                reduced={reduced}
                onPick={(p) => present(p.ean, p.art)}
                onMystery={() => present(MYSTERY_EAN, MYSTERY_ART)}
                mysteryName={t.mysteryName}
                mysterySub={t.mysterySub}
                tryMe={t.tryMe}
              />
            </View>
          </View>
        </View>

        {phase.kind === 'looking' ? (
          <View style={{ position: 'absolute', left: space.lg, right: space.lg, bottom: Math.max(insets.bottom, space.lg) + space.sm }}>
            <SourceChecklist progress={phase.progress} t={lt} reduced={reduced} onCancel={cancelLook} />
          </View>
        ) : null}

        <Sheet visible={phase.kind === 'notfound'} onClose={resume} reduced={reduced} label={lt.scanAnother}>
          {phase.kind === 'notfound' ? (
            <RealNotFoundBody
              compact
              code={phase.code}
              progress={phase.progress}
              unreachable={phase.unreachable}
              reduced={reduced}
              onRetry={() => look(phase.code, virtualGeometry(frame).sticker, true, undefined, true)}
              onType={() => {
                resume();
                setSheet('keypad');
              }}
              onPick={(pick) => router.replace({ pathname: '/product/[ean]', params: { ean: pick, from: phase.code } })}
              onDismiss={resume}
            />
          ) : null}
        </Sheet>

        <KeypadSheet
          visible={sheet === 'keypad'}
          reduced={reduced}
          t={t}
          onClose={() => setSheet(null)}
          onSubmit={(code) => present(code, lookup(code)?.art)}
        />
        <HelpSheet visible={sheet === 'help'} reduced={reduced} t={t} onClose={() => setSheet(null)} />
        <UnknownSheet
          code={phase.kind === 'unknown' ? phase.code : MYSTERY_EAN}
          visible={phase.kind === 'unknown'}
          reduced={reduced}
          t={t}
          onPhoto={() => phase.kind === 'unknown' && photograph(phase.code)}
          onDismiss={resume}
        />

        {phase.kind === 'reading' ? (
          <LabelReader
            result={aiRead && aiRead.code === phase.code ? aiRead.product : null}
            width={size.w}
            reduced={reduced}
            t={t}
            onDone={readerDone}
            onCancel={resume}
          />
        ) : null}

        <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: '#FFFFFF' }, shutterStyle]} />
      </View>
    </View>
  );
}

/** A faint barcode inside the empty frame, so it is clear what goes there. */
function StandbyBars({ frame }: { frame: Box }) {
  const { bars, total } = eanBars('5990000000001');
  const w = frame.width * 0.56;
  const h = frame.height * 0.36;
  const unit = w / total;
  return (
    <View
      pointerEvents="none"
      style={{
        position: 'absolute',
        left: frame.x + (frame.width - w) / 2,
        top: frame.y + frame.height * 0.16,
        opacity: 0.1,
      }}
    >
      <Svg width={w} height={h}>
        {bars.map((b) => (
          <Rect key={b.x} x={b.x * unit} y={0} width={b.w * unit} height={b.guard ? h : h * 0.88} fill="#FFFFFF" />
        ))}
      </Svg>
    </View>
  );
}

function CameraMessage({
  frame,
  status,
  t,
  onRetry,
}: {
  frame: Box;
  status: CameraStatus;
  t: (typeof strings)['hu'];
  onRetry?: () => void;
}) {
  const map: Partial<Record<CameraStatus, { icon: IconName; title: string; body: string }>> = {
    denied: { icon: 'camera', title: t.deniedTitle, body: t.deniedBody },
    nocamera: { icon: 'camera', title: t.noCamTitle, body: t.noCamBody },
    insecure: { icon: 'shield-check', title: t.insecureTitle, body: t.insecureBody },
    unsupported: { icon: 'camera', title: t.noCamTitle, body: t.noCamBody },
    error: { icon: 'circle-alert', title: t.errorTitle, body: t.errorBody },
  };
  const m = map[status];
  return (
    <View
      style={{
        position: 'absolute',
        left: frame.x,
        top: frame.y,
        width: frame.width,
        height: frame.height,
        alignItems: 'center',
        justifyContent: m ? 'flex-end' : 'center',
        paddingHorizontal: space.lg,
        paddingBottom: m ? space.lg : 0,
        borderRadius: FRAME_RADIUS,
      }}
    >
      {m ? (
        <>
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: 'rgba(255,201,61,0.16)',
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: space.sm,
            }}
          >
            <Icon name={m.icon} size={20} color={palette.sun} />
          </View>
          <Txt variant="bodyStrong" color="#FFFFFF" center>
            {m.title}
          </Txt>
          <Txt variant="small" color="rgba(255,255,255,0.65)" center style={{ marginTop: 2 }} numberOfLines={3}>
            {m.body}
          </Txt>
          {onRetry ? (
            <View style={{ marginTop: space.sm }}>
              <GlassPill label={t.retry} icon="refresh-cw" onPress={onRetry} />
            </View>
          ) : null}
        </>
      ) : (
        <Txt variant="small" color="rgba(255,255,255,0.7)" center style={{ marginTop: frame.height * 0.3 }}>
          {t.starting}
        </Txt>
      )}
    </View>
  );
}

function LiveTag({ label, live, reduced }: { label: string; live: boolean; reduced: boolean }) {
  const pulse = useSharedValue(1);
  useEffect(() => {
    if (!live || reduced) {
      pulse.set(1);
      return;
    }
    pulse.set(withRepeat(withSequence(withTiming(0.3, { duration: 700 }), withTiming(1, { duration: 700 })), -1));
    return () => cancelAnimation(pulse);
  }, [live, reduced, pulse]);
  const dot = useAnimatedStyle(() => ({ opacity: pulse.value }));
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}>
      <Animated.View
        style={[
          {
            width: 7,
            height: 7,
            borderRadius: 4,
            backgroundColor: live ? palette.lime : 'rgba(255,255,255,0.35)',
          },
          dot,
        ]}
      />
      <Txt variant="tiny" upper color="rgba(255,255,255,0.85)" style={{ letterSpacing: 1.4 }}>
        {label}
      </Txt>
    </View>
  );
}

function FoundPill({ label, sub, reduced }: { label: string; sub: string; reduced: boolean }) {
  const p = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    if (!reduced) p.set(withSpring(1, springs.bouncy));
  }, [p, reduced]);
  const style = useAnimatedStyle(() => ({
    opacity: Math.min(1, p.value * 1.5),
    transform: [{ scale: 0.6 + 0.4 * p.value }],
  }));
  return (
    <Animated.View style={[{ alignItems: 'center' }, style]}>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: space.sm,
          backgroundColor: palette.lime,
          borderRadius: radius.pill,
          paddingLeft: 6,
          paddingRight: 18,
          paddingVertical: 6,
        }}
      >
        <View
          style={{
            width: 28,
            height: 28,
            borderRadius: 14,
            backgroundColor: palette.ink,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name="check" size={17} color={palette.lime} strokeWidth={3} />
        </View>
        <Txt variant="h3" color={palette.ink}>
          {label}
        </Txt>
      </View>
      <Txt variant="bodyStrong" color="#FFFFFF" center numberOfLines={1} style={{ marginTop: space.sm, maxWidth: 300 }}>
        {sub}
      </Txt>
    </Animated.View>
  );
}
