import { StyleSheet } from 'react-native';
import Svg, { Defs, Ellipse, RadialGradient, Stop } from 'react-native-svg';

export type GlowSpot = { x: number; y: number; rx: number; ry: number; color: string; opacity: number };

/** Big soft light without a blur filter: radial gradients, drawn once. */
export function Glows({ width, height, spots }: { width: number; height: number; spots: GlowSpot[] }) {
  return (
    <Svg width={width} height={height} style={StyleSheet.absoluteFill} pointerEvents="none">
      <Defs>
        {spots.map((s, i) => (
          <RadialGradient key={i} id={`scanglow${i}`} cx="50%" cy="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor={s.color} stopOpacity={s.opacity} />
            <Stop offset="0.55" stopColor={s.color} stopOpacity={s.opacity * 0.35} />
            <Stop offset="1" stopColor={s.color} stopOpacity={0} />
          </RadialGradient>
        ))}
      </Defs>
      {spots.map((s, i) => (
        <Ellipse key={i} cx={s.x} cy={s.y} rx={s.rx} ry={s.ry} fill={`url(#scanglow${i})`} />
      ))}
    </Svg>
  );
}
