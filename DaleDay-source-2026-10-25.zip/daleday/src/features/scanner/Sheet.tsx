import { type ReactNode, useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, useWindowDimensions, View } from 'react-native';
import Animated, { Easing, useAnimatedStyle, useSharedValue, withSpring, withTiming } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { radius, space, springs } from '@/theme/tokens';
import { useTheme } from '@/ui';

type Props = {
  visible: boolean;
  onClose: () => void;
  children: ReactNode;
  reduced: boolean;
  label: string;
};

/** A bottom sheet that follows the app theme, over the (always dark) scanner. */
export function Sheet({ visible, onClose, children, reduced, label }: Props) {
  const { c, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { height: winH } = useWindowDimensions();
  const [mounted, setMounted] = useState(visible);
  const [h, setH] = useState(520);
  const p = useSharedValue(0);

  // Mount as soon as it should show (adjusting state while rendering, not in an effect).
  if (visible && !mounted) setMounted(true);

  useEffect(() => {
    if (visible) {
      p.set(reduced ? withTiming(1, { duration: 160 }) : withSpring(1, springs.soft));
      return;
    }
    p.set(withTiming(0, { duration: 220, easing: Easing.in(Easing.quad) }));
    const t = setTimeout(() => setMounted(false), 240);
    return () => clearTimeout(t);
  }, [visible, reduced, p]);

  const backdrop = useAnimatedStyle(() => ({ opacity: p.value }));
  const panel = useAnimatedStyle(() => ({
    opacity: reduced ? p.value : 1,
    transform: [{ translateY: reduced ? 0 : (1 - p.value) * (h + 40) }],
  }));

  if (!mounted) return null;
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents={visible ? 'auto' : 'none'}>
      <Animated.View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(3,8,6,0.62)' }, backdrop]}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityRole="button" accessibilityLabel={label} />
      </Animated.View>
      <Animated.View
        accessibilityViewIsModal
        onLayout={(e) => setH(e.nativeEvent.layout.height)}
        style={[
          {
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: isDark ? c.bgAlt : c.bg,
            borderTopLeftRadius: radius.xl + 4,
            borderTopRightRadius: radius.xl + 4,
            borderTopWidth: 1,
            borderColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.9)',
            paddingHorizontal: space.xl,
            paddingTop: space.md,
            paddingBottom: Math.max(insets.bottom, space.lg) + space.sm,
            // A tall sheet on a small phone (320 × 640) stops below the notch and scrolls inside.
            maxHeight: winH - insets.top - space.md,
          },
          panel,
        ]}
      >
        <View style={{ alignSelf: 'center', width: 40, height: 5, borderRadius: 3, backgroundColor: c.textFaint, opacity: 0.35, marginBottom: space.lg }} />
        <ScrollView style={{ flexShrink: 1 }} bounces={false} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          {children}
        </ScrollView>
      </Animated.View>
    </View>
  );
}
