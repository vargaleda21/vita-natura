// The web camera (Metro picks CameraFeed.native.tsx on the phone apps).
// getUserMedia into a <video>; decoded by the browser's own BarcodeDetector where it exists
// (Chrome on Android), otherwise by @zxing/library (Safari on iPhone), loaded only when needed.
import { useEffect, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';

import { makeConfirmer } from '@/data/api';
import { BARCODE_FORMATS_WEB, type Box, type CameraFeedProps, type CameraStatus } from './cameraTypes';

type Hit = { code: string; box?: Box };
type Decoder = { interval: number; decode: (video: HTMLVideoElement, region: Box | null) => Promise<Hit | null> };

type DetectedBarcode = { rawValue: string; boundingBox?: DOMRectReadOnly };
type BarcodeDetectorLike = { detect: (source: HTMLVideoElement) => Promise<DetectedBarcode[]> };
type BarcodeDetectorClass = {
  new (options?: { formats: string[] }): BarcodeDetectorLike;
  getSupportedFormats?: () => Promise<string[]>;
};

const DIGITS = /^\d{8,13}$/;

async function browserDetector(): Promise<Decoder | null> {
  const Ctor = (globalThis as { BarcodeDetector?: BarcodeDetectorClass }).BarcodeDetector;
  if (!Ctor) return null;
  try {
    const supported = (await Ctor.getSupportedFormats?.()) ?? [];
    const formats = BARCODE_FORMATS_WEB.filter((f) => supported.includes(f));
    if (!formats.includes('ean_13')) return null;
    const detector = new Ctor({ formats: [...formats] });
    return {
      interval: 120,
      decode: async (video) => {
        const found = await detector.detect(video);
        const first = found.find((b) => DIGITS.test(b.rawValue));
        if (!first) return null;
        const r = first.boundingBox;
        return { code: first.rawValue, box: r ? { x: r.x, y: r.y, width: r.width, height: r.height } : undefined };
      },
    };
  } catch {
    return null;
  }
}

async function zxingDecoder(): Promise<Decoder> {
  const z = await import('@zxing/library');
  const hints = new Map<import('@zxing/library').DecodeHintType, unknown>();
  hints.set(z.DecodeHintType.POSSIBLE_FORMATS, [
    z.BarcodeFormat.EAN_13,
    z.BarcodeFormat.EAN_8,
    z.BarcodeFormat.UPC_A,
    z.BarcodeFormat.UPC_E,
  ]);
  hints.set(z.DecodeHintType.TRY_HARDER, true);
  const reader = new z.MultiFormatReader();
  reader.setHints(hints);
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  return {
    interval: 180,
    decode: async (video, region) => {
      if (!ctx) return null;
      const vw = video.videoWidth;
      const vh = video.videoHeight;
      // Read only the part of the picture behind the frame: faster, and fewer false reads.
      const r = region ?? { x: vw * 0.07, y: vh * 0.22, width: vw * 0.86, height: vh * 0.56 };
      const sx = Math.max(0, Math.round(r.x));
      const sy = Math.max(0, Math.round(r.y));
      const sw = Math.min(vw - sx, Math.round(r.width));
      const sh = Math.min(vh - sy, Math.round(r.height));
      if (sw < 32 || sh < 32) return null;
      const scale = Math.min(1, 720 / sw);
      canvas.width = Math.round(sw * scale);
      canvas.height = Math.round(sh * scale);
      ctx.drawImage(video, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
      try {
        const bitmap = new z.BinaryBitmap(new z.HybridBinarizer(new z.HTMLCanvasElementLuminanceSource(canvas)));
        const result = reader.decodeWithState(bitmap);
        const code = result.getText();
        if (!DIGITS.test(code)) return null;
        const pts = result.getResultPoints() ?? [];
        let box: Box | undefined;
        if (pts.length >= 2) {
          const xs = pts.map((p) => sx + p.getX() / scale);
          const ys = pts.map((p) => sy + p.getY() / scale);
          const x0 = Math.min(...xs);
          const w = Math.max(Math.max(...xs) - x0, 40);
          const yc = ys.reduce((a, b) => a + b, 0) / ys.length;
          box = { x: x0, y: yc - w * 0.3, width: w, height: w * 0.6 };
        }
        return { code, box };
      } catch {
        return null; // no code in this frame
      }
    },
  };
}

/** The <video> is drawn with object-fit: cover. Map between the view and the video's pixels. */
function coverTransform(video: HTMLVideoElement) {
  const cw = video.clientWidth;
  const ch = video.clientHeight;
  const vw = video.videoWidth;
  const vh = video.videoHeight;
  const scale = Math.max(cw / vw, ch / vh);
  return { scale, offX: (cw - vw * scale) / 2, offY: (ch - vh * scale) / 2 };
}

function stopStream(stream: MediaStream | null) {
  stream?.getTracks().forEach((t) => t.stop());
}

export function CameraFeed({ onCode, active, onStatus, retryKey = 0, region }: CameraFeedProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const decoderRef = useRef<Promise<Decoder> | null>(null);
  const onCodeRef = useRef(onCode);
  const onStatusRef = useRef(onStatus);
  const regionRef = useRef(region);
  const [status, setStatus] = useState<CameraStatus>('starting');
  const [wake, setWake] = useState(0);

  useEffect(() => {
    onCodeRef.current = onCode;
    onStatusRef.current = onStatus;
    regionRef.current = region;
  });

  // Start the camera; stop every track when leaving or when the tab goes to the background.
  useEffect(() => {
    let cancelled = false;
    const video = videoRef.current;
    const report = (s: CameraStatus) => {
      if (cancelled) return;
      setStatus(s);
      onStatusRef.current?.(s);
    };
    const start = async () => {
      if (typeof window === 'undefined') return;
      if (!window.isSecureContext) return report('insecure');
      const md = typeof navigator !== 'undefined' ? navigator.mediaDevices : undefined;
      if (!md?.getUserMedia) return report('unsupported');
      report('starting');
      try {
        const stream = await md.getUserMedia({
          audio: false,
          video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        });
        if (cancelled) {
          stopStream(stream);
          return;
        }
        streamRef.current = stream;
        const video = videoRef.current;
        if (video) {
          video.muted = true;
          video.setAttribute('playsinline', 'true');
          video.srcObject = stream;
          await video.play().catch(() => undefined);
        }
        report('live');
      } catch (e) {
        const name = (e as { name?: string } | null)?.name ?? '';
        if (name === 'NotAllowedError' || name === 'PermissionDeniedError' || name === 'SecurityError') report('denied');
        else if (name === 'NotFoundError' || name === 'DevicesNotFoundError' || name === 'OverconstrainedError') report('nocamera');
        else report('error');
      }
    };
    void start();
    // Warm up the decoder while the camera starts.
    decoderRef.current ??= browserDetector().then((d) => d ?? zxingDecoder());

    const onVisibility = () => {
      if (document.hidden) {
        stopStream(streamRef.current);
        streamRef.current = null;
      } else if (!streamRef.current) {
        setWake((n) => n + 1);
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      cancelled = true;
      document.removeEventListener('visibilitychange', onVisibility);
      stopStream(streamRef.current);
      streamRef.current = null;
      if (video) video.srcObject = null;
    };
  }, [retryKey, wake]);

  // The decode loop runs only while the screen wants codes.
  useEffect(() => {
    if (!active || status !== 'live') return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    // A read counts only with a valid check digit and the same code twice in a row: one misread
    // digit never opens the wrong product.
    const confirm = makeConfirmer();
    const run = async () => {
      const decoder = await (decoderRef.current ?? Promise.resolve(null));
      if (!decoder) return;
      const tick = async () => {
        if (stopped) return;
        const video = videoRef.current;
        let wait = decoder.interval;
        if (video && video.readyState >= 2 && video.videoWidth > 0 && video.clientWidth > 0) {
          const t = coverTransform(video);
          const reg = regionRef.current;
          // The frame in video pixels, with a generous margin around it.
          const inVideo = reg
            ? {
                x: (reg.x - reg.width * 0.15 - t.offX) / t.scale,
                y: (reg.y - reg.height * 0.3 - t.offY) / t.scale,
                width: (reg.width * 1.3) / t.scale,
                height: (reg.height * 1.6) / t.scale,
              }
            : null;
          let hit: Hit | null = null;
          try {
            hit = await decoder.decode(video, inVideo);
          } catch {
            hit = null;
          }
          if (stopped) return;
          if (hit && confirm(hit.code)) {
            const b = hit.box;
            onCodeRef.current(
              hit.code,
              b ? { x: b.x * t.scale + t.offX, y: b.y * t.scale + t.offY, width: b.width * t.scale, height: b.height * t.scale } : undefined,
            );
            wait = 1500;
          }
        }
        timer = setTimeout(() => void tick(), wait);
      };
      void tick();
    };
    void run();
    return () => {
      stopped = true;
      if (timer) clearTimeout(timer);
    };
  }, [active, status]);

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      <video
        ref={videoRef}
        playsInline
        muted
        autoPlay
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          background: 'transparent',
          opacity: status === 'live' ? 1 : 0,
          transition: 'opacity 450ms ease',
        }}
      />
    </View>
  );
}
