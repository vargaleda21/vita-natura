// iOS and Android: expo-camera does the decoding natively. Metro picks this file on the phone.
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useEffect, useRef } from 'react';
import { StyleSheet, View } from 'react-native';

import { makeConfirmer } from '@/data/api';
import type { CameraFeedProps } from './cameraTypes';

export function CameraFeed({ onCode, active, torch, onStatus, retryKey = 0 }: CameraFeedProps) {
  const [permission, requestPermission] = useCameraPermissions();
  const asked = useRef(-1);
  // A read counts only with a valid check digit and the same code twice in a row.
  const confirm = useRef(makeConfirmer());

  useEffect(() => {
    if (!permission) return;
    if (permission.granted) return;
    if (permission.canAskAgain && asked.current !== retryKey) {
      asked.current = retryKey;
      onStatus?.('starting');
      void requestPermission();
      return;
    }
    onStatus?.('denied');
  }, [permission, retryKey, requestPermission, onStatus]);

  if (!permission?.granted) return <View style={StyleSheet.absoluteFill} />;

  return (
    <CameraView
      style={StyleSheet.absoluteFill}
      facing="back"
      active={active}
      enableTorch={torch}
      barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8', 'upc_a', 'upc_e'] }}
      onCameraReady={() => onStatus?.('live')}
      onMountError={() => onStatus?.('error')}
      onBarcodeScanned={
        active
          ? (r) => {
              if (!confirm.current(r.data)) return;
              const b = r.bounds;
              const box =
                b && b.size.width > 0 && b.size.height > 0
                  ? { x: b.origin.x, y: b.origin.y, width: b.size.width, height: b.size.height }
                  : undefined;
              onCode(r.data, box);
            }
          : undefined
      }
    />
  );
}
