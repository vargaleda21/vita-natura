import { LinearGradient } from 'expo-linear-gradient';
import { type ReactNode, useEffect } from 'react';
import { ScrollView, View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

import { localSize } from '@/data/api';
import type { Product } from '@/data/types';
import { useLang, useTr } from '@/i18n';
import { font, palette, radius, space, springs } from '@/theme/tokens';
import { Icon, PackArt, PressableScale, Txt } from '@/ui';

const CARD_W = 116;
const CARD_H = 152;

type Props = {
  products: Product[];
  disabled: boolean;
  reduced: boolean;
  onPick: (product: Product) => void;
  onMystery: () => void;
  mysteryName: string;
  mysterySub: string;
  tryMe: string;
};

function alpha(hex: string, a: number): string {
  const h = hex.replace('#', '');
  if (h.length !== 6) return hex;
  return `#${h}${Math.round(a * 255)
    .toString(16)
    .padStart(2, '0')}`;
}

/** "No product to hand?": the way most people will try the demo, so it is big and inviting. */
export function DemoStrip({ products, disabled, reduced, onPick, onMystery, mysteryName, mysterySub, tryMe }: Props) {
  const tr = useTr();
  const lang = useLang();
  // The mystery card sits second, so the AI label-reading path is visible without scrolling.
  const renderCard = (p: Product, i: number) => (
    <Appear key={p.ean} index={i === 0 ? 0 : i + 1} reduced={reduced}>
      <PressableScale
        disabled={disabled}
        onPress={() => onPick(p)}
        accessibilityRole="button"
        accessibilityLabel={`${tr(p.name)}, ${p.brand}`}
        style={{ width: CARD_W, height: CARD_H }}
      >
        <LinearGradient
          colors={[alpha(p.art.colors[1], 0.34), 'rgba(255,255,255,0.05)']}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
          style={{
            flex: 1,
            borderRadius: radius.lg,
            borderWidth: 1,
            borderColor: 'rgba(255,255,255,0.13)',
            padding: space.md,
            paddingTop: space.sm,
          }}
        >
          <View style={{ alignItems: 'center', height: 70, justifyContent: 'flex-end' }}>
            <PackArt art={p.art} size={62} />
          </View>
          <Txt variant="small" color="#FFFFFF" numberOfLines={2} style={{ marginTop: space.sm, fontFamily: font.bodySemi }}>
            {tr(p.name)}
          </Txt>
          <Txt variant="tiny" color="rgba(255,255,255,0.55)" numberOfLines={1} style={{ marginTop: 2, letterSpacing: 0.2 }}>
            {p.brand} · {localSize(p.size, lang)}
          </Txt>
        </LinearGradient>
      </PressableScale>
      {i === 0 ? <TryMe label={tryMe} reduced={reduced} /> : null}
    </Appear>
  );
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{
        paddingHorizontal: space.xl,
        gap: space.md,
        paddingTop: 10,
        paddingBottom: 4,
      }}
      style={{ flexGrow: 0, overflow: 'visible' }}
    >
      {products.slice(0, 1).map(renderCard)}
      <Appear index={1} reduced={reduced}>
        <PressableScale
          disabled={disabled}
          onPress={onMystery}
          accessibilityRole="button"
          accessibilityLabel={`${mysteryName}. ${mysterySub}`}
          style={{
            width: CARD_W,
            height: CARD_H,
            borderRadius: radius.lg,
            borderWidth: 1.5,
            borderStyle: 'dashed',
            borderColor: 'rgba(198,243,107,0.55)',
            backgroundColor: 'rgba(198,243,107,0.06)',
            padding: space.md,
            justifyContent: 'flex-end',
          }}
        >
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <View
              style={{
                width: 46,
                height: 46,
                borderRadius: 23,
                backgroundColor: 'rgba(198,243,107,0.16)',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="sparkles" size={23} color={palette.lime} />
            </View>
          </View>
          <Txt variant="small" color="#FFFFFF" numberOfLines={2} style={{ fontFamily: font.bodySemi }}>
            {mysteryName}
          </Txt>
          <Txt variant="tiny" color={palette.lime} numberOfLines={2} style={{ marginTop: 2, letterSpacing: 0.2 }}>
            {mysterySub}
          </Txt>
        </PressableScale>
      </Appear>
      {products.slice(1).map((p, i) => renderCard(p, i + 1))}
    </ScrollView>
  );
}

function Appear({ index, reduced, children }: { index: number; reduced: boolean; children: ReactNode }) {
  const p = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    if (reduced) return;
    p.set(withDelay(180 + index * 70, withSpring(1, springs.soft)));
  }, [index, reduced, p]);
  const style = useAnimatedStyle(() => ({
    opacity: p.value,
    transform: [{ translateX: (1 - p.value) * 46 }],
  }));
  return <Animated.View style={style}>{children}</Animated.View>;
}

function TryMe({ label, reduced }: { label: string; reduced: boolean }) {
  const bob = useSharedValue(0);
  useEffect(() => {
    if (reduced) return;
    const e = Easing.inOut(Easing.sin);
    bob.set(
      withDelay(
        900,
        withRepeat(withSequence(withTiming(1, { duration: 650, easing: e }), withTiming(0, { duration: 650, easing: e })), -1),
      ),
    );
  }, [reduced, bob]);
  const style = useAnimatedStyle(() => ({
    transform: [{ translateY: -bob.value * 4 }, { rotate: '-4deg' }],
  }));
  return (
    <Animated.View
      pointerEvents="none"
      style={[
        {
          position: 'absolute',
          top: -9,
          left: -4,
          backgroundColor: palette.lime,
          borderRadius: radius.pill,
          paddingHorizontal: 9,
          paddingVertical: 3,
        },
        style,
      ]}
    >
      <Txt variant="tiny" color={palette.ink} style={{ letterSpacing: 0.3 }}>
        {label}
      </Txt>
    </Animated.View>
  );
}
