import { useEffect, useRef, useState } from 'react';
import { Platform, View } from 'react-native';

import { font, radius, space, verdictColor } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { PrimaryButton } from './buttons';
import { checkDigit, isValidCode } from './ean';
import { Sheet } from './Sheet';
import { strings } from './strings';

type Props = {
  visible: boolean;
  reduced: boolean;
  t: (typeof strings)['hu'];
  onClose: () => void;
  onSubmit: (code: string) => void;
};

const MAX = 13;

type Check = { tone: 'info' | 'ok' | 'bad'; text: string };

function describe(code: string, t: Props['t']): Check {
  if (code.length === 0) return { tone: 'info', text: t.keypadSub };
  if (code.length === 8 && isValidCode(code)) return { tone: 'ok', text: t.validCode8 };
  if (code.length === 12 && isValidCode(code)) return { tone: 'ok', text: t.validCode12 };
  if (code.length < MAX) return { tone: 'info', text: t.digitsLeft(MAX - code.length) };
  if (isValidCode(code)) return { tone: 'ok', text: t.validCode };
  return { tone: 'bad', text: t.badCheck(checkDigit(code.slice(0, -1))) };
}

/** Type an EAN by hand. The check digit is verified as you type the last one. */
export function KeypadSheet({ visible, reduced, t, onClose, onSubmit }: Props) {
  const { c, isDark } = useTheme();
  const [code, setCode] = useState('');
  const codeRef = useRef(code);
  useEffect(() => {
    codeRef.current = code;
  }, [code]);
  const check = describe(code, t);
  const ready = check.tone === 'ok';

  const press = (k: string) => setCode((s) => (s.length >= MAX ? s : s + k));
  const back = () => setCode((s) => s.slice(0, -1));
  const submit = () => {
    if (!ready) return;
    onSubmit(code);
    setCode('');
  };

  // A hardware keyboard works too, on the web. Listen in the capture phase and swallow the keys we
  // use, so Enter does not also press the button that opened the sheet (it keeps focus behind it).
  useEffect(() => {
    if (!visible || Platform.OS !== 'web' || typeof window === 'undefined') return;
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      // Typing in a text field elsewhere (the maker search on the not-found sheet) is not for the keypad.
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable)) return;
      if (/^\d$/.test(e.key)) setCode((s) => (s.length >= MAX ? s : s + e.key));
      else if (e.key === 'Backspace') setCode((s) => s.slice(0, -1));
      else if (e.key === 'Escape') onClose();
      else if (e.key === 'Enter') {
        const s = codeRef.current;
        if (isValidCode(s) && (s.length === 13 || s.length === 12 || s.length === 8)) {
          setCode('');
          onSubmit(s);
        }
      } else return;
      e.preventDefault();
      e.stopPropagation();
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [visible, onClose, onSubmit]);

  const tone = check.tone === 'ok' ? verdictColor.great : check.tone === 'bad' ? verdictColor.avoid : c.textMuted;
  const slots = Array.from({ length: MAX }, (_, i) => code[i]);
  const keyBg = isDark ? c.surfaceAlt : c.surface;

  return (
    <Sheet visible={visible} onClose={onClose} reduced={reduced} label={t.close}>
      <Txt variant="h2">{t.keypadTitle}</Txt>

      <View
        style={{
          marginTop: space.lg,
          borderRadius: radius.lg,
          backgroundColor: keyBg,
          borderWidth: 1.5,
          borderColor: check.tone === 'bad' ? verdictColor.avoid : check.tone === 'ok' ? verdictColor.great : c.border,
          paddingVertical: space.lg,
          paddingHorizontal: space.md,
        }}
        accessibilityLiveRegion="polite"
        accessibilityLabel={code.length ? code.split('').join(' ') : t.keypadSub}
      >
        <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
          {slots.map((d, i) => (
            <View key={i} style={{ width: 21, alignItems: 'center', marginLeft: i === 1 || i === 7 ? 8 : 0 }}>
              <Txt
                style={{
                  fontFamily: font.display,
                  fontSize: 26,
                  lineHeight: 32,
                  color: d ? (i === MAX - 1 && check.tone === 'bad' ? verdictColor.avoid : c.text) : c.textFaint,
                  opacity: d ? 1 : 0.5,
                }}
              >
                {d ?? '·'}
              </Txt>
            </View>
          ))}
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: space.sm, minHeight: 20 }}>
          {check.tone !== 'info' ? (
            <Icon name={check.tone === 'ok' ? 'check' : 'circle-alert'} size={15} color={tone} strokeWidth={2.6} />
          ) : null}
          <Txt variant="small" color={tone} center style={{ flexShrink: 1 }}>
            {check.text}
          </Txt>
        </View>
      </View>

      <View style={{ marginTop: space.lg, gap: space.sm }}>
        {[
          ['1', '2', '3'],
          ['4', '5', '6'],
          ['7', '8', '9'],
          ['clear', '0', 'back'],
        ].map((row, r) => (
          <View key={r} style={{ flexDirection: 'row', gap: space.sm }}>
            {row.map((k) => {
              const special = k === 'clear' || k === 'back';
              return (
                <PressableScale
                  key={k}
                  scaleTo={0.92}
                  onPress={() => (k === 'back' ? back() : k === 'clear' ? setCode('') : press(k))}
                  accessibilityRole="button"
                  accessibilityLabel={k === 'back' ? t.backspace : k === 'clear' ? t.clearAll : k}
                  style={{
                    flex: 1,
                    height: 54,
                    borderRadius: radius.md,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: special ? 'transparent' : keyBg,
                    borderWidth: special ? 0 : 1,
                    borderColor: c.border,
                  }}
                >
                  {k === 'back' ? (
                    <Icon name="chevron-left" size={26} color={c.text} />
                  ) : k === 'clear' ? (
                    <Txt variant="bodyStrong" muted>
                      C
                    </Txt>
                  ) : (
                    <Txt style={{ fontFamily: font.displaySemi, fontSize: 24, lineHeight: 28, color: c.text }}>{k}</Txt>
                  )}
                </PressableScale>
              );
            })}
          </View>
        ))}
      </View>

      <View style={{ marginTop: space.lg }}>
        <PrimaryButton label={t.search} icon="scan-barcode" onPress={submit} disabled={!ready} />
      </View>
    </Sheet>
  );
}
