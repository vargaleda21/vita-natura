import { View } from 'react-native';

import { font, palette, radius, space } from '@/theme/tokens';
import { Icon, type IconName, PressableScale, Txt, useTheme } from '@/ui';

type BtnProps = { label: string; icon?: IconName; onPress: () => void; disabled?: boolean; a11y?: string };

/** The lime call to action. */
export function PrimaryButton({ label, icon, onPress, disabled, a11y }: BtnProps) {
  return (
    <PressableScale
      haptic="medium"
      disabled={disabled}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={a11y ?? label}
      accessibilityState={{ disabled }}
      style={{
        height: 56,
        borderRadius: radius.pill,
        backgroundColor: palette.lime,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: space.sm,
        opacity: disabled ? 0.4 : 1,
      }}
    >
      {icon ? <Icon name={icon} size={20} color={palette.ink} strokeWidth={2.2} /> : null}
      <Txt variant="bodyStrong" color={palette.ink} style={{ fontSize: 16 }}>
        {label}
      </Txt>
    </PressableScale>
  );
}

/** A quiet text button for the second choice. */
export function GhostButton({ label, icon, onPress, a11y }: BtnProps) {
  const { c } = useTheme();
  return (
    <PressableScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={a11y ?? label}
      style={{ height: 50, borderRadius: radius.pill, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: space.sm }}
    >
      {icon ? <Icon name={icon} size={18} color={c.textMuted} /> : null}
      <Txt variant="bodyStrong" muted>
        {label}
      </Txt>
    </PressableScale>
  );
}

/** A round glassy icon button for the dark camera screen. */
export function GlassIconButton({
  icon,
  glyph,
  onPress,
  label,
  active,
}: {
  icon: IconName;
  /** A text glyph instead of the icon, e.g. "?". */
  glyph?: string;
  onPress: () => void;
  label: string;
  active?: boolean;
}) {
  return (
    <PressableScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ selected: active }}
      hitSlop={6}
      style={{
        width: 44,
        height: 44,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: active ? palette.lime : 'rgba(255,255,255,0.12)',
        borderWidth: 1,
        borderColor: active ? palette.lime : 'rgba(255,255,255,0.18)',
      }}
    >
      {glyph ? (
        <Txt style={{ fontFamily: font.display, fontSize: 21, lineHeight: 24, color: '#FFFFFF', marginTop: -1 }}>{glyph}</Txt>
      ) : (
        <Icon name={icon} size={20} color={active ? palette.ink : '#FFFFFF'} strokeWidth={2.2} />
      )}
    </PressableScale>
  );
}

/** A small glassy pill with an icon, for the dark camera screen. */
export function GlassPill({ label, icon, onPress, a11y }: BtnProps) {
  return (
    <PressableScale
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={a11y ?? label}
      hitSlop={4}
      style={{
        minHeight: 44,
        paddingHorizontal: 14,
        borderRadius: radius.pill,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        backgroundColor: 'rgba(255,255,255,0.1)',
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.16)',
      }}
    >
      {icon ? <Icon name={icon} size={16} color="#FFFFFF" /> : null}
      <Txt variant="small" color="#FFFFFF" style={{ fontFamily: font.bodySemi }}>
        {label}
      </Txt>
    </PressableScale>
  );
}

export function Spacer({ h }: { h: number }) {
  return <View style={{ height: h }} />;
}
