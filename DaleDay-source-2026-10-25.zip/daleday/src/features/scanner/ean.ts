// Barcode maths: the GS1 check digit and the EAN-13 / EAN-8 bar patterns, so the demo can
// draw a real, scannable barcode for any code instead of a fake stripe pattern.

import { canonical } from '@/data/api';

/** The check digit for a code body (every digit but the last), for EAN-13, EAN-8 and UPC-A. */
export function checkDigit(body: string): number {
  let sum = 0;
  for (let i = 0; i < body.length; i++) {
    const d = Number(body[body.length - 1 - i]);
    sum += d * (i % 2 === 0 ? 3 : 1);
  }
  return (10 - (sum % 10)) % 10;
}

/** True for a complete EAN-13, EAN-8, UPC-A or UPC-E code whose check digit fits. */
export function isValidCode(code: string): boolean {
  return /^\d+$/.test(code) && canonical(code) !== null;
}

/** The codes our catalogue may hold for a scanned value: the canonical 13-digit key first
 *  (UPC-A is EAN-13 with a leading zero; UPC-E expands to UPC-A), then the code as read. */
export function lookupCandidates(code: string): string[] {
  const c = canonical(code);
  return c ? [...new Set([c.key, ...c.variants, code])] : [code];
}

const L = ['0001101', '0011001', '0010011', '0111101', '0100011', '0110001', '0101111', '0111011', '0110111', '0001011'];
const G = ['0100111', '0110011', '0011011', '0100001', '0011101', '0111001', '0000101', '0010001', '0001001', '0010111'];
const R = ['1110010', '1100110', '1101100', '1000010', '1011100', '1001110', '1010000', '1000100', '1001000', '1110100'];
const PARITY = ['LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', 'LGLLGG', 'LGGLLG', 'LGGGLL', 'LGLGLG', 'LGLGGL', 'LGGLGL'];

export type BarModule = { x: number; w: number; guard: boolean };

/**
 * The bars of an EAN-13 (or EAN-8) code as runs of dark modules. `total` is the width in modules.
 * Anything else is padded to 13 digits first.
 */
export function eanBars(code: string): { bars: BarModule[]; total: number } {
  let bits = '';
  let guards: boolean[] = [];
  const push = (s: string, guard: boolean) => {
    bits += s;
    guards = guards.concat(Array.from(s, () => guard));
  };
  if (code.length === 8) {
    push('101', true);
    for (let i = 0; i < 4; i++) push(L[Number(code[i])], false);
    push('01010', true);
    for (let i = 4; i < 8; i++) push(R[Number(code[i])], false);
    push('101', true);
  } else {
    const c = code.padStart(13, '0').slice(-13);
    const parity = PARITY[Number(c[0])];
    push('101', true);
    for (let i = 1; i <= 6; i++) push((parity[i - 1] === 'L' ? L : G)[Number(c[i])], false);
    push('01010', true);
    for (let i = 7; i <= 12; i++) push(R[Number(c[i])], false);
    push('101', true);
  }
  const bars: BarModule[] = [];
  let i = 0;
  while (i < bits.length) {
    if (bits[i] === '1') {
      const start = i;
      while (i < bits.length && bits[i] === '1' && guards[i] === guards[start]) i++;
      bars.push({ x: start, w: i - start, guard: guards[start] });
    } else {
      i++;
    }
  }
  return { bars, total: bits.length };
}

/** "5 990000 123457": how the digits are printed under an EAN-13. */
export function printedGroups(code: string): string[] {
  if (code.length === 13) return [code[0], code.slice(1, 7), code.slice(7)];
  if (code.length === 8) return [code.slice(0, 4), code.slice(4)];
  return [code];
}
