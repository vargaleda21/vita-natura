/** A rectangle in the camera view's own coordinates (points / CSS pixels). */
export type Box = { x: number; y: number; width: number; height: number };

export type CameraStatus =
  | 'starting'
  | 'live'
  | 'denied'
  | 'nocamera'
  | 'insecure'
  | 'unsupported'
  | 'error';

/** One interface for both platforms: CameraFeed.tsx (web) and CameraFeed.native.tsx. */
export type CameraFeedProps = {
  /** Called once per detected code while `active`. `box` is where the code sits, if known. */
  onCode: (code: string, box?: Box) => void;
  /** When false the feed keeps showing but stops decoding. */
  active: boolean;
  /** Native only; the web feed ignores it. */
  torch: boolean;
  onStatus?: (status: CameraStatus) => void;
  /** Bump it to try the camera again after an error. */
  retryKey?: number;
  /** The viewfinder, in view coordinates: the web decoder reads only around it. */
  region?: Box;
};

export const BARCODE_FORMATS_WEB = ['ean_13', 'ean_8', 'upc_a', 'upc_e'] as const;
