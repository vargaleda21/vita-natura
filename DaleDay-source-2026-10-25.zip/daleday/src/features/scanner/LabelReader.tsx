import { LinearGradient } from 'expo-linear-gradient';
import { useEffect, useRef, useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import Animated, {
  cancelAnimation,
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { evaluate } from '@/data/api';
import type { Ingredient, Product } from '@/data/types';
import { groupDigits, useTr } from '@/i18n';
import { getSettings } from '@/state/store';
import { font, palette, radius, shadow, space, springs } from '@/theme/tokens';
import { Icon, Txt } from '@/ui';
import { GlassIconButton } from './buttons';
import { Glows } from './Glows';
import type { strings } from './strings';

type T = (typeof strings)['hu'];

const NBSP = ' ';
const decimal = (x: number) => (Number.isInteger(x) ? String(x) : x.toFixed(1).replace('.', ','));

/** One ingredient as it is printed on a Hungarian label. `[E322]` marks an E number for the second step. */
function printed(i: Ingredient): string {
  let name = i.name.hu;
  if (i.eNumber) {
    const colon = name.indexOf(':');
    name = colon > 0 ? `${name.slice(0, colon)}: [${i.eNumber}] (${name.slice(colon + 1).trim()})` : `${name} ([${i.eNumber}])`;
  }
  return i.percent !== undefined ? `${name} (${decimal(i.percent)}%)` : name;
}

/** The "photo" of the label is built from what the AI read. It is a printed Hungarian label, so it stays Hungarian in both languages. */
function labelLines(product: Product, maxChars: number): string[] {
  const words = `${product.ingredients.map(printed).join(', ')}.`.split(' ');
  const lines: string[] = [];
  let line = '';
  for (const w of words) {
    const next = line ? `${line} ${w}` : w;
    if (line && next.length > maxChars) {
      lines.push(line);
      line = w;
    } else line = next;
  }
  if (line) lines.push(line);
  return lines;
}

function nutritionRows(product: Product): [string, string][] {
  // The mock AI read always gives every value.
  const n = product.nutrition;
  const kcal = n.energyKcal ?? 0;
  return [
    ['Energia', `${groupDigits(kcal * 4.184, NBSP)}${NBSP}kJ / ${groupDigits(kcal, NBSP)}${NBSP}kcal`],
    ['Telített zsírsavak', `${decimal(n.satFatG ?? 0)}${NBSP}g`],
    ['Cukrok', `${decimal(n.sugarG ?? 0)}${NBSP}g`],
    ['Só', `${decimal(n.saltG ?? 0)}${NBSP}g`],
  ];
}

const NUTRITION_BLANK: [string, string][] = [
  ['Energia', ''],
  ['Telített zsírsavak', ''],
  ['Cukrok', ''],
  ['Só', ''],
];

type Props = {
  /** What the AI read; null while it is still reading. */
  result: Product | null;
  width: number;
  reduced: boolean;
  t: T;
  onDone: (product: Product) => void;
  onCancel: () => void;
};

/** "AI reads the label": a mock that looks like the real thing, then hands the Product back. */
export function LabelReader({ result, width, reduced, t, onDone, onCancel }: Props) {
  const insets = useSafeAreaInsets();
  const tr = useTr();
  const [step, setStep] = useState(0);
  const [paperH, setPaperH] = useState(260);
  const onDoneRef = useRef(onDone);
  useEffect(() => {
    onDoneRef.current = onDone;
  });

  // The steps run once the read is in: highlight the lines, find the E numbers, compare, done.
  useEffect(() => {
    if (!result) return;
    const at = reduced ? [150, 300, 450, 1350] : [900, 1600, 2300, 3900];
    const timers = [
      setTimeout(() => setStep(1), at[0]),
      setTimeout(() => setStep(2), at[1]),
      setTimeout(() => setStep(3), at[2]),
      setTimeout(() => onDoneRef.current(result), at[3]),
    ];
    return () => timers.forEach(clearTimeout);
  }, [result, reduced]);

  const enter = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    enter.set(reduced ? 1 : withSpring(1, springs.soft));
  }, [enter, reduced]);
  const paperStyle = useAnimatedStyle(() => ({
    opacity: enter.value,
    transform: [
      { translateY: (1 - enter.value) * 40 },
      { rotate: `${-2.5 - (1 - enter.value) * 6}deg` },
      { scale: 0.92 + 0.08 * enter.value },
    ],
  }));

  const labelW = Math.min(width - 64, 318);
  // Inner width over the average glyph width of 12px text, so a line never needs to wrap.
  const maxChars = Math.max(24, Math.floor((labelW - 46) / 7.2));
  const done = step >= 3;
  const settings = getSettings();
  const hitNames = new Set(result ? evaluate(result, settings).hits.flatMap((h) => h.ingredients.map((i) => tr(i))) : []);
  const eCount = result ? result.ingredients.filter((i) => i.eNumber).length : 0;
  const lines = result ? labelLines(result, maxChars) : null;
  const nutrition = result ? nutritionRows(result) : null;

  return (
    <View style={[StyleSheet.absoluteFill, { backgroundColor: palette.night }]}>
      <Glows
        width={width}
        height={900}
        spots={[
          { x: width * 0.1, y: 120, rx: 260, ry: 220, color: palette.lilac, opacity: 0.32 },
          { x: width * 0.95, y: 520, rx: 240, ry: 260, color: palette.sky, opacity: 0.2 },
          { x: width * 0.5, y: 860, rx: 300, ry: 200, color: palette.lime, opacity: 0.12 },
        ]}
      />
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + 8,
          paddingBottom: insets.bottom + 32,
          minHeight: '100%',
        }}
        showsVerticalScrollIndicator={false}
      >
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            paddingHorizontal: space.lg,
            height: 52,
          }}
        >
          <GlassIconButton icon="x" label={t.readerCancel} onPress={onCancel} />
          <View style={{ flex: 1, alignItems: 'center' }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 6,
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: radius.pill,
                backgroundColor: 'rgba(185,164,255,0.16)',
                borderWidth: 1,
                borderColor: 'rgba(185,164,255,0.35)',
              }}
            >
              <Icon name="sparkles" size={14} color={palette.lilac} />
              <Txt variant="tiny" color={palette.lilac} upper>
                {t.readerBadge}
              </Txt>
            </View>
          </View>
          <View style={{ width: 44 }} />
        </View>

        <Txt variant="h1" color="#FFFFFF" center style={{ marginTop: space.lg }}>
          {done ? t.readerDone : t.readerTitle}
        </Txt>

        <Animated.View style={[{ alignSelf: 'center', marginTop: space.xl, width: labelW }, paperStyle]}>
          <View style={[{ backgroundColor: '#FFFFFF', borderRadius: 16, padding: 9 }, shadow.float]}>
            <View
              onLayout={(e) => setPaperH(e.nativeEvent.layout.height)}
              style={{
                backgroundColor: '#FBF6E8',
                borderRadius: 9,
                paddingHorizontal: 14,
                paddingVertical: 14,
                overflow: 'hidden',
              }}
            >
              <Txt
                style={{
                  fontFamily: font.bodyBold,
                  fontSize: 12,
                  letterSpacing: 0.8,
                  color: palette.ink,
                  marginBottom: 6,
                }}
              >
                ÖSSZETEVŐK:
              </Txt>
              {lines
                ? lines.map((line, i) => <LabelLine key={i} line={line} index={i} step={step} reduced={reduced} />)
                : [0.94, 0.8, 0.88, 0.7, 0.9, 0.55].map((w, i) => <Smudge key={i} width={w} index={i} reduced={reduced} />)}
              <View style={{ height: 1, backgroundColor: 'rgba(16,35,28,0.18)', marginVertical: 9 }} />
              <Txt
                style={{
                  fontFamily: font.bodyBold,
                  fontSize: 10.5,
                  letterSpacing: 0.6,
                  color: palette.ink,
                  marginBottom: 3,
                }}
              >
                TÁPÉRTÉK 100 g-BAN
              </Txt>
              {(nutrition ?? NUTRITION_BLANK).map(([k, v]) => (
                <View
                  key={k}
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    paddingVertical: 1,
                  }}
                >
                  <Txt
                    style={{
                      fontFamily: font.body,
                      fontSize: 11,
                      lineHeight: 15,
                      color: '#3B4A43',
                    }}
                  >
                    {k}
                  </Txt>
                  {v ? (
                    <Txt
                      style={{
                        fontFamily: font.bodySemi,
                        fontSize: 11,
                        lineHeight: 15,
                        color: '#3B4A43',
                      }}
                    >
                      {v}
                    </Txt>
                  ) : (
                    <View
                      style={{
                        width: 54,
                        height: 7,
                        borderRadius: 4,
                        backgroundColor: 'rgba(16,35,28,0.14)',
                      }}
                    />
                  )}
                </View>
              ))}
              {done ? null : <Beam reduced={reduced} height={paperH} />}
            </View>
          </View>
        </Animated.View>

        <View style={{ marginTop: space.xxl, paddingHorizontal: space.xxl, gap: space.md }}>
          {[
            [t.step1, t.step1Done],
            [t.step2, result && eCount === 0 ? t.step2None : t.step2Done],
            [t.step3, t.step3Done],
          ].map(([busy, ok], i) => (
            <StepRow key={i} label={step > i ? ok : busy} state={step > i ? 'done' : step === i ? 'busy' : 'todo'} reduced={reduced} />
          ))}
        </View>

        {result && done ? (
          <Found
            reduced={reduced}
            summary={t.foundSummary(result.ingredients.length, eCount)}
            chips={result.ingredients.slice(0, 7).map((i) => ({ name: tr(i.name), hit: hitNames.has(tr(i.name)) }))}
          />
        ) : null}

        <View style={{ flex: 1 }} />
        <View
          style={{
            alignSelf: 'center',
            marginTop: space.xl,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            paddingHorizontal: 14,
            paddingVertical: 8,
            borderRadius: radius.pill,
            backgroundColor: 'rgba(255,255,255,0.07)',
            borderWidth: 1,
            borderColor: 'rgba(255,255,255,0.12)',
          }}
        >
          <Icon name="info" size={14} color="rgba(255,255,255,0.75)" />
          <Txt variant="small" color="rgba(255,255,255,0.75)">
            {t.aiNote}
          </Txt>
        </View>
      </ScrollView>
    </View>
  );
}

function LabelLine({ line, index, step, reduced }: { line: string; index: number; step: number; reduced: boolean }) {
  const mark = useSharedValue(0);
  useEffect(() => {
    mark.set(withDelay(reduced ? 0 : 250 + index * 170, withTiming(1, { duration: reduced ? 0 : 260 })));
  }, [mark, index, reduced]);
  const markStyle = useAnimatedStyle(() => ({
    opacity: mark.value * 0.55,
    transform: [{ scaleX: 0.2 + 0.8 * mark.value }],
  }));
  const parts = line.split(/(\[E\d+[a-z]?\])/).filter(Boolean);
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start',
        paddingVertical: 1.5,
      }}
    >
      <Animated.View
        style={[
          {
            position: 'absolute',
            left: -3,
            right: -3,
            top: 1,
            bottom: 1,
            borderRadius: 4,
            backgroundColor: palette.lime,
            transformOrigin: 'left',
          },
          markStyle,
        ]}
      />
      {parts.map((part, i) => {
        const e = /^\[(E\d+[a-z]?)\]$/.exec(part);
        if (e) return <ENumber key={i} label={e[1]} active={step >= 1} reduced={reduced} />;
        return (
          <Txt
            key={i}
            style={{
              fontFamily: font.bodyMedium,
              fontSize: 12,
              lineHeight: 17,
              color: palette.ink,
            }}
            numberOfLines={1}
          >
            {part}
          </Txt>
        );
      })}
    </View>
  );
}

/** A line of the photo the AI has not read yet. */
function Smudge({ width, index, reduced }: { width: number; index: number; reduced: boolean }) {
  const p = useSharedValue(0.5);
  useEffect(() => {
    if (reduced) return;
    const e = Easing.inOut(Easing.sin);
    p.set(withDelay(index * 110, withRepeat(withTiming(1, { duration: 700, easing: e }), -1, true)));
    return () => cancelAnimation(p);
  }, [p, index, reduced]);
  const style = useAnimatedStyle(() => ({ opacity: 0.35 + 0.65 * p.value }));
  return (
    <View style={{ paddingVertical: 4.5 }}>
      <Animated.View
        style={[
          {
            width: `${width * 100}%`,
            height: 8,
            borderRadius: 4,
            backgroundColor: 'rgba(16,35,28,0.16)',
          },
          style,
        ]}
      />
    </View>
  );
}

function ENumber({ label, active, reduced }: { label: string; active: boolean; reduced: boolean }) {
  const p = useSharedValue(0);
  useEffect(() => {
    if (active) p.set(reduced ? 1 : withDelay(120, withSpring(1, springs.bouncy)));
  }, [active, reduced, p]);
  const ring = useAnimatedStyle(() => ({
    opacity: p.value,
    transform: [{ scale: 1.5 - 0.5 * p.value }],
  }));
  return (
    <View style={{ paddingHorizontal: 3 }}>
      <Animated.View
        style={[
          {
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            borderRadius: 4,
            borderWidth: 1.5,
            borderColor: palette.tangerine,
            backgroundColor: 'rgba(255,201,61,0.45)',
          },
          ring,
        ]}
      />
      <Txt style={{ fontFamily: font.bodyBold, fontSize: 12, lineHeight: 17, color: palette.ink }}>{label}</Txt>
    </View>
  );
}

function Beam({ reduced, height }: { reduced: boolean; height: number }) {
  const y = useSharedValue(0);
  useEffect(() => {
    if (reduced) return;
    y.set(withRepeat(withTiming(1, { duration: 1300, easing: Easing.inOut(Easing.quad) }), -1, true));
    return () => cancelAnimation(y);
  }, [y, reduced]);
  const style = useAnimatedStyle(() => ({ transform: [{ translateY: -40 + y.value * height }] }));
  if (reduced) return null;
  return (
    <Animated.View pointerEvents="none" style={[{ position: 'absolute', left: 0, right: 0, top: 0, height: 80 }, style]}>
      <LinearGradient colors={['rgba(143,209,59,0)', 'rgba(143,209,59,0.26)', 'rgba(143,209,59,0)']} style={StyleSheet.absoluteFill} />
      <View
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 39,
          height: 2,
          backgroundColor: palette.limeDeep,
        }}
      />
    </Animated.View>
  );
}

function StepRow({ label, state, reduced }: { label: string; state: 'todo' | 'busy' | 'done'; reduced: boolean }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
      <View style={{ width: 24, height: 24, alignItems: 'center', justifyContent: 'center' }}>
        {state === 'done' ? (
          <View
            style={{
              width: 22,
              height: 22,
              borderRadius: 11,
              backgroundColor: palette.lime,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Icon name="check" size={14} color={palette.ink} strokeWidth={3} />
          </View>
        ) : state === 'busy' ? (
          <Spinner reduced={reduced} />
        ) : (
          <View
            style={{
              width: 18,
              height: 18,
              borderRadius: 9,
              borderWidth: 2,
              borderColor: 'rgba(255,255,255,0.18)',
            }}
          />
        )}
      </View>
      <Txt
        variant="bodyStrong"
        color={state === 'todo' ? 'rgba(255,255,255,0.4)' : state === 'busy' ? '#FFFFFF' : 'rgba(255,255,255,0.78)'}
      >
        {label}
      </Txt>
    </View>
  );
}

function Spinner({ reduced }: { reduced: boolean }) {
  const r = useSharedValue(0);
  useEffect(() => {
    if (reduced) return;
    r.set(withRepeat(withTiming(1, { duration: 800, easing: Easing.linear }), -1, false));
    return () => cancelAnimation(r);
  }, [r, reduced]);
  const style = useAnimatedStyle(() => ({ transform: [{ rotate: `${r.value * 360}deg` }] }));
  return (
    <Animated.View
      style={[
        {
          width: 20,
          height: 20,
          borderRadius: 10,
          borderWidth: 2.5,
          borderColor: 'rgba(255,255,255,0.18)',
          borderTopColor: palette.lime,
        },
        style,
      ]}
    />
  );
}

function Found({ summary, chips, reduced }: { summary: string; chips: { name: string; hit: boolean }[]; reduced: boolean }) {
  const p = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    if (!reduced) p.set(withSpring(1, springs.bouncy));
  }, [p, reduced]);
  const style = useAnimatedStyle(() => ({
    opacity: p.value,
    transform: [{ translateY: (1 - p.value) * 16 }],
  }));
  return (
    <Animated.View style={[{ marginTop: space.xl, paddingHorizontal: space.xl }, style]}>
      <Txt variant="tiny" upper color={palette.lime} center>
        {summary}
      </Txt>
      <View
        style={{
          flexDirection: 'row',
          flexWrap: 'wrap',
          gap: 6,
          justifyContent: 'center',
          marginTop: space.sm,
        }}
      >
        {chips.map((chip, i) => (
          <View
            key={i}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 5,
              paddingHorizontal: 10,
              paddingVertical: 5,
              borderRadius: radius.pill,
              backgroundColor: chip.hit ? 'rgba(255,138,61,0.18)' : 'rgba(255,255,255,0.08)',
              borderWidth: 1,
              borderColor: chip.hit ? 'rgba(255,138,61,0.6)' : 'rgba(255,255,255,0.12)',
            }}
          >
            {chip.hit ? <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: palette.tangerine }} /> : null}
            <Txt variant="small" color="#FFFFFF">
              {chip.name}
            </Txt>
          </View>
        ))}
      </View>
    </Animated.View>
  );
}
