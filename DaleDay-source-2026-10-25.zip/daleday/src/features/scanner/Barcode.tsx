import { View } from 'react-native';
import Svg, { Rect } from 'react-native-svg';

import { font, palette } from '@/theme/tokens';
import { Txt } from '@/ui';
import { eanBars, printedGroups } from './ean';

type Props = { code: string; width: number; height: number; color?: string; digits?: boolean };

/** A real EAN-13 / EAN-8 barcode, drawn bar by bar. */
export function Barcode({ code, width, height, color = palette.ink, digits = true }: Props) {
  const { bars, total } = eanBars(code);
  const quiet = 6;
  const unit = width / (total + quiet * 2);
  const textH = digits ? 14 : 0;
  const barH = height - textH;
  const groups = printedGroups(code);
  return (
    <View style={{ width, height }}>
      <Svg width={width} height={barH + (digits ? 5 : 0)}>
        {bars.map((b) => (
          <Rect
            key={b.x}
            x={(quiet + b.x) * unit}
            y={0}
            width={b.w * unit}
            height={b.guard && digits ? barH + 5 : barH}
            fill={color}
          />
        ))}
      </Svg>
      {digits ? (
        <View style={{ flexDirection: 'row', justifyContent: 'space-around', paddingHorizontal: unit * 2, marginTop: -3 }}>
          {groups.map((g, i) => (
            <Txt
              key={i}
              color={color}
              style={{ fontFamily: font.bodySemi, fontSize: Math.max(9, Math.min(13, unit * 6.4)), lineHeight: 14, letterSpacing: unit * 1.6 }}
            >
              {g}
            </Txt>
          ))}
        </View>
      ) : null}
    </View>
  );
}
