import { LinearGradient } from 'expo-linear-gradient';
import { useEffect } from 'react';
import { Text, View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring, withTiming } from 'react-native-reanimated';

import type { PackArt } from '@/data/types';
import { shadow, springs } from '@/theme/tokens';
import { Barcode } from './Barcode';
import type { Box } from './cameraTypes';

/** Where the pack face and its barcode sticker sit inside the viewfinder. */
export function virtualGeometry(frame: Box) {
  const cw = Math.round(frame.width * 0.86);
  const ch = Math.round(frame.height * 0.74);
  const card = { x: frame.x + (frame.width - cw) / 2, y: frame.y + (frame.height - ch) / 2, width: cw, height: ch };
  const sw = Math.round(cw * 0.6);
  const sh = Math.round(ch * 0.7);
  const sticker = { x: card.x + cw - 14 - sw, y: card.y + (ch - sh) / 2, width: sw, height: sh };
  return { card, sticker };
}

type Props = { frame: Box; code: string; art?: PackArt; reduced: boolean };

/** A demo pack held up to the camera, with a real barcode for the brackets to snap to. */
export function VirtualLabel({ frame, code, art, reduced }: Props) {
  const { card, sticker } = virtualGeometry(frame);
  const p = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    p.set(reduced ? withTiming(1, { duration: 120 }) : withSpring(1, springs.soft));
  }, [p, reduced]);
  const style = useAnimatedStyle(() => ({
    opacity: Math.min(1, p.value * 1.6),
    transform: [
      { translateY: (1 - p.value) * 90 },
      { rotate: `${(1 - p.value) * -9}deg` },
      { scale: 0.84 + 0.16 * p.value },
    ],
  }));
  const colors: [string, string] = art ? [art.colors[1], art.colors[0]] : ['#F3F1EA', '#D9D5C9'];
  return (
    <Animated.View
      pointerEvents="none"
      style={[{ position: 'absolute', left: card.x, top: card.y, width: card.width, height: card.height }, style]}
    >
      <LinearGradient
        colors={colors}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[{ flex: 1, borderRadius: 18, overflow: 'hidden' }, shadow.float]}
      >
        <View
          style={{ position: 'absolute', left: 18, top: 0, bottom: 0, width: 16, backgroundColor: 'rgba(255,255,255,0.2)' }}
        />
        {art ? (
          <View style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: card.width - sticker.width - 14, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: Math.round(card.height * 0.36) }}>{art.emoji}</Text>
          </View>
        ) : null}
      </LinearGradient>
      <View
        style={{
          position: 'absolute',
          left: sticker.x - card.x,
          top: sticker.y - card.y,
          width: sticker.width,
          height: sticker.height,
          backgroundColor: '#FFFFFF',
          borderRadius: 8,
          paddingHorizontal: 6,
          paddingTop: 8,
          paddingBottom: 4,
          alignItems: 'center',
        }}
      >
        <Barcode code={code} width={sticker.width - 12} height={sticker.height - 12} />
      </View>
    </Animated.View>
  );
}
