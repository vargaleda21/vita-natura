import { LinearGradient } from 'expo-linear-gradient';
import { useEffect, useRef } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  cancelAnimation,
  Easing,
  interpolate,
  type SharedValue,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import Svg, { Path } from 'react-native-svg';

import { palette, springs } from '@/theme/tokens';
import type { Box } from './cameraTypes';

export const FRAME_RADIUS = 26;
const L = 36; // bracket arm length
const STROKE = 4;

type Props = {
  width: number;
  height: number;
  frame: Box;
  /** Where a code was found: the brackets snap to it, with a flash and a burst. */
  lock: Box | null;
  /** Laser, particles and breathing run only while looking for a code. */
  scanning: boolean;
  reduced: boolean;
};

function roundedRect({ x, y, width: w, height: h }: Box, r: number) {
  return `M${x + r} ${y}H${x + w - r}A${r} ${r} 0 0 1 ${x + w} ${y + r}V${y + h - r}A${r} ${r} 0 0 1 ${x + w - r} ${y + h}H${x + r}A${r} ${r} 0 0 1 ${x} ${y + h - r}V${y + r}A${r} ${r} 0 0 1 ${x + r} ${y}Z`;
}

/** The lock box, padded and never smaller than two bracket arms. */
function lockTarget(b: Box): Box {
  const w = Math.max(b.width + 20, L * 2 + 20);
  const h = Math.max(b.height + 20, L * 2 + 8);
  return { x: b.x + b.width / 2 - w / 2, y: b.y + b.height / 2 - h / 2, width: w, height: h };
}

export function ScanOverlay({ width: W, height: H, frame, lock, scanning, reduced }: Props) {
  const rx = useSharedValue(frame.x);
  const ry = useSharedValue(frame.y);
  const rw = useSharedValue(frame.width);
  const rh = useSharedValue(frame.height);
  const breath = useSharedValue(0);
  const laser = useSharedValue(0.5);
  const live = useSharedValue(1);
  const flash = useSharedValue(0);
  const burst = useSharedValue(0);
  const prevLock = useRef<Box | null>(null);

  const { x: fx, y: fy, width: fw, height: fh } = frame;
  useEffect(() => {
    const target = lock ? lockTarget(lock) : { x: fx, y: fy, width: fw, height: fh };
    const lockChanged = prevLock.current !== lock;
    prevLock.current = lock;
    if (!lockChanged || reduced) {
      rx.set(target.x);
      ry.set(target.y);
      rw.set(target.width);
      rh.set(target.height);
    } else {
      rx.set(withSpring(target.x, springs.snappy));
      ry.set(withSpring(target.y, springs.snappy));
      rw.set(withSpring(target.width, springs.snappy));
      rh.set(withSpring(target.height, springs.snappy));
    }
    if (lock && lockChanged) {
      flash.set(withSequence(withTiming(1, { duration: 90 }), withTiming(0, { duration: 560 })));
      burst.set(0);
      if (!reduced) burst.set(withTiming(1, { duration: 760, easing: Easing.out(Easing.cubic) }));
    }
  }, [lock, fx, fy, fw, fh, reduced, rx, ry, rw, rh, flash, burst]);

  const looking = scanning && !lock;
  useEffect(() => {
    live.set(withTiming(looking ? 1 : 0, { duration: 220 }));
    if (reduced || !looking) {
      cancelAnimation(breath);
      cancelAnimation(laser);
      breath.set(withTiming(0, { duration: 200 }));
      if (reduced) laser.set(0.5);
      return;
    }
    const sine = Easing.inOut(Easing.sin);
    breath.set(
      withRepeat(withSequence(withTiming(1, { duration: 1150, easing: sine }), withTiming(0, { duration: 1150, easing: sine })), -1),
    );
    laser.set(0);
    laser.set(withRepeat(withTiming(1, { duration: 1900, easing: Easing.inOut(Easing.quad) }), -1, true));
  }, [looking, reduced, breath, laser, live]);

  const laserStyle = useAnimatedStyle(() => ({
    opacity: live.value,
    transform: [{ translateY: 10 + laser.value * (rh.value - 20) - 40 }],
  }));
  const flashStyle = useAnimatedStyle(() => ({ opacity: flash.value * 0.5 }));

  const center = lock ? { x: lock.x + lock.width / 2, y: lock.y + lock.height / 2 } : null;

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <Svg width={W} height={H} style={StyleSheet.absoluteFill}>
        <Path d={`M0 0H${W}V${H}H0Z ${roundedRect(frame, FRAME_RADIUS)}`} fill="rgba(4,11,8,0.64)" fillRule="evenodd" />
        <Path d={roundedRect(frame, FRAME_RADIUS)} fill="none" stroke="rgba(255,255,255,0.16)" strokeWidth={1} />
      </Svg>

      {/* Laser, clipped to the viewfinder. */}
      <View
        style={{
          position: 'absolute',
          left: frame.x,
          top: frame.y,
          width: frame.width,
          height: frame.height,
          borderRadius: FRAME_RADIUS,
          overflow: 'hidden',
        }}
      >
        <Animated.View style={[{ position: 'absolute', left: 0, right: 0, top: 0, height: 80 }, laserStyle]}>
          <LinearGradient
            colors={['rgba(198,243,107,0)', 'rgba(198,243,107,0.2)', 'rgba(198,243,107,0)']}
            style={StyleSheet.absoluteFill}
          />
          <LinearGradient
            colors={['rgba(198,243,107,0)', palette.lime, 'rgba(198,243,107,0)']}
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            style={{ position: 'absolute', left: 12, right: 12, top: 39, height: 2, borderRadius: 1 }}
          />
        </Animated.View>
        <Animated.View style={[StyleSheet.absoluteFill, { backgroundColor: palette.lime }, flashStyle]} />
      </View>

      {reduced ? null : <Particles frame={frame} live={live} />}

      {(['tl', 'tr', 'bl', 'br'] as const).map((corner) => (
        <Bracket key={corner} corner={corner} rx={rx} ry={ry} rw={rw} rh={rh} breath={breath} />
      ))}

      {center && !reduced ? <Burst x={center.x} y={center.y} burst={burst} /> : null}
    </View>
  );
}

type Corner = 'tl' | 'tr' | 'bl' | 'br';

function Bracket({
  corner,
  rx,
  ry,
  rw,
  rh,
  breath,
}: {
  corner: Corner;
  rx: SharedValue<number>;
  ry: SharedValue<number>;
  rw: SharedValue<number>;
  rh: SharedValue<number>;
  breath: SharedValue<number>;
}) {
  const left = corner === 'tl' || corner === 'bl';
  const top = corner === 'tl' || corner === 'tr';
  const style = useAnimatedStyle(() => {
    const p = breath.value * 7;
    const x = left ? rx.value - p - STROKE / 2 : rx.value + rw.value + p - L + STROKE / 2;
    const y = top ? ry.value - p - STROKE / 2 : ry.value + rh.value + p - L + STROKE / 2;
    return { transform: [{ translateX: x }, { translateY: y }] };
  });
  const r = FRAME_RADIUS + 2;
  return (
    <Animated.View
      style={[
        {
          position: 'absolute',
          left: 0,
          top: 0,
          width: L,
          height: L,
          borderColor: palette.lime,
          borderTopWidth: top ? STROKE : 0,
          borderBottomWidth: top ? 0 : STROKE,
          borderLeftWidth: left ? STROKE : 0,
          borderRightWidth: left ? 0 : STROKE,
          borderTopLeftRadius: corner === 'tl' ? r : 0,
          borderTopRightRadius: corner === 'tr' ? r : 0,
          borderBottomLeftRadius: corner === 'bl' ? r : 0,
          borderBottomRightRadius: corner === 'br' ? r : 0,
        },
        style,
      ]}
    />
  );
}

// Small floating motes around the viewfinder: deterministic, so every visit looks the same.
const MOTES = Array.from({ length: 14 }, (_, i) => {
  const r = (n: number) => {
    const v = Math.sin((i + 1) * 12.9898 + n * 78.233) * 43758.5453;
    return v - Math.floor(v);
  };
  return {
    fx: r(1) * 1.2 - 0.1,
    fy: 0.15 + r(2) * 1.05,
    size: 2 + Math.round(r(3) * 2.5),
    color: [palette.lime, palette.mint, '#FFFFFF'][i % 3],
    dist: 28 + r(4) * 46,
    duration: 2600 + r(5) * 2200,
    delay: r(6) * 2400,
    peak: 0.45 + r(7) * 0.45,
  };
});

function Particles({ frame, live }: { frame: Box; live: SharedValue<number> }) {
  return (
    <>
      {MOTES.map((m, i) => (
        <Mote
          key={i}
          x={frame.x + m.fx * frame.width}
          y={frame.y + m.fy * frame.height}
          size={m.size}
          color={m.color}
          dist={m.dist}
          duration={m.duration}
          delay={m.delay}
          peak={m.peak}
          live={live}
        />
      ))}
    </>
  );
}

function Mote(p: {
  x: number;
  y: number;
  size: number;
  color: string;
  dist: number;
  duration: number;
  delay: number;
  peak: number;
  live: SharedValue<number>;
}) {
  const t = useSharedValue(0);
  useEffect(() => {
    t.set(withDelay(p.delay, withRepeat(withTiming(1, { duration: p.duration, easing: Easing.linear }), -1, false)));
    return () => cancelAnimation(t);
  }, [t, p.delay, p.duration]);
  const style = useAnimatedStyle(() => ({
    opacity: interpolate(t.value, [0, 0.2, 0.75, 1], [0, p.peak, p.peak, 0]) * (0.25 + 0.75 * p.live.value),
    transform: [{ translateY: -p.dist * t.value }, { translateX: Math.sin(t.value * Math.PI * 2) * 5 }],
  }));
  return (
    <Animated.View
      style={[
        {
          position: 'absolute',
          left: p.x,
          top: p.y,
          width: p.size,
          height: p.size,
          borderRadius: p.size,
          backgroundColor: p.color,
        },
        style,
      ]}
    />
  );
}

const SPARKS = Array.from({ length: 12 }, (_, i) => ({
  angle: (i / 12) * Math.PI * 2 + (i % 2 ? 0.12 : 0),
  dist: i % 2 ? 78 : 112,
  color: [palette.lime, palette.sun, palette.mint, '#FFFFFF'][i % 4],
  size: i % 2 ? 6 : 8,
}));

function Burst({ x, y, burst }: { x: number; y: number; burst: SharedValue<number> }) {
  const ring = useAnimatedStyle(() => ({
    opacity: interpolate(burst.value, [0, 0.08, 1], [0, 0.95, 0]),
    transform: [{ scale: interpolate(burst.value, [0, 1], [0.3, 2.1]) }],
  }));
  return (
    <View style={{ position: 'absolute', left: x, top: y }}>
      <Animated.View
        style={[
          { position: 'absolute', left: -70, top: -70, width: 140, height: 140, borderRadius: 70, borderWidth: 3, borderColor: palette.lime },
          ring,
        ]}
      />
      {SPARKS.map((s, i) => (
        <Spark key={i} {...s} burst={burst} />
      ))}
    </View>
  );
}

function Spark({
  angle,
  dist,
  color,
  size,
  burst,
}: {
  angle: number;
  dist: number;
  color: string;
  size: number;
  burst: SharedValue<number>;
}) {
  const style = useAnimatedStyle(() => {
    const d = burst.value * dist;
    return {
      opacity: interpolate(burst.value, [0, 0.1, 0.7, 1], [0, 1, 0.8, 0]),
      transform: [
        { translateX: Math.cos(angle) * d },
        { translateY: Math.sin(angle) * d },
        { scale: interpolate(burst.value, [0, 1], [1, 0.3]) },
      ],
    };
  });
  return (
    <Animated.View
      style={[
        { position: 'absolute', left: -size / 2, top: -size / 2, width: size, height: size, borderRadius: size, backgroundColor: color },
        style,
      ]}
    />
  );
}
