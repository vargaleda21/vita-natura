import { Platform, View } from 'react-native';

import { palette, radius, space } from '@/theme/tokens';
import { Icon, type IconName, Txt, useTheme } from '@/ui';
import { Barcode } from './Barcode';
import { GhostButton, PrimaryButton } from './buttons';
import { Sheet } from './Sheet';
import type { strings } from './strings';

type T = (typeof strings)['hu'];

/** A code we do not know yet: offer the AI label reading. */
export function UnknownSheet({
  code,
  visible,
  reduced,
  t,
  onPhoto,
  onDismiss,
}: {
  code: string;
  visible: boolean;
  reduced: boolean;
  t: T;
  onPhoto: () => void;
  onDismiss: () => void;
}) {
  const { c, isDark } = useTheme();
  return (
    <Sheet visible={visible} onClose={onDismiss} reduced={reduced} label={t.scanAnother}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
        <View
          style={{
            width: 44,
            height: 44,
            borderRadius: 14,
            backgroundColor: palette.lilac,
            alignItems: 'center',
            justifyContent: 'center',
            transform: [{ rotate: '-6deg' }],
          }}
        >
          <Icon name="sparkles" size={22} color={palette.ink} />
        </View>
        <Txt variant="tiny" upper muted>
          {t.unknownEyebrow}
        </Txt>
      </View>
      <Txt variant="h1" style={{ marginTop: space.lg }}>
        {t.unknownTitle}
      </Txt>
      <Txt variant="body" muted style={{ marginTop: space.sm }}>
        {t.unknownBody}
      </Txt>
      <View
        style={{
          marginTop: space.lg,
          alignSelf: 'flex-start',
          backgroundColor: '#FFFFFF',
          borderRadius: radius.md,
          paddingHorizontal: space.md,
          paddingTop: space.sm,
          paddingBottom: 4,
          borderWidth: isDark ? 0 : 1,
          borderColor: c.border,
        }}
      >
        <Barcode code={code} width={176} height={58} />
      </View>
      <View style={{ marginTop: space.xl, gap: space.xs }}>
        <PrimaryButton label={t.photograph} icon="camera" onPress={onPhoto} />
        <GhostButton label={t.scanAnother} onPress={onDismiss} />
      </View>
    </Sheet>
  );
}

/** The "?" in the top bar. */
export function HelpSheet({ visible, reduced, t, onClose }: { visible: boolean; reduced: boolean; t: T; onClose: () => void }) {
  const { c, isDark } = useTheme();
  const rows: { icon: IconName; text: string }[] = [
    { icon: 'scan-barcode', text: t.help1 },
    { icon: Platform.OS === 'web' ? 'sun' : 'flashlight', text: Platform.OS === 'web' ? t.help2Web : t.help2Native },
    { icon: 'globe', text: t.help3 },
    { icon: 'shopping-basket', text: t.help4 },
  ];
  return (
    <Sheet visible={visible} onClose={onClose} reduced={reduced} label={t.close}>
      <Txt variant="h1">{t.helpTitle}</Txt>
      <View style={{ marginTop: space.lg, gap: space.md }}>
        {rows.map((r, i) => (
          <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: i === 0 ? palette.lime : isDark ? c.surfaceAlt : c.surface,
                borderWidth: i === 0 ? 0 : 1,
                borderColor: c.border,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name={r.icon} size={19} color={i === 0 ? palette.ink : c.text} />
            </View>
            <Txt variant="body" style={{ flex: 1 }}>
              {r.text}
            </Txt>
          </View>
        ))}
      </View>
      <View
        style={{
          marginTop: space.lg,
          flexDirection: 'row',
          gap: space.sm,
          alignItems: 'center',
          padding: space.md,
          borderRadius: radius.md,
          backgroundColor: isDark ? 'rgba(123,224,181,0.08)' : 'rgba(47,203,116,0.08)',
        }}
      >
        <Icon name="shield-check" size={18} color={isDark ? palette.mint : palette.forest} />
        <Txt variant="small" muted style={{ flex: 1 }}>
          {t.privacy}
        </Txt>
      </View>
      <View style={{ marginTop: space.xl }}>
        <PrimaryButton label={t.gotIt} onPress={onClose} />
      </View>
    </Sheet>
  );
}
