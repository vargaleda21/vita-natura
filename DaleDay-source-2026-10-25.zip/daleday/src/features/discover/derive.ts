// Turns the catalogue into Discover's stories. Everything is derived from the data API,
// so new products show up here by themselves.
import { alternativesFor, CRITERIA_ORDER, evaluate } from '@/data/api';
import type { Alternative, AvoidKey, Lang, Product, RecipeChange, Settings, StoreKey } from '@/data/types';

export type ShrinkItem = {
  product: Product;
  change: RecipeChange;
  /** after / before, e.g. 0.89. */
  ratio: number;
  /** How much more you pay per gram, in whole percent. */
  unitUpPct: number;
};

export type SwapItem = {
  from: Product;
  alt: Alternative;
  store: StoreKey;
  fromPrice: number;
  toPrice: number;
  saving: number;
  removed: AvoidKey[];
  fromMatched: number;
  total: number;
};

/** "450 g" → 450; "1,5 l" → 1500. Units only need to agree with each other. */
export function parseQty(s: string | undefined): number | null {
  if (!s) return null;
  const m = /([\d]+(?:[.,]\d+)?)\s*(kg|g|ml|l|db)?/i.exec(s);
  if (!m) return null;
  const n = Number(m[1].replace(',', '.'));
  const unit = (m[2] ?? '').toLowerCase();
  return unit === 'kg' || unit === 'l' ? n * 1000 : n;
}

const byDateDesc = (a: RecipeChange, b: RecipeChange) => b.date.localeCompare(a.date);

export function shrinkItems(products: Product[]): ShrinkItem[] {
  return products
    .flatMap((product) => {
      const change = [...(product.history ?? [])].sort(byDateDesc).find((h) => h.kind === 'size_down');
      if (!change) return [];
      const before = parseQty(change.before);
      const after = parseQty(change.after);
      const ratio = before && after && after < before ? after / before : 0.9;
      return [{ product, change, ratio, unitUpPct: Math.round((1 / ratio - 1) * 100) }];
    })
    .sort((a, b) => a.ratio - b.ratio);
}

export function dualItems(products: Product[]): Product[] {
  return products.filter((p) => p.dualQuality && p.dualQuality.verdict !== 'same');
}

export function worseItems(products: Product[]): Product[] {
  return products
    .filter((p) => p.history?.some((h) => h.kind === 'recipe_worse'))
    .sort((a, b) => {
      const da = [...(a.history ?? [])].sort(byDateDesc)[0]?.date ?? '';
      const db = [...(b.history ?? [])].sort(byDateDesc)[0]?.date ?? '';
      return db.localeCompare(da);
    });
}

/** For every product that goes against your settings: a better one, cheaper in the same shop. */
export function swapItems(products: Product[], settings: Settings): SwapItem[] {
  const seen = new Set<string>();
  const out: SwapItem[] = [];
  for (const from of products) {
    const mine = evaluate(from, settings);
    if (mine.verdict === 'great') continue;
    const alt = alternativesFor(from, settings).find((a) => (a.savingHuf ?? 0) > 0 && a.sameStore);
    if (!alt || !alt.sameStore) continue;
    const key = `${from.ean}>${alt.product.ean}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const store = alt.sameStore;
    const fromPrice = from.prices.find((p) => p.store === store)?.priceHuf;
    const toPrice = alt.product.prices.find((p) => p.store === store)?.priceHuf;
    if (fromPrice === undefined || toPrice === undefined) continue;
    const theirs = new Set(alt.result.hits.map((h) => h.key));
    const removed = CRITERIA_ORDER.filter((k) => mine.hits.some((h) => h.key === k) && !theirs.has(k));
    out.push({
      from,
      alt,
      store,
      fromPrice,
      toPrice,
      saving: fromPrice - toPrice,
      removed,
      fromMatched: mine.matched,
      total: mine.total,
    });
  }
  // Big savings that also drop more of what you avoid come first; then keep the top varied,
  // so the same alternative does not fill the first cards.
  const weight = (x: SwapItem) => x.saving * (1 + 0.5 * x.removed.length);
  const sorted = out.sort((a, b) => weight(b) - weight(a));
  const used = new Set<string>();
  const first: SwapItem[] = [];
  const rest: SwapItem[] = [];
  for (const item of sorted) {
    if (used.has(item.alt.product.ean)) rest.push(item);
    else {
      used.add(item.alt.product.ean);
      first.push(item);
    }
  }
  return [...first, ...rest];
}

/** "2025. március" / "March 2025". */
export function monthYear(iso: string, lang: Lang): string {
  const d = new Date(`${iso}T12:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  try {
    return d.toLocaleDateString(lang === 'hu' ? 'hu-HU' : 'en-GB', { year: 'numeric', month: 'long' });
  } catch {
    return iso.slice(0, 7);
  }
}

const HU_MONTH_POSS = [
  'januárja',
  'februárja',
  'márciusa',
  'áprilisa',
  'májusa',
  'júniusa',
  'júliusa',
  'augusztusa',
  'szeptembere',
  'októbere',
  'novembere',
  'decembere',
];

/** "2025 márciusa óta" / "since March 2025". */
export function sinceLabel(iso: string, lang: Lang): string {
  const [y, m] = iso.split('-').map(Number);
  if (!y || !m) return iso;
  if (lang === 'hu') return `${y} ${HU_MONTH_POSS[m - 1]} óta`;
  return `since ${monthYear(iso, 'en')}`;
}
