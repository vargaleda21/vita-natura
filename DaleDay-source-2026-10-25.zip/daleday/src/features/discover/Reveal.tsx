import { type ReactNode, useEffect } from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withDelay, withSpring } from 'react-native-reanimated';

import { springs } from '@/theme/tokens';

/** Cards rise in one after another. Later cards wait a little more, up to a cap. */
export function Reveal({
  index,
  reduced,
  children,
  style,
}: {
  index: number;
  reduced: boolean;
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  const p = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    if (reduced) {
      p.set(1);
      return;
    }
    p.set(withDelay(60 + Math.min(index, 7) * 75, withSpring(1, springs.soft)));
  }, [index, reduced, p]);
  const anim = useAnimatedStyle(() => ({
    opacity: Math.min(1, p.value * 1.4),
    transform: [{ translateY: (1 - p.value) * 26 }, { scale: 0.97 + 0.03 * p.value }],
  }));
  return <Animated.View style={[style, anim]}>{children}</Animated.View>;
}
