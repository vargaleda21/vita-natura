import { LinearGradient } from 'expo-linear-gradient';
import { useEffect } from 'react';
import { StyleSheet } from 'react-native';
import Animated, {
  Easing,
  interpolate,
  Extrapolation,
  type SharedValue,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import Svg, { Defs, Ellipse, RadialGradient, Stop } from 'react-native-svg';

import { palette } from '@/theme/tokens';
import { useTheme } from '@/ui';

export const AURORA_H = 440;

type Blob = { x: number; y: number; rx: number; ry: number; color: string; opacity: number; drift: number; period: number };

/** Soft aurora light behind the Discover title: radial gradients that drift, no blur filter. */
export function Aurora({ width, scrollY, reduced }: { width: number; scrollY: SharedValue<number>; reduced: boolean }) {
  const { c, isDark } = useTheme();
  const blobs: Blob[] = isDark
    ? [
        { x: 0.18, y: 70, rx: 280, ry: 210, color: palette.forest, opacity: 1, drift: 18, period: 9000 },
        { x: 0.88, y: 70, rx: 230, ry: 180, color: palette.lime, opacity: 0.2, drift: -22, period: 11000 },
        { x: 0.68, y: 270, rx: 230, ry: 150, color: palette.lilac, opacity: 0.2, drift: 16, period: 10000 },
        { x: 0.05, y: 320, rx: 200, ry: 130, color: palette.mint, opacity: 0.14, drift: -14, period: 12000 },
      ]
    : [
        { x: 0.12, y: 50, rx: 280, ry: 220, color: palette.lime, opacity: 0.85, drift: 18, period: 9000 },
        { x: 0.95, y: 40, rx: 250, ry: 200, color: palette.sky, opacity: 0.6, drift: -22, period: 11000 },
        { x: 0.72, y: 270, rx: 230, ry: 150, color: palette.lilac, opacity: 0.42, drift: 16, period: 10000 },
        { x: 0.02, y: 330, rx: 210, ry: 130, color: palette.sun, opacity: 0.32, drift: -14, period: 12000 },
      ];

  const parallax = useAnimatedStyle(() => {
    const y = scrollY.value;
    return {
      transform: [
        { translateY: y > 0 ? -y * 0.45 : -y * 0.5 },
        { scale: interpolate(y, [-240, 0], [1.35, 1], Extrapolation.CLAMP) },
      ],
      opacity: interpolate(y, [0, 320], [1, 0.25], Extrapolation.CLAMP),
    };
  });

  return (
    <Animated.View pointerEvents="none" style={[{ position: 'absolute', left: 0, right: 0, top: 0, height: AURORA_H }, parallax]}>
      {blobs.map((b, i) => (
        <DriftBlob key={`${isDark}${i}`} blob={b} width={width} id={i} reduced={reduced} />
      ))}
      <LinearGradient
        colors={[isDark ? 'rgba(11,22,18,0)' : 'rgba(247,244,236,0)', c.bg]}
        style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 170 }}
      />
    </Animated.View>
  );
}

function DriftBlob({ blob, width, id, reduced }: { blob: Blob; width: number; id: number; reduced: boolean }) {
  const t = useSharedValue(0);
  useEffect(() => {
    if (reduced) return;
    const e = Easing.inOut(Easing.sin);
    t.set(withRepeat(withSequence(withTiming(1, { duration: blob.period / 2, easing: e }), withTiming(0, { duration: blob.period / 2, easing: e })), -1));
  }, [t, reduced, blob.period]);
  const style = useAnimatedStyle(() => ({
    transform: [{ translateX: blob.drift * t.value }, { translateY: blob.drift * 0.4 * t.value }, { scale: 1 + 0.05 * t.value }],
  }));
  const w = blob.rx * 2;
  const h = blob.ry * 2;
  return (
    <Animated.View style={[{ position: 'absolute', left: blob.x * width - blob.rx, top: blob.y - blob.ry, width: w, height: h }, style]}>
      <Svg width={w} height={h} style={StyleSheet.absoluteFill}>
        <Defs>
          <RadialGradient id={`aurora${id}`} cx="50%" cy="50%" rx="50%" ry="50%">
            <Stop offset="0" stopColor={blob.color} stopOpacity={blob.opacity} />
            <Stop offset="0.5" stopColor={blob.color} stopOpacity={blob.opacity * 0.42} />
            <Stop offset="1" stopColor={blob.color} stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Ellipse cx={blob.rx} cy={blob.ry} rx={blob.rx} ry={blob.ry} fill={`url(#aurora${id})`} />
      </Svg>
    </Animated.View>
  );
}
