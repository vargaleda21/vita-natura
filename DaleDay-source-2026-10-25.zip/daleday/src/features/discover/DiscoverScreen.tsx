import { LinearGradient } from 'expo-linear-gradient';
import { useState } from 'react';
import { ScrollView, View } from 'react-native';
import Animated, {
  Extrapolation,
  interpolate,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { allProducts } from '@/data/api';
import { formatHuf, useLang, useT } from '@/i18n';
import { useSettings } from '@/state/store';
import { palette, radius, space } from '@/theme/tokens';
import { Chip, Icon, type IconName, PressableScale, Txt, useTheme } from '@/ui';
import { Aurora } from './Aurora';
import { DualCard, EmptyCard, HowCard, PricesCard, SectionHeader, ShrinkCard, SwapCard, WorseCard } from './cards';
import { dualItems, shrinkItems, swapItems, worseItems } from './derive';
import { Reveal } from './Reveal';
import { strings } from './strings';

type Filter = 'all' | 'shrink' | 'recipe' | 'cheaper';

const COLUMN = 480;
const SWAPS_SHOWN = 3;

export function DiscoverScreen() {
  const t = useT(strings);
  const lang = useLang();
  const settings = useSettings();
  const insets = useSafeAreaInsets();
  const reduced = useReducedMotion();
  const { c, isDark } = useTheme();
  const [filter, setFilter] = useState<Filter>('all');
  const [moreSwaps, setMoreSwaps] = useState(false);
  const [width, setWidth] = useState(390);
  const scrollY = useSharedValue(0);
  const onScroll = useAnimatedScrollHandler((e) => {
    scrollY.value = e.contentOffset.y;
  });

  const products = allProducts();
  const shrink = shrinkItems(products);
  const dual = dualItems(products);
  const worse = worseItems(products);
  const swaps = swapItems(products, settings);
  const bestSave = swaps.reduce((m, s) => Math.max(m, s.saving), 0);
  const total = shrink.length + dual.length + worse.length + swaps.length;

  const show = {
    shrink: (filter === 'all' || filter === 'shrink') && shrink.length > 0,
    dual: (filter === 'all' || filter === 'recipe') && dual.length > 0,
    worse: (filter === 'all' || filter === 'recipe') && worse.length > 0,
    swap: (filter === 'all' || filter === 'cheaper') && swaps.length > 0,
    how: filter === 'all',
    prices: filter === 'all' || filter === 'cheaper',
  };
  const empty = !show.shrink && !show.dual && !show.worse && !show.swap;
  const allAT = dual.every((p) => p.dualQuality?.country === 'AT');

  const titleStyle = useAnimatedStyle(() => ({
    opacity: interpolate(scrollY.value, [0, 160], [1, 0], Extrapolation.CLAMP),
    transform: [{ translateY: interpolate(scrollY.value, [-200, 0, 200], [-40, 0, 70], Extrapolation.CLAMP) }],
  }));
  const barStyle = useAnimatedStyle(() => ({
    opacity: interpolate(scrollY.value, [150, 200], [0, 1], Extrapolation.CLAMP),
  }));

  const filters: { key: Filter; label: string; icon: IconName }[] = [
    { key: 'all', label: t.filterAll, icon: 'sparkles' },
    { key: 'shrink', label: t.filterShrink, icon: 'trending-down' },
    { key: 'recipe', label: t.filterRecipe, icon: 'flask-conical' },
    { key: 'cheaper', label: t.filterCheaper, icon: 'tag' },
  ];

  let n = 0; // running index for the stagger
  const auroraW = Math.min(width, 720);

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }} onLayout={(e) => setWidth(e.nativeEvent.layout.width)}>
      <View style={{ position: 'absolute', top: 0, width: auroraW, height: 440, alignSelf: 'center' }} pointerEvents="none">
        <Aurora width={auroraW} scrollY={scrollY} reduced={reduced} />
      </View>

      <Animated.ScrollView
        onScroll={onScroll}
        scrollEventThrottle={16}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 130 + insets.bottom }}
      >
        <View style={{ width: '100%', maxWidth: COLUMN, alignSelf: 'center', paddingHorizontal: space.xl }}>
          {/* Header */}
          <Animated.View style={[{ paddingTop: insets.top + 36 }, titleStyle]}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 6,
                alignSelf: 'flex-start',
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: radius.pill,
                backgroundColor: isDark ? 'rgba(255,255,255,0.07)' : 'rgba(255,255,255,0.6)',
                borderWidth: 1,
                borderColor: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(255,255,255,0.9)',
              }}
            >
              <Icon name="sparkles" size={13} color={isDark ? palette.lime : palette.forest} />
              <Txt variant="tiny" color={isDark ? palette.lime : palette.forest} style={{ letterSpacing: 0.3 }}>
                {t.finds(total)}
              </Txt>
            </View>
            <Txt variant="hero" style={{ fontSize: 50, lineHeight: 52, letterSpacing: -1.8, marginTop: space.lg }}>
              {t.title}
            </Txt>
            <Txt variant="h3" muted style={{ marginTop: space.xs }}>
              {t.sub}
            </Txt>
          </Animated.View>

          {/* Bento: the three numbers worth a tap */}
          <Reveal index={n++} reduced={reduced} style={{ marginTop: space.xxl }}>
            <View style={{ flexDirection: 'row', gap: space.md }}>
              {swaps.length > 0 ? (
                <PressableScale
                  onPress={() => setFilter('cheaper')}
                  accessibilityRole="button"
                  accessibilityLabel={t.filterCheaper}
                  style={{ flex: 1.15 }}
                >
                  <LinearGradient
                    colors={[palette.lime, palette.mint]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={{ borderRadius: radius.lg, padding: space.lg, minHeight: 168, justifyContent: 'space-between' }}
                  >
                    <View
                      style={{
                        width: 36,
                        height: 36,
                        borderRadius: 18,
                        backgroundColor: palette.ink,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon name="arrow-left-right" size={17} color={palette.lime} />
                    </View>
                    <View>
                      <Txt variant="number" color={palette.ink} numberOfLines={1} adjustsFontSizeToFit>
                        −{formatHuf(bestSave, lang)}
                      </Txt>
                      <Txt variant="small" color={palette.ink} style={{ opacity: 0.75 }}>
                        {t.statSave}
                      </Txt>
                    </View>
                  </LinearGradient>
                </PressableScale>
              ) : null}
              <View style={{ flex: 1, gap: space.md }}>
                {shrink.length > 0 ? (
                  <StatTile value={shrink.length} label={t.statShrink} icon="trending-down" tint={palette.tangerine} onPress={() => setFilter('shrink')} />
                ) : null}
                {dual.length > 0 ? (
                  <StatTile value={dual.length} label={t.statDual} icon="globe" tint={palette.sky} onPress={() => setFilter('recipe')} />
                ) : null}
              </View>
            </View>
          </Reveal>
        </View>

        {/* Filter chips: edge to edge on a phone, inside the column on a wide screen */}
        <Reveal index={n++} reduced={reduced}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{ marginTop: space.xl, flexGrow: 0, width: '100%', maxWidth: COLUMN, alignSelf: 'center' }}
            contentContainerStyle={{ gap: space.sm, paddingHorizontal: space.xl }}
          >
            {filters.map((f) => (
              <Chip key={f.key} label={f.label} icon={f.icon} selected={filter === f.key} onPress={() => setFilter(f.key)} />
            ))}
          </ScrollView>
        </Reveal>

        <View key={filter} style={{ width: '100%', maxWidth: COLUMN, alignSelf: 'center', paddingHorizontal: space.xl }}>
          {show.shrink ? (
            <View style={{ marginTop: space.xxl }}>
              <Reveal index={n++} reduced={reduced}>
                <SectionHeader eyebrow={t.shrinkEyebrow} title={t.shrinkTitle} sub={t.shrinkSub} tint={palette.tangerine} />
              </Reveal>
              <View style={{ gap: space.md }}>
                {shrink.map((item) => (
                  <Reveal key={item.product.ean} index={n++} reduced={reduced}>
                    <ShrinkCard item={item} reduced={reduced} />
                  </Reveal>
                ))}
              </View>
            </View>
          ) : null}

          {show.dual ? (
            <View style={{ marginTop: space.xxl }}>
              <Reveal index={n++} reduced={reduced}>
                <SectionHeader
                  eyebrow={t.dualEyebrow}
                  title={allAT ? t.dualTitleAT : t.dualTitleAny}
                  sub={t.dualSub}
                  tint={palette.sky}
                />
              </Reveal>
              <View style={{ gap: space.md }}>
                {dual.map((p) => (
                  <Reveal key={p.ean} index={n++} reduced={reduced}>
                    <DualCard product={p} />
                  </Reveal>
                ))}
              </View>
            </View>
          ) : null}

          {show.worse ? (
            <View style={{ marginTop: space.xxl }}>
              <Reveal index={n++} reduced={reduced}>
                <SectionHeader eyebrow={t.worseEyebrow} title={t.worseTitle} sub={t.worseSub} tint={palette.coral} />
              </Reveal>
              <View style={{ gap: space.md }}>
                {worse.map((p) => (
                  <Reveal key={p.ean} index={n++} reduced={reduced}>
                    <WorseCard product={p} settings={settings} reduced={reduced} />
                  </Reveal>
                ))}
              </View>
            </View>
          ) : null}

          {show.swap ? (
            <View style={{ marginTop: space.xxl }}>
              <Reveal index={n++} reduced={reduced}>
                <SectionHeader eyebrow={t.swapEyebrow} title={t.swapTitle} sub={t.swapSub} tint={palette.great} />
              </Reveal>
              <View style={{ gap: space.md }}>
                {(filter === 'cheaper' || moreSwaps ? swaps : swaps.slice(0, SWAPS_SHOWN)).map((item) => (
                  <Reveal key={`${item.from.ean}${item.alt.product.ean}`} index={n++} reduced={reduced}>
                    <SwapCard item={item} />
                  </Reveal>
                ))}
              </View>
              {filter !== 'cheaper' && !moreSwaps && swaps.length > SWAPS_SHOWN ? (
                <PressableScale
                  onPress={() => setMoreSwaps(true)}
                  accessibilityRole="button"
                  style={{
                    marginTop: space.md,
                    height: 50,
                    borderRadius: radius.pill,
                    borderWidth: 1,
                    borderColor: c.border,
                    backgroundColor: isDark ? c.surface : 'rgba(255,255,255,0.6)',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: space.sm,
                  }}
                >
                  <Txt variant="bodyStrong">{t.moreSwaps(swaps.length - SWAPS_SHOWN)}</Txt>
                  <Icon name="chevron-right" size={18} color={c.text} />
                </PressableScale>
              ) : null}
            </View>
          ) : null}

          {empty ? (
            <View style={{ marginTop: space.xxl }}>
              <EmptyCard />
            </View>
          ) : null}

          {show.how || show.prices ? (
            <View style={{ marginTop: space.xxl, gap: space.md }}>
              {show.how ? (
                <Reveal index={n++} reduced={reduced}>
                  <HowCard />
                </Reveal>
              ) : null}
              {show.prices ? (
                <Reveal index={n++} reduced={reduced}>
                  <PricesCard />
                </Reveal>
              ) : null}
            </View>
          ) : null}
        </View>
      </Animated.ScrollView>

      {/* A compact title bar fades in once the big title has scrolled away. */}
      <Animated.View
        pointerEvents="none"
        style={[
          {
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            paddingTop: insets.top,
            height: insets.top + 50,
            backgroundColor: c.bg,
            borderBottomWidth: 1,
            borderBottomColor: c.border,
            alignItems: 'center',
            justifyContent: 'center',
          },
          barStyle,
        ]}
      >
        <Txt variant="h3">{t.title}</Txt>
      </Animated.View>
    </View>
  );
}

function StatTile({
  value,
  label,
  icon,
  tint,
  onPress,
}: {
  value: number;
  label: string;
  icon: IconName;
  tint: string;
  onPress: () => void;
}) {
  const { isDark } = useTheme();
  return (
    <PressableScale onPress={onPress} accessibilityRole="button" accessibilityLabel={`${value} ${label}`} style={{ flex: 1 }}>
      <View
        style={{
          flex: 1,
          borderRadius: radius.lg,
          padding: space.md,
          paddingLeft: space.lg,
          backgroundColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.72)',
          borderWidth: 1,
          borderColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.95)',
          flexDirection: 'row',
          alignItems: 'center',
          gap: space.md,
        }}
      >
        <View style={{ alignItems: 'center', gap: 2 }}>
          <Txt variant="number" style={{ minWidth: 26 }} center>
            {value}
          </Txt>
          <Icon name={icon} size={15} color={tint} strokeWidth={2.4} />
        </View>
        <Txt variant="small" muted style={{ flex: 1 }} numberOfLines={3}>
          {label}
        </Txt>
      </View>
    </PressableScale>
  );
}
