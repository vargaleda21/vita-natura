import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useEffect } from 'react';
import { View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

import { cheapestPrice, evaluate, getStore, STORES } from '@/data/api';
import type { DualQuality, Lang, PackArt as Art, Product, RecipeChange, RecipeChangeKind, Settings } from '@/data/types';
import { formatHuf, useLang, useT, useTr } from '@/i18n';
import { font, palette, radius, space, springs, verdictColor } from '@/theme/tokens';
import { Card, Icon, type IconName, PackArt, PressableScale, Txt, useTheme, VerdictBadge } from '@/ui';
import { monthYear, type ShrinkItem, sinceLabel, type SwapItem } from './derive';
import { strings } from './strings';

const open = (ean: string) => router.push(`/product/${ean}`);

/** Before and after in the current language: the bilingual `values` when set, else the plain strings (a pack size). */
function sides(change: RecipeChange, lang: Lang): { was?: string; now?: string } {
  return change.values ? { was: change.values.before[lang], now: change.values.after[lang] } : { was: change.before, now: change.after };
}

export function SectionHeader({ eyebrow, title, sub, tint }: { eyebrow: string; title: string; sub: string; tint: string }) {
  return (
    <View style={{ marginBottom: space.md, paddingHorizontal: 2 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: tint }} />
        <Txt variant="tiny" upper muted>
          {eyebrow}
        </Txt>
      </View>
      <Txt variant="h2" style={{ marginTop: 6 }}>
        {title}
      </Txt>
      <Txt variant="small" muted style={{ marginTop: 2 }}>
        {sub}
      </Txt>
    </View>
  );
}

function Hairline() {
  const { c } = useTheme();
  return <View style={{ height: 1, backgroundColor: c.border, marginVertical: space.md }} />;
}

function SoftPill({ text, color, icon }: { text: string; color: string; icon?: IconName }) {
  const { isDark } = useTheme();
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 5,
        alignSelf: 'flex-start',
        borderRadius: radius.pill,
        paddingHorizontal: 10,
        paddingVertical: 4,
        backgroundColor: `${color}${isDark ? '33' : '26'}`,
      }}
    >
      {icon ? <Icon name={icon} size={13} color={isDark ? color : palette.ink} /> : null}
      <Txt variant="tiny" color={isDark ? color : palette.ink} style={{ letterSpacing: 0.2 }}>
        {text}
      </Txt>
    </View>
  );
}

// ── Kisebb lett ─────────────────────────────────────────────────────────────

function ShrinkingPack({ art, ratio, reduced }: { art: Art; ratio: number; reduced: boolean }) {
  const { isDark } = useTheme();
  // The real change is often ~10%; draw it a little stronger so the eye catches it.
  const target = Math.max(0.62, 1 - (1 - ratio) * 1.9);
  const s = useSharedValue(reduced ? target : 1);
  useEffect(() => {
    if (reduced) return;
    const e = Easing.inOut(Easing.cubic);
    s.set(
      withDelay(
        500,
        withRepeat(
          withSequence(
            withDelay(700, withTiming(target, { duration: 900, easing: e })),
            withDelay(1600, withTiming(1, { duration: 700, easing: e })),
          ),
          -1,
        ),
      ),
    );
  }, [s, target, reduced]);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: s.value }] }));
  const size = 96;
  return (
    <View style={{ width: size + 8, height: size + 8, alignItems: 'center', justifyContent: 'flex-end' }}>
      {/* What it used to be: a faint ghost of the bigger pack. */}
      <View style={{ position: 'absolute', bottom: 4, opacity: isDark ? 0.1 : 0.16 }}>
        <PackArt art={art} size={size} />
      </View>
      <Animated.View style={[{ transformOrigin: 'bottom', marginBottom: 4 }, style]}>
        <PackArt art={art} size={size} />
      </Animated.View>
    </View>
  );
}

export function ShrinkCard({ item, reduced }: { item: ShrinkItem; reduced: boolean }) {
  const t = useT(strings);
  const tr = useTr();
  const lang = useLang();
  const { product, change, ratio, unitUpPct } = item;
  const { was, now } = sides(change, lang);
  const price = cheapestPrice(product);
  const pct = Math.round((1 - ratio) * 100);
  return (
    <PressableScale onPress={() => open(product.ean)} accessibilityRole="button" accessibilityLabel={tr(product.name)}>
      <Card>
        <View style={{ flexDirection: 'row', gap: space.lg, alignItems: 'center' }}>
          <ShrinkingPack art={product.art} ratio={ratio} reduced={reduced} />
          <View style={{ flex: 1 }}>
            <Txt variant="tiny" upper faint numberOfLines={1}>
              {product.brand}
            </Txt>
            <Txt variant="h3" numberOfLines={2} style={{ marginTop: 2 }}>
              {tr(product.name)}
            </Txt>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm, marginTop: space.sm }}>
              <Txt variant="number" color={palette.tangerine}>
                −{pct}%
              </Txt>
              <View>
                <Txt variant="small" faint style={{ textDecorationLine: 'line-through' }}>
                  {was}
                </Txt>
                <Txt variant="bodyStrong">{now}</Txt>
              </View>
            </View>
          </View>
        </View>
        <Hairline />
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: space.sm }}>
          <View style={{ flexShrink: 1 }}>
            <Txt variant="small" muted>
              {t.samePrice}
              {price ? ': ' : ''}
              {price ? <Txt variant="small" style={{ fontFamily: font.bodyBold }}>{formatHuf(price.priceHuf, lang)}</Txt> : null}
            </Txt>
            <Txt variant="tiny" faint style={{ marginTop: 2, letterSpacing: 0.2 }}>
              {sinceLabel(change.date, lang)}
            </Txt>
          </View>
          <SoftPill text={t.unitPrice(unitUpPct)} color={palette.coral} icon="tag" />
        </View>
      </Card>
    </PressableScale>
  );
}

// ── Más a recept külföldön ───────────────────────────────────────────────────

const FLAGS: Record<'HU' | DualQuality['country'], [string, string, string]> = {
  HU: ['#CD2A3E', '#FFFFFF', '#436F4D'],
  AT: ['#C8102E', '#FFFFFF', '#C8102E'],
  DE: ['#1A1A1A', '#DD0000', '#FFCE00'],
  SK: ['#FFFFFF', '#0B4EA2', '#EE1C25'],
  CZ: ['#FFFFFF', '#11457E', '#D7141A'],
};

function FlagEdge({ colors, side }: { colors: [string, string, string]; side: 'left' | 'right' }) {
  return (
    <View
      style={{
        position: 'absolute',
        top: 0,
        bottom: 0,
        [side]: 0,
        width: 7,
        overflow: 'hidden',
      }}
    >
      {colors.map((col, i) => (
        <View key={i} style={{ flex: 1, backgroundColor: col }} />
      ))}
    </View>
  );
}

function CountryHalf({
  code,
  label,
  art,
  side,
  tint,
}: {
  code: 'HU' | DualQuality['country'];
  label: string;
  art: Art;
  side: 'left' | 'right';
  tint: string | null;
}) {
  const { c, isDark } = useTheme();
  return (
    <View
      style={{
        flex: 1,
        paddingVertical: space.lg,
        paddingLeft: side === 'left' ? space.xl : space.lg,
        paddingRight: side === 'right' ? space.xl : space.lg,
        backgroundColor: tint ? `${tint}${isDark ? '24' : '1C'}` : isDark ? c.surfaceAlt : c.surfaceAlt,
        alignItems: side === 'left' ? 'flex-start' : 'flex-end',
      }}
    >
      <FlagEdge colors={FLAGS[code]} side={side} />
      <Txt variant="h1">{code}</Txt>
      <Txt variant="small" muted>
        {label}
      </Txt>
      <View style={{ marginTop: space.sm }}>
        <PackArt art={art} size={64} />
      </View>
    </View>
  );
}

export function DualCard({ product }: { product: Product }) {
  const t = useT(strings);
  const tr = useTr();
  const { c } = useTheme();
  const dq = product.dualQuality;
  if (!dq) return null;
  const worse = dq.verdict === 'worse_here';
  const better = dq.verdict === 'better_here';
  const tone = worse ? palette.tangerine : better ? palette.great : palette.sky;
  return (
    <PressableScale onPress={() => open(product.ean)} accessibilityRole="button" accessibilityLabel={tr(product.name)}>
      <Card padded={false}>
        <View style={{ flexDirection: 'row' }}>
          <CountryHalf code="HU" label={t.home} art={product.art} side="left" tint={worse ? palette.tangerine : better ? palette.great : null} />
          <View style={{ width: 1, backgroundColor: c.border }} />
          <CountryHalf code={dq.country} label={t.country[dq.country]} art={product.art} side="right" tint={worse ? palette.great : null} />
          <View
            style={{
              position: 'absolute',
              left: '50%',
              top: '50%',
              width: 38,
              height: 38,
              marginLeft: -19,
              marginTop: -19,
              borderRadius: 19,
              backgroundColor: c.surface,
              borderWidth: 1,
              borderColor: c.border,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Txt variant="tiny" style={{ letterSpacing: 0 }}>
              VS
            </Txt>
          </View>
        </View>
        <View style={{ padding: space.lg }}>
          <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.sm }}>
            <View style={{ flex: 1 }}>
              <Txt variant="tiny" upper faint>
                {product.brand}
              </Txt>
              <Txt variant="h3" numberOfLines={2} style={{ marginTop: 2 }}>
                {tr(product.name)}
              </Txt>
            </View>
            <SoftPill text={t.dualVerdict[dq.verdict]} color={tone} />
          </View>
          <View style={{ marginTop: space.md, gap: space.sm }}>
            {dq.diffs.map((d, i) => (
              <View key={i} style={{ flexDirection: 'row', gap: space.sm, alignItems: 'flex-start' }}>
                <View
                  style={{
                    width: 26,
                    height: 26,
                    borderRadius: 13,
                    backgroundColor: c.surfaceAlt,
                    borderWidth: 1,
                    borderColor: c.border,
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginTop: -2,
                  }}
                >
                  <Icon name="arrow-left-right" size={13} color={c.textMuted} />
                </View>
                <Txt variant="body" style={{ flex: 1 }}>
                  {tr(d)}
                </Txt>
              </View>
            ))}
          </View>
        </View>
      </Card>
    </PressableScale>
  );
}

// ── Rosszabb lett a recept ──────────────────────────────────────────────────

const KIND_COLOR: Record<RecipeChangeKind, string> = {
  recipe_worse: palette.tangerine,
  size_down: palette.sun,
  price_up: palette.coral,
  recipe_better: palette.great,
};

function TimelineDot({ color, index, reduced, last }: { color: string; index: number; reduced: boolean; last: boolean }) {
  const p = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    if (!reduced) p.set(withDelay(350 + index * 220, withSpring(1, springs.bouncy)));
  }, [p, index, reduced]);
  const dot = useAnimatedStyle(() => ({ transform: [{ scale: p.value }] }));
  const line = useAnimatedStyle(() => ({ transform: [{ scaleY: Math.min(1, p.value) }] }));
  const { c } = useTheme();
  return (
    <View style={{ width: 20, alignItems: 'center' }}>
      <Animated.View
        style={[{ width: 14, height: 14, borderRadius: 7, backgroundColor: color, borderWidth: 3, borderColor: c.surface, marginTop: 3 }, dot]}
      />
      {last ? null : (
        <Animated.View style={[{ flex: 1, width: 2, backgroundColor: c.border, marginTop: 2, transformOrigin: 'top' }, line]} />
      )}
    </View>
  );
}

export function WorseCard({ product, settings, reduced }: { product: Product; settings: Settings; reduced: boolean }) {
  const t = useT(strings);
  const tr = useTr();
  const lang = useLang();
  const { c, isDark } = useTheme();
  const entries = [...(product.history ?? [])].sort((a, b) => a.date.localeCompare(b.date));
  const result = evaluate(product, settings);
  return (
    <PressableScale onPress={() => open(product.ean)} accessibilityRole="button" accessibilityLabel={tr(product.name)}>
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
          <PackArt art={product.art} size={54} />
          <View style={{ flex: 1 }}>
            <Txt variant="tiny" upper faint>
              {product.brand}
            </Txt>
            <Txt variant="h3" numberOfLines={2} style={{ marginTop: 2 }}>
              {tr(product.name)}
            </Txt>
          </View>
        </View>
        <View style={{ marginTop: space.lg }}>
          {entries.map((h, i) => {
            const { was, now } = sides(h, lang);
            return (
              <View key={`${h.date}${i}`} style={{ flexDirection: 'row', gap: space.md }}>
                <TimelineDot color={KIND_COLOR[h.kind]} index={i} reduced={reduced} last={i === entries.length - 1} />
                <View style={{ flex: 1, paddingBottom: i === entries.length - 1 ? 0 : space.lg }}>
                  <Txt variant="tiny" upper faint>
                    {monthYear(h.date, lang)}
                  </Txt>
                  <Txt variant="bodyStrong" style={{ marginTop: 2 }}>
                    {tr(h.text)}
                  </Txt>
                  {was && now ? (
                    <View style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 6, marginTop: space.sm }}>
                      <View style={{ borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 4, backgroundColor: isDark ? c.surfaceAlt : c.bgAlt }}>
                        <Txt variant="small" muted style={{ textDecorationLine: 'line-through' }}>
                          {was}
                        </Txt>
                      </View>
                      <Icon name="arrow-right" size={14} color={c.textFaint} />
                      <View
                        style={{
                          borderRadius: radius.pill,
                          paddingHorizontal: 10,
                          paddingVertical: 4,
                          backgroundColor: `${KIND_COLOR[h.kind]}${isDark ? '33' : '2E'}`,
                        }}
                      >
                        <Txt variant="small" style={{ fontFamily: font.bodySemi }}>
                          {now}
                        </Txt>
                      </View>
                    </View>
                  ) : null}
                </View>
              </View>
            );
          })}
        </View>
        <Hairline />
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Txt variant="small" muted>
            {t.forYou}
          </Txt>
          <VerdictBadge verdict={result.verdict} />
        </View>
      </Card>
    </PressableScale>
  );
}

// ── Ugyanitt olcsóbb és jobb ────────────────────────────────────────────────

function MiniProduct({ product, price, faded }: { product: Product; price: number; faded?: boolean }) {
  const tr = useTr();
  const lang = useLang();
  return (
    <View style={{ flex: 1, alignItems: 'center', opacity: faded ? 0.62 : 1 }}>
      <PackArt art={product.art} size={faded ? 52 : 62} />
      <Txt variant="small" center numberOfLines={2} style={{ marginTop: space.sm, fontFamily: faded ? undefined : font.bodySemi }}>
        {tr(product.name)}
      </Txt>
      <Txt
        variant="bodyStrong"
        center
        style={[{ marginTop: 2 }, faded ? { textDecorationLine: 'line-through' } : null]}
        muted={faded}
      >
        {formatHuf(price, lang)}
      </Txt>
    </View>
  );
}

export function SwapCard({ item }: { item: SwapItem }) {
  const t = useT(strings);
  const lang = useLang();
  const { c, isDark } = useTheme();
  const store = getStore(item.store);
  const alt = item.alt;
  const green = isDark ? palette.great : palette.forest;
  return (
    <PressableScale onPress={() => open(alt.product.ean)} accessibilityRole="button" accessibilityLabel={`${t.swapTitle}: ${alt.product.brand}`}>
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.sm }}>
          <View style={{ flex: 1 }}>
            <Txt variant="number" color={green}>
              −{formatHuf(item.saving, lang)}
            </Txt>
            <Txt variant="h3" style={{ marginTop: 2 }}>
              {t.swapHeadline(item.removed)}
            </Txt>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 4,
              borderRadius: radius.pill,
              paddingHorizontal: 10,
              paddingVertical: 5,
              marginTop: 6,
              backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
            }}
            accessibilityLabel={`${t.fit}: ${item.fromMatched}/${item.total} → ${alt.result.matched}/${alt.result.total}`}
          >
            <Txt variant="tiny" muted>
              {t.fit}
            </Txt>
            <Txt variant="tiny" color={verdictColor.avoid}>
              {item.fromMatched}/{item.total}
            </Txt>
            <Icon name="arrow-right" size={11} color={c.textFaint} />
            <Txt variant="tiny" color={verdictColor.great}>
              {alt.result.matched}/{alt.result.total}
            </Txt>
          </View>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: space.lg, gap: space.sm }}>
          <MiniProduct product={item.from} price={item.fromPrice} faded />
          <View
            style={{
              width: 38,
              height: 38,
              borderRadius: 19,
              backgroundColor: palette.lime,
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 34,
            }}
          >
            <Icon name="arrow-right" size={20} color={palette.ink} strokeWidth={2.4} />
          </View>
          <MiniProduct product={alt.product} price={item.toPrice} />
        </View>
        <Hairline />
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: store.color }} />
          <Txt variant="small" muted numberOfLines={1} style={{ flexShrink: 1 }}>
            {t.bothAt} <Txt variant="small" style={{ fontFamily: font.bodySemi }}>{store.name}</Txt>
          </Txt>
        </View>
        {alt.product.affiliate ? (
          <View style={{ flexDirection: 'row', gap: 6, alignItems: 'flex-start', marginTop: space.md }}>
            <Icon name="badge-percent" size={14} color={c.textFaint} />
            <Txt variant="tiny" faint style={{ flex: 1, letterSpacing: 0.1, fontFamily: font.bodyMedium }}>
              {t.partner}
            </Txt>
          </View>
        ) : null}
      </Card>
    </PressableScale>
  );
}

// ── Magyarázók ──────────────────────────────────────────────────────────────

export function HowCard() {
  const t = useT(strings);
  const rows: { icon: IconName; text: string }[] = [
    { icon: 'settings', text: t.how1 },
    { icon: 'shield-check', text: t.how2 },
    { icon: 'heart', text: t.how3 },
  ];
  return (
    <View style={{ borderRadius: radius.lg, overflow: 'hidden' }}>
      <LinearGradient colors={['#D7F79A', '#A6EBC9']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ padding: space.xl }}>
        <Txt variant="h2" color={palette.ink}>
          {t.howTitle}
        </Txt>
        <View style={{ marginTop: space.lg, gap: space.md }}>
          {rows.map((r) => (
            <View key={r.icon} style={{ flexDirection: 'row', gap: space.md, alignItems: 'center' }}>
              <View
                style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: palette.ink, alignItems: 'center', justifyContent: 'center' }}
              >
                <Icon name={r.icon} size={18} color={palette.lime} />
              </View>
              <Txt variant="body" color={palette.ink} style={{ flex: 1 }}>
                {r.text}
              </Txt>
            </View>
          ))}
        </View>
      </LinearGradient>
    </View>
  );
}

export function PricesCard() {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
        <View
          style={{
            width: 42,
            height: 42,
            borderRadius: 14,
            backgroundColor: isDark ? 'rgba(255,201,61,0.16)' : 'rgba(255,201,61,0.3)',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name="store" size={20} color={isDark ? palette.sun : palette.ink} />
        </View>
        <Txt variant="h3" style={{ flex: 1 }}>
          {t.pricesTitle}
        </Txt>
      </View>
      <Txt variant="body" muted style={{ marginTop: space.md }}>
        {t.pricesBody}
      </Txt>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: space.md }}>
        {STORES.map((s) => (
          <View
            key={s.key}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              paddingHorizontal: 10,
              paddingVertical: 5,
              borderRadius: radius.pill,
              backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
            }}
          >
            <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: s.color }} />
            <Txt variant="small">{s.name}</Txt>
          </View>
        ))}
        <View style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: radius.pill, borderWidth: 1, borderColor: c.border }}>
          <Txt variant="small" faint>
            {t.demoPrices}
          </Txt>
        </View>
      </View>
    </Card>
  );
}

export function EmptyCard() {
  const t = useT(strings);
  return (
    <Card style={{ alignItems: 'center', paddingVertical: space.xxl }}>
      <Icon name="sprout" size={30} color={palette.limeDeep} />
      <Txt variant="h3" center style={{ marginTop: space.md }}>
        {t.emptyTitle}
      </Txt>
      <Txt variant="small" muted center style={{ marginTop: 4 }}>
        {t.emptyBody}
      </Txt>
    </Card>
  );
}
