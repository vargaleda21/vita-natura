import type { AvoidKey } from '@/data/types';

type Country = 'AT' | 'DE' | 'SK' | 'CZ';

/** What the better product has none of, as in „pálmaolaj nélkül”. `high_salt` and `ultra_processed` are phrases of their own. */
const withoutHu: Record<AvoidKey, string> = {
  palm_oil: 'pálmaolaj',
  added_sugar: 'hozzáadott cukor',
  sweeteners: 'édesítőszer',
  additives: 'E-szám',
  nitrites: 'nitrit',
  artificial_colors: 'mesterséges színezék',
  ultra_processed: 'kevésbé feldolgozott',
  high_salt: 'kevesebb sóval',
  lactose: 'laktóz',
  gluten: 'glutén',
  nuts: 'diófélék',
  egg: 'tojás',
  soy: 'szója',
  caffeine: 'koffein',
};

const withoutEn: Record<AvoidKey, string> = {
  palm_oil: 'palm oil',
  added_sugar: 'added sugar',
  sweeteners: 'sweeteners',
  additives: 'E numbers',
  nitrites: 'nitrites',
  artificial_colors: 'artificial colours',
  ultra_processed: 'less processed',
  high_salt: 'less salt',
  lactose: 'lactose',
  gluten: 'gluten',
  nuts: 'nuts',
  egg: 'egg',
  soy: 'soya',
  caffeine: 'caffeine',
};

/** Keys that read as a phrase of their own („kevesebb sóval”, "less processed"), not as a thing left out. */
const PHRASES: AvoidKey[] = ['high_salt', 'ultra_processed'];

function list(items: string[], joiner: string): string {
  if (items.length <= 1) return items.join('');
  return `${items.slice(0, -1).join(', ')} ${joiner} ${items[items.length - 1]}`;
}

function capitalise(text: string): string {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

/** „Pálmaolaj nélkül”, „Pálmaolaj és hozzáadott cukor nélkül”, „Pálmaolaj nélkül, kevésbé feldolgozott”. */
function withoutPhraseHu(removed: AvoidKey[]): string {
  const nouns = removed.filter((k) => !PHRASES.includes(k)).map((k) => withoutHu[k]);
  const parts = nouns.length > 0 ? [`${list(nouns, 'és')}\u00A0nélkül`] : [];
  for (const k of PHRASES) if (removed.includes(k)) parts.push(withoutHu[k]);
  return capitalise(parts.join(', '));
}

/** "No palm oil", "No palm oil or added sugar", "No palm oil, less processed". */
function withoutPhraseEn(removed: AvoidKey[]): string {
  const nouns = removed.filter((k) => !PHRASES.includes(k)).map((k) => withoutEn[k]);
  const parts = nouns.length > 0 ? [`no ${list(nouns, 'or')}`] : [];
  for (const k of PHRASES) if (removed.includes(k)) parts.push(withoutEn[k]);
  return capitalise(parts.join(', '));
}

export const strings = {
  hu: {
    title: 'Felfedezés',
    sub: 'Amit a címke nem mond el.',
    finds: (n: number) => `${n} friss felfedezés a polcokról`,
    filterAll: 'Mind',
    filterShrink: 'Kisebb lett',
    filterRecipe: 'Más a recept',
    filterCheaper: 'Ugyanott olcsóbb',
    statShrink: 'termék lett kisebb',
    statDual: 'termék receptje más külföldön',
    statSave: 'a legjobb cserén',
    shrinkEyebrow: 'Zsugorinfláció',
    shrinkTitle: 'Kisebb lett, ugyanannyiért',
    shrinkSub: 'Ugyanolyan a csomag, de kevesebb van benne. A polcon nem látszik, itt igen.',
    samePrice: 'Az ára maradt',
    unitPrice: (pct: number) => `Egységár: +${pct}%`,
    dualEyebrow: 'Kettős minőség',
    dualTitleAT: 'Más a recept Ausztriában',
    dualTitleAny: 'Más a recept külföldön',
    dualSub: 'Ugyanaz a márka, ugyanaz a csomag, más összetétel.',
    home: 'Itthon',
    country: { AT: 'Ausztriában', DE: 'Németországban', SK: 'Szlovákiában', CZ: 'Csehországban' } satisfies Record<Country, string>,
    dualVerdict: {
      different: 'Más a recept',
      worse_here: 'Itthon gyengébb a recept',
      better_here: 'Itthon jobb a recept',
      same: 'Ugyanaz a recept',
    },
    worseEyebrow: 'Receptfigyelő',
    worseTitle: 'Spóroltak a recepten',
    worseSub: 'Ugyanaz a név, de olcsóbb összetevők kerültek bele.',
    forYou: 'A beállításaid szerint',
    swapEyebrow: 'Okos csere',
    swapTitle: 'Ugyanott jobbat, olcsóbban',
    swapSub: 'A beállításaid alapján válogattuk.',
    swapHeadline: (removed: AvoidKey[]) => (removed.length === 0 ? 'Jobban illik hozzád' : withoutPhraseHu(removed)),
    bothAt: 'Mindkettő kapható itt:',
    moreSwaps: (n: number) => `Még ${n} okos csere`,
    fit: 'Neked',
    partner: 'Partnerajánlat is van rá, de a sorrendet ez soha nem befolyásolja.',
    howTitle: 'Hogyan dönt a DaleDay?',
    how1: 'A te beállításaid szerint, nem egy mindenkire ráhúzott pontszámmal.',
    how2: 'Forrásokkal: WHO, EFSA, Nébih és a NOVA-besorolás.',
    how3: 'A sorrendet nem lehet megvenni. A partnerboltok jutaléka nem számít bele.',
    pricesTitle: 'Honnan jönnek az árak?',
    pricesBody:
      'A kész alkalmazásban a GVH Árfigyelő napi árai. Ebben a demóban kitalált boltok és árak szerepelnek.',
    demoPrices: 'Demóárak',
    emptyTitle: 'Most nincs itt semmi',
    emptyBody: 'Nézz vissza holnap, a polcok folyton változnak.',
    open: 'Megnyitás',
  },
  en: {
    title: 'Discover',
    sub: 'What the label won’t tell you.',
    finds: (n: number) => (n === 1 ? '1 fresh find from the shelves' : `${n} fresh finds from the shelves`),
    filterAll: 'All',
    filterShrink: 'Got smaller',
    filterRecipe: 'Different recipe',
    filterCheaper: 'Cheaper, same shop',
    statShrink: 'products got smaller',
    statDual: 'products differ abroad',
    statSave: 'on the best swap',
    shrinkEyebrow: 'Shrinkflation',
    shrinkTitle: 'Smaller, same price',
    shrinkSub: 'Same pack, less inside. You can’t see it on the shelf, but you can here.',
    samePrice: 'Same price',
    unitPrice: (pct: number) => `Unit price: +${pct}%`,
    dualEyebrow: 'Dual quality',
    dualTitleAT: 'A different recipe in Austria',
    dualTitleAny: 'A different recipe abroad',
    dualSub: 'Same brand, same pack, different recipe.',
    home: 'In Hungary',
    country: { AT: 'In Austria', DE: 'In Germany', SK: 'In Slovakia', CZ: 'In Czechia' } satisfies Record<Country, string>,
    dualVerdict: {
      different: 'Different recipe',
      worse_here: 'Weaker recipe here',
      better_here: 'Better recipe here',
      same: 'Same recipe',
    },
    worseEyebrow: 'Recipe watch',
    worseTitle: 'They skimped on the recipe',
    worseSub: 'Same name, but cheaper ingredients went in.',
    forYou: 'By your settings',
    swapEyebrow: 'Smart swap',
    swapTitle: 'Better and cheaper, same shop',
    swapSub: 'Picked to match your settings.',
    swapHeadline: (removed: AvoidKey[]) =>
      removed.length === 0 ? 'Suits you better' : withoutPhraseEn(removed),
    bothAt: 'Both sold at',
    moreSwaps: (n: number) => (n === 1 ? '1 more smart swap' : `${n} more smart swaps`),
    fit: 'For you',
    partner: 'There is a partner offer too, but it never changes the ranking.',
    howTitle: 'How does DaleDay decide?',
    how1: 'By your own settings, not one score for everybody.',
    how2: 'With sources: WHO, EFSA, Nébih and the NOVA groups.',
    how3: 'Nobody can buy a better ranking. Partner shops’ commission never counts.',
    pricesTitle: 'Where do the prices come from?',
    pricesBody: 'In the finished app: daily prices from the GVH Árfigyelő price monitor. This demo uses made-up shops and prices.',
    demoPrices: 'Demo prices',
    emptyTitle: 'Nothing here right now',
    emptyBody: 'Check back tomorrow; the shelves keep changing.',
    open: 'Open',
  },
};
