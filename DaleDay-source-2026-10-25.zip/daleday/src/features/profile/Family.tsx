import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Text, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

import { CRITERIA } from '@/data/api';
import type { Member } from '@/data/types';
import { useT, useTr } from '@/i18n';
import { palette, radius, shadow, space } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { alpha } from './AvoidPicker';
import { strings } from './strings';

/** A member's round picture: their emoji on their colour. */
export function MemberAvatar({ member, size, ring }: { member: Pick<Member, 'avatar' | 'color'>; size: number; ring?: string }) {
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: member.color,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: ring ? Math.max(2, size * 0.06) : 0,
        borderColor: ring,
      }}
    >
      <Text style={{ fontSize: size * 0.52, lineHeight: size * 0.66 }} allowFontScaling={false}>
        {member.avatar}
      </Text>
    </View>
  );
}

const CARD_H = 172;

function MemberCard({ m, width, delay, reduced }: { m: Member; width: number; delay: number; reduced: boolean }) {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const shown = m.avoid.slice(0, 4);
  const more = m.avoid.length - shown.length;
  return (
    <Animated.View entering={reduced ? undefined : FadeInDown.delay(delay).springify().damping(18)} style={{ width }}>
      <PressableScale
        onPress={() => router.push(`/member/${m.id}`)}
        accessibilityRole="button"
        accessibilityLabel={t.editMember(m.name)}
        scaleTo={0.97}
        style={[
          {
            height: CARD_H,
            borderRadius: radius.lg,
            overflow: 'hidden',
            backgroundColor: c.surface,
            borderWidth: isDark ? 1 : 0,
            borderColor: c.border,
          },
          isDark ? null : shadow.card,
        ]}
      >
        <LinearGradient
          colors={[alpha(m.color, isDark ? 0.22 : 0.32), alpha(m.color, 0)]}
          start={{ x: 0, y: 0 }}
          end={{ x: 0.4, y: 1 }}
          style={{ flex: 1, padding: space.lg }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' }}>
            <MemberAvatar member={m} size={50} ring={isDark ? c.surface : palette.white} />
            <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: c.border, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="chevron-right" size={16} color={c.textMuted} strokeWidth={2.4} />
            </View>
          </View>
          <View style={{ flex: 1 }} />
          <Txt variant="h3" numberOfLines={1}>
            {m.name}
          </Txt>
          <Txt variant="small" muted numberOfLines={1}>
            {t.memberAvoids(m.avoid.length)}
          </Txt>
          <View style={{ flexDirection: 'row', gap: 4, marginTop: space.sm, minHeight: 24 }}>
            {shown.map((k) => (
              <View
                key={k}
                accessibilityLabel={tr(CRITERIA[k].label)}
                style={{
                  width: 24,
                  height: 24,
                  borderRadius: 12,
                  backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icon name={CRITERIA[k].icon} size={13} color={c.text} strokeWidth={2.2} />
              </View>
            ))}
            {more > 0 ? (
              <View style={{ height: 24, paddingHorizontal: 6, borderRadius: 12, backgroundColor: isDark ? c.surfaceAlt : c.bgAlt, justifyContent: 'center' }}>
                <Txt variant="tiny" muted>
                  +{more}
                </Txt>
              </View>
            ) : null}
          </View>
        </LinearGradient>
      </PressableScale>
    </Animated.View>
  );
}

function AddCard({ width, wide, first, delay, reduced }: { width: number; wide: boolean; first: boolean; delay: number; reduced: boolean }) {
  const t = useT(strings);
  const { isDark } = useTheme();
  const plus = (
    <View style={{ width: 46, height: 46, borderRadius: 23, backgroundColor: palette.lime, alignItems: 'center', justifyContent: 'center' }}>
      <Icon name="plus" size={24} color={palette.ink} strokeWidth={2.6} />
    </View>
  );
  return (
    <Animated.View entering={reduced ? undefined : FadeInDown.delay(delay).springify().damping(18)} style={{ width }}>
      <PressableScale
        onPress={() => router.push('/member/new')}
        accessibilityRole="button"
        accessibilityLabel={t.addMember}
        scaleTo={0.97}
        style={{
          height: wide ? undefined : CARD_H,
          minHeight: wide ? 88 : undefined,
          borderRadius: radius.lg,
          borderWidth: 1.5,
          borderStyle: 'dashed',
          borderColor: isDark ? 'rgba(238,246,239,0.22)' : 'rgba(16,35,28,0.2)',
          padding: space.lg,
          flexDirection: wide ? 'row' : 'column',
          alignItems: wide ? 'center' : 'flex-start',
          gap: space.md,
        }}
      >
        {plus}
        {wide ? null : <View style={{ flex: 1 }} />}
        <View style={{ flex: wide ? 1 : undefined, gap: 2 }}>
          <Txt variant="h3">{wide ? t.addMember : t.addMemberShort}</Txt>
          {wide ? (
            <Txt variant="small" muted>
              {first ? t.familySub : t.addMemberSub}
            </Txt>
          ) : (
            <Txt variant="small" muted numberOfLines={2}>
              {t.addMemberSub}
            </Txt>
          )}
        </View>
      </PressableScale>
    </Animated.View>
  );
}

/** Member cards two by two, and an add card that fills the gap (or the whole row). */
export function FamilyGrid({ members, inner, gap, reduced }: { members: Member[]; inner: number; gap: number; reduced: boolean }) {
  const half = (inner - gap) / 2;
  const wide = members.length % 2 === 0;
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap }}>
      {members.map((m, i) => (
        <MemberCard key={m.id} m={m} width={half} delay={60 + i * 60} reduced={reduced} />
      ))}
      <AddCard width={wide ? inner : half} wide={wide} first={members.length === 0} delay={60 + members.length * 60} reduced={reduced} />
    </View>
  );
}
