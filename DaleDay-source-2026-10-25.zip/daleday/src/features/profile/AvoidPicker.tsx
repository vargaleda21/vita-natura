import { useState } from 'react';
import { Linking, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, FadeOut, ZoomIn } from 'react-native-reanimated';

import { CRITERIA, CRITERIA_ORDER } from '@/data/api';
import type { AvoidKey, CriterionGroup } from '@/data/types';
import { useT, useTr } from '@/i18n';
import { palette, radius, space } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { strings } from './strings';

/** "rgba(…)" from a #RRGGBB hex. */
export function alpha(hex: string, a: number): string {
  const n = parseInt(hex.slice(1, 7), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

function ToggleChip({ k, on, tint, onToggle, onExplain, explained }: {
  k: AvoidKey;
  on: boolean;
  tint: string;
  onToggle: () => void;
  onExplain: () => void;
  explained: boolean;
}) {
  const tr = useTr();
  const { c, isDark } = useTheme();
  const cr = CRITERIA[k];
  const fg = on ? palette.ink : c.text;
  return (
    <PressableScale
      onPress={onToggle}
      onLongPress={onExplain}
      delayLongPress={380}
      scaleTo={0.93}
      accessibilityRole="switch"
      accessibilityState={{ checked: on }}
      accessibilityLabel={tr(cr.label)}
      accessibilityHint={tr(cr.short)}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 7,
        minHeight: 44,
        paddingLeft: 12,
        paddingRight: on ? 8 : 14,
        borderRadius: radius.pill,
        backgroundColor: on ? tint : isDark ? c.surfaceAlt : c.surface,
        borderWidth: 1.5,
        borderColor: explained ? c.text : on ? 'transparent' : c.border,
      }}
    >
      <Icon name={cr.icon} size={17} color={on ? palette.ink : c.textMuted} strokeWidth={2.1} />
      <Txt variant="bodyStrong" color={fg} style={{ fontSize: 14 }}>
        {tr(cr.label)}
      </Txt>
      {on ? (
        <Animated.View
          entering={ZoomIn.springify().damping(12)}
          style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: palette.ink, alignItems: 'center', justifyContent: 'center' }}
        >
          <Icon name="check" size={13} color={tint} strokeWidth={3} />
        </Animated.View>
      ) : null}
    </PressableScale>
  );
}

function Explain({ k, on, tint, onClose }: { k: AvoidKey; on: boolean; tint: string; onClose: () => void }) {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const cr = CRITERIA[k];
  return (
    <Animated.View
      entering={FadeInDown.duration(260)}
      exiting={FadeOut.duration(160)}
      style={{
        marginTop: space.sm,
        borderRadius: radius.md,
        padding: space.md,
        backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
        borderWidth: 1,
        borderColor: c.border,
        flexDirection: 'row',
        gap: space.md,
      }}
    >
      <View
        style={{
          width: 40,
          height: 40,
          borderRadius: 12,
          backgroundColor: on ? tint : alpha(isDark ? palette.white : palette.ink, 0.07),
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Icon name={cr.icon} size={20} color={on ? palette.ink : c.text} strokeWidth={2} />
      </View>
      <View style={{ flex: 1, gap: 4 }}>
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.sm }}>
          <View style={{ flex: 1 }}>
            <Txt variant="h3">{tr(cr.label)}</Txt>
            <Txt variant="small" muted>
              {on ? t.explainOn : t.explainOff}
            </Txt>
          </View>
          <PressableScale
            onPress={onClose}
            accessibilityRole="button"
            accessibilityLabel={t.explainClose}
            hitSlop={10}
            style={{ width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: c.border }}
          >
            <Icon name="x" size={15} color={c.textMuted} strokeWidth={2.4} />
          </PressableScale>
        </View>
        <Txt variant="body" style={{ marginTop: 2 }}>
          {tr(cr.short)}
        </Txt>
        <PressableScale
          onPress={() => {
            if (cr.source.url) void Linking.openURL(cr.source.url);
          }}
          disabled={!cr.source.url}
          accessibilityRole="link"
          scaleTo={0.97}
          style={{ alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 4 }}
        >
          <Txt variant="small" color={isDark ? palette.lime : palette.forest}>
            {t.explainSource}: {cr.source.name}
          </Txt>
          {cr.source.url ? <Icon name="arrow-right" size={13} color={isDark ? palette.lime : palette.forest} strokeWidth={2.4} /> : null}
        </PressableScale>
      </View>
    </Animated.View>
  );
}

/**
 * The avoid list as grouped toggle chips. Tap switches, press and hold explains.
 * Switching one on also explains it once, so nobody turns on a word they do not know.
 */
export function AvoidPicker({ selected, onToggle, tint = palette.lime, order }: {
  selected: AvoidKey[];
  onToggle: (key: AvoidKey) => void;
  tint?: string;
  order: CriterionGroup[];
}) {
  const t = useT(strings);
  const { c } = useTheme();
  const [explained, setExplained] = useState<AvoidKey | null>(null);

  return (
    <View style={{ gap: space.lg }}>
      {order.map((g) => {
        const keys = CRITERIA_ORDER.filter((k) => CRITERIA[k].group === g);
        if (keys.length === 0) return null;
        const count = keys.filter((k) => selected.includes(k)).length;
        const open = explained && keys.includes(explained) ? explained : null;
        return (
          <View key={g}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm, marginBottom: space.sm }}>
              <Txt variant="tiny" upper faint>
                {t.groups[g]}
              </Txt>
              {count > 0 ? (
                <Animated.View entering={FadeIn.duration(200)} style={{ paddingHorizontal: 6, borderRadius: radius.pill, backgroundColor: c.border }}>
                  <Txt variant="tiny" muted>
                    {count}/{keys.length}
                  </Txt>
                </Animated.View>
              ) : null}
            </View>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
              {keys.map((k) => {
                const on = selected.includes(k);
                return (
                  <ToggleChip
                    key={k}
                    k={k}
                    on={on}
                    tint={tint}
                    explained={open === k}
                    onToggle={() => {
                      onToggle(k);
                      if (!on) setExplained(k);
                      else if (explained === k) setExplained(null);
                    }}
                    onExplain={() => setExplained(k)}
                  />
                );
              })}
            </View>
            {open ? <Explain key={open} k={open} on={selected.includes(open)} tint={tint} onClose={() => setExplained(null)} /> : null}
          </View>
        );
      })}
    </View>
  );
}
