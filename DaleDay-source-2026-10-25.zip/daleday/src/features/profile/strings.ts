// The profile tab and the family member editor. Hungarian first, informal "te".

import type { CriterionGroup, ThemePref } from '@/data/types';
import { groupDigits } from '@/i18n';
import type { IconName } from '@/ui';

const h = (n: number) => groupDigits(n, ' ');
const e = (n: number) => groupDigits(n, ',');

type ThemeCopy = Record<ThemePref, { label: string; sub: string }>;
type Row = { icon: IconName; title: string; body: string };
const rows = (r: Row[]) => r;

const hu = {
  title: 'Profil',
  // Hero
  greet: (hour: number): string => (hour >= 5 && hour < 10 ? 'Jó reggelt' : hour >= 10 && hour < 18 ? 'Szia' : 'Jó estét'),
  heroSub: 'Erre figyel a DaleDay – neked és a családodnak.',
  statAvoid: (n: number) => (n === 0 ? 'Még semmit nem kerülsz' : `${h(n)} dolgot kerülsz`),
  statFamily: (n: number) => (n === 0 ? 'Csak te' : `Te + ${h(n)} családtag`),

  // Avoid list
  avoidTitle: 'Amit kerülsz',
  avoidSub: 'Koppints a be- és kikapcsoláshoz. Tartsd lenyomva, ha kíváncsi vagy, miért kerülik sokan.',
  groups: {
    diet: 'Étrend',
    additive: 'Adalékanyagok',
    allergy: 'Allergének és érzékenységek',
    planet: 'A bolygóért',
  } satisfies Record<CriterionGroup, string>,
  explainSource: 'Forrás',
  explainOn: 'Bekapcsolva: minden szkennelésnél figyeljük.',
  explainOff: 'Kikapcsolva. Egy koppintás, és már figyeljük.',
  explainClose: 'Magyarázat bezárása',
  toggledOn: (label: string) => `${label}: bekapcsolva`,
  toggledOff: (label: string) => `${label}: kikapcsolva`,

  // Family
  familyTitle: 'Család',
  familySub: 'Egy szkennelés mindenkire figyel: a kicsi tejallergiájára és a nagyi cukrára is.',
  memberAvoids: (n: number) => (n === 0 ? 'Még nincs beállítva' : `${h(n)} dolgot kerül`),
  addMember: 'Családtag hozzáadása',
  addMemberShort: 'Új családtag',
  addMemberSub: 'Egy szkennelés mindenkire figyel.',
  editMember: (name: string) => `${name} szerkesztése`,

  // Settings
  settingsTitle: 'Beállítások',
  nameLabel: 'A neved',
  namePlaceholder: 'Hogyan szólíthatunk?',
  langLabel: 'Nyelv',
  themeLabel: 'Megjelenés',
  theme: {
    auto: { label: 'Automatikus', sub: 'Este sötét, napközben világos' },
    light: { label: 'Világos', sub: 'Mindig világos' },
    dark: { label: 'Sötét', sub: 'Mindig sötét' },
    system: { label: 'Rendszer', sub: 'Ahogy a telefonod be van állítva' },
  } satisfies ThemeCopy,
  themeNow: (dark: boolean): string => (dark ? 'Most: sötét' : 'Most: világos'),

  // Honest money
  moneyTitle: 'Hogyan keres pénzt a DaleDay?',
  moneyLead: 'Röviden: néha jutalékot kapunk, de soha nem a sorrendért.',
  money: rows([
    {
      icon: 'store',
      title: 'Jutalék a partnerboltoktól',
      body: 'Ha egy jobb terméket partnerboltban veszel meg, a bolt fizethet nekünk egy kis jutalékot. Ezt mindig jelöljük.',
    },
    {
      icon: 'scale',
      title: 'A sorrend nem eladó',
      body: 'A jutalék soha nem változtat a sorrenden. Az ajánlatok sorrendjét csak a beállításaid és az ár határozza meg.',
    },
    {
      icon: 'shield-check',
      title: 'Nincs hirdetés, nincs adatárulás',
      body: 'Nem adjuk el az adataidat. A beállításaid és a kosarad a telefonodon maradnak.',
    },
  ]),

  // Data sources
  dataTitle: 'Honnan jönnek az adatok?',
  data: rows([
    { icon: 'users', title: 'Közösség', body: 'Vásárlók töltik fel az összetevőket, és ellenőrzik egymás munkáját.' },
    { icon: 'factory', title: 'Gyártók', body: 'A márkák saját adatai, ha megosztják velünk.' },
    { icon: 'sparkles', title: 'AI-címkeolvasás', body: 'Ha egy vonalkódot még nem ismerünk, lefotózod a címkét, és az AI kiolvassa. Ezt a terméknél jelöljük.' },
    { icon: 'tag', title: 'Árak', body: 'Boltonkénti napi árak a GVH Árfigyelő adataiból.' },
    { icon: 'info', title: 'Magyarázatok', body: 'A WHO, az EFSA, a Nébih és az uniós rendeletek nyilvános anyagaiból.' },
  ]),
  dataDemo: 'Ez egy demó: minden márka, bolt és ár kitalált.',

  // Reset
  resetTitle: 'Demó újrakezdése',
  resetSub: 'Törli a beállításaidat, és elölről indul a bemutató.',
  resetConfirm: 'Biztos? Koppints még egyszer',
  version: 'DaleDay 0.1 demó',
  tagline: 'Tudd, mi van benne.',

  // Member editor
  ed: {
    titleNew: 'Új családtag',
    titleEdit: 'Családtag szerkesztése',
    close: 'Bezárás',
    name: 'Név',
    namePlaceholder: 'Például: Bence vagy Mama',
    avatar: 'Kép',
    color: 'Szín',
    avoid: 'Mit kerüljön?',
    avoidSub: 'Minden szkennelésnél az ő listáját is megnézzük.',
    save: 'Mentés',
    add: 'Hozzáadás',
    needName: 'Előbb adj meg egy nevet',
    remove: 'Eltávolítás a családból',
    removeConfirm: 'Biztos? Koppints még egyszer',
    notFound: 'Ezt a családtagot nem találjuk.',
    back: 'Vissza a profilhoz',
    preview: (name: string, n: number) =>
      n === 0 ? `${name || 'Az új családtag'} még semmit nem kerül.` : `${name || 'Az új családtag'} ${h(n)} dolgot kerül.`,
  },
};

type Strings = typeof hu;

const en: Strings = {
  title: 'Profile',
  greet: (hour) => (hour >= 5 && hour < 10 ? 'Good morning' : hour >= 10 && hour < 18 ? 'Hello' : 'Good evening'),
  heroSub: 'This is what DaleDay watches for you and your family.',
  statAvoid: (n) => (n === 0 ? 'Nothing avoided yet' : n === 1 ? 'Avoiding 1 thing' : `Avoiding ${e(n)} things`),
  statFamily: (n) => (n === 0 ? 'Just you' : `You + ${e(n)} family`),

  avoidTitle: 'What you avoid',
  avoidSub: 'Tap to switch on or off. Press and hold to see why people avoid it.',
  groups: {
    diet: 'Diet',
    additive: 'Additives',
    allergy: 'Allergens and intolerances',
    planet: 'For the planet',
  },
  explainSource: 'Source',
  explainOn: 'On: we check it on every scan.',
  explainOff: 'Off. One tap and we’ll check it.',
  explainClose: 'Close the explanation',
  toggledOn: (label) => `${label}: on`,
  toggledOff: (label) => `${label}: off`,

  familyTitle: 'Family',
  familySub: 'One scan looks out for everyone: the little one’s milk allergy and grandma’s sugar.',
  memberAvoids: (n) => (n === 0 ? 'Nothing set yet' : n === 1 ? 'Avoids 1 thing' : `Avoids ${e(n)} things`),
  addMember: 'Add a family member',
  addMemberShort: 'New member',
  addMemberSub: 'One scan looks out for everyone.',
  editMember: (name) => `Edit ${name}`,

  settingsTitle: 'Settings',
  nameLabel: 'Your name',
  namePlaceholder: 'What should we call you?',
  langLabel: 'Language',
  themeLabel: 'Appearance',
  theme: {
    auto: { label: 'Auto', sub: 'Dark at night, light by day' },
    light: { label: 'Light', sub: 'Always light' },
    dark: { label: 'Dark', sub: 'Always dark' },
    system: { label: 'System', sub: 'Follows your phone' },
  },
  themeNow: (dark) => (dark ? 'Now: dark' : 'Now: light'),

  moneyTitle: 'How does DaleDay make money?',
  moneyLead: 'In short: sometimes we earn a commission, but never for the ranking.',
  money: rows([
    {
      icon: 'store',
      title: 'Commission from partner shops',
      body: 'If you buy a better product in a partner shop, the shop may pay us a small commission. We always mark it.',
    },
    {
      icon: 'scale',
      title: 'The ranking is not for sale',
      body: 'A commission never changes the ranking. Only your settings and the price decide the order.',
    },
    {
      icon: 'shield-check',
      title: 'No ads, no selling your data',
      body: 'We never sell your data. Your settings and your basket stay on your phone.',
    },
  ]),

  dataTitle: 'Where does the data come from?',
  data: rows([
    { icon: 'users', title: 'Community', body: 'Shoppers add ingredient lists and check each other’s work.' },
    { icon: 'factory', title: 'Makers', body: 'Brands’ own data, when they share it with us.' },
    { icon: 'sparkles', title: 'AI label reading', body: 'If we don’t know a barcode yet, you photograph the label and AI reads it. We mark this on the product.' },
    { icon: 'tag', title: 'Prices', body: 'Daily prices per shop from the GVH Árfigyelő price monitor.' },
    { icon: 'info', title: 'Explanations', body: 'From public material by the WHO, EFSA, Nébih and EU regulations.' },
  ]),
  dataDemo: 'This is a demo: every brand, shop and price is made up.',

  resetTitle: 'Restart the demo',
  resetSub: 'Clears your settings and starts the tour again.',
  resetConfirm: 'Sure? Tap once more',
  version: 'DaleDay 0.1 demo',
  tagline: 'Know what’s inside.',

  ed: {
    titleNew: 'New family member',
    titleEdit: 'Edit family member',
    close: 'Close',
    name: 'Name',
    namePlaceholder: 'For example, Ben or Grandma',
    avatar: 'Picture',
    color: 'Colour',
    avoid: 'What should they avoid?',
    avoidSub: 'Every scan checks their list too.',
    save: 'Save',
    add: 'Add',
    needName: 'Add a name first',
    remove: 'Remove from the family',
    removeConfirm: 'Sure? Tap once more',
    notFound: 'We can’t find this family member.',
    back: 'Back to the profile',
    preview: (name, n) =>
      n === 0 ? `${name || 'The new member'} avoids nothing yet.` : n === 1 ? `${name || 'The new member'} avoids 1 thing.` : `${name || 'The new member'} avoids ${e(n)} things.`,
  },
};

export const strings = { hu, en };
