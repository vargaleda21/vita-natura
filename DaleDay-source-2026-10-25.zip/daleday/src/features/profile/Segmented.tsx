import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Pressable, View } from 'react-native';
import Animated, { useAnimatedStyle, useReducedMotion, useSharedValue, withSpring } from 'react-native-reanimated';

import { palette, radius, shadow, springs } from '@/theme/tokens';
import { Txt, useTheme } from '@/ui';

export type SegmentOption<T extends string> = {
  value: T;
  label: string;
  /** Drawn above the label in the tall layout, beside it in the flat one. */
  icon?: (active: boolean) => ReactNode;
};

const PAD = 4;

/** A segmented control with a thumb that springs to the chosen option. */
export function Segmented<T extends string>({ options, value, onChange, tall, label }: {
  options: SegmentOption<T>[];
  value: T;
  onChange: (value: T) => void;
  /** Icon over label, for four options in one row. */
  tall?: boolean;
  label: string;
}) {
  const { c, isDark } = useTheme();
  const reduced = useReducedMotion();
  const [w, setW] = useState(0);
  const n = options.length;
  // The content box: the measured width minus the 1 px border and the padding.
  const segW = w > 0 ? (w - 2 - PAD * 2) / n : 0;
  const idx = Math.max(0, options.findIndex((o) => o.value === value));
  const x = useSharedValue(idx * segW);
  const laidOut = useRef(0);

  useEffect(() => {
    const to = idx * segW;
    // The first measure (or a resize) places the thumb; only a new choice springs it.
    if (laidOut.current !== segW || reduced) {
      laidOut.current = segW;
      x.set(to);
      return;
    }
    x.set(withSpring(to, springs.snappy));
  }, [x, idx, segW, reduced]);

  const thumb = useAnimatedStyle(() => ({ transform: [{ translateX: x.get() }] }));
  const height = tall ? 66 : 46;

  return (
    <View
      accessibilityRole="radiogroup"
      accessibilityLabel={label}
      onLayout={(e) => setW(e.nativeEvent.layout.width)}
      style={{
        height,
        borderRadius: radius.md,
        padding: PAD,
        flexDirection: 'row',
        backgroundColor: isDark ? palette.night : c.bgAlt,
        borderWidth: 1,
        borderColor: c.border,
      }}
    >
      {segW > 0 ? (
        <Animated.View
          pointerEvents="none"
          style={[
            {
              position: 'absolute',
              left: PAD,
              top: PAD,
              width: segW,
              height: height - PAD * 2 - 2,
              borderRadius: radius.md - PAD,
              backgroundColor: isDark ? palette.night3 : palette.white,
              borderWidth: isDark ? 1 : 0,
              borderColor: 'rgba(198,243,107,0.35)',
            },
            isDark ? null : shadow.card,
            thumb,
          ]}
        />
      ) : null}
      {options.map((o) => {
        const active = o.value === value;
        return (
          <Pressable
            key={o.value}
            onPress={() => onChange(o.value)}
            accessibilityRole="radio"
            accessibilityState={{ selected: active, checked: active }}
            accessibilityLabel={o.label}
            style={{
              flex: 1,
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: tall ? 'column' : 'row',
              gap: tall ? 3 : 6,
            }}
          >
            {o.icon ? o.icon(active) : null}
            <Txt
              variant={tall ? 'tiny' : 'bodyStrong'}
              numberOfLines={1}
              color={active ? c.text : c.textMuted}
              style={tall ? { letterSpacing: 0.1, fontSize: 11.5 } : { fontSize: 14 }}
            >
              {o.label}
            </Txt>
          </Pressable>
        );
      })}
    </View>
  );
}
