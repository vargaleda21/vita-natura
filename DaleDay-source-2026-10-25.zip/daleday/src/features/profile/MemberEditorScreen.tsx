import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { useRef, useState, type ComponentRef } from 'react';
import { ScrollView, Text, TextInput, useWindowDimensions, View } from 'react-native';
import Animated, {
  FadeIn,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withSequence,
  withSpring,
  withTiming,
  ZoomIn,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import type { AvoidKey, Member } from '@/data/types';
import { useT } from '@/i18n';
import { removeMember, upsertMember, useSettings } from '@/state/store';
import { font, palette, radius, space, springs } from '@/theme/tokens';
import { Card, Icon, PressableScale, Txt, useTheme } from '@/ui';
import { alpha, AvoidPicker } from './AvoidPicker';
import { Field } from './Cards';
import { strings } from './strings';

const MAX_W = 480;
const PAD = space.lg;

export const AVATARS = ['🧒', '👧', '👦', '👶', '👩', '👨', '👵', '👴', '🧑', '🐣', '🦊', '🐻', '🐼', '🐨', '🌻', '⭐'];
export const COLORS = [palette.sky, palette.lilac, palette.tangerine, palette.sun, palette.coral, palette.mint, palette.lime, palette.limeDeep];

function close() {
  if (router.canGoBack()) router.back();
  else router.replace('/profile');
}

function TopBar({ title }: { title: string }) {
  const t = useT(strings).ed;
  const { c } = useTheme();
  const insets = useSafeAreaInsets();
  return (
    <View
      style={{
        paddingTop: insets.top + space.sm,
        paddingHorizontal: PAD,
        paddingBottom: space.sm,
        flexDirection: 'row',
        alignItems: 'center',
        gap: space.md,
      }}
    >
      <PressableScale
        onPress={close}
        accessibilityRole="button"
        accessibilityLabel={t.close}
        style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: c.surface, borderWidth: 1, borderColor: c.border, alignItems: 'center', justifyContent: 'center' }}
      >
        <Icon name="x" size={20} color={c.text} strokeWidth={2.4} />
      </PressableScale>
      <Txt variant="h3" style={{ flex: 1 }} numberOfLines={1}>
        {title}
      </Txt>
    </View>
  );
}

function NotFound() {
  const t = useT(strings).ed;
  const { c } = useTheme();
  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <View style={{ flex: 1, width: '100%', maxWidth: MAX_W, alignSelf: 'center' }}>
        <TopBar title={t.titleEdit} />
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: space.xxl, gap: space.lg }}>
          <Text style={{ fontSize: 48 }}>🔍</Text>
          <Txt variant="h3" center>
            {t.notFound}
          </Txt>
          <PressableScale
            onPress={() => router.replace('/profile')}
            accessibilityRole="button"
            style={{ height: 48, paddingHorizontal: space.xl, borderRadius: radius.pill, backgroundColor: palette.lime, justifyContent: 'center' }}
          >
            <Txt variant="bodyStrong" color={palette.ink}>
              {t.back}
            </Txt>
          </PressableScale>
        </View>
      </View>
    </View>
  );
}

/** Add or edit one family member: name, picture, colour and what to avoid. */
export function MemberEditorScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const settings = useSettings();
  const existing = id && id !== 'new' ? settings.members.find((m) => m.id === id) : undefined;
  if (id !== 'new' && !existing) return <NotFound />;
  return <Editor key={existing?.id ?? 'new'} existing={existing} members={settings.members} />;
}

function Editor({ existing, members }: { existing?: Member; members: Member[] }) {
  const t = useT(strings).ed;
  const { c, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const reduced = useReducedMotion();

  // A new member gets a picture and a colour nobody in the family has yet.
  const [name, setName] = useState(existing?.name ?? '');
  const [avatar, setAvatar] = useState(existing?.avatar ?? AVATARS.find((a) => !members.some((m) => m.avatar === a)) ?? AVATARS[0]);
  const [color, setColor] = useState(existing?.color ?? COLORS.find((col) => !members.some((m) => m.color === col)) ?? COLORS[0]);
  const [avoid, setAvoid] = useState<AvoidKey[]>(existing?.avoid ?? []);
  const [armed, setArmed] = useState(false);
  const [needName, setNeedName] = useState(false);
  const input = useRef<ComponentRef<typeof TextInput>>(null);

  const colW = Math.min(width, MAX_W);
  // The card's content width: the column, the page padding, the card padding and its 1 px border in dark mode.
  const cardInner = colW - PAD * 2 - space.lg * 2 - 2;
  const cols = 6;
  const cell = 46;
  const cellGap = Math.max(4, Math.floor((cardInner - cols * cell) / (cols - 1)));

  // The preview bounces whenever the picture or colour changes.
  const pop = useSharedValue(1);
  const popStyle = useAnimatedStyle(() => ({ transform: [{ scale: pop.get() }] }));
  const bump = () => {
    if (reduced) return;
    pop.set(withSequence(withTiming(0.86, { duration: 90 }), withSpring(1, springs.bouncy)));
  };
  const shake = useSharedValue(0);
  const shakeStyle = useAnimatedStyle(() => ({ transform: [{ translateX: shake.get() }] }));

  const save = () => {
    const clean = name.trim();
    if (!clean) {
      setNeedName(true);
      input.current?.focus();
      if (!reduced) {
        shake.set(withSequence(withTiming(-8, { duration: 50 }), withTiming(8, { duration: 70 }), withTiming(-5, { duration: 60 }), withTiming(0, { duration: 50 })));
      }
      return;
    }
    upsertMember({ id: existing?.id ?? `m${Date.now().toString(36)}`, name: clean, avatar, color, avoid });
    close();
  };

  const remove = () => {
    if (!existing) return;
    if (!armed) {
      setArmed(true);
      setTimeout(() => setArmed(false), 3500);
      return;
    }
    removeMember(existing.id);
    close();
  };

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <View style={{ flex: 1, width: '100%', maxWidth: MAX_W, alignSelf: 'center' }}>
        {/* A wash of the member's colour behind the header. */}
        <LinearGradient
          pointerEvents="none"
          colors={[alpha(color, isDark ? 0.22 : 0.35), alpha(color, 0)]}
          style={{ position: 'absolute', left: 0, right: 0, top: 0, height: insets.top + 300 }}
        />
        <TopBar title={existing ? t.titleEdit : t.titleNew} />
        <ScrollView
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: PAD, paddingBottom: insets.bottom + 120, gap: space.lg }}
        >
          {/* Preview */}
          <View style={{ alignItems: 'center', gap: space.sm, paddingVertical: space.md }}>
            <Animated.View style={popStyle}>
              <View
                style={{
                  width: 120,
                  height: 120,
                  borderRadius: 60,
                  backgroundColor: color,
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderWidth: 4,
                  borderColor: isDark ? c.surface : palette.white,
                }}
              >
                <Animated.Text key={avatar} entering={reduced ? undefined : ZoomIn.springify().damping(10)} style={{ fontSize: 62, lineHeight: 76 }} allowFontScaling={false}>
                  {avatar}
                </Animated.Text>
              </View>
            </Animated.View>
            <Txt style={{ fontFamily: font.display, fontSize: 26, lineHeight: 30, letterSpacing: -0.6, color: name.trim() ? c.text : c.textFaint }} numberOfLines={1}>
              {name.trim() || t.titleNew}
            </Txt>
            <Txt variant="small" muted center>
              {t.preview(name.trim(), avoid.length)}
            </Txt>
          </View>

          {/* Name */}
          <Card>
            <Txt variant="bodyStrong" style={{ marginBottom: space.sm }}>
              {t.name}
            </Txt>
            <Animated.View style={shakeStyle}>
              <Field
                inputRef={input}
                value={name}
                label={t.name}
                placeholder={t.namePlaceholder}
                onChangeText={(v) => {
                  setName(v);
                  if (v.trim()) setNeedName(false);
                }}
              />
            </Animated.View>
            {needName ? (
              <Animated.View entering={FadeIn.duration(200)} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: space.sm }}>
                <Icon name="circle-alert" size={14} color={palette.coral} strokeWidth={2.4} />
                <Txt variant="small" color={isDark ? palette.coral : c.text}>
                  {t.needName}
                </Txt>
              </Animated.View>
            ) : null}
          </Card>

          {/* Picture */}
          <Card>
            <Txt variant="bodyStrong" style={{ marginBottom: space.md }}>
              {t.avatar}
            </Txt>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', columnGap: cellGap, rowGap: space.sm }}>
              {AVATARS.map((a) => {
                const on = a === avatar;
                return (
                  <PressableScale
                    key={a}
                    onPress={() => {
                      setAvatar(a);
                      bump();
                    }}
                    accessibilityRole="radio"
                    accessibilityState={{ selected: on, checked: on }}
                    accessibilityLabel={a}
                    scaleTo={0.88}
                    style={{
                      width: cell,
                      height: cell,
                      borderRadius: cell / 2,
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor: on ? alpha(color, isDark ? 0.4 : 0.5) : isDark ? c.surfaceAlt : c.bgAlt,
                      borderWidth: 2,
                      borderColor: on ? c.text : 'transparent',
                    }}
                  >
                    <Text style={{ fontSize: 24, lineHeight: 30 }} allowFontScaling={false}>
                      {a}
                    </Text>
                  </PressableScale>
                );
              })}
            </View>
          </Card>

          {/* Colour */}
          <Card>
            <Txt variant="bodyStrong" style={{ marginBottom: space.md }}>
              {t.color}
            </Txt>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              {COLORS.map((col) => {
                const on = col === color;
                return (
                  <PressableScale
                    key={col}
                    onPress={() => {
                      setColor(col);
                      bump();
                    }}
                    accessibilityRole="radio"
                    accessibilityState={{ selected: on, checked: on }}
                    accessibilityLabel={col}
                    scaleTo={0.85}
                    hitSlop={4}
                    style={{
                      width: 38,
                      height: 38,
                      borderRadius: 19,
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderWidth: 2.5,
                      borderColor: on ? c.text : 'transparent',
                    }}
                  >
                    <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: col, alignItems: 'center', justifyContent: 'center' }}>
                      {on ? (
                        <Animated.View entering={reduced ? undefined : ZoomIn.springify().damping(12)}>
                          <Icon name="check" size={15} color={palette.ink} strokeWidth={3} />
                        </Animated.View>
                      ) : null}
                    </View>
                  </PressableScale>
                );
              })}
            </View>
          </Card>

          {/* Avoid list */}
          <Card>
            <Txt variant="bodyStrong">{t.avoid}</Txt>
            <Txt variant="small" muted style={{ marginBottom: space.lg }}>
              {t.avoidSub}
            </Txt>
            <AvoidPicker
              selected={avoid}
              onToggle={(k) => setAvoid((list) => (list.includes(k) ? list.filter((x) => x !== k) : [...list, k]))}
              tint={color}
              order={['allergy', 'diet', 'additive', 'planet']}
            />
          </Card>

          {existing ? (
            <PressableScale
              haptic="medium"
              onPress={remove}
              accessibilityRole="button"
              accessibilityLabel={armed ? t.removeConfirm : t.remove}
              style={{
                height: 52,
                borderRadius: radius.pill,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                backgroundColor: armed ? palette.coral : 'transparent',
                borderWidth: 1.5,
                borderColor: armed ? palette.coral : alpha(palette.coral, 0.5),
              }}
            >
              <Icon name="trash-2" size={18} color={armed ? palette.ink : palette.coral} strokeWidth={2.2} />
              <Txt variant="bodyStrong" color={armed ? palette.ink : isDark ? palette.coral : c.text}>
                {armed ? t.removeConfirm : t.remove}
              </Txt>
            </PressableScale>
          ) : null}
        </ScrollView>

        {/* The save button stays in reach. */}
        <View pointerEvents="box-none" style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }}>
          <LinearGradient pointerEvents="none" colors={[alpha(isDark ? palette.night : palette.oat, 0), c.bg]} style={{ height: 28 }} />
          <View style={{ backgroundColor: c.bg, paddingHorizontal: PAD, paddingBottom: Math.max(insets.bottom, space.lg) }}>
            <PressableScale
              haptic="medium"
              onPress={save}
              accessibilityRole="button"
              accessibilityLabel={existing ? t.save : t.add}
              style={{
                height: 56,
                borderRadius: radius.pill,
                backgroundColor: palette.lime,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
              }}
            >
              <Icon name={existing ? 'check' : 'plus'} size={20} color={palette.ink} strokeWidth={2.6} />
              <Txt variant="bodyStrong" color={palette.ink} style={{ fontSize: 16 }}>
                {existing ? t.save : t.add}
              </Txt>
            </PressableScale>
          </View>
        </View>
      </View>
    </View>
  );
}
