import { LinearGradient } from 'expo-linear-gradient';
import { useId, type ReactNode } from 'react';
import { useWindowDimensions, View } from 'react-native';
import Animated, {
  Extrapolation,
  FadeInDown,
  interpolate,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  type SharedValue,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Defs, RadialGradient, Rect, Stop } from 'react-native-svg';

import type { Member } from '@/data/types';
import { useT } from '@/i18n';
import { useHour } from '@/state/clock';
import { toggleAvoid, useSettings } from '@/state/store';
import { font, palette, radius, space } from '@/theme/tokens';
import { Card, Icon, Txt, useTheme, type IconName } from '@/ui';
import { alpha, AvoidPicker } from './AvoidPicker';
import { DataCard, Footer, MoneyCard, ResetButton, SectionHead, SettingsCard } from './Cards';
import { FamilyGrid, MemberAvatar } from './Family';
import { strings } from './strings';

const MAX_W = 480;
const PAD = space.lg;
const GAP = space.md;

/** A soft round light: a radial gradient, never a blur filter. */
function Glow({ size, color, opacity }: { size: number; color: string; opacity: number }) {
  const id = `pg${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  return (
    <Svg width={size} height={size} pointerEvents="none">
      <Defs>
        <RadialGradient id={id} cx="50%" cy="50%" rx="50%" ry="50%">
          <Stop offset="0" stopColor={color} stopOpacity={opacity} />
          <Stop offset="0.6" stopColor={color} stopOpacity={opacity * 0.35} />
          <Stop offset="1" stopColor={color} stopOpacity={0} />
        </RadialGradient>
      </Defs>
      <Rect x={0} y={0} width={size} height={size} fill={`url(#${id})`} />
    </Svg>
  );
}

function Layer({ y, speed, style, children }: { y: SharedValue<number>; speed: number; style?: object; children: ReactNode }) {
  const anim = useAnimatedStyle(() => ({ transform: [{ translateY: Math.max(0, y.get()) * speed }] }));
  return (
    <Animated.View pointerEvents="none" style={[{ position: 'absolute' }, style, anim]}>
      {children}
    </Animated.View>
  );
}

function Pill({ icon, children }: { icon: IconName; children: string }) {
  const { c, isDark } = useTheme();
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: radius.pill,
        backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.62)',
        borderWidth: 1,
        borderColor: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(255,255,255,0.9)',
      }}
    >
      <Icon name={icon} size={14} color={c.text} strokeWidth={2.3} />
      <Txt variant="small" color={c.text}>
        {children}
      </Txt>
    </View>
  );
}

/** The owner's round picture: the first letter of the name, or a waving hand. */
function OwnerAvatar({ name, size }: { name?: string; size: number }) {
  const { c } = useTheme();
  const initial = name?.trim().charAt(0).toLocaleUpperCase('hu');
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: palette.lime,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 3,
        borderColor: c.bg,
      }}
    >
      {initial ? (
        <Txt style={{ fontFamily: font.display, fontSize: size * 0.46, lineHeight: size * 0.56, color: palette.ink }}>{initial}</Txt>
      ) : (
        <Txt style={{ fontSize: size * 0.42, lineHeight: size * 0.56 }}>👋</Txt>
      )}
    </View>
  );
}

/** Everyone DaleDay checks for, side by side: the owner, then up to three members. */
function Household({ name, members }: { name?: string; members: Member[] }) {
  const { c } = useTheme();
  const shown = members.slice(0, 3);
  const more = members.length - shown.length;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <OwnerAvatar name={name} size={76} />
      {shown.map((m, i) => (
        <View key={m.id} style={{ marginLeft: -14, zIndex: -i - 1 }}>
          <MemberAvatar member={m} size={46} ring={c.bg} />
        </View>
      ))}
      {more > 0 ? (
        <View
          style={{
            marginLeft: -10,
            width: 34,
            height: 34,
            borderRadius: 17,
            backgroundColor: c.surface,
            borderWidth: 2,
            borderColor: c.bg,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Txt variant="tiny">+{more}</Txt>
        </View>
      ) : null}
    </View>
  );
}

function Hero({ y, height }: { y: SharedValue<number>; height: number }) {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const settings = useSettings();
  const hour = useHour();
  const name = settings.name?.trim();

  const bg = useAnimatedStyle(() => {
    const v = y.get();
    return {
      transform: [{ translateY: v > 0 ? v * 0.5 : v }, { scale: interpolate(v, [-200, 0], [1.35, 1], Extrapolation.CLAMP) }],
    };
  });
  const front = useAnimatedStyle(() => {
    const v = y.get();
    return {
      opacity: interpolate(v, [0, height * 0.55], [1, 0], Extrapolation.CLAMP),
      transform: [{ translateY: v > 0 ? v * 0.3 : 0 }],
    };
  });

  const colors: readonly [string, string, string] = isDark
    ? [alpha(palette.lilac, 0.26), alpha(palette.sky, 0.08), alpha(palette.night, 0)]
    : [alpha(palette.lilac, 0.55), alpha(palette.sky, 0.38), alpha(palette.mint, 0.22)];

  return (
    <View style={{ height, overflow: 'hidden', backgroundColor: c.bg }}>
      <Animated.View style={[{ position: 'absolute', left: 0, right: 0, top: 0, height: height + 40 }, bg]}>
        <LinearGradient colors={colors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ flex: 1 }} />
      </Animated.View>
      <Layer y={y} speed={0.7} style={{ right: -100, top: -80 }}>
        <Glow size={300} color={isDark ? palette.lilac : palette.white} opacity={isDark ? 0.2 : 0.8} />
      </Layer>
      <Layer y={y} speed={0.35} style={{ left: -110, bottom: -70 }}>
        <Glow size={260} color={isDark ? palette.sky : palette.sun} opacity={isDark ? 0.1 : 0.3} />
      </Layer>

      <Animated.View style={[{ paddingTop: insets.top + space.md, paddingHorizontal: PAD, gap: space.md }, front]}>
        <Txt variant="h1">{t.title}</Txt>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg, marginTop: space.xs }}>
          <Household name={name} members={settings.members} />
        </View>
        <View style={{ gap: 2 }}>
          <Txt style={{ fontFamily: font.display, fontSize: 28, lineHeight: 32, letterSpacing: -0.8, color: c.text }} numberOfLines={1}>
            {name ? `${t.greet(hour)}, ${name}!` : `${t.greet(hour)}!`}
          </Txt>
          <Txt variant="body" muted>
            {t.heroSub}
          </Txt>
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
          <Pill icon="shield-check">{t.statAvoid(settings.avoid.length)}</Pill>
          <Pill icon="users">{t.statFamily(settings.members.length)}</Pill>
        </View>
      </Animated.View>
    </View>
  );
}

export function ProfileScreen() {
  const t = useT(strings);
  const { c } = useTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const reduced = useReducedMotion();
  const settings = useSettings();

  const colW = Math.min(width, MAX_W);
  const inner = colW - PAD * 2;
  const heroH = insets.top + 318;

  const y = useSharedValue(0);
  const onScroll = useAnimatedScrollHandler((e) => {
    y.set(e.contentOffset.y);
  });
  const bar = useAnimatedStyle(() => ({
    opacity: interpolate(y.get(), [heroH - 150, heroH - 100], [0, 1], Extrapolation.CLAMP),
  }));

  const enter = (delay: number) => (reduced ? undefined : FadeInDown.delay(delay).springify().damping(18));

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <View style={{ flex: 1, width: '100%', maxWidth: MAX_W, alignSelf: 'center' }}>
        <Animated.ScrollView
          onScroll={onScroll}
          scrollEventThrottle={16}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingBottom: 130 }}
        >
          <Hero y={y} height={heroH} />
          <View
            style={{
              marginTop: -28,
              borderTopLeftRadius: 28,
              borderTopRightRadius: 28,
              backgroundColor: c.bg,
              paddingTop: space.xl,
              paddingHorizontal: PAD,
              gap: space.xxl,
            }}
          >
            <Animated.View entering={enter(60)}>
              <SectionHead title={t.avoidTitle} sub={t.avoidSub} />
              <Card>
                <AvoidPicker selected={settings.avoid} onToggle={toggleAvoid} order={['diet', 'planet', 'additive', 'allergy']} />
              </Card>
            </Animated.View>

            <View>
              <SectionHead title={t.familyTitle} sub={settings.members.length > 0 ? t.familySub : undefined} />
              <FamilyGrid members={settings.members} inner={inner} gap={GAP} reduced={reduced} />
            </View>

            <View>
              <SectionHead title={t.settingsTitle} />
              <SettingsCard />
            </View>

            <MoneyCard />
            <DataCard />
            <ResetButton />
            <Footer />
          </View>
        </Animated.ScrollView>

        {/* The compact bar that takes over once the hero has scrolled away. */}
        <Animated.View
          pointerEvents="none"
          style={[
            {
              position: 'absolute',
              left: 0,
              right: 0,
              top: 0,
              paddingTop: insets.top,
              height: insets.top + 52,
              backgroundColor: c.bg,
              borderBottomWidth: 1,
              borderBottomColor: c.border,
              alignItems: 'center',
              justifyContent: 'center',
            },
            bar,
          ]}
        >
          <Txt variant="h3">{t.title}</Txt>
        </Animated.View>
      </View>
    </View>
  );
}
