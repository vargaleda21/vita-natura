import { router } from 'expo-router';
import { useEffect, useRef, useState, type ComponentRef, type ReactNode, type Ref } from 'react';
import { TextInput, View } from 'react-native';
import Animated, { FadeIn, useAnimatedStyle, useSharedValue, withSequence, withTiming } from 'react-native-reanimated';

import { demoHistory } from '@/data/demo';
import type { Lang, ThemePref } from '@/data/types';
import { useT } from '@/i18n';
import { replaceHistory, resetAll, updateSettings, useSettings } from '@/state/store';
import { font, palette, radius, space } from '@/theme/tokens';
import { Card, Icon, PressableScale, Txt, useTheme, type IconName } from '@/ui';
import { alpha } from './AvoidPicker';
import { Segmented, type SegmentOption } from './Segmented';
import { strings } from './strings';

export function SectionHead({ title, sub, right }: { title: string; sub?: string; right?: ReactNode }) {
  return (
    <View style={{ gap: 2, marginBottom: space.md, marginTop: space.sm }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Txt variant="h2">{title}</Txt>
        {right}
      </View>
      {sub ? (
        <Txt variant="small" muted>
          {sub}
        </Txt>
      ) : null}
    </View>
  );
}

/** A text field that wears the theme and shows its focus with a border, not a browser ring. */
export function Field({ value, onChangeText, placeholder, label, onBlur, maxLength = 30, inputRef, autoCapitalize = 'words', returnKeyType = 'done' }: {
  value: string;
  onChangeText: (v: string) => void;
  placeholder: string;
  label: string;
  onBlur?: () => void;
  maxLength?: number;
  inputRef?: Ref<ComponentRef<typeof TextInput>>;
  autoCapitalize?: 'none' | 'sentences' | 'words';
  returnKeyType?: 'done' | 'search';
}) {
  const { c, isDark } = useTheme();
  const [focus, setFocus] = useState(false);
  return (
    <TextInput
      ref={inputRef}
      value={value}
      onChangeText={onChangeText}
      placeholder={placeholder}
      placeholderTextColor={c.textFaint}
      accessibilityLabel={label}
      maxLength={maxLength}
      autoCapitalize={autoCapitalize}
      autoCorrect={false}
      returnKeyType={returnKeyType}
      onFocus={() => setFocus(true)}
      onBlur={() => {
        setFocus(false);
        onBlur?.();
      }}
      style={{
        height: 50,
        borderRadius: radius.md,
        paddingHorizontal: 14,
        // 16 px or more, so Safari on the iPhone does not zoom in on focus.
        fontSize: 16,
        fontFamily: font.bodyMedium,
        color: c.text,
        backgroundColor: isDark ? palette.night : c.bgAlt,
        borderWidth: 1.5,
        borderColor: focus ? (isDark ? palette.lime : palette.forest) : c.border,
        outlineWidth: 0,
      }}
    />
  );
}

function Label({ icon, children, right }: { icon: IconName; children: string; right?: ReactNode }) {
  const { c } = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: space.sm }}>
      <Icon name={icon} size={16} color={c.textMuted} strokeWidth={2.2} />
      <Txt variant="bodyStrong" style={{ flex: 1 }}>
        {children}
      </Txt>
      {right}
    </View>
  );
}

/** Sun and moon together: the "auto" theme. */
function AutoGlyph({ color }: { color: string }) {
  return (
    <View style={{ width: 20, height: 20 }}>
      <View style={{ position: 'absolute', left: 0, top: 0 }}>
        <Icon name="sun" size={14} color={color} strokeWidth={2.3} />
      </View>
      <View style={{ position: 'absolute', right: 0, bottom: 0 }}>
        <Icon name="moon" size={12} color={color} strokeWidth={2.3} />
      </View>
    </View>
  );
}

export function SettingsCard() {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const settings = useSettings();
  const [name, setName] = useState(settings.name ?? '');
  // A reset elsewhere clears the name; follow it.
  const [savedName, setSavedName] = useState(settings.name);
  if (savedName !== settings.name) {
    setSavedName(settings.name);
    setName(settings.name ?? '');
  }

  const accent = (active: boolean) => (active ? (isDark ? palette.lime : palette.forest) : c.textMuted);
  const themeOptions: SegmentOption<ThemePref>[] = [
    { value: 'auto', label: t.theme.auto.label, icon: (a) => <AutoGlyph color={accent(a)} /> },
    { value: 'light', label: t.theme.light.label, icon: (a) => <Icon name="sun" size={18} color={accent(a)} strokeWidth={2.2} /> },
    { value: 'dark', label: t.theme.dark.label, icon: (a) => <Icon name="moon" size={18} color={accent(a)} strokeWidth={2.2} /> },
    { value: 'system', label: t.theme.system.label, icon: (a) => <Icon name="settings" size={18} color={accent(a)} strokeWidth={2.2} /> },
  ];
  const langOptions: SegmentOption<Lang>[] = [
    { value: 'hu', label: 'Magyar' },
    { value: 'en', label: 'English' },
  ];
  const follows = settings.theme === 'auto' || settings.theme === 'system';

  return (
    <Card style={{ gap: space.xl }}>
      <View>
        <Label icon="user-round">{t.nameLabel}</Label>
        <Field
          value={name}
          label={t.nameLabel}
          placeholder={t.namePlaceholder}
          onChangeText={(v) => {
            setName(v);
            updateSettings({ name: v.trim() ? v : undefined });
          }}
          onBlur={() => updateSettings({ name: name.trim() || undefined })}
        />
      </View>
      <View>
        <Label icon="languages">{t.langLabel}</Label>
        <Segmented options={langOptions} value={settings.lang} onChange={(lang) => updateSettings({ lang })} label={t.langLabel} />
      </View>
      <View>
        <Label
          icon="palette"
          right={
            follows ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 2, borderRadius: radius.pill, backgroundColor: c.border }}>
                <Icon name={isDark ? 'moon' : 'sun'} size={12} color={c.textMuted} strokeWidth={2.4} />
                <Txt variant="tiny" muted>
                  {t.themeNow(isDark)}
                </Txt>
              </View>
            ) : null
          }
        >
          {t.themeLabel}
        </Label>
        <Segmented options={themeOptions} value={settings.theme} onChange={(theme) => updateSettings({ theme })} tall label={t.themeLabel} />
        <Animated.View key={settings.theme} entering={FadeIn.duration(220)}>
          <Txt variant="small" muted style={{ marginTop: space.sm, textAlign: 'center' }}>
            {t.theme[settings.theme].sub}
          </Txt>
        </Animated.View>
      </View>
    </Card>
  );
}

function Row({ icon, title, body, tile }: { icon: IconName; title: string; body: string; tile: string }) {
  const { c } = useTheme();
  return (
    <View style={{ flexDirection: 'row', gap: space.md }}>
      <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: tile, alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={icon} size={18} color={c.text} strokeWidth={2.1} />
      </View>
      <View style={{ flex: 1, gap: 2 }}>
        <Txt variant="bodyStrong">{title}</Txt>
        <Txt variant="small" muted>
          {body}
        </Txt>
      </View>
    </View>
  );
}

export function MoneyCard() {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  return (
    <Card
      gradient={isDark ? [alpha(palette.sun, 0.14), alpha(palette.tangerine, 0.06)] : [alpha(palette.sun, 0.34), alpha(palette.tangerine, 0.14)]}
      style={{ borderWidth: 1, borderColor: isDark ? alpha(palette.sun, 0.18) : alpha(palette.sun, 0.5) }}
    >
      <View style={{ padding: space.xs, gap: space.lg }}>
        <View style={{ gap: space.sm }}>
          <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: palette.ink, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="badge-percent" size={22} color={palette.sun} strokeWidth={2.2} />
          </View>
          <Txt variant="h2">{t.moneyTitle}</Txt>
          <Txt variant="body" style={{ fontFamily: font.bodySemi }}>
            {t.moneyLead}
          </Txt>
        </View>
        {t.money.map((r) => (
          <Row key={r.title} icon={r.icon} title={r.title} body={r.body} tile={isDark ? c.surfaceAlt : 'rgba(255,255,255,0.7)'} />
        ))}
      </View>
    </Card>
  );
}

export function DataCard() {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  return (
    <Card style={{ gap: space.lg }}>
      <Txt variant="h2">{t.dataTitle}</Txt>
      {t.data.map((r) => (
        <Row key={r.title} icon={r.icon} title={r.title} body={r.body} tile={alpha(palette.lilac, isDark ? 0.18 : 0.28)} />
      ))}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 8,
          padding: space.md,
          borderRadius: radius.md,
          backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
        }}
      >
        <Icon name="circle-alert" size={16} color={c.textMuted} strokeWidth={2.2} />
        <Txt variant="small" muted style={{ flex: 1 }}>
          {t.dataDemo}
        </Txt>
      </View>
    </Card>
  );
}

/** Two taps: the first asks, the second resets everything and starts the tour again. */
export function ResetButton() {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const [armed, setArmed] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const shake = useSharedValue(0);
  const anim = useAnimatedStyle(() => ({ transform: [{ translateX: shake.get() }] }));
  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  const onPress = () => {
    if (!armed) {
      setArmed(true);
      shake.set(withSequence(withTiming(-5, { duration: 50 }), withTiming(5, { duration: 70 }), withTiming(-3, { duration: 60 }), withTiming(0, { duration: 50 })));
      timer.current = setTimeout(() => setArmed(false), 3500);
      return;
    }
    if (timer.current) clearTimeout(timer.current);
    resetAll();
    // A restarted demo looks like a first visit: a believable past included.
    replaceHistory(demoHistory());
    router.replace('/onboarding');
  };

  return (
    <Animated.View style={anim}>
      <PressableScale
        haptic="medium"
        onPress={onPress}
        accessibilityRole="button"
        accessibilityLabel={armed ? t.resetConfirm : t.resetTitle}
        accessibilityHint={t.resetSub}
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: space.md,
          padding: space.lg,
          borderRadius: radius.lg,
          backgroundColor: armed ? palette.coral : c.surface,
          borderWidth: 1,
          borderColor: armed ? palette.coral : c.border,
        }}
      >
        <View
          style={{
            width: 40,
            height: 40,
            borderRadius: 20,
            backgroundColor: armed ? 'rgba(16,35,28,0.14)' : alpha(palette.coral, isDark ? 0.16 : 0.14),
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name="refresh-cw" size={19} color={armed ? palette.ink : palette.coral} strokeWidth={2.3} />
        </View>
        <View style={{ flex: 1 }}>
          <Txt variant="bodyStrong" color={armed ? palette.ink : c.text}>
            {armed ? t.resetConfirm : t.resetTitle}
          </Txt>
          <Txt variant="small" color={armed ? palette.ink : c.textMuted} style={{ opacity: armed ? 0.8 : 1 }}>
            {t.resetSub}
          </Txt>
        </View>
      </PressableScale>
    </Animated.View>
  );
}

export function Footer() {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  return (
    <View style={{ alignItems: 'center', gap: 4, paddingTop: space.lg }}>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 3 }}>
        <Txt style={{ fontFamily: font.display, fontSize: 26, lineHeight: 28, letterSpacing: -1, color: c.text }}>DaleDay</Txt>
        <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: isDark ? palette.lime : palette.limeDeep, marginBottom: 6 }} />
      </View>
      <Txt variant="small" faint>
        {t.version}
      </Txt>
      <Txt variant="small" muted>
        {t.tagline}
      </Txt>
    </View>
  );
}
