import { useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  Easing,
  interpolate,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withDelay,
  withRepeat,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';

import { Glow } from '@/features/brand';
import { useHour } from '@/state/clock';
import { palette } from '@/theme/tokens';
import { useTheme } from '@/ui';

export type Phase = 'morning' | 'day' | 'evening' | 'night';

export function phaseOf(hour: number): Phase {
  if (hour >= 5 && hour < 10) return 'morning';
  if (hour >= 10 && hour < 17) return 'day';
  if (hour >= 17 && hour < 21) return 'evening';
  return 'night';
}

/** One drifting light: its colour and opacity in the light theme, then in the dark theme. */
type Light = { light: [string, number]; dark: [string, number] };
const L = (color: string, light: number, dark: number): Light => ({ light: [color, light], dark: [color, dark] });

const PALETTES: Record<Phase, Light[]> = {
  // Golden morning: sun and a lime sprout.
  morning: [L(palette.sun, 0.75, 0.24), L(palette.lime, 0.75, 0.2), L(palette.tangerine, 0.32, 0.16), L(palette.lime, 0.5, 0.18)],
  // Bright day: lime, mint and sky.
  day: [L(palette.lime, 0.8, 0.22), L(palette.sky, 0.55, 0.18), L(palette.mint, 0.6, 0.2), L(palette.lime, 0.45, 0.18)],
  // Golden hour: tangerine and lilac.
  evening: [L(palette.tangerine, 0.5, 0.26), L(palette.lilac, 0.62, 0.28), L(palette.sun, 0.5, 0.16), L(palette.lime, 0.35, 0.14)],
  // Night: deep forest with lime glints (a cool moonlight if someone keeps the light theme at night).
  night: [
    { light: [palette.sky, 0.45], dark: [palette.forest, 0.95] },
    { light: [palette.lilac, 0.42], dark: [palette.mint, 0.14] },
    { light: [palette.mint, 0.45], dark: [palette.forest, 0.8] },
    L(palette.lime, 0.4, 0.3),
  ],
};

/** Where each light sits (fractions of the width) and how it drifts. */
const SPOTS = [
  { x: -0.35, y: -0.45, s: 1.15, dx: 26, dy: 18, ms: 11000 },
  { x: 0.35, y: -0.4, s: 1.05, dx: -22, dy: 24, ms: 13000 },
  { x: -0.05, y: 0.25, s: 0.95, dx: 30, dy: -16, ms: 15000 },
  { x: 0.55, y: 0.2, s: 0.42, dx: -18, dy: 14, ms: 9000 },
];

function Spot({ i, width, light }: { i: number; width: number; light: Light }) {
  const { isDark } = useTheme();
  const reduced = useReducedMotion();
  const spot = SPOTS[i];
  const t = useSharedValue(0);
  useEffect(() => {
    if (reduced) return;
    t.set(withDelay(i * 700, withRepeat(withTiming(1, { duration: spot.ms, easing: Easing.inOut(Easing.sin) }), -1, true)));
  }, [reduced, i, spot.ms, t]);
  const anim = useAnimatedStyle(() => {
    const v = t.get();
    return { transform: [{ translateX: (v - 0.5) * 2 * spot.dx }, { translateY: (v - 0.5) * 2 * spot.dy }, { scale: 1 + v * 0.06 }] };
  });
  const size = spot.s * width;
  const [color, opacity] = isDark ? light.dark : light.light;
  return (
    <Animated.View style={[{ position: 'absolute', left: spot.x * width, top: spot.y * width }, anim]}>
      <Glow width={size} color={color} opacity={opacity} />
    </Animated.View>
  );
}

/**
 * The home hero's sky: soft radial lights that drift slowly and follow the time of day.
 * It scrolls at half the content's speed and stretches a little when pulled down.
 */
export function Aurora({ width, scrollY }: { width: number; scrollY: SharedValue<number> }) {
  // Tall enough that every light fades out before the edge: no hard line where it is clipped.
  const height = width * 1.32;
  const phase = phaseOf(useHour());
  const lights = PALETTES[phase];
  const parallax = useAnimatedStyle(() => {
    const y = scrollY.get();
    return {
      opacity: interpolate(y, [0, height * 0.6], [1, 0.25], 'clamp'),
      transform: [{ translateY: y > 0 ? y * 0.5 : y }, { scale: y < 0 ? 1 + -y / 500 : 1 }],
    };
  });
  return (
    <Animated.View pointerEvents="none" style={[{ position: 'absolute', left: 0, top: 0, width, height }, parallax]}>
      <View style={[StyleSheet.absoluteFill, { overflow: 'hidden' }]}>
        {lights.map((l, i) => (
          <Spot key={`${phase}-${i}`} i={i} width={width} light={l} />
        ))}
      </View>
    </Animated.View>
  );
}
