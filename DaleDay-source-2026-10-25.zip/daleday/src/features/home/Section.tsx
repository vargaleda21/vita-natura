import type { ReactNode } from 'react';
import { View } from 'react-native';

import { space } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';

/** A section title with an optional link on the right. */
export function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const { c } = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: space.md }}>
      <Txt variant="h2" accessibilityRole="header" style={{ flexShrink: 1 }}>
        {title}
      </Txt>
      {action && onAction ? (
        <PressableScale
          accessibilityRole="link"
          onPress={onAction}
          hitSlop={10}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 2, minHeight: 44, paddingLeft: space.sm }}
        >
          <Txt variant="small" muted>
            {action}
          </Txt>
          <Icon name="chevron-right" size={16} color={c.textMuted} />
        </PressableScale>
      ) : null}
    </View>
  );
}

export function Section({ children, style }: { children: ReactNode; style?: object }) {
  return <View style={[{ marginTop: space.xxxl - 4 }, style]}>{children}</View>;
}
