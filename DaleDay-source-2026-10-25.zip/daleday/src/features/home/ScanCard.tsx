import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useEffect } from 'react';
import { View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import Svg, { Rect } from 'react-native-svg';

import { Glow } from '@/features/brand';
import { useT } from '@/i18n';
import { palette, radius, shadow, space } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { strings } from './strings';

const BOX = 116;
// A made-up barcode: [x, width] in a 100-wide box.
const CODE: [number, number][] = [
  [4, 3], [9, 1.5], [12.5, 4], [19, 1.5], [22.5, 2.5], [27, 5], [34, 1.5], [37.5, 3], [43, 1.5], [46.5, 4.5],
  [53, 1.5], [56.5, 3], [61.5, 1.5], [65, 5], [72, 2], [76, 1.5], [79.5, 4], [86, 1.5], [89.5, 3], [94.5, 1.5],
];

function Bracket({ corner }: { corner: 'tl' | 'tr' | 'bl' | 'br' }) {
  const s = 22;
  const w = 3.5;
  const top = corner[0] === 't';
  const left = corner[1] === 'l';
  return (
    <View
      style={{
        position: 'absolute',
        width: s,
        height: s,
        [top ? 'top' : 'bottom']: 0,
        [left ? 'left' : 'right']: 0,
        borderColor: palette.lime,
        borderTopWidth: top ? w : 0,
        borderBottomWidth: top ? 0 : w,
        borderLeftWidth: left ? w : 0,
        borderRightWidth: left ? 0 : w,
        borderTopLeftRadius: top && left ? 12 : 0,
        borderTopRightRadius: top && !left ? 12 : 0,
        borderBottomLeftRadius: !top && left ? 12 : 0,
        borderBottomRightRadius: !top && !left ? 12 : 0,
      }}
    />
  );
}

/** A tiny viewfinder: a barcode and a lime laser sweeping over it. */
function Viewfinder() {
  const reduced = useReducedMotion();
  const t = useSharedValue(0.5);
  const beep = useSharedValue(0);
  useEffect(() => {
    if (reduced) return;
    t.set(0);
    t.set(withRepeat(withTiming(1, { duration: 1500, easing: Easing.inOut(Easing.quad) }), -1, true));
    beep.set(
      withRepeat(withSequence(withTiming(0, { duration: 2400 }), withTiming(1, { duration: 120 }), withTiming(0, { duration: 500 })), -1),
    );
  }, [reduced, t, beep]);
  const laser = useAnimatedStyle(() => ({ transform: [{ translateY: 18 + t.get() * (BOX - 36) }] }));
  const flash = useAnimatedStyle(() => ({ opacity: beep.get() * 0.5 }));
  return (
    <View style={{ width: BOX, height: BOX }}>
      <View style={{ position: 'absolute', left: 14, right: 14, top: 26, bottom: 26, borderRadius: 8, backgroundColor: palette.oat, overflow: 'hidden', padding: 6 }}>
        <Svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
          {CODE.map(([x, w]) => (
            <Rect key={x} x={x} y={0} width={w} height={100} fill={palette.ink} />
          ))}
        </Svg>
        <Animated.View style={[{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, backgroundColor: palette.lime }, flash]} />
      </View>
      <Bracket corner="tl" />
      <Bracket corner="tr" />
      <Bracket corner="bl" />
      <Bracket corner="br" />
      <Animated.View style={[{ position: 'absolute', left: 6, right: 6, top: -9, height: 20 }, laser]}>
        <LinearGradient
          colors={['rgba(198,243,107,0)', 'rgba(198,243,107,0.45)', 'rgba(198,243,107,0)']}
          style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 }}
        />
        <View style={{ position: 'absolute', left: 0, right: 0, top: 8.5, height: 3, borderRadius: 2, backgroundColor: palette.lime }} />
      </Animated.View>
    </View>
  );
}

/** The giant "scan now" card. */
export function ScanCard() {
  const t = useT(strings);
  const { isDark } = useTheme();
  return (
    <PressableScale
      haptic="medium"
      scaleTo={0.97}
      accessibilityRole="button"
      accessibilityLabel={t.scanA11y}
      onPress={() => router.push('/scan')}
      style={[{ borderRadius: radius.xl }, isDark ? null : shadow.float]}
    >
      <View
        style={{
          borderRadius: radius.xl,
          overflow: 'hidden',
          backgroundColor: palette.ink,
          borderWidth: 1,
          borderColor: isDark ? 'rgba(198,243,107,0.18)' : 'rgba(255,255,255,0.06)',
        }}
      >
        <LinearGradient colors={['#1D4636', palette.ink]} start={{ x: 0, y: 0 }} end={{ x: 0.8, y: 1 }} style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 }} />
        <Glow width={260} color={palette.lime} opacity={0.22} style={{ position: 'absolute', right: -90, top: -110 }} />
        <LinearGradient
          colors={['rgba(255,255,255,0.09)', 'rgba(255,255,255,0)']}
          style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 60 }}
        />
        <View style={{ flexDirection: 'row', alignItems: 'center', padding: space.xl, paddingRight: space.lg, gap: space.md }}>
          <View style={{ flex: 1 }}>
            <Txt variant="tiny" upper color={palette.lime}>
              {t.scanKicker}
            </Txt>
            <Txt variant="h2" color={palette.oat} style={{ marginTop: 6 }}>
              {t.scanTitle}
            </Txt>
            <Txt variant="small" color="rgba(247,244,236,0.7)" style={{ marginTop: 6 }}>
              {t.scanBody}
            </Txt>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                alignSelf: 'flex-start',
                gap: 8,
                marginTop: space.lg,
                height: 44,
                paddingLeft: 6,
                paddingRight: 16,
                borderRadius: radius.pill,
                backgroundColor: palette.lime,
              }}
            >
              <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: palette.ink, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="scan-barcode" size={17} color={palette.lime} strokeWidth={2.2} />
              </View>
              <Txt variant="bodyStrong" color={palette.ink} numberOfLines={1} style={{ flexShrink: 0 }}>
                {t.scanCta}
              </Txt>
            </View>
          </View>
          <Viewfinder />
        </View>
      </View>
    </PressableScale>
  );
}
