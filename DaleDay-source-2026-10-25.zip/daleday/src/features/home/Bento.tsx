import { LinearGradient } from 'expo-linear-gradient';
import { useEffect } from 'react';
import { View } from 'react-native';
import Animated, { useAnimatedStyle, useReducedMotion, useSharedValue, withDelay, withSpring } from 'react-native-reanimated';
import Svg, { Circle } from 'react-native-svg';

import type { Insights } from '@/data/types';
import { formatHuf, useLang, useT } from '@/i18n';
import { font, gradients, palette, radius, shadow, space, springs } from '@/theme/tokens';
import { Icon, Txt, useTheme } from '@/ui';
import { strings } from './strings';
import { useCountUp } from './useCountUp';

const GAP = 10;
const BAR_H = 46;

function WeekBar({ value, max, i, today }: { value: number; max: number; i: number; today: boolean }) {
  const reduced = useReducedMotion();
  const p = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    if (!reduced) p.set(withDelay(350 + i * 70, withSpring(1, springs.bouncy)));
  }, [reduced, i, p]);
  const h = Math.max(6, (value / Math.max(max, 1)) * BAR_H);
  const anim = useAnimatedStyle(() => {
    const v = p.get();
    return { transform: [{ translateY: (h / 2) * (1 - v) }, { scaleY: Math.max(v, 0.001) }] };
  });
  return (
    <Animated.View
      style={[{ width: 12, height: h, borderRadius: 6, backgroundColor: palette.ink, opacity: today ? 1 : 0.28 }, anim]}
    />
  );
}

function Tile({ children, gradient, style }: { children: React.ReactNode; gradient?: readonly [string, string, ...string[]]; style?: object }) {
  const { c, isDark } = useTheme();
  const base = {
    borderRadius: radius.lg,
    overflow: 'hidden' as const,
    backgroundColor: gradient ? undefined : c.surface,
    borderWidth: isDark && !gradient ? 1 : 0,
    borderColor: c.border,
  };
  return (
    <View style={[{ borderRadius: radius.lg }, isDark ? null : shadow.card, style]}>
      <View style={[base, { flex: 1 }]}>
        {gradient ? (
          <LinearGradient colors={gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 }} />
        ) : null}
        <LinearGradient
          colors={['rgba(255,255,255,0.35)', 'rgba(255,255,255,0)']}
          style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 40, opacity: gradient ? 1 : 0 }}
        />
        <View style={{ flex: 1, padding: space.lg }}>{children}</View>
      </View>
    </View>
  );
}

function Ring({ share, size = 92 }: { share: number; size?: number }) {
  const { c, isDark } = useTheme();
  const shown = useCountUp(share, 1300, 300);
  const stroke = 11;
  const r = (size - stroke) / 2;
  const len = 2 * Math.PI * r;
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={{ position: 'absolute', transform: [{ rotate: '-90deg' }] }}>
        <Circle cx={size / 2} cy={size / 2} r={r} stroke={isDark ? c.surfaceAlt : palette.oat2} strokeWidth={stroke} fill="none" />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={isDark ? palette.lime : palette.limeDeep}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${len} ${len}`}
          strokeDashoffset={len * (1 - Math.max(0.001, shown))}
        />
      </Svg>
      <Txt variant="h3" style={{ fontFamily: font.display, fontSize: 22 }}>
        {Math.round(shown * 100)}%
      </Txt>
      <View style={{ position: 'absolute', top: 6, right: 6 }}>
        <Icon name="tree-palm" size={14} color={c.textFaint} />
      </View>
    </View>
  );
}

type Props = { all: Insights; month: Insights };

/** The month at a glance: streak, swaps, money saved and the palm-oil-free share. Numbers count up. */
export function Bento({ all, month }: Props) {
  const t = useT(strings);
  const lang = useLang();
  const streak = useCountUp(all.streakDays, 900);
  const swaps = useCountUp(month.swaps, 1000, 120);
  const saved = useCountUp(month.savedHuf, 1300, 200);
  const maxDay = Math.max(...all.weekly, 1);
  const today = new Date();
  const letters = all.weekly.map((_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() - (all.weekly.length - 1 - i));
    return t.days[d.getDay()];
  });
  const pct = Math.round(month.palmFreeShare * 100);

  return (
    <View style={{ gap: GAP }}>
      <View style={{ flexDirection: 'row', gap: GAP }}>
        <Tile gradient={gradients.sprout} style={{ flex: 1, minHeight: 236 }}>
          <View style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: palette.ink, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="flame" size={19} color={palette.sun} strokeWidth={2.4} />
          </View>
          <Txt style={{ fontFamily: font.display, fontSize: 64, lineHeight: 64, letterSpacing: -2.5, marginTop: space.md }} color={palette.ink}>
            {Math.round(streak)}
          </Txt>
          <Txt variant="bodyStrong" color={palette.ink}>
            {t.streak}
          </Txt>
          <View style={{ flex: 1 }} />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: space.md, marginHorizontal: -4 }}>
            {all.weekly.map((v, i) => {
              const today = i === all.weekly.length - 1;
              return (
                <View key={i} style={{ width: 20, alignItems: 'center' }}>
                  <View style={{ height: BAR_H, justifyContent: 'flex-end' }}>
                    <WeekBar value={v} max={maxDay} i={i} today={today} />
                  </View>
                  <Txt variant="tiny" color={palette.ink} style={{ marginTop: 6, letterSpacing: 0, opacity: today ? 1 : 0.55 }}>
                    {letters[i]}
                  </Txt>
                </View>
              );
            })}
          </View>
        </Tile>

        <View style={{ flex: 1, gap: GAP }}>
          <Tile style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <Txt style={{ fontFamily: font.display, fontSize: 38, lineHeight: 40, letterSpacing: -1.2 }}>{Math.round(swaps)}</Txt>
              <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: palette.lilac, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="arrow-left-right" size={17} color={palette.ink} />
              </View>
            </View>
            <Txt variant="small" muted style={{ marginTop: 4 }}>
              {t.swaps}
            </Txt>
          </Tile>
          <Tile gradient={gradients.sunrise} style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 4 }}>
              <Txt
                numberOfLines={1}
                adjustsFontSizeToFit
                style={{ fontFamily: font.display, fontSize: 28, lineHeight: 34, letterSpacing: -1, flexShrink: 1 }}
                color={palette.ink}
              >
                {formatHuf(saved, lang)}
              </Txt>
            </View>
            <Txt variant="small" color="rgba(16,35,28,0.72)" style={{ marginTop: 4 }}>
              {t.saved}
            </Txt>
          </Tile>
        </View>
      </View>

      <Tile>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg }}>
          <Ring share={month.palmFreeShare} />
          <View style={{ flex: 1 }}>
            <Txt variant="h3">{t.palmTitle}</Txt>
            <Txt variant="small" muted style={{ marginTop: 4 }}>
              {t.palmBody(pct)}
            </Txt>
          </View>
        </View>
      </Tile>
    </View>
  );
}
