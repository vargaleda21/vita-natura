import { router } from 'expo-router';
import { useState } from 'react';
import { useWindowDimensions, View } from 'react-native';
import Animated, {
  interpolate,
  useAnimatedReaction,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useSharedValue,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { scheduleOnRN } from 'react-native-worklets';

import { insights } from '@/data/api';
import type { ScanEntry } from '@/data/types';
import { Logo, Wordmark } from '@/features/brand';
import { useLang, useT } from '@/i18n';
import { useHour } from '@/state/clock';
import { useHistory, useSettings } from '@/state/store';
import { palette, radius, space } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { Aurora, phaseOf } from './Aurora';
import { Bento } from './Bento';
import { RecentScans } from './RecentScans';
import { ScanCard } from './ScanCard';
import { Section, SectionHeader } from './Section';
import { strings } from './strings';
import { WatchList } from './WatchList';
import { WhatsNew } from './WhatsNew';

const PAD = space.xl;
/** Where the compact header has fully faded in. */
const HEADER_AT = 190;

function inThisMonth(e: ScanEntry): boolean {
  const d = new Date(e.at);
  const now = new Date();
  return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
}

function todayLabel(lang: 'hu' | 'en'): string {
  const s = new Intl.DateTimeFormat(lang === 'hu' ? 'hu-HU' : 'en-GB', { weekday: 'long', month: 'long', day: 'numeric' }).format(new Date());
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** The app-icon tile; in the dark it gets a faint lime edge so it does not sink into the background. */
function Badge({ size }: { size: number }) {
  const { isDark } = useTheme();
  return (
    <View style={{ borderRadius: size * 0.28, borderWidth: isDark ? 1 : 0, borderColor: 'rgba(198,243,107,0.3)' }}>
      <Logo size={size} tone="lime" badge />
    </View>
  );
}

function ScanButton({ label }: { label: string }) {
  return (
    <PressableScale
      haptic="medium"
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={() => router.push('/scan')}
      style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: palette.lime, alignItems: 'center', justifyContent: 'center' }}
    >
      <Icon name="scan-barcode" size={20} color={palette.ink} strokeWidth={2.2} />
    </PressableScale>
  );
}

export function HomeScreen() {
  const t = useT(strings);
  const lang = useLang();
  const { c, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const win = useWindowDimensions();
  const colW = Math.min(win.width, 480);
  const settings = useSettings();
  const history = useHistory();
  const hour = useHour();
  const night = phaseOf(hour) === 'night' || phaseOf(hour) === 'evening';

  const scrollY = useSharedValue(0);
  const onScroll = useAnimatedScrollHandler({
    onScroll: (e) => {
      scrollY.set(e.contentOffset.y);
    },
  });
  const [compact, setCompact] = useState(false);
  useAnimatedReaction(
    () => scrollY.get() > HEADER_AT - 30,
    (now, before) => {
      if (now !== before) scheduleOnRN(setCompact, now);
    },
  );

  const all = insights(history, settings);
  const month = insights(history.filter(inThisMonth), settings);
  const greet = `${t.greeting(hour)}${settings.name ? `, ${settings.name}` : ''}!`;

  // The hero text drifts up a little faster than the page and fades: a second parallax speed.
  const heroText = useAnimatedStyle(() => {
    const y = scrollY.get();
    return {
      opacity: interpolate(y, [0, 170], [1, 0], 'clamp'),
      transform: [{ translateY: interpolate(y, [-100, 0, 200], [30, 0, -36]) }],
    };
  });
  const header = useAnimatedStyle(() => {
    const y = scrollY.get();
    return {
      opacity: interpolate(y, [HEADER_AT - 50, HEADER_AT], [0, 1], 'clamp'),
      transform: [{ translateY: interpolate(y, [HEADER_AT - 50, HEADER_AT], [-10, 0], 'clamp') }],
    };
  });

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <Animated.ScrollView
        onScroll={onScroll}
        scrollEventThrottle={16}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ alignItems: 'center', paddingBottom: insets.bottom + 132 }}
      >
        <Aurora width={win.width} scrollY={scrollY} />
        <View style={{ width: colW }}>
          <View style={{ paddingTop: insets.top + 12, paddingHorizontal: PAD }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', height: 44 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }} accessibilityRole="header" accessibilityLabel="DaleDay">
                <Badge size={34} />
                <Wordmark size={30} color={c.text} />
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 6,
                  height: 32,
                  paddingHorizontal: 12,
                  borderRadius: radius.pill,
                  backgroundColor: isDark ? 'rgba(255,255,255,0.07)' : 'rgba(255,255,255,0.6)',
                  borderWidth: 1,
                  borderColor: c.border,
                }}
              >
                <Icon name={night ? 'moon' : 'sun'} size={14} color={c.textMuted} />
                <Txt variant="small" muted>
                  {todayLabel(lang)}
                </Txt>
              </View>
            </View>

            <Animated.View style={[{ marginTop: space.xxl }, heroText]}>
              <Txt variant="h3" muted>
                {greet}
              </Txt>
              <Txt variant="hero" accessibilityRole="header" style={{ marginTop: 6, fontSize: 42, lineHeight: 44 }}>
                {t.headlineA}
                <Txt variant="hero" color={isDark ? palette.lime : palette.forest} style={{ fontSize: 42, lineHeight: 44 }}>
                  {t.headlineB}
                </Txt>
              </Txt>
            </Animated.View>
          </View>

          <View style={{ paddingHorizontal: PAD, marginTop: space.xxl }}>
            <ScanCard />
          </View>

          <Section style={{ paddingHorizontal: PAD }}>
            <SectionHeader title={t.watchTitle} action={t.edit} onAction={() => router.push('/(tabs)/profile')} />
            <WatchList />
          </Section>

          <Section style={{ paddingHorizontal: PAD }}>
            <SectionHeader title={t.bentoTitle} action={t.all} onAction={() => router.push('/(tabs)/insights')} />
            <Bento all={all} month={month} />
          </Section>

          <Section>
            <View style={{ paddingHorizontal: PAD }}>
              <SectionHeader title={t.recentTitle} />
            </View>
            <RecentScans padding={PAD} />
          </Section>

          <Section>
            <View style={{ paddingHorizontal: PAD }}>
              <SectionHeader title={t.newTitle} />
            </View>
            <WhatsNew padding={PAD} />
          </Section>
        </View>
      </Animated.ScrollView>

      <Animated.View
        pointerEvents={compact ? 'auto' : 'none'}
        style={[
          {
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            paddingTop: insets.top,
            backgroundColor: c.bg,
            borderBottomWidth: 1,
            borderBottomColor: c.border,
            alignItems: 'center',
          },
          header,
        ]}
      >
        <View style={{ width: colW, height: 58, paddingHorizontal: PAD, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Badge size={30} />
            <Wordmark size={26} color={c.text} />
          </View>
          <ScanButton label={t.scanIcon} />
        </View>
      </Animated.View>
    </View>
  );
}
