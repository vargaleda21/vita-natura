import { LinearGradient } from 'expo-linear-gradient';
import { router, type Href } from 'expo-router';
import { ScrollView, View } from 'react-native';

import { useT } from '@/i18n';
import { gradients, palette, radius, shadow, space } from '@/theme/tokens';
import { Icon, type IconName, PressableScale, Txt, useTheme } from '@/ui';
import { strings } from './strings';

type Teaser = {
  key: string;
  title: string;
  body: string;
  icon: IconName;
  colors: readonly [string, string, ...string[]];
  href: Href;
  isNew?: boolean;
  story?: boolean;
};

const W = 232;

function StoryBars() {
  return (
    <View style={{ flexDirection: 'row', gap: 4, marginBottom: space.md }}>
      {[1, 0.55, 0, 0, 0].map((fill, i) => (
        <View key={i} style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: 'rgba(16,35,28,0.18)', overflow: 'hidden' }}>
          <View style={{ width: `${fill * 100}%`, height: 4, backgroundColor: palette.ink }} />
        </View>
      ))}
    </View>
  );
}

/** Teasers for what is new: the monthly story and the Discover features. */
export function WhatsNew({ padding }: { padding: number }) {
  const t = useT(strings);
  const { isDark } = useTheme();
  const items: Teaser[] = [
    { key: 'wrapped', title: t.wrappedTitle, body: t.wrappedBody, icon: 'sparkles', colors: gradients.dusk, href: '/wrapped', isNew: true, story: true },
    { key: 'dual', title: t.dualTitle, body: t.dualBody, icon: 'globe', colors: ['#FFD6A8', palette.tangerine], href: '/(tabs)/discover' },
    { key: 'recipe', title: t.recipeTitle, body: t.recipeBody, icon: 'trending-down', colors: ['#FFF0B8', palette.sun], href: '/(tabs)/discover' },
    { key: 'cheaper', title: t.cheaperTitle, body: t.cheaperBody, icon: 'store', colors: gradients.sprout, href: '/(tabs)/discover' },
  ];
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      decelerationRate="fast"
      snapToInterval={W + 12}
      contentContainerStyle={{ paddingHorizontal: padding, gap: 12, paddingBottom: 14, paddingTop: 2 }}
      style={{ marginBottom: -14 }}
    >
      {items.map((it) => (
        <PressableScale
          key={it.key}
          accessibilityRole="button"
          accessibilityLabel={it.title}
          onPress={() => router.push(it.href)}
          style={[{ width: W, borderRadius: radius.lg }, isDark ? null : shadow.card]}
        >
          <View style={{ borderRadius: radius.lg, overflow: 'hidden', minHeight: 176 }}>
            <LinearGradient colors={it.colors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 }} />
            <LinearGradient
              colors={['rgba(255,255,255,0.4)', 'rgba(255,255,255,0)']}
              style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 50 }}
            />
            <View style={{ position: 'absolute', right: -30, bottom: -34, opacity: 0.1 }}>
              <Icon name={it.icon} size={116} color={palette.ink} strokeWidth={1.6} />
            </View>
            <View style={{ padding: space.lg, flex: 1 }}>
              {it.story ? <StoryBars /> : null}
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: 'rgba(255,255,255,0.7)', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name={it.icon} size={19} color={palette.ink} />
                </View>
                {it.isNew ? (
                  <View style={{ paddingHorizontal: 9, paddingVertical: 4, borderRadius: radius.pill, backgroundColor: palette.ink }}>
                    <Txt variant="tiny" upper color={palette.lime}>
                      {t.newBadge}
                    </Txt>
                  </View>
                ) : null}
              </View>
              <Txt variant="h3" color={palette.ink} style={{ marginTop: space.md }}>
                {it.title}
              </Txt>
              <Txt variant="small" color="rgba(16,35,28,0.72)" style={{ marginTop: 4 }}>
                {it.body}
              </Txt>
            </View>
          </View>
        </PressableScale>
      ))}
    </ScrollView>
  );
}
