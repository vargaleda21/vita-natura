import { router } from 'expo-router';
import { Text, View } from 'react-native';

import { activeKeys, CRITERIA } from '@/data/api';
import type { CriterionGroup } from '@/data/types';
import { useT, useTr } from '@/i18n';
import { useSettings } from '@/state/store';
import { font, palette, radius, shadow, space } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { strings } from './strings';

const TINT: Record<CriterionGroup, string> = {
  diet: palette.sun,
  additive: palette.lilac,
  allergy: palette.sky,
  planet: palette.lime,
};
const MAX = 6;

/** "Today you watch for": the avoid keys of you and your family, each with who asked for it. */
export function WatchList() {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const settings = useSettings();
  const keys = activeKeys(settings);
  const shown = keys.slice(0, MAX);
  const toProfile = () => router.push('/(tabs)/profile');
  const chipBg = isDark ? c.surface : palette.white;

  return (
    <View>
      {shown.length === 0 ? (
        <PressableScale
          accessibilityRole="button"
          onPress={toProfile}
          style={{ gap: space.md, padding: space.lg, borderRadius: radius.lg, borderWidth: 1.5, borderStyle: 'dashed', borderColor: c.border }}
        >
          <Txt muted>{t.watchEmpty}</Txt>
          <View style={{ alignSelf: 'flex-start', paddingHorizontal: 16, height: 40, justifyContent: 'center', borderRadius: radius.pill, backgroundColor: palette.lime }}>
            <Txt variant="bodyStrong" color={palette.ink}>
              {t.watchEmptyCta}
            </Txt>
          </View>
        </PressableScale>
      ) : (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {shown.map((k) => {
            const crit = CRITERIA[k];
            const who = settings.members.filter((m) => m.avoid.includes(k));
            return (
              <PressableScale
                key={k}
                accessibilityRole="button"
                accessibilityLabel={tr(crit.label)}
                onPress={toProfile}
                style={[
                  {
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 7,
                    height: 40,
                    paddingLeft: 6,
                    paddingRight: who.length ? 6 : 14,
                    borderRadius: radius.pill,
                    backgroundColor: chipBg,
                    borderWidth: 1,
                    borderColor: c.border,
                  },
                  isDark ? null : shadow.card,
                ]}
              >
                <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: TINT[crit.group], alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name={crit.icon} size={15} color={palette.ink} />
                </View>
                <Txt variant="small" style={{ fontFamily: font.bodySemi }}>
                  {tr(crit.label)}
                </Txt>
                {who.length ? (
                  <View style={{ flexDirection: 'row', paddingLeft: 2 }}>
                    {who.map((m, i) => (
                      <View
                        key={m.id}
                        style={{
                          width: 26,
                          height: 26,
                          borderRadius: 13,
                          marginLeft: i ? -8 : 0,
                          backgroundColor: m.color,
                          borderWidth: 2,
                          borderColor: chipBg,
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        <Text style={{ fontSize: 13 }}>{m.avatar}</Text>
                      </View>
                    ))}
                  </View>
                ) : null}
              </PressableScale>
            );
          })}
          {keys.length > MAX ? (
            <PressableScale
              accessibilityRole="button"
              onPress={toProfile}
              style={{ height: 40, paddingHorizontal: 14, justifyContent: 'center', borderRadius: radius.pill, borderWidth: 1, borderColor: c.border }}
            >
              <Txt variant="small" muted>
                {t.more(keys.length - MAX)}
              </Txt>
            </PressableScale>
          ) : null}
        </View>
      )}

      <PressableScale
        scaleTo={0.98}
        accessibilityRole="button"
        accessibilityLabel={`${t.familyLine(settings.members.length)}. ${t.edit}`}
        onPress={toProfile}
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: space.md,
          marginTop: space.md,
          minHeight: 52,
          paddingLeft: 8,
          paddingRight: 14,
          borderRadius: radius.pill,
          backgroundColor: isDark ? c.surfaceAlt : 'rgba(255,255,255,0.55)',
          borderWidth: 1,
          borderColor: c.border,
        }}
      >
        <View style={{ flexDirection: 'row' }}>
          <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: palette.lime, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: c.bg }}>
            <Txt variant="tiny" color={palette.ink} style={{ letterSpacing: 0, fontFamily: font.bodyBold }}>
              {t.you}
            </Txt>
          </View>
          {settings.members.slice(0, 5).map((m) => (
            <View
              key={m.id}
              style={{ width: 34, height: 34, borderRadius: 17, marginLeft: -9, backgroundColor: m.color, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: c.bg }}
            >
              <Text style={{ fontSize: 17 }}>{m.avatar}</Text>
            </View>
          ))}
        </View>
        <Txt variant="small" style={{ flex: 1, fontFamily: font.bodySemi }}>
          {t.familyLine(settings.members.length)}
        </Txt>
        <Icon name="chevron-right" size={18} color={c.textMuted} />
      </PressableScale>
    </View>
  );
}
