import { router } from 'expo-router';
import { ScrollView, View } from 'react-native';

import { evaluate, getProduct } from '@/data/api';
import type { Product, ScanEntry } from '@/data/types';
import { useT, useTr } from '@/i18n';
import { useHistory, useSettings } from '@/state/store';
import { font, palette, radius, shadow, space } from '@/theme/tokens';
import { Icon, PackArt, PressableScale, Txt, useTheme, VerdictBadge } from '@/ui';
import { strings } from './strings';

const CARD = 150;

function hexA(hex: string, a: number) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

function daysSince(iso: string): number {
  const a = new Date(iso);
  const b = new Date();
  const day = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  return Math.max(0, Math.round((day(b) - day(a)) / 86_400_000));
}

/** The latest scan of each product, newest first. */
function recent(history: ScanEntry[], max: number): { entry: ScanEntry; product: Product }[] {
  const seen = new Set<string>();
  const out: { entry: ScanEntry; product: Product }[] = [];
  for (const entry of [...history].sort((a, b) => b.at.localeCompare(a.at))) {
    if (seen.has(entry.ean)) continue;
    seen.add(entry.ean);
    const product = getProduct(entry.ean);
    if (product) out.push({ entry, product });
    if (out.length >= max) break;
  }
  return out;
}

export function RecentScans({ padding }: { padding: number }) {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const history = useHistory();
  const settings = useSettings();
  const items = recent(history, 10);

  if (items.length === 0) {
    return (
      <View style={{ paddingHorizontal: padding }}>
        <View style={{ padding: space.lg, borderRadius: radius.lg, borderWidth: 1.5, borderStyle: 'dashed', borderColor: c.border, flexDirection: 'row', gap: space.md, alignItems: 'center' }}>
          <Icon name="scan-barcode" size={22} color={c.textMuted} />
          <Txt muted style={{ flex: 1 }}>
            {t.recentEmpty}
          </Txt>
        </View>
      </View>
    );
  }

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ paddingHorizontal: padding, gap: 12, paddingBottom: 14, paddingTop: 2 }}
      style={{ marginBottom: -14 }}
    >
      {items.map(({ entry, product }) => {
        const result = evaluate(product, settings);
        const ago = daysSince(entry.at);
        const when = ago === 0 ? t.today : ago === 1 ? t.yesterday : t.daysAgo(ago);
        return (
          <PressableScale
            key={entry.ean}
            accessibilityRole="button"
            accessibilityLabel={tr(product.name)}
            onPress={() => router.push(`/product/${product.ean}`)}
            style={[
              {
                width: CARD,
                borderRadius: radius.lg,
                backgroundColor: c.surface,
                borderWidth: isDark ? 1 : 0,
                borderColor: c.border,
                padding: 10,
              },
              isDark ? null : shadow.card,
            ]}
          >
            <View
              style={{
                height: 112,
                borderRadius: radius.md,
                backgroundColor: hexA(product.art.colors[1], isDark ? 0.16 : 0.28),
                alignItems: 'center',
                justifyContent: 'center',
                overflow: 'hidden',
              }}
            >
              <PackArt art={product.art} size={84} />
              {entry.swapped ? (
                <View
                  style={{
                    position: 'absolute',
                    top: 8,
                    left: 8,
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 3,
                    paddingHorizontal: 7,
                    paddingVertical: 3,
                    borderRadius: radius.pill,
                    backgroundColor: palette.ink,
                  }}
                >
                  <Icon name="arrow-left-right" size={10} color={palette.lime} strokeWidth={2.6} />
                  <Txt variant="tiny" color={palette.lime} style={{ letterSpacing: 0.2, fontSize: 10 }}>
                    {t.swapped}
                  </Txt>
                </View>
              ) : null}
            </View>
            <View style={{ marginTop: 10 }}>
              <VerdictBadge verdict={result.verdict} />
            </View>
            <Txt variant="small" numberOfLines={2} style={{ fontFamily: font.bodySemi, marginTop: 8, minHeight: 36 }}>
              {tr(product.name)}
            </Txt>
            <Txt variant="tiny" faint numberOfLines={1} style={{ marginTop: 4, letterSpacing: 0.2 }}>
              {product.brand} · {when}
            </Txt>
          </PressableScale>
        );
      })}
    </ScrollView>
  );
}
