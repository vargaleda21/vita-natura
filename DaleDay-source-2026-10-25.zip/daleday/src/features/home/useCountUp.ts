import { useEffect, useState } from 'react';
import { useReducedMotion } from 'react-native-reanimated';

/** A number that counts up from 0 to `target` on mount (ease-out). Reduced motion shows the target at once. */
export function useCountUp(target: number, duration = 1100, delay = 0): number {
  const reduced = useReducedMotion();
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (reduced) return;
    let raf = 0;
    let start = 0;
    const tick = (now: number) => {
      if (!start) start = now;
      const p = Math.min(1, Math.max(0, (now - start - delay) / duration));
      setValue(target * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration, delay, reduced]);
  return reduced ? target : value;
}
