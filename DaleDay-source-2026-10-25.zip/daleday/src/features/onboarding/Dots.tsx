import { View } from 'react-native';
import Animated, { interpolate, useAnimatedStyle, type SharedValue } from 'react-native-reanimated';

import { palette } from '@/theme/tokens';
import { useTheme } from '@/ui';

const DOT = 8;
const STEP = 22;
const REST = 22; // the active pill's length at rest
const LONG = REST + STEP; // its length halfway between two pages

function Dot({ i, x, width }: { i: number; x: SharedValue<number>; width: number }) {
  const { c } = useTheme();
  const anim = useAnimatedStyle(() => {
    const d = Math.abs(x.get() / width - i);
    return { opacity: interpolate(d, [0, 0.6, 1], [0, 0.6, 1], 'clamp') };
  });
  return (
    <Animated.View
      style={[
        { position: 'absolute', left: i * STEP - DOT / 2, top: 0, width: DOT, height: DOT, borderRadius: DOT / 2, backgroundColor: c.textFaint },
        anim,
      ]}
    />
  );
}

/** Page dots with a lime pill that slides and stretches with the scroll (transforms only). */
export function Dots({ x, width, count }: { x: SharedValue<number>; width: number; count: number }) {
  const { isDark } = useTheme();
  const pill = useAnimatedStyle(() => {
    const p = Math.max(0, Math.min(count - 1, x.get() / width));
    const frac = p - Math.floor(p);
    const stretch = interpolate(frac, [0, 0.5, 1], [REST, LONG, REST]);
    return { transform: [{ translateX: p * STEP }, { scaleX: stretch / LONG }] };
  });
  return (
    <View
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
      style={{ width: (count - 1) * STEP + REST, height: DOT }}
    >
      <View style={{ position: 'absolute', left: REST / 2, top: 0 }}>
        {Array.from({ length: count }, (_, i) => (
          <Dot key={i} i={i} x={x} width={width} />
        ))}
      </View>
      <Animated.View
        style={[
          {
            position: 'absolute',
            left: REST / 2 - LONG / 2,
            top: 0,
            width: LONG,
            height: DOT,
            borderRadius: DOT / 2,
            backgroundColor: isDark ? palette.lime : palette.ink,
          },
          pill,
        ]}
      />
    </View>
  );
}
