import { LinearGradient } from 'expo-linear-gradient';
import { Text, View } from 'react-native';
import type { SharedValue } from 'react-native-reanimated';

import { AnimatedLogo, Glow } from '@/features/brand';
import { useT } from '@/i18n';
import { font, palette, radius, shadow, space, verdictColor } from '@/theme/tokens';
import { Icon, Txt, useTheme } from '@/ui';
import { Bob, Parallax } from './Parallax';
import { strings } from './strings';

export type PageProps = { x: SharedValue<number>; index: number; width: number; height: number; active: boolean };

type Verdict = keyof typeof verdictColor;

/** A tiny clay pack with a verdict dot: what DaleDay looks at. */
function PackTile({ emoji, colors, size, rotate, verdict }: { emoji: string; colors: [string, string]; size: number; rotate: number; verdict: Verdict }) {
  return (
    <View style={{ transform: [{ rotate: `${rotate}deg` }] }}>
      <LinearGradient
        colors={colors}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={[
          {
            width: size,
            height: size,
            borderRadius: size * 0.3,
            alignItems: 'center',
            justifyContent: 'center',
            borderWidth: 1,
            borderColor: 'rgba(255,255,255,0.45)',
          },
          shadow.card,
        ]}
      >
        <View style={{ position: 'absolute', left: size * 0.14, top: 6, bottom: 6, width: size * 0.1, borderRadius: 4, backgroundColor: 'rgba(255,255,255,0.28)' }} />
        <Text style={{ fontSize: size * 0.46 }}>{emoji}</Text>
      </LinearGradient>
      <View
        style={{
          position: 'absolute',
          right: -6,
          top: -6,
          width: 22,
          height: 22,
          borderRadius: 11,
          backgroundColor: verdictColor[verdict],
          borderWidth: 2,
          borderColor: palette.white,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Icon name={verdict === 'avoid' ? 'x' : 'check'} size={12} color={palette.ink} strokeWidth={3} />
      </View>
    </View>
  );
}

export function WelcomePage({ x, index, width, height }: PageProps) {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const stage = 330;
  return (
    <View style={{ width, height, justifyContent: 'center', paddingBottom: space.lg }}>

      <View style={{ height: stage, alignItems: 'center', justifyContent: 'center' }}>
        <Parallax x={x} index={index} width={width} lag={0.7} fade style={{ position: 'absolute', right: width * 0.08, top: 42 }}>
          <Bob period={4200} delay={300}>
            <PackTile emoji="🥛" colors={['#9FD8B6', '#E3F6EA']} size={58} rotate={10} verdict="great" />
          </Bob>
        </Parallax>
        <Parallax x={x} index={index} width={width} lag={0.42} fade style={{ position: 'absolute', left: width * 0.1, top: 26 }}>
          <Bob period={3800}>
            <PackTile emoji="🥣" colors={['#E0A040', '#FFE08A']} size={70} rotate={-12} verdict="okay" />
          </Bob>
        </Parallax>

        <Parallax x={x} index={index} width={width} lag={0.18} fade>
          <View
            style={[
              {
                width: 156,
                height: 156,
                borderRadius: 46,
                backgroundColor: palette.ink,
                alignItems: 'center',
                justifyContent: 'center',
                overflow: 'hidden',
                borderWidth: 1,
                borderColor: isDark ? 'rgba(198,243,107,0.22)' : 'rgba(255,255,255,0.08)',
              },
              shadow.float,
            ]}
          >
            <Glow width={190} color={palette.forest} opacity={0.95} style={{ position: 'absolute', left: -17, top: -40 }} />
            <LinearGradient
              colors={['rgba(255,255,255,0.10)', 'rgba(255,255,255,0)']}
              style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 70 }}
            />
            <AnimatedLogo size={128} tone="lime" delay={250} />
          </View>
        </Parallax>

        <Parallax x={x} index={index} width={width} lag={-0.28} fade style={{ position: 'absolute', left: width * 0.14, top: 236 }}>
          <Bob period={4600} delay={600} amplitude={5}>
            <PackTile emoji="🍫" colors={['#7A4A2A', '#C98B5A']} size={54} rotate={9} verdict="avoid" />
          </Bob>
        </Parallax>
        <Parallax x={x} index={index} width={width} lag={-0.4} fade style={{ position: 'absolute', right: width * 0.07, top: 252 }}>
          <Bob period={5000} delay={900} amplitude={4}>
            <View
              style={[
                {
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 6,
                  paddingLeft: 8,
                  paddingRight: 12,
                  paddingVertical: 7,
                  borderRadius: radius.pill,
                  backgroundColor: c.surface,
                  borderWidth: 1,
                  borderColor: c.border,
                  transform: [{ rotate: '-4deg' }],
                },
                shadow.card,
              ]}
            >
              <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: verdictColor.avoid, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="tree-palm" size={13} color={palette.ink} />
              </View>
              <Txt variant="small" style={{ fontFamily: font.bodySemi }}>
                {t.palmOil}
              </Txt>
            </View>
          </Bob>
        </Parallax>
      </View>

      <Parallax x={x} index={index} width={width} lag={-0.14} fade style={{ paddingHorizontal: space.xxl }}>
        <Txt variant="hero" center accessibilityRole="header">
          {t.welcomeTitle}
        </Txt>
        <Txt muted center style={{ marginTop: space.md, maxWidth: 340, alignSelf: 'center' }}>
          {t.welcomeBody}
        </Txt>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: space.sm, marginTop: space.xl }}>
          {t.welcomePoints.map((p) => (
            <View
              key={p}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 6,
                paddingLeft: 6,
                paddingRight: 12,
                paddingVertical: 6,
                borderRadius: radius.pill,
                backgroundColor: isDark ? c.surfaceAlt : 'rgba(255,255,255,0.72)',
                borderWidth: 1,
                borderColor: c.border,
              }}
            >
              <View style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: palette.lime, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="check" size={12} color={palette.ink} strokeWidth={3} />
              </View>
              <Txt variant="small">{p}</Txt>
            </View>
          ))}
        </View>
      </Parallax>
    </View>
  );
}
