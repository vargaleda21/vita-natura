import { useEffect, type ReactNode } from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import Animated, {
  Easing,
  interpolate,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withRepeat,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';

type Props = {
  /** The pager's horizontal scroll offset. */
  x: SharedValue<number>;
  index: number;
  width: number;
  /**
   * How much this layer lags behind the page: 0 moves with the page, 0.6 moves at 40% of its speed
   * (far background), a negative value runs ahead of it (foreground text).
   */
  lag: number;
  fade?: boolean;
  style?: StyleProp<ViewStyle>;
  children: ReactNode;
  pointerEvents?: 'box-none' | 'none' | 'auto';
};

/** One depth layer of a pager page. Different lags on one page make the differential parallax. */
export function Parallax({ x, index, width, lag, fade, style, children, pointerEvents }: Props) {
  const anim = useAnimatedStyle(() => {
    const d = x.get() - index * width;
    return {
      opacity: fade ? interpolate(Math.abs(d), [0, width * 0.75], [1, 0], 'clamp') : 1,
      transform: [{ translateX: d * lag }],
    };
  });
  return (
    <Animated.View pointerEvents={pointerEvents} style={[style, anim]}>
      {children}
    </Animated.View>
  );
}

/** A slow up-and-down bob for floating things. */
export function Bob({
  children,
  amplitude = 6,
  period = 3600,
  delay = 0,
  style,
}: {
  children: ReactNode;
  amplitude?: number;
  period?: number;
  delay?: number;
  style?: StyleProp<ViewStyle>;
}) {
  const reduced = useReducedMotion();
  const t = useSharedValue(0);
  useEffect(() => {
    if (reduced) return;
    const id = setTimeout(() => {
      t.set(withRepeat(withTiming(1, { duration: period / 2, easing: Easing.inOut(Easing.sin) }), -1, true));
    }, delay);
    return () => clearTimeout(id);
  }, [reduced, period, delay, t]);
  const anim = useAnimatedStyle(() => ({ transform: [{ translateY: (t.get() - 0.5) * 2 * amplitude }] }));
  return <Animated.View style={[style, anim]}>{children}</Animated.View>;
}
