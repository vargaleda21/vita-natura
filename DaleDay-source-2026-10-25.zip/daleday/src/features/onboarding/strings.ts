import type { AvoidKey, CriterionGroup } from '@/data/types';

type Preset = { id: string; avatar: string; color: string; avoid: AvoidKey[] };

/** The quick-add family members. Their avoid lists are a sensible start; each can be changed later. */
export const PRESETS: Preset[] = [
  { id: 'child', avatar: '👧', color: '#FFC93D', avoid: ['artificial_colors', 'added_sugar'] },
  { id: 'grandma', avatar: '👵', color: '#B9A4FF', avoid: ['added_sugar', 'high_salt'] },
  { id: 'pregnant', avatar: '🤰', color: '#FF8A3D', avoid: ['caffeine', 'nitrites'] },
  { id: 'partner', avatar: '🧑', color: '#7FD3FF', avoid: ['lactose'] },
];

const hu = {
  skip: 'Kihagyom',
  next: 'Tovább',
  start: 'Kezdjük',
  langLabel: 'Nyelv',
  // 1
  welcomeTitle: 'Tudd, mi van benne.',
  welcomeBody:
    'Szkenneld be egy termék vonalkódját, és a\u00A0DaleDay megmutatja, van-e benne olyan, amit kerülnél. Ha van, mutat helyette jobbat, sokszor olcsóbbat is.',
  welcomePoints: ['A te szempontjaid', 'Jobbat, olcsóbban', 'Az egész családnak'],
  palmOil: 'pálmaolaj',
  // 2
  avoidKicker: 'A te szempontjaid',
  avoidTitle: 'Mit kerülnél?',
  avoidBody: 'Válaszd ki, mire figyeljen a DaleDay. Bármikor átállíthatod.',
  selected: (n: number) => (n === 0 ? 'Semmi sincs kiválasztva' : `${n} kiválasztva`),
  groups: {
    diet: 'Étrend',
    additive: 'Adalékanyagok',
    allergy: 'Allergének és érzékenységek',
    planet: 'A bolygóért',
  } satisfies Record<CriterionGroup, string>,
  // 3
  familyKicker: 'A családod',
  familyTitle: 'Kire figyelsz még?',
  familyBody: 'Egy szkennelés mindenkire figyel. Koppints azokra, akiknek vásárolsz.',
  presetNames: { child: 'Gyerek', grandma: 'Nagyi', pregnant: 'Kismama', partner: 'Társ' } as Record<string, string>,
  you: 'Te',
  familyNone: 'Csak magadnak vásárolsz? Így is tökéletes.',
  familySome: (n: number) => `Te és ${n} családtagod. Egy szkennelés mindenkire figyel.`,
  added: 'Hozzáadva',
  add: 'Hozzáadás',
  // 4
  doneKicker: 'Minden megvan',
  doneTitle: 'Kész is vagy!',
  doneBody: 'A boltban csak tartsd rá a kamerát a vonalkódra. A többit a DaleDay intézi.',
  watching: 'Ezekre figyel a DaleDay',
  nothing: 'Még semmit nem választottál',
  family: 'Család',
  justYou: 'Csak te',
  go: 'Belevágok',
  scanNow: 'Rögtön szkennelek egyet',
};

type Strings = typeof hu;

const en: Strings = {
  skip: 'Skip',
  next: 'Next',
  start: 'Get started',
  langLabel: 'Language',
  welcomeTitle: 'Know what’s inside.',
  welcomeBody:
    'Scan a product’s barcode and DaleDay shows whether it contains anything you’d rather avoid. If it does, it suggests a better one, often for less.',
  welcomePoints: ['Your own choices', 'Better, for less', 'For the whole family'],
  palmOil: 'palm oil',
  avoidKicker: 'Your choices',
  avoidTitle: 'What would you avoid?',
  avoidBody: 'Pick what DaleDay should watch for. You can change it any time.',
  selected: (n: number) => (n === 0 ? 'Nothing selected' : `${n} selected`),
  groups: {
    diet: 'Diet',
    additive: 'Additives',
    allergy: 'Allergens and intolerances',
    planet: 'For the planet',
  },
  familyKicker: 'Your family',
  familyTitle: 'Who else do you shop for?',
  familyBody: 'One scan looks out for everyone. Tap the people you shop for.',
  presetNames: { child: 'Child', grandma: 'Grandma', pregnant: 'Mum-to-be', partner: 'Partner' },
  you: 'You',
  familyNone: 'Just shopping for yourself? That’s fine too.',
  familySome: (n: number) => `You and ${n} family ${n === 1 ? 'member' : 'members'}. One scan looks out for everyone.`,
  added: 'Added',
  add: 'Add',
  doneKicker: 'All set',
  doneTitle: 'You’re ready!',
  doneBody: 'In the shop, just point the camera at the barcode and let DaleDay do the rest.',
  watching: 'What DaleDay watches for',
  nothing: 'Nothing picked yet',
  family: 'Family',
  justYou: 'Just you',
  go: 'Let’s go',
  scanNow: 'Scan something right away',
};

export const strings = { hu, en };
