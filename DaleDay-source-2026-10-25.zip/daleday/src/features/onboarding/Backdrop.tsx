import { StyleSheet, View } from 'react-native';
import Animated, { interpolate, useAnimatedStyle, type SharedValue } from 'react-native-reanimated';

import { Glow } from '@/features/brand';
import { palette } from '@/theme/tokens';
import { useTheme } from '@/ui';

/** Each page's light: a few soft glows. `x`/`y`/`w` are fractions of the screen width; `o` is light / dark opacity. */
type Spot = { color: string; x: number; y: number; w: number; h?: number; o: [number, number] };

const SPOTS: Spot[][] = [
  [
    { color: palette.lime, x: -0.2, y: 0.05, w: 1.4, h: 1.25, o: [0.8, 0.28] },
    { color: palette.sky, x: 0.45, y: 0.95, w: 1, o: [0.5, 0.14] },
    { color: palette.sun, x: -0.45, y: 1.2, w: 0.9, o: [0.4, 0.1] },
  ],
  [
    { color: palette.lilac, x: 0.35, y: -0.1, w: 1.1, o: [0.5, 0.2] },
    { color: palette.sun, x: -0.4, y: 0.45, w: 0.9, o: [0.42, 0.12] },
    { color: palette.sky, x: 0.2, y: 1.4, w: 1, o: [0.38, 0.12] },
  ],
  [
    { color: palette.tangerine, x: -0.45, y: -0.05, w: 1.1, o: [0.34, 0.16] },
    { color: palette.sun, x: 0.4, y: 0.65, w: 1.1, o: [0.42, 0.12] },
    { color: palette.lilac, x: -0.2, y: 1.45, w: 1, o: [0.34, 0.14] },
  ],
  [
    { color: palette.lime, x: -0.15, y: -0.05, w: 1.3, o: [0.72, 0.24] },
    { color: palette.mint, x: 0.4, y: 0.95, w: 1, o: [0.45, 0.14] },
  ],
];

function PageLight({ i, x, width, left, spots }: { i: number; x: SharedValue<number>; width: number; left: number; spots: Spot[] }) {
  const { isDark } = useTheme();
  // The light drifts at half the page speed and crossfades into the next page's light.
  const anim = useAnimatedStyle(() => {
    const d = i * width - x.get();
    return {
      opacity: interpolate(Math.abs(d), [0, width], [1, 0], 'clamp'),
      transform: [{ translateX: d * 0.5 }],
    };
  });
  return (
    <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, anim]}>
      {spots.map((s, k) => (
        <Glow
          key={k}
          width={s.w * width}
          height={(s.h ?? s.w) * width}
          color={s.color}
          opacity={s.o[isDark ? 1 : 0]}
          style={{ position: 'absolute', left: left + s.x * width, top: s.y * width }}
        />
      ))}
    </Animated.View>
  );
}

/**
 * The light behind the pager. It sits behind every page, so a page's glow never covers the next page's content.
 * It spans the whole window (`left` is where the 480 px column starts), so on a wide screen the light
 * spills softly past the column instead of stopping at a hard edge.
 */
export function Backdrop({ x, width, left = 0 }: { x: SharedValue<number>; width: number; left?: number }) {
  return (
    <View pointerEvents="none" style={[StyleSheet.absoluteFill, { overflow: 'hidden' }]}>
      {SPOTS.map((spots, i) => (
        <PageLight key={i} i={i} x={x} width={width} left={left} spots={spots} />
      ))}
    </View>
  );
}
