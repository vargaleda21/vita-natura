import { ScrollView, View } from 'react-native';

import { CRITERIA, CRITERIA_ORDER } from '@/data/api';
import type { AvoidKey, CriterionGroup } from '@/data/types';
import { useT, useTr } from '@/i18n';
import { toggleAvoid, useSettings } from '@/state/store';
import { font, palette, radius, space } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { Parallax } from './Parallax';
import { strings } from './strings';
import type { PageProps } from './WelcomePage';

export const GROUP_ORDER: CriterionGroup[] = ['diet', 'additive', 'allergy', 'planet'];
export const GROUP_TINT: Record<CriterionGroup, string> = {
  diet: palette.sun,
  additive: palette.lilac,
  allergy: palette.sky,
  planet: palette.lime,
};

function AvoidChip({ k, on, tint }: { k: AvoidKey; on: boolean; tint: string }) {
  const { c, isDark } = useTheme();
  const tr = useTr();
  const crit = CRITERIA[k];
  const fg = on ? palette.ink : c.text;
  return (
    <PressableScale
      accessibilityRole="checkbox"
      accessibilityState={{ checked: on }}
      accessibilityLabel={tr(crit.label)}
      hitSlop={{ top: 3, bottom: 3, left: 2, right: 2 }}
      onPress={() => toggleAvoid(k)}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 7,
        height: 40,
        paddingLeft: 12,
        paddingRight: on ? 10 : 14,
        borderRadius: radius.pill,
        backgroundColor: on ? tint : isDark ? c.surfaceAlt : c.surface,
        borderWidth: 1,
        borderColor: on ? 'rgba(16,35,28,0.12)' : c.border,
      }}
    >
      <Icon name={crit.icon} size={16} color={fg} />
      <Txt variant="small" color={fg} style={{ fontFamily: font.bodySemi }}>
        {tr(crit.label)}
      </Txt>
      {on ? (
        <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: palette.ink, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="check" size={11} color={tint} strokeWidth={3.2} />
        </View>
      ) : null}
    </PressableScale>
  );
}

export function AvoidPage({ x, index, width, height }: PageProps) {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const { avoid } = useSettings();
  return (
    <View style={{ width, height }}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: space.xl, paddingTop: space.md, paddingBottom: space.xl }}>
        <Parallax x={x} index={index} width={width} lag={-0.08} fade>
          <Txt variant="tiny" upper color={isDark ? palette.lime : palette.forest}>
            {t.avoidKicker}
          </Txt>
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', gap: space.md, marginTop: space.xs }}>
            <Txt variant="h1" accessibilityRole="header" style={{ flexShrink: 1 }}>
              {t.avoidTitle}
            </Txt>
            <View
              style={{
                paddingHorizontal: 10,
                paddingVertical: 4,
                borderRadius: radius.pill,
                backgroundColor: avoid.length ? (isDark ? palette.lime : palette.ink) : c.bgAlt,
                marginBottom: 4,
              }}
            >
              <Txt variant="tiny" color={avoid.length ? (isDark ? palette.ink : palette.lime) : c.textMuted}>
                {t.selected(avoid.length)}
              </Txt>
            </View>
          </View>
          <Txt muted style={{ marginTop: space.sm }}>
            {t.avoidBody}
          </Txt>
        </Parallax>

        <Parallax x={x} index={index} width={width} lag={-0.2} fade style={{ marginTop: space.xl, gap: space.xl }}>
          {GROUP_ORDER.map((g) => {
            const keys = CRITERIA_ORDER.filter((k) => CRITERIA[k].group === g);
            if (keys.length === 0) return null;
            return (
              <View key={g}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: space.sm }}>
                  <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: GROUP_TINT[g] }} />
                  <Txt variant="tiny" upper muted>
                    {t.groups[g]}
                  </Txt>
                </View>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
                  {keys.map((k) => (
                    <AvoidChip key={k} k={k} on={avoid.includes(k)} tint={GROUP_TINT[g]} />
                  ))}
                </View>
              </View>
            );
          })}
        </Parallax>
      </ScrollView>
    </View>
  );
}
