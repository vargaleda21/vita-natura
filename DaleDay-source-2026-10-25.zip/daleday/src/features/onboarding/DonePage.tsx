import { ScrollView, Text, View } from 'react-native';

import { activeKeys, CRITERIA } from '@/data/api';
import { Confetti, Logo } from '@/features/brand';
import { useT, useTr } from '@/i18n';
import { useSettings } from '@/state/store';
import { font, palette, radius, shadow, space } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { Parallax } from './Parallax';
import { strings } from './strings';
import type { PageProps } from './WelcomePage';

type Props = PageProps & { onGo: () => void; onScan: () => void };

export function DonePage({ x, index, width, height, active, onGo, onScan }: Props) {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const settings = useSettings();
  const keys = activeKeys(settings);
  const shown = keys.slice(0, 6);
  return (
    <View style={{ width, height }}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', paddingHorizontal: space.xl, paddingBottom: space.xl }}>
        <Parallax x={x} index={index} width={width} lag={0.2} fade style={{ alignItems: 'center', marginTop: space.lg }}>
          <View
            style={[
              { borderRadius: 32, borderWidth: isDark ? 1 : 0, borderColor: 'rgba(198,243,107,0.25)' },
              isDark ? null : shadow.float,
            ]}
          >
            <Logo size={112} tone="lime" badge />
          </View>
        </Parallax>

        <Parallax x={x} index={index} width={width} lag={-0.1} fade style={{ marginTop: space.xl }}>
          <Txt variant="tiny" upper center color={isDark ? palette.lime : palette.forest}>
            {t.doneKicker}
          </Txt>
          <Txt variant="hero" center accessibilityRole="header" style={{ marginTop: space.xs }}>
            {t.doneTitle}
          </Txt>
          <Txt muted center style={{ marginTop: space.sm, maxWidth: 330, alignSelf: 'center' }}>
            {t.doneBody}
          </Txt>
        </Parallax>

        <Parallax x={x} index={index} width={width} lag={-0.22} fade style={{ marginTop: space.xl }}>
          <View
            style={[
              {
                padding: space.lg,
                borderRadius: radius.lg,
                backgroundColor: isDark ? c.surface : palette.white,
                borderWidth: isDark ? 1 : 0,
                borderColor: c.border,
                gap: space.md,
              },
              isDark ? null : shadow.card,
            ]}
          >
            <Txt variant="tiny" upper muted>
              {t.watching}
            </Txt>
            {shown.length ? (
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                {shown.map((k) => (
                  <View
                    key={k}
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: 5,
                      paddingHorizontal: 10,
                      paddingVertical: 5,
                      borderRadius: radius.pill,
                      backgroundColor: isDark ? c.surfaceAlt : c.bg,
                    }}
                  >
                    <Icon name={CRITERIA[k].icon} size={13} color={c.text} />
                    <Txt variant="small">{tr(CRITERIA[k].label)}</Txt>
                  </View>
                ))}
                {keys.length > shown.length ? (
                  <View style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: radius.pill, backgroundColor: palette.lime }}>
                    <Txt variant="small" color={palette.ink} style={{ fontFamily: font.bodySemi }}>
                      +{keys.length - shown.length}
                    </Txt>
                  </View>
                ) : null}
              </View>
            ) : (
              <Txt variant="small" muted>
                {t.nothing}
              </Txt>
            )}
            <View style={{ height: 1, backgroundColor: c.border }} />
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <Txt variant="small" muted>
                {t.family}
              </Txt>
              {settings.members.length ? (
                <View style={{ flexDirection: 'row', gap: 4 }}>
                  {settings.members.map((m) => (
                    <Text key={m.id} style={{ fontSize: 20 }}>
                      {m.avatar}
                    </Text>
                  ))}
                </View>
              ) : (
                <Txt variant="small">{t.justYou}</Txt>
              )}
            </View>
          </View>
        </Parallax>

        <Parallax x={x} index={index} width={width} lag={-0.3} fade style={{ marginTop: space.xl, gap: space.sm }}>
          <PressableScale
            haptic="medium"
            accessibilityRole="button"
            onPress={onGo}
            style={[
              {
                height: 58,
                borderRadius: radius.pill,
                backgroundColor: palette.lime,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: space.sm,
              },
              shadow.card,
            ]}
          >
            <Txt variant="bodyStrong" color={palette.ink} style={{ fontSize: 17 }}>
              {t.go}
            </Txt>
            <Icon name="arrow-right" size={20} color={palette.ink} strokeWidth={2.4} />
          </PressableScale>
          <PressableScale
            accessibilityRole="button"
            onPress={onScan}
            style={{
              height: 54,
              borderRadius: radius.pill,
              borderWidth: 1.5,
              borderColor: isDark ? 'rgba(238,246,239,0.22)' : 'rgba(16,35,28,0.18)',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              gap: space.sm,
            }}
          >
            <Icon name="scan-barcode" size={20} color={c.text} />
            <Txt variant="bodyStrong">{t.scanNow}</Txt>
          </PressableScale>
        </Parallax>
      </ScrollView>
      <Confetti fire={active} x={width / 2} y={110} count={44} />
    </View>
  );
}
