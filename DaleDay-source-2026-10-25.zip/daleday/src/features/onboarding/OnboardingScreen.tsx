import { router } from 'expo-router';
import { useState } from 'react';
import { useWindowDimensions, View } from 'react-native';
import Animated, {
  interpolate,
  useAnimatedReaction,
  useAnimatedRef,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useSharedValue,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { scheduleOnRN } from 'react-native-worklets';

import { useT } from '@/i18n';
import { updateSettings } from '@/state/store';
import { palette, radius, shadow, space } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { AvoidPage } from './AvoidPage';
import { Backdrop } from './Backdrop';
import { DonePage } from './DonePage';
import { Dots } from './Dots';
import { FamilyPage } from './FamilyPage';
import { LangToggle } from './LangToggle';
import { strings } from './strings';
import { WelcomePage } from './WelcomePage';

const PAGES = 4;
const TOP = 60;
const BOTTOM = 92;

function finish(scan: boolean) {
  updateSettings({ onboarded: true });
  router.replace('/(tabs)');
  if (scan) router.push('/scan');
}

/** Four swipeable pages: hello, what you avoid, who else you shop for, done. */
export function OnboardingScreen() {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const win = useWindowDimensions();
  const width = Math.min(win.width, 480);
  const height = win.height - insets.top - TOP - insets.bottom - BOTTOM;
  const x = useSharedValue(0);
  const ref = useAnimatedRef<Animated.ScrollView>();
  const [page, setPage] = useState(0);

  const onScroll = useAnimatedScrollHandler({
    onScroll: (e) => {
      x.set(e.contentOffset.x);
    },
  });
  useAnimatedReaction(
    () => Math.round(x.get() / width),
    (now, before) => {
      if (now !== before) scheduleOnRN(setPage, now);
    },
  );

  const go = (to: number) => {
    ref.current?.scrollTo({ x: to * width, animated: true });
  };

  // The skip link and the next button step aside on the last page, where the page has its own buttons.
  const lastFade = useAnimatedStyle(() => {
    const v = interpolate(x.get(), [(PAGES - 2) * width, (PAGES - 1.4) * width], [1, 0], 'clamp');
    return { opacity: v, transform: [{ scale: 0.85 + 0.15 * v }] };
  });
  const last = page >= PAGES - 1;

  return (
    <View style={{ flex: 1, backgroundColor: c.bg, alignItems: 'center' }}>
      <Backdrop x={x} width={width} left={(win.width - width) / 2} />
      <View style={{ flex: 1, width, overflow: 'hidden' }}>
        <Animated.ScrollView
          ref={ref}
          horizontal
          pagingEnabled
          bounces={false}
          showsHorizontalScrollIndicator={false}
          onScroll={onScroll}
          scrollEventThrottle={16}
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingTop: insets.top + TOP, paddingBottom: insets.bottom + BOTTOM }}
        >
          <WelcomePage x={x} index={0} width={width} height={height} active={page === 0} />
          <AvoidPage x={x} index={1} width={width} height={height} active={page === 1} />
          <FamilyPage x={x} index={2} width={width} height={height} active={page === 2} />
          <DonePage x={x} index={3} width={width} height={height} active={page === 3} onGo={() => finish(false)} onScan={() => finish(true)} />
        </Animated.ScrollView>

        <View
          pointerEvents="box-none"
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: insets.top + 10,
            paddingHorizontal: space.xl,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <LangToggle />
          <Animated.View style={lastFade} pointerEvents={last ? 'none' : 'auto'}>
            <PressableScale
              accessibilityRole="button"
              onPress={() => finish(false)}
              hitSlop={8}
              style={{ height: 44, justifyContent: 'center', paddingHorizontal: space.sm }}
            >
              <Txt variant="bodyStrong" muted>
                {t.skip}
              </Txt>
            </PressableScale>
          </Animated.View>
        </View>

        <View
          pointerEvents="box-none"
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: insets.bottom + 22,
            paddingHorizontal: space.xl,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            height: 56,
          }}
        >
          <Dots x={x} width={width} count={PAGES} />
          <Animated.View style={lastFade} pointerEvents={last ? 'none' : 'auto'}>
            <PressableScale
              accessibilityRole="button"
              onPress={() => go(Math.min(page + 1, PAGES - 1))}
              style={[
                {
                  height: 56,
                  paddingLeft: 24,
                  paddingRight: 18,
                  borderRadius: radius.pill,
                  backgroundColor: isDark ? palette.lime : palette.ink,
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: space.sm,
                },
                shadow.float,
              ]}
            >
              <Txt variant="bodyStrong" color={isDark ? palette.ink : palette.oat}>
                {page === 0 ? t.start : t.next}
              </Txt>
              <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: isDark ? palette.ink : palette.lime, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="arrow-right" size={16} color={isDark ? palette.lime : palette.ink} strokeWidth={2.6} />
              </View>
            </PressableScale>
          </Animated.View>
        </View>
      </View>
    </View>
  );
}
