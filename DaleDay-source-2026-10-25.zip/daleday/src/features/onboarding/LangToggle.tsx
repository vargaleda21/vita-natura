import { useEffect } from 'react';
import { View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';

import type { Lang } from '@/data/types';
import { updateSettings, useSettings } from '@/state/store';
import { palette, radius, springs } from '@/theme/tokens';
import { PressableScale, Txt, useTheme } from '@/ui';

const SEG = 46;
const LANGS: { lang: Lang; label: string; name: string }[] = [
  { lang: 'hu', label: 'HU', name: 'Magyar' },
  { lang: 'en', label: 'EN', name: 'English' },
];

/** HU | EN with a lime thumb that springs across. */
export function LangToggle() {
  const { c, isDark } = useTheme();
  const { lang } = useSettings();
  const pos = useSharedValue(lang === 'hu' ? 0 : 1);
  useEffect(() => {
    pos.set(withSpring(lang === 'hu' ? 0 : 1, springs.snappy));
  }, [lang, pos]);
  const thumb = useAnimatedStyle(() => ({ transform: [{ translateX: pos.get() * SEG }] }));
  return (
    <View
      accessibilityRole="radiogroup"
      style={{
        flexDirection: 'row',
        padding: 3,
        borderRadius: radius.pill,
        backgroundColor: isDark ? c.surfaceAlt : 'rgba(255,255,255,0.7)',
        borderWidth: 1,
        borderColor: c.border,
      }}
    >
      <Animated.View
        style={[
          { position: 'absolute', left: 3, top: 3, width: SEG, height: 38, borderRadius: radius.pill, backgroundColor: palette.lime },
          thumb,
        ]}
      />
      {LANGS.map((l) => {
        const on = l.lang === lang;
        return (
          <PressableScale
            key={l.lang}
            accessibilityRole="radio"
            accessibilityLabel={l.name}
            accessibilityState={{ checked: on }}
            onPress={() => updateSettings({ lang: l.lang })}
            style={{ width: SEG, height: 38, alignItems: 'center', justifyContent: 'center' }}
          >
            <Txt variant="tiny" color={on ? palette.ink : c.textMuted} style={{ letterSpacing: 0.8 }}>
              {l.label}
            </Txt>
          </PressableScale>
        );
      })}
    </View>
  );
}
