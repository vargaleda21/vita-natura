import { ScrollView, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, LinearTransition, ZoomIn, ZoomOut } from 'react-native-reanimated';

import { CRITERIA } from '@/data/api';
import { useT, useTr } from '@/i18n';
import { removeMember, upsertMember, useSettings } from '@/state/store';
import { font, palette, radius, space, springs } from '@/theme/tokens';
import { Icon, PressableScale, Txt, useTheme } from '@/ui';
import { Parallax } from './Parallax';
import { PRESETS, strings } from './strings';
import type { PageProps } from './WelcomePage';

const memberId = (preset: string) => `preset-${preset}`;

function hexA(hex: string, a: number) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

function PresetTile({ preset, on, w }: { preset: (typeof PRESETS)[number]; on: boolean; w: number }) {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const name = t.presetNames[preset.id];
  return (
    <PressableScale
      accessibilityRole="checkbox"
      accessibilityState={{ checked: on }}
      accessibilityLabel={name}
      onPress={() => {
        if (on) removeMember(memberId(preset.id));
        else upsertMember({ id: memberId(preset.id), name, avatar: preset.avatar, color: preset.color, avoid: preset.avoid });
      }}
      style={{
        width: w,
        minHeight: 148,
        padding: space.lg,
        borderRadius: radius.lg,
        backgroundColor: on ? hexA(preset.color, isDark ? 0.2 : 0.26) : isDark ? c.surface : 'rgba(255,255,255,0.8)',
        borderWidth: on ? 2 : 1,
        borderColor: on ? preset.color : c.border,
      }}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <View
          style={{
            width: 52,
            height: 52,
            borderRadius: 26,
            backgroundColor: hexA(preset.color, isDark ? 0.3 : 0.38),
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Text style={{ fontSize: 28 }}>{preset.avatar}</Text>
        </View>
        <View
          style={{
            width: 28,
            height: 28,
            borderRadius: 14,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: on ? palette.ink : 'transparent',
            borderWidth: on ? 0 : 1.5,
            borderColor: c.textFaint,
          }}
        >
          <Icon name={on ? 'check' : 'plus'} size={15} color={on ? palette.lime : c.textMuted} strokeWidth={2.6} />
        </View>
      </View>
      <Txt variant="h3" style={{ marginTop: space.md }}>
        {name}
      </Txt>
      <Txt variant="small" muted numberOfLines={3} style={{ marginTop: 2 }}>
        {preset.avoid.map((k) => tr(CRITERIA[k].label)).join(', ')}
      </Txt>
    </PressableScale>
  );
}

export function FamilyPage({ x, index, width, height }: PageProps) {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const { members } = useSettings();
  const pad = space.xl;
  const tileW = (Math.min(width, 480) - pad * 2 - space.md) / 2;
  const added = PRESETS.filter((p) => members.some((m) => m.id === memberId(p.id)));
  const others = members.filter((m) => !PRESETS.some((p) => memberId(p.id) === m.id));
  const family = [...added.map((p) => ({ id: memberId(p.id), avatar: p.avatar, color: p.color })), ...others];
  return (
    <View style={{ width, height }}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: pad, paddingTop: space.md, paddingBottom: space.xl }}>
        <Parallax x={x} index={index} width={width} lag={-0.08} fade>
          <Txt variant="tiny" upper color={isDark ? palette.lime : palette.forest}>
            {t.familyKicker}
          </Txt>
          <Txt variant="h1" accessibilityRole="header" style={{ marginTop: space.xs }}>
            {t.familyTitle}
          </Txt>
          <Txt muted style={{ marginTop: space.sm }}>
            {t.familyBody}
          </Txt>
        </Parallax>

        <Parallax x={x} index={index} width={width} lag={-0.2} fade style={{ marginTop: space.xl }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.md }}>
            {PRESETS.map((p) => (
              <PresetTile key={p.id} preset={p} w={tileW} on={members.some((m) => m.id === memberId(p.id))} />
            ))}
          </View>
        </Parallax>

        <Parallax x={x} index={index} width={width} lag={-0.32} fade style={{ marginTop: space.xl }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: space.md,
              padding: space.md,
              borderRadius: radius.lg,
              backgroundColor: isDark ? c.surfaceAlt : 'rgba(255,255,255,0.6)',
              borderWidth: 1,
              borderColor: c.border,
            }}
          >
            <View style={{ flexDirection: 'row' }}>
              <View style={[styles.avatar, { backgroundColor: palette.lime, borderColor: isDark ? c.surfaceAlt : palette.white }]}>
                <Txt variant="tiny" color={palette.ink} style={{ fontFamily: font.bodyBold }}>
                  {t.you}
                </Txt>
              </View>
              {family.map((m) => (
                <Animated.View
                  key={m.id}
                  entering={ZoomIn.springify().damping(springs.bouncy.damping).stiffness(springs.bouncy.stiffness)}
                  exiting={ZoomOut.duration(160)}
                  layout={LinearTransition.springify()}
                  style={[styles.avatar, { marginLeft: -10, backgroundColor: hexA(m.color, 0.9), borderColor: isDark ? c.surfaceAlt : palette.white }]}
                >
                  <Text style={{ fontSize: 18 }}>{m.avatar}</Text>
                </Animated.View>
              ))}
            </View>
            <Animated.View key={family.length ? 'some' : 'none'} entering={FadeIn.duration(220)} style={{ flex: 1 }}>
              <Txt variant="small" muted>
                {family.length ? t.familySome(family.length) : t.familyNone}
              </Txt>
            </Animated.View>
          </View>
        </Parallax>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  avatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    borderWidth: 2.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
