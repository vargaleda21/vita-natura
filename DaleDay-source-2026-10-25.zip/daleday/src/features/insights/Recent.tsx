import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useEffect, useState, type ReactNode } from 'react';
import { Text, View } from 'react-native';
import Animated, {
  Easing,
  FadeIn,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';

import { getProduct } from '@/data/api';
import type { ScanEntry } from '@/data/types';
import { useLang, useT, useTr } from '@/i18n';
import { font, palette, radius, shadow, space } from '@/theme/tokens';
import { Card, Icon, PackArt, PressableScale, Txt, useTheme, VerdictBadge } from '@/ui';
import { alpha, whenText } from './format';
import { strings } from './strings';

// ── Recent scans ────────────────────────────────────────────────────────────

const FIRST = 6;

export function RecentList({ entries }: { entries: ScanEntry[] }) {
  const t = useT(strings);
  const tr = useTr();
  const lang = useLang();
  const { c, isDark } = useTheme();
  const [all, setAll] = useState(false);
  const shown = all ? entries : entries.slice(0, FIRST);
  return (
    <Card padded={false}>
      <View style={{ paddingHorizontal: space.lg, paddingTop: space.lg, paddingBottom: space.sm }}>
        <Txt variant="h3">{t.recentTitle}</Txt>
      </View>
      {shown.map((e, i) => {
        const p = getProduct(e.ean);
        if (!p) return null;
        return (
          <PressableScale
            key={`${e.ean}-${e.at}`}
            scaleTo={0.98}
            accessibilityRole="button"
            accessibilityLabel={`${tr(p.name)}, ${p.brand}`}
            onPress={() => router.push(`/product/${e.ean}`)}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: space.md,
              paddingHorizontal: space.lg,
              paddingVertical: space.md,
              borderTopWidth: i === 0 ? 0 : 1,
              borderTopColor: c.border,
            }}
          >
            <View
              style={{
                width: 52,
                height: 52,
                borderRadius: radius.md,
                backgroundColor: isDark ? c.surfaceAlt : c.bgAlt,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <PackArt art={p.art} size={42} />
            </View>
            <View style={{ flex: 1, gap: 2 }}>
              <Txt variant="bodyStrong" numberOfLines={2}>
                {tr(p.name)}
              </Txt>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Txt variant="small" faint numberOfLines={1} style={{ flexShrink: 1 }}>
                  {p.brand} · {whenText(e.at, lang)}
                </Txt>
              </View>
              {e.swapped ? (
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 4,
                    alignSelf: 'flex-start',
                    marginTop: 2,
                    paddingHorizontal: 8,
                    paddingVertical: 2,
                    borderRadius: radius.pill,
                    backgroundColor: alpha(palette.lilac, isDark ? 0.22 : 0.3),
                  }}
                >
                  <Icon name="arrow-left-right" size={11} color={isDark ? palette.lilac : palette.ink} strokeWidth={2.4} />
                  <Txt variant="tiny" color={isDark ? palette.lilac : palette.ink}>
                    {t.swapped}
                  </Txt>
                </View>
              ) : null}
            </View>
            <VerdictBadge verdict={e.verdict} score={e.score} compact />
            <Icon name="chevron-right" size={18} color={c.textFaint} />
          </PressableScale>
        );
      })}
      {entries.length > FIRST ? (
        <PressableScale
          accessibilityRole="button"
          onPress={() => setAll((a) => !a)}
          style={{ borderTopWidth: 1, borderTopColor: c.border, paddingVertical: space.lg, alignItems: 'center' }}
        >
          <Txt variant="bodyStrong" color={isDark ? palette.lime : palette.forest}>
            {all ? t.showLess : t.showAll(entries.length)}
          </Txt>
        </PressableScale>
      ) : (
        <View style={{ height: space.sm }} />
      )}
    </Card>
  );
}

// ── Story card ──────────────────────────────────────────────────────────────

/** A slow up-and-down drift for the card's playful shapes. */
function Drift({ children, dy, period, delay, rotate = 0, reduced }: {
  children: ReactNode;
  dy: number;
  period: number;
  delay: number;
  rotate?: number;
  reduced: boolean;
}) {
  const v = useSharedValue(0);
  useEffect(() => {
    if (reduced) return;
    const id = setTimeout(() => v.set(withRepeat(withTiming(1, { duration: period, easing: Easing.inOut(Easing.sin) }), -1, true)), delay);
    return () => clearTimeout(id);
  }, [v, period, delay, reduced]);
  const anim = useAnimatedStyle(() => ({
    transform: [{ translateY: (v.get() - 0.5) * 2 * dy }, { rotate: `${(v.get() - 0.5) * 2 * rotate}deg` }],
  }));
  return <Animated.View style={anim}>{children}</Animated.View>;
}

/** Three tilted mini "story" frames, like a stack of slides. */
function Frames() {
  const frame = (colors: readonly [string, string], rot: number, x: number, y: number, emoji: string) => (
    <View
      style={[
        {
          position: 'absolute',
          left: x,
          top: y,
          width: 66,
          height: 108,
          borderRadius: 14,
          overflow: 'hidden',
          borderWidth: 2,
          borderColor: 'rgba(255,255,255,0.75)',
          transform: [{ rotate: `${rot}deg` }],
        },
        shadow.card,
      ]}
    >
      <LinearGradient colors={colors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ flex: 1, padding: 7 }}>
        <View style={{ flexDirection: 'row', gap: 2 }}>
          {[0, 1, 2].map((i) => (
            <View key={i} style={{ flex: 1, height: 2, borderRadius: 1, backgroundColor: i === 0 ? palette.ink : 'rgba(16,35,28,0.25)' }} />
          ))}
        </View>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 26 }}>{emoji}</Text>
        </View>
      </LinearGradient>
    </View>
  );
  return (
    <View style={{ width: 128, height: 140 }}>
      {frame([palette.sky, palette.lilac], -12, 0, 22, '🍬')}
      {frame([palette.sun, palette.tangerine], 9, 56, 18, '💸')}
      {frame([palette.lime, palette.mint], -2, 26, 6, '🔎')}
    </View>
  );
}

export function StoryCard({ month, reduced }: { month: number; reduced: boolean }) {
  const t = useT(strings);
  return (
    <Animated.View entering={reduced ? undefined : FadeIn.delay(350).duration(500)}>
      <PressableScale
        haptic="medium"
        accessibilityRole="button"
        accessibilityLabel={t.storyTitle}
        onPress={() => router.push('/wrapped')}
        style={[{ borderRadius: radius.xl, overflow: 'hidden' }, shadow.float]}
      >
        <LinearGradient
          colors={[palette.lilac, palette.tangerine, palette.sun]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ padding: space.xl, minHeight: 196, flexDirection: 'row', gap: space.md, overflow: 'hidden' }}
        >
          {/* Soft light and playful shapes, each drifting at its own pace. */}
          <View style={{ position: 'absolute', right: -40, top: -50, width: 180, height: 180, borderRadius: 90, backgroundColor: 'rgba(255,255,255,0.18)' }} />
          <View style={{ position: 'absolute', left: -30, bottom: -60, width: 140, height: 140, borderRadius: 70, borderWidth: 16, borderColor: 'rgba(255,255,255,0.16)' }} />
          <View style={{ flex: 1, justifyContent: 'space-between', gap: space.md }}>
            <View style={{ gap: space.sm }}>
              <View style={{ alignSelf: 'flex-start', backgroundColor: palette.ink, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 4 }}>
                <Txt variant="tiny" color={palette.lime} upper>
                  {t.storyKicker}
                </Txt>
              </View>
              <Txt style={{ fontFamily: font.display, fontSize: 28, lineHeight: 30, letterSpacing: -0.8, color: palette.ink }}>{t.storyTitle}</Txt>
              <Txt variant="small" color={palette.ink} style={{ opacity: 0.8 }}>
                {t.storySub(month)}
              </Txt>
            </View>
            <View
              style={{
                alignSelf: 'flex-start',
                flexDirection: 'row',
                alignItems: 'center',
                gap: 8,
                backgroundColor: palette.ink,
                borderRadius: radius.pill,
                paddingLeft: 14,
                paddingRight: 18,
                height: 44,
              }}
            >
              <View
                style={{
                  width: 0,
                  height: 0,
                  borderTopWidth: 7,
                  borderBottomWidth: 7,
                  borderLeftWidth: 11,
                  borderTopColor: 'transparent',
                  borderBottomColor: 'transparent',
                  borderLeftColor: palette.lime,
                  marginLeft: 2,
                }}
              />
              <Txt variant="bodyStrong" color={palette.lime}>
                {t.storyPlay}
              </Txt>
            </View>
          </View>
          <Drift dy={6} period={2600} delay={0} rotate={2} reduced={reduced}>
            <Frames />
          </Drift>
        </LinearGradient>
      </PressableScale>
    </Animated.View>
  );
}

// ── Empty state ─────────────────────────────────────────────────────────────

export function EmptyBasket() {
  const t = useT(strings);
  return (
    <Card style={{ alignItems: 'center', paddingVertical: space.xxl }}>
      <Text style={{ fontSize: 54 }}>🧺</Text>
      <Txt variant="h2" center style={{ marginTop: space.md }}>
        {t.emptyTitle}
      </Txt>
      <Txt muted center style={{ marginTop: space.sm, maxWidth: 300 }}>
        {t.emptyBody}
      </Txt>
      <PressableScale
        accessibilityRole="button"
        onPress={() => router.push('/scan')}
        style={{
          marginTop: space.xl,
          backgroundColor: palette.lime,
          borderRadius: radius.pill,
          paddingHorizontal: space.xl,
          height: 48,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 8,
        }}
      >
        <Icon name="scan-barcode" size={20} color={palette.ink} />
        <Txt variant="bodyStrong" color={palette.ink}>
          {t.emptyCta}
        </Txt>
      </PressableScale>
    </Card>
  );
}
