import { useMemo } from 'react';

import { insights } from '@/data/api';
import type { Insights, ScanEntry } from '@/data/types';
import { useHistory, useSettings } from '@/state/store';

export type Period = {
  /** The scans the numbers are about. */
  entries: ScanEntry[];
  /** 'month' = the calendar month so far; '30d' = the last 30 days (early in a month). */
  kind: 'month' | '30d';
  /** 0–11. */
  month: number;
  stats: Insights;
};

/**
 * "This month" for the basket tab and the story. Early in a month there is little to show, so with
 * fewer than five scans this month it looks at the last 30 days instead.
 */
export function usePeriod(): Period {
  const history = useHistory();
  const settings = useSettings();
  return useMemo(() => {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    const inMonth = history.filter((h) => new Date(h.at).getTime() >= monthStart);
    const since30 = now.getTime() - 30 * 86_400_000;
    const useMonth = inMonth.length >= 5;
    const entries = useMonth ? inMonth : history.filter((h) => new Date(h.at).getTime() >= since30);
    return { entries, kind: useMonth ? 'month' : '30d', month: now.getMonth(), stats: insights(entries, settings) };
  }, [history, settings]);
}
