import type { Lang } from '@/data/types';
import { groupDigits } from '@/i18n';

const NBSP = '\u00A0';

/** A whole number grouped the way each language writes it: "1 220" (no-break spaces) or "1,220". */
export function num(n: number, lang: Lang): string {
  return groupDigits(Math.abs(n), lang === 'hu' ? NBSP : ',');
}

/** The currency unit on its own, for a big number with a small unit beside it ("1 220 Ft", "HUF 1,220"). */
export function hufUnit(lang: Lang): { unit: string; before: boolean } {
  return lang === 'hu' ? { unit: 'Ft', before: false } : { unit: 'HUF', before: true };
}

/** "rgba(…)" from a #RRGGBB hex. */
export function alpha(hex: string, a: number): string {
  const n = parseInt(hex.slice(1, 7), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

export const MONTHS: Record<Lang, string[]> = {
  hu: ['január', 'február', 'március', 'április', 'május', 'június', 'július', 'augusztus', 'szeptember', 'október', 'november', 'december'],
  en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
};

const MONTH_IN = [
  'januárban',
  'februárban',
  'márciusban',
  'áprilisban',
  'májusban',
  'júniusban',
  'júliusban',
  'augusztusban',
  'szeptemberben',
  'októberben',
  'novemberben',
  'decemberben',
];

/** "októberben", "áprilisban": the month with the right suffix. */
export function monthIn(month: number): string {
  return MONTH_IN[month];
}

export function capitalise(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** Short weekday names by Date.getDay() (0 = Sunday). */
export const WEEKDAY_SHORT: Record<Lang, string[]> = {
  hu: ['V', 'H', 'K', 'Sze', 'Cs', 'P', 'Szo'],
  en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
};

/** "csütörtökönként" / "Thursdays", by Date.getDay(). */
export const WEEKDAY_EVERY: Record<Lang, string[]> = {
  hu: ['vasárnaponként', 'hétfőnként', 'keddenként', 'szerdánként', 'csütörtökönként', 'péntekenként', 'szombatonként'],
  en: ['Sundays', 'Mondays', 'Tuesdays', 'Wednesdays', 'Thursdays', 'Fridays', 'Saturdays'],
};

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

/** "ma, 19:42" / "tegnap, 8:05" / "3 napja" (and the English forms). */
export function whenText(iso: string, lang: Lang, now: Date = new Date()): string {
  const d = new Date(iso);
  const day0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const dayD = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const days = Math.round((day0 - dayD) / 86_400_000);
  const time = `${d.getHours()}:${pad(d.getMinutes())}`;
  if (lang === 'hu') {
    if (days <= 0) return `ma, ${time}`;
    if (days === 1) return `tegnap, ${time}`;
    return `${days} napja`;
  }
  if (days <= 0) return `today, ${time}`;
  if (days === 1) return `yesterday, ${time}`;
  return `${days} days ago`;
}
