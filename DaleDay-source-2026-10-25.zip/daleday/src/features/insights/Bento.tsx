import { LinearGradient } from 'expo-linear-gradient';
import { useId, type ReactNode } from 'react';
import { View } from 'react-native';
import Animated, { FadeInDown, ZoomIn } from 'react-native-reanimated';
import Svg, { Circle, Defs, LinearGradient as SvgGradient, Stop } from 'react-native-svg';

import type { Insights } from '@/data/types';
import { useLang, useT } from '@/i18n';
import { font, gradients, palette, radius, shadow, space } from '@/theme/tokens';
import { Icon, Txt, useTheme } from '@/ui';
import { alpha, hufUnit, num } from './format';
import { strings } from './strings';
import { useCountUp } from './useCountUp';

type TileProps = { stats: Insights; width: number; reduced: boolean; delay: number };

const TILE_H = 172;

function Shell({ children, width, height, delay, reduced, gradient }: {
  children: ReactNode;
  width: number;
  height?: number;
  delay: number;
  reduced: boolean;
  gradient?: readonly [string, string, ...string[]];
}) {
  const { c, isDark } = useTheme();
  const base = {
    width,
    height,
    borderRadius: radius.lg,
    overflow: 'hidden' as const,
    backgroundColor: c.surface,
    borderWidth: isDark && !gradient ? 1 : 0,
    borderColor: c.border,
    ...(isDark ? null : shadow.card),
  };
  return (
    <Animated.View entering={reduced ? undefined : FadeInDown.delay(delay).springify().damping(18)} style={base}>
      {gradient ? (
        <LinearGradient colors={gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ flex: 1, padding: space.lg }}>
          {children}
        </LinearGradient>
      ) : (
        <View style={{ flex: 1, padding: space.lg }}>{children}</View>
      )}
    </Animated.View>
  );
}

/** A big display number with a smaller unit beside it. */
function BigNumber({ value, unit, unitBefore, color, size = 40 }: {
  value: string;
  unit?: string;
  /** English money reads "HUF 1,220", so the unit leads. */
  unitBefore?: boolean;
  color: string;
  size?: number;
}) {
  const u = unit ? (
    <Txt style={{ fontFamily: font.displayBold, fontSize: size * 0.45, lineHeight: size * 0.6, color }}>{unit}</Txt>
  ) : null;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 4 }}>
      {unitBefore ? u : null}
      <Txt style={{ fontFamily: font.display, fontSize: size, lineHeight: size * 1.05, letterSpacing: -size * 0.03, color }}>{value}</Txt>
      {unitBefore ? null : u}
    </View>
  );
}

function IconDot({ name, bg, fg }: { name: string; bg: string; fg: string }) {
  return (
    <View style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: bg, alignItems: 'center', justifyContent: 'center' }}>
      <Icon name={name} size={18} color={fg} strokeWidth={2.2} />
    </View>
  );
}

export function SavedTile({ stats, width, reduced, delay }: TileProps) {
  const t = useT(strings);
  const lang = useLang();
  const n = useCountUp(stats.savedHuf, { reduced, delay: delay + 150 });
  const money = hufUnit(lang);
  return (
    <Shell width={width} height={TILE_H} delay={delay} reduced={reduced} gradient={gradients.sprout}>
      <IconDot name="tag" bg="rgba(16,35,28,0.1)" fg={palette.ink} />
      <View style={{ flex: 1 }} />
      <BigNumber value={num(n, lang)} unit={money.unit} unitBefore={money.before} color={palette.ink} size={36} />
      <Txt variant="small" color={palette.ink} style={{ opacity: 0.8 }} numberOfLines={2}>
        {t.savedLine}
      </Txt>
    </Shell>
  );
}

export function SwapsTile({ stats, width, reduced, delay }: TileProps) {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const n = useCountUp(stats.swaps, { reduced, delay: delay + 150, duration: 800 });
  return (
    <Shell width={width} height={TILE_H} delay={delay} reduced={reduced}>
      <IconDot name="arrow-left-right" bg={alpha(palette.lilac, isDark ? 0.25 : 0.35)} fg={isDark ? palette.lilac : palette.ink} />
      <View style={{ flex: 1 }} />
      <BigNumber value={String(Math.round(n))} unit={t.swapsUnit} color={c.text} size={36} />
      <Txt variant="small" muted numberOfLines={2}>
        {t.swapsLine}
      </Txt>
    </Shell>
  );
}

/** One sugar cube, drawn: a white block with a shaded side and a lit top edge. */
function Cube({ size, dark }: { size: number; dark: boolean }) {
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.2,
        backgroundColor: dark ? '#EDEBE4' : palette.white,
        overflow: 'hidden',
        shadowColor: palette.ink,
        shadowOpacity: dark ? 0 : 0.14,
        shadowRadius: 2,
        shadowOffset: { width: 0, height: 1.5 },
      }}
    >
      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: size * 0.28, backgroundColor: 'rgba(16,35,28,0.09)' }} />
      <View style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: size * 0.24, backgroundColor: 'rgba(16,35,28,0.05)' }} />
      <View style={{ position: 'absolute', left: size * 0.18, top: size * 0.18, width: size * 0.18, height: size * 0.18, borderRadius: size, backgroundColor: 'rgba(16,35,28,0.06)' }} />
    </View>
  );
}

export function SugarTile({ stats, width, reduced, delay }: TileProps) {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const spoons = stats.sugarSpoons;
  const n = useCountUp(spoons, { reduced, delay: delay + 150 });
  // A unit chart: each cube is a fixed number of teaspoons, so the pile stays honest.
  const per = spoons <= 12 ? 1 : spoons <= 60 ? 5 : 10;
  const cubes = Math.min(24, Math.ceil(spoons / per));
  const size = 20;
  const gap = 5;
  const cols = 6;
  const gridW = cols * size + (cols - 1) * gap;
  return (
    <Shell
      width={width}
      delay={delay}
      reduced={reduced}
      gradient={[alpha(palette.sun, isDark ? 0.16 : 0.34), alpha(palette.sun, isDark ? 0.03 : 0.1)]}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg }}>
        <View style={{ flex: 1, gap: 2 }}>
          <IconDot name="candy" bg={isDark ? alpha(palette.sun, 0.22) : 'rgba(255,255,255,0.7)'} fg={isDark ? palette.sun : palette.ink} />
          <View style={{ height: space.md }} />
          <BigNumber value={String(Math.round(n))} color={c.text} size={40} />
          <Txt variant="small" muted>
            {spoons > 0 ? t.sugarLine : t.sugarNone}
          </Txt>
        </View>
        {cubes > 0 ? (
          <View style={{ width: gridW, alignItems: 'flex-end', gap: space.sm }}>
            <View style={{ width: gridW, flexDirection: 'row', flexWrap: 'wrap-reverse', gap }}>
              {Array.from({ length: cubes }, (_, i) => (
                <Animated.View key={i} entering={reduced ? undefined : FadeInDown.delay(delay + 300 + i * 55).springify().damping(11)}>
                  <Cube size={size} dark={isDark} />
                </Animated.View>
              ))}
            </View>
            <Txt variant="tiny" faint>
              {t.sugarKey(per)}
            </Txt>
          </View>
        ) : null}
      </View>
    </Shell>
  );
}

export function PalmTile({ stats, width, reduced, delay }: TileProps) {
  const t = useT(strings);
  const { c, isDark } = useTheme();
  const pct = Math.round(stats.palmFreeShare * 100);
  const shown = useCountUp(pct, { reduced, delay: delay + 200, duration: 1200 });
  const gid = `palm${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const size = 78;
  const stroke = 9;
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  return (
    <Shell width={width} height={TILE_H + 24} delay={delay} reduced={reduced}>
      <View style={{ width: size, height: size }}>
        <View style={{ position: 'absolute', inset: 0, transform: [{ rotate: '-90deg' }] }}>
          <Svg width={size} height={size}>
            <Defs>
              <SvgGradient id={gid} x1="0" y1="0" x2="1" y2="1">
                <Stop offset="0" stopColor={palette.lime} />
                <Stop offset="1" stopColor={palette.great} />
              </SvgGradient>
            </Defs>
            <Circle cx={size / 2} cy={size / 2} r={r} stroke={isDark ? c.surfaceAlt : c.bgAlt} strokeWidth={stroke} fill="none" />
            {shown > 0.5 ? (
              <Circle
                cx={size / 2}
                cy={size / 2}
                r={r}
                stroke={`url(#${gid})`}
                strokeWidth={stroke}
                strokeLinecap="round"
                fill="none"
                strokeDasharray={`${(circ * shown) / 100} ${circ}`}
              />
            ) : null}
          </Svg>
        </View>
        <View style={{ position: 'absolute', inset: 0, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="tree-palm" size={24} color={c.text} />
        </View>
      </View>
      <View style={{ flex: 1 }} />
      <BigNumber value={String(Math.round(shown))} unit="%" color={c.text} size={34} />
      <Txt variant="small" muted numberOfLines={3}>
        {t.palmLine}
      </Txt>
    </Shell>
  );
}

export function StreakTile({ stats, width, reduced, delay }: TileProps) {
  const t = useT(strings);
  const lang = useLang();
  const { c, isDark } = useTheme();
  const n = useCountUp(stats.streakDays, { reduced, delay: delay + 150, duration: 700 });
  const today = new Date().getDay();
  const days = lang === 'hu' ? ['V', 'H', 'K', 'Sze', 'Cs', 'P', 'Szo'] : ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  return (
    <Shell
      width={width}
      height={TILE_H + 24}
      delay={delay}
      reduced={reduced}
      gradient={[alpha(palette.tangerine, isDark ? 0.2 : 0.2), alpha(palette.sun, isDark ? 0.04 : 0.1)]}
    >
      <Animated.View entering={reduced ? undefined : ZoomIn.delay(delay + 250).springify().damping(9)}>
        <View
          style={{
            width: 48,
            height: 48,
            borderRadius: 24,
            backgroundColor: alpha(palette.tangerine, isDark ? 0.3 : 0.22),
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name="flame" size={28} color={palette.tangerine} strokeWidth={2.4} />
        </View>
      </Animated.View>
      <View style={{ flex: 1 }} />
      {stats.streakDays > 0 ? (
        <>
          <BigNumber value={String(Math.round(n))} unit={t.streakUnit} color={c.text} size={34} />
          <Txt variant="small" muted numberOfLines={2}>
            {t.streakLine}
          </Txt>
        </>
      ) : (
        <Txt variant="small" muted numberOfLines={3}>
          {t.streakNone}
        </Txt>
      )}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: space.md }}>
        {stats.weekly.map((v, i) => {
          const dow = (today - 6 + i + 7) % 7;
          return (
            <View key={i} style={{ alignItems: 'center', gap: 3 }}>
              <View
                style={{
                  width: 11,
                  height: 11,
                  borderRadius: 6,
                  backgroundColor: v > 0 ? palette.tangerine : 'transparent',
                  borderWidth: v > 0 ? 0 : 1.5,
                  borderColor: c.textFaint,
                }}
              />
              <Txt style={{ fontFamily: font.bodySemi, fontSize: 9, lineHeight: 11, color: c.textFaint }}>{days[dow]}</Txt>
            </View>
          );
        })}
      </View>
    </Shell>
  );
}
