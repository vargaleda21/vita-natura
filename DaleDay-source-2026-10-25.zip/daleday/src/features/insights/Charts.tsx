import { useEffect, useState } from 'react';
import { Pressable, View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withDelay, withSpring, withTiming } from 'react-native-reanimated';
import Svg, { Circle } from 'react-native-svg';

import { CRITERIA } from '@/data/api';
import type { Insights, Verdict } from '@/data/types';
import { useLang, useT, useTr } from '@/i18n';
import { font, palette, radius, space, springs, verdictColor } from '@/theme/tokens';
import { Card, Icon, Txt, useTheme, VERDICT_LABEL } from '@/ui';
import { alpha, WEEKDAY_SHORT } from './format';
import { strings } from './strings';

function Title({ title, sub }: { title: string; sub?: string }) {
  return (
    <View style={{ gap: 2, marginBottom: space.lg }}>
      <Txt variant="h3">{title}</Txt>
      {sub ? (
        <Txt variant="small" muted>
          {sub}
        </Txt>
      ) : null}
    </View>
  );
}

// ── Weekly columns ──────────────────────────────────────────────────────────

const CHART_H = 112;

function Column({
  value,
  max,
  index,
  label,
  isToday,
  selected,
  showValue,
  onPress,
  reduced,
  a11y,
}: {
  value: number;
  max: number;
  index: number;
  label: string;
  isToday: boolean;
  selected: boolean;
  showValue: boolean;
  onPress: () => void;
  reduced: boolean;
  a11y: string;
}) {
  const { c, isDark } = useTheme();
  const h = value > 0 ? Math.max(8, (value / max) * CHART_H) : 3;
  const grow = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    if (!reduced) grow.set(withDelay(250 + index * 70, withSpring(1, springs.soft)));
  }, [grow, index, reduced]);
  // The bar rises from the baseline: it slides up inside a clipped slot (transform only).
  const anim = useAnimatedStyle(() => ({ transform: [{ translateY: (1 - grow.get()) * (h + 4) }] }));
  const bar = isDark ? palette.lime : palette.forest;
  const color = value === 0 ? c.border : isToday || selected ? bar : alpha(bar, isDark ? 0.55 : 0.5);
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={a11y}
      style={{ flex: 1, alignItems: 'center' }}
      hitSlop={4}
    >
      <View style={{ height: CHART_H + 22, justifyContent: 'flex-end', alignItems: 'center' }}>
        {showValue || selected ? (
          <Txt style={{ fontFamily: font.bodyBold, fontSize: 12, lineHeight: 16, color: c.text, marginBottom: 4 }}>{value}</Txt>
        ) : null}
        <View style={{ height: h, width: 22, overflow: 'hidden' }}>
          <Animated.View
            style={[
              {
                height: h,
                width: 22,
                backgroundColor: color,
                borderTopLeftRadius: value > 0 ? 4 : 2,
                borderTopRightRadius: value > 0 ? 4 : 2,
              },
              anim,
            ]}
          />
        </View>
      </View>
      <View style={{ height: 1, alignSelf: 'stretch', backgroundColor: c.border }} />
      <Txt
        style={{
          marginTop: 6,
          fontFamily: isToday ? font.bodyBold : font.bodyMedium,
          fontSize: 11,
          lineHeight: 14,
          color: isToday ? c.text : c.textFaint,
        }}
      >
        {label}
      </Txt>
    </Pressable>
  );
}

export function WeekChart({ stats, reduced }: { stats: Insights; reduced: boolean }) {
  const t = useT(strings);
  const lang = useLang();
  const [selected, setSelected] = useState<number | null>(null);
  const max = Math.max(1, ...stats.weekly);
  const maxIndex = stats.weekly.lastIndexOf(Math.max(...stats.weekly));
  const today = new Date().getDay();
  return (
    <Card>
      <Title title={t.weekTitle} sub={t.weekSub} />
      <View style={{ flexDirection: 'row' }}>
        {stats.weekly.map((v, i) => {
          const dow = (today - 6 + i + 7) % 7;
          const isToday = i === 6;
          const label = isToday ? t.today : WEEKDAY_SHORT[lang][dow];
          return (
            <Column
              key={i}
              value={v}
              max={max}
              index={i}
              label={label}
              isToday={isToday}
              selected={selected === i}
              showValue={selected === null && (isToday || i === maxIndex)}
              onPress={() => setSelected((s) => (s === i ? null : i))}
              reduced={reduced}
              a11y={t.weekA11y(label, v)}
            />
          );
        })}
      </View>
    </Card>
  );
}

// ── Verdict donut ───────────────────────────────────────────────────────────

const ORDER: Verdict[] = ['great', 'okay', 'avoid'];

export function VerdictDonut({ stats, reduced }: { stats: Insights; reduced: boolean }) {
  const t = useT(strings);
  const lang = useLang();
  const { c } = useTheme();
  const total = ORDER.reduce((s, v) => s + stats.byVerdict[v], 0);
  const size = 132;
  const stroke = 20;
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const gap = total > 0 && ORDER.filter((v) => stats.byVerdict[v] > 0).length > 1 ? 3 : 0;

  const spin = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    if (!reduced) spin.set(withDelay(200, withTiming(1, { duration: 900 })));
  }, [spin, reduced]);
  const anim = useAnimatedStyle(() => ({
    opacity: spin.get(),
    transform: [{ rotate: `${-90 - (1 - spin.get()) * 120}deg` }, { scale: 0.85 + 0.15 * spin.get() }],
  }));

  const arcs = ORDER.map((v, i) => {
    const n = stats.byVerdict[v];
    const len = total > 0 ? (n / total) * circ : 0;
    const start = ORDER.slice(0, i).reduce((sum, w) => sum + (total > 0 ? (stats.byVerdict[w] / total) * circ : 0), 0);
    return { v, n, dash: Math.max(0, len - gap), offset: -start };
  });

  return (
    <Card>
      <Title title={t.donutTitle} sub={t.donutSub} />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.xl }}>
        <View style={{ width: size, height: size }}>
          <Animated.View style={[{ position: 'absolute', inset: 0 }, anim]}>
            <Svg width={size} height={size}>
              <Circle cx={size / 2} cy={size / 2} r={r} stroke={c.border} strokeWidth={stroke} fill="none" />
              {arcs.map((a) =>
                a.dash > 0 ? (
                  <Circle
                    key={a.v}
                    cx={size / 2}
                    cy={size / 2}
                    r={r}
                    stroke={verdictColor[a.v]}
                    strokeWidth={stroke}
                    fill="none"
                    strokeDasharray={`${a.dash} ${circ}`}
                    strokeDashoffset={a.offset}
                  />
                ) : null,
              )}
            </Svg>
          </Animated.View>
          <View style={{ position: 'absolute', inset: 0, alignItems: 'center', justifyContent: 'center' }}>
            <Txt style={{ fontFamily: font.display, fontSize: 32, lineHeight: 34, letterSpacing: -1, color: c.text }}>{total}</Txt>
            <Txt variant="tiny" faint>
              {t.donutCenter}
            </Txt>
          </View>
        </View>
        <View style={{ flex: 1, gap: space.md }}>
          {arcs.map((a) => (
            <View key={a.v} style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
              <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: verdictColor[a.v] }} />
              <Txt variant="small" style={{ flex: 1 }} numberOfLines={1}>
                {VERDICT_LABEL[a.v][lang]}
              </Txt>
              <Txt variant="bodyStrong">{a.n}</Txt>
              <Txt variant="small" faint style={{ width: 38, textAlign: 'right' }}>
                {total > 0 ? `${Math.round((a.n / total) * 100)}%` : '–'}
              </Txt>
            </View>
          ))}
        </View>
      </View>
    </Card>
  );
}

// ── Top criteria ────────────────────────────────────────────────────────────

function Meter({ ratio, delay, reduced }: { ratio: number; delay: number; reduced: boolean }) {
  const { c, isDark } = useTheme();
  const [w, setW] = useState(0);
  const p = useSharedValue(reduced ? 1 : 0);
  useEffect(() => {
    if (w > 0 && !reduced) p.set(withDelay(delay, withSpring(1, springs.soft)));
  }, [w, delay, reduced, p]);
  const fillW = Math.max(6, ratio * w);
  const anim = useAnimatedStyle(() => ({ transform: [{ translateX: -(1 - p.get()) * fillW }] }));
  return (
    <View
      onLayout={(e) => setW(e.nativeEvent.layout.width)}
      style={{ height: 6, borderRadius: 3, backgroundColor: isDark ? c.surfaceAlt : c.bgAlt, overflow: 'hidden' }}
    >
      {w > 0 ? (
        <Animated.View style={[{ width: fillW, height: 6, borderRadius: 3, backgroundColor: palette.tangerine }, anim]} />
      ) : null}
    </View>
  );
}

export function TopHits({ stats, reduced }: { stats: Insights; reduced: boolean }) {
  const t = useT(strings);
  const tr = useTr();
  const { c, isDark } = useTheme();
  const top = (stats.topHits ?? []).slice(0, 4);
  const max = Math.max(1, ...top.map((h) => h.count));
  return (
    <Card>
      <Title title={t.topTitle} sub={top.length ? t.topSub : undefined} />
      {top.length === 0 ? (
        <Txt muted>{t.topNone}</Txt>
      ) : (
        <View style={{ gap: space.lg }}>
          {top.map((h, i) => {
            const cr = CRITERIA[h.key];
            return (
              <View key={h.key} style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
                <View
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: radius.md,
                    backgroundColor: i === 0 ? alpha(palette.tangerine, isDark ? 0.25 : 0.18) : isDark ? c.surfaceAlt : c.bgAlt,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name={cr.icon} size={20} color={i === 0 ? palette.tangerine : c.text} />
                </View>
                <View style={{ flex: 1, gap: 6 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: space.sm }}>
                    <Txt variant="bodyStrong" style={{ flex: 1 }} numberOfLines={1}>
                      {tr(cr.label)}
                    </Txt>
                    <Txt variant="small" muted>
                      {t.topCount(h.count)}
                    </Txt>
                  </View>
                  <Meter ratio={h.count / max} delay={300 + i * 90} reduced={reduced} />
                </View>
              </View>
            );
          })}
        </View>
      )}
    </Card>
  );
}
