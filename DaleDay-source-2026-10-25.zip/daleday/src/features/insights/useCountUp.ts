import { useEffect, useState } from 'react';

/**
 * Counts from 0 up to `to` with an ease-out, on one short requestAnimationFrame loop.
 * With `run` false it waits at 0; with reduced motion it shows the final value at once.
 */
export function useCountUp(to: number, { duration = 1100, delay = 0, run = true, reduced = false } = {}): number {
  // The value remembers which target it was counted for, so a new target starts again from 0.
  const [count, setCount] = useState({ to: Number.NaN, value: 0 });
  useEffect(() => {
    if (reduced || !run) return;
    let raf = 0;
    let start = 0;
    const timer = setTimeout(() => {
      const step = (now: number) => {
        if (!start) start = now;
        const t = Math.min(1, (now - start) / duration);
        setCount({ to, value: to * (1 - Math.pow(1 - t, 3)) });
        if (t < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    }, delay);
    return () => {
      clearTimeout(timer);
      cancelAnimationFrame(raf);
    };
  }, [to, duration, delay, run, reduced]);
  if (reduced) return to;
  if (!run || count.to !== to) return 0;
  return count.value;
}
