import { LinearGradient } from 'expo-linear-gradient';
import { useId, type ReactNode } from 'react';
import { Text, useWindowDimensions, View } from 'react-native';
import Animated, {
  Extrapolation,
  interpolate,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  type SharedValue,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Defs, RadialGradient, Rect, Stop } from 'react-native-svg';

import { useLang, useT } from '@/i18n';
import { font, gradients, palette, radius, space } from '@/theme/tokens';
import { Txt, useTheme } from '@/ui';
import { PalmTile, SavedTile, StreakTile, SugarTile, SwapsTile } from './Bento';
import { TopHits, VerdictDonut, WeekChart } from './Charts';
import { capitalise, MONTHS } from './format';
import { usePeriod } from './period';
import { EmptyBasket, RecentList, StoryCard } from './Recent';
import { strings } from './strings';
import { useCountUp } from './useCountUp';

const MAX_W = 480;
const PAD = space.lg;
const GAP = space.md;

/** A soft round light: a radial gradient, never a blur filter. */
function Glow({ size, color, opacity }: { size: number; color: string; opacity: number }) {
  const id = `g${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  return (
    <Svg width={size} height={size} pointerEvents="none">
      <Defs>
        <RadialGradient id={id} cx="50%" cy="50%" rx="50%" ry="50%">
          <Stop offset="0" stopColor={color} stopOpacity={opacity} />
          <Stop offset="0.6" stopColor={color} stopOpacity={opacity * 0.35} />
          <Stop offset="1" stopColor={color} stopOpacity={0} />
        </RadialGradient>
      </Defs>
      <Rect x={0} y={0} width={size} height={size} fill={`url(#${id})`} />
    </Svg>
  );
}

/** One parallax layer: it moves at `speed` of the scroll (0 = pinned to the page, 1 = pinned to the screen). */
function Layer({ y, speed, style, children }: { y: SharedValue<number>; speed: number; style?: object; children: ReactNode }) {
  const anim = useAnimatedStyle(() => ({ transform: [{ translateY: Math.max(0, y.get()) * speed }] }));
  return (
    <Animated.View pointerEvents="none" style={[{ position: 'absolute' }, style, anim]}>
      {children}
    </Animated.View>
  );
}

function Bubble({ emoji, size, light }: { emoji: string; size: number; light: boolean }) {
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: light ? 'rgba(255,255,255,0.45)' : 'rgba(255,255,255,0.08)',
        borderWidth: 1,
        borderColor: light ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.14)',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text style={{ fontSize: size * 0.48 }}>{emoji}</Text>
    </View>
  );
}

function Hero({ y, height, count, line, pill, reduced }: {
  y: SharedValue<number>;
  height: number;
  count: number;
  line: string;
  pill: string;
  reduced: boolean;
}) {
  const t = useT(strings);
  const { isDark, c } = useTheme();
  const insets = useSafeAreaInsets();
  const ink = isDark ? c.text : palette.ink;
  const n = useCountUp(count, { reduced, delay: 200, duration: 1300 });

  const bg = useAnimatedStyle(() => {
    const v = y.get();
    return {
      transform: [
        { translateY: v > 0 ? v * 0.5 : v },
        { scale: interpolate(v, [-200, 0], [1.35, 1], Extrapolation.CLAMP) },
      ],
    };
  });
  const front = useAnimatedStyle(() => {
    const v = y.get();
    return {
      opacity: interpolate(v, [0, height * 0.55], [1, 0], Extrapolation.CLAMP),
      transform: [{ translateY: v > 0 ? v * 0.25 : 0 }],
    };
  });

  return (
    <View style={{ height, overflow: 'hidden' }}>
      <Animated.View style={[{ position: 'absolute', left: 0, right: 0, top: 0, height: height + 40 }, bg]}>
        <LinearGradient
          colors={isDark ? gradients.heroDark : gradients.hero}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ flex: 1 }}
        />
      </Animated.View>
      <Layer y={y} speed={0.7} style={{ right: -90, top: -70 }}>
        <Glow size={300} color={isDark ? palette.lime : palette.white} opacity={isDark ? 0.18 : 0.75} />
      </Layer>
      <Layer y={y} speed={0.35} style={{ left: -120, bottom: -40 }}>
        <Glow size={280} color={isDark ? palette.mint : palette.sun} opacity={isDark ? 0.12 : 0.35} />
      </Layer>
      <Layer y={y} speed={0.15} style={{ right: 26, top: insets.top + 96 }}>
        <Bubble emoji="🍓" size={52} light={!isDark} />
      </Layer>
      <Layer y={y} speed={0.45} style={{ right: 84, top: insets.top + 168 }}>
        <Bubble emoji="🥛" size={40} light={!isDark} />
      </Layer>
      <Layer y={y} speed={0.6} style={{ right: 18, top: insets.top + 196 }}>
        <Bubble emoji="🌾" size={34} light={!isDark} />
      </Layer>

      <Animated.View style={[{ paddingTop: insets.top + space.md, paddingHorizontal: PAD }, front]}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Txt variant="h1" color={ink}>
            {t.title}
          </Txt>
          <View
            style={{
              backgroundColor: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(255,255,255,0.6)',
              borderWidth: 1,
              borderColor: isDark ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.9)',
              borderRadius: radius.pill,
              paddingHorizontal: space.md,
              paddingVertical: 6,
            }}
          >
            <Txt variant="small" color={ink}>
              {pill}
            </Txt>
          </View>
        </View>
        <Txt
          accessibilityLabel={`${count}`}
          style={{ fontFamily: font.display, fontSize: 104, lineHeight: 108, letterSpacing: -4, color: ink, marginTop: space.xl }}
        >
          {Math.round(n)}
        </Txt>
        <Txt variant="h3" color={ink} style={{ maxWidth: 250, opacity: 0.85 }}>
          {line}
        </Txt>
      </Animated.View>
    </View>
  );
}

export function InsightsScreen() {
  const t = useT(strings);
  const lang = useLang();
  const { c } = useTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const reduced = useReducedMotion();
  const period = usePeriod();
  const { stats, entries } = period;

  const colW = Math.min(width, MAX_W);
  const inner = colW - PAD * 2;
  const half = (inner - GAP) / 2;
  const heroH = insets.top + 290;

  const y = useSharedValue(0);
  const onScroll = useAnimatedScrollHandler((e) => {
    y.set(e.contentOffset.y);
  });
  const bar = useAnimatedStyle(() => ({
    opacity: interpolate(y.get(), [heroH - 150, heroH - 100], [0, 1], Extrapolation.CLAMP),
  }));

  const monthName = MONTHS[lang][period.month];
  const line = period.kind === 'month' ? t.heroMonth(period.month) : t.hero30;
  const pill = period.kind === 'month' ? capitalise(monthName) : t.heroPill30;
  const empty = entries.length === 0;

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <View style={{ flex: 1, width: '100%', maxWidth: MAX_W, alignSelf: 'center' }}>
        <Animated.ScrollView onScroll={onScroll} scrollEventThrottle={16} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 130 }}>
          <Hero y={y} height={heroH} count={stats.scans} line={line} pill={pill} reduced={reduced} />
          <View
            style={{
              marginTop: -28,
              borderTopLeftRadius: 28,
              borderTopRightRadius: 28,
              backgroundColor: c.bg,
              paddingTop: space.xl,
              paddingHorizontal: PAD,
              gap: GAP,
            }}
          >
            {empty ? (
              <EmptyBasket />
            ) : (
              <>
                <View style={{ flexDirection: 'row', gap: GAP }}>
                  <SavedTile stats={stats} width={half} reduced={reduced} delay={80} />
                  <SwapsTile stats={stats} width={half} reduced={reduced} delay={140} />
                </View>
                <SugarTile stats={stats} width={inner} reduced={reduced} delay={200} />
                <View style={{ flexDirection: 'row', gap: GAP }}>
                  <PalmTile stats={stats} width={half} reduced={reduced} delay={260} />
                  <StreakTile stats={stats} width={half} reduced={reduced} delay={320} />
                </View>
                <View style={{ height: space.sm }} />
                <StoryCard month={period.month} reduced={reduced} />
                <View style={{ height: space.sm }} />
                <WeekChart stats={stats} reduced={reduced} />
                <VerdictDonut stats={stats} reduced={reduced} />
                <TopHits stats={stats} reduced={reduced} />
                <RecentList entries={entries} />
              </>
            )}
          </View>
        </Animated.ScrollView>

        {/* The compact bar that takes over once the hero has scrolled away. */}
        <Animated.View
          pointerEvents="none"
          style={[
            {
              position: 'absolute',
              left: 0,
              right: 0,
              top: 0,
              paddingTop: insets.top,
              height: insets.top + 52,
              backgroundColor: c.bg,
              borderBottomWidth: 1,
              borderBottomColor: c.border,
              alignItems: 'center',
              justifyContent: 'center',
            },
            bar,
          ]}
        >
          <Txt variant="h3">{t.title}</Txt>
        </Animated.View>
      </View>
    </View>
  );
}
