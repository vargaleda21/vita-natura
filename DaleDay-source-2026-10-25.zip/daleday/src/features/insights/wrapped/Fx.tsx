import { useEffect } from 'react';
import { Text, View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withDelay,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';

import { palette } from '@/theme/tokens';

// Playful moving shapes for the story slides. Transforms only, so a phone can keep up.

export type Floater = {
  kind: 'circle' | 'ring' | 'square' | 'pill' | 'emoji' | 'spark';
  /** Position as a fraction of the slide (0–1); the shape's centre sits there. */
  x: number;
  y: number;
  size: number;
  color?: string;
  emoji?: string;
  /** Milliseconds for one swing; different speeds make the depth. */
  period: number;
  /** How far it drifts, in px. */
  dx?: number;
  dy?: number;
  /** Degrees it turns over one swing. */
  spin?: number;
  opacity?: number;
};

function Shape({ f }: { f: Floater }) {
  const s = f.size;
  const color = f.color ?? palette.white;
  switch (f.kind) {
    case 'circle':
      return <View style={{ width: s, height: s, borderRadius: s / 2, backgroundColor: color }} />;
    case 'ring':
      return <View style={{ width: s, height: s, borderRadius: s / 2, borderWidth: Math.max(3, s * 0.14), borderColor: color }} />;
    case 'square':
      return <View style={{ width: s, height: s, borderRadius: s * 0.22, backgroundColor: color }} />;
    case 'pill':
      return <View style={{ width: s * 2.2, height: s, borderRadius: s / 2, backgroundColor: color }} />;
    case 'spark':
      return (
        <Text style={{ fontSize: s, lineHeight: s * 1.1, color }} allowFontScaling={false}>
          ✦
        </Text>
      );
    default:
      return (
        <Text style={{ fontSize: s, lineHeight: s * 1.2 }} allowFontScaling={false}>
          {f.emoji}
        </Text>
      );
  }
}

function Float({ f, w, h, reduced }: { f: Floater; w: number; h: number; reduced: boolean }) {
  const t = useSharedValue(0);
  useEffect(() => {
    if (reduced) return;
    t.set(withRepeat(withTiming(1, { duration: f.period, easing: Easing.inOut(Easing.sin) }), -1, true));
  }, [t, f.period, reduced]);
  const anim = useAnimatedStyle(() => {
    const k = t.get() - 0.5;
    return {
      transform: [{ translateX: k * 2 * (f.dx ?? 0) }, { translateY: k * 2 * (f.dy ?? 14) }, { rotate: `${k * (f.spin ?? 0)}deg` }],
    };
  });
  const width = f.kind === 'pill' ? f.size * 2.2 : f.size;
  return (
    <Animated.View
      pointerEvents="none"
      style={[{ position: 'absolute', left: f.x * w - width / 2, top: f.y * h - f.size / 2, opacity: f.opacity ?? 1 }, anim]}
    >
      <Shape f={f} />
    </Animated.View>
  );
}

export function Floaters({ items, width, height }: { items: Floater[]; width: number; height: number }) {
  const reduced = useReducedMotion();
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: 0, top: 0, width, height, overflow: 'hidden' }}>
      {items.map((f, i) => (
        <Float key={i} f={f} w={width} h={height} reduced={reduced} />
      ))}
    </View>
  );
}

/** A drawn sugar cube: white, a shaded side, a lit top. */
export function SugarCube({ size }: { size: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size * 0.18, backgroundColor: palette.white, overflow: 'hidden' }}>
      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: size * 0.3, backgroundColor: 'rgba(16,35,28,0.1)' }} />
      <View style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: size * 0.25, backgroundColor: 'rgba(16,35,28,0.06)' }} />
      <View
        style={{
          position: 'absolute',
          left: size * 0.2,
          top: size * 0.22,
          width: size * 0.14,
          height: size * 0.14,
          borderRadius: size,
          backgroundColor: 'rgba(16,35,28,0.08)',
        }}
      />
    </View>
  );
}

function Falling({ x, size, duration, delay, spin, height }: { x: number; size: number; duration: number; delay: number; spin: number; height: number }) {
  const reduced = useReducedMotion();
  const t = useSharedValue(reduced ? 0.5 : 0);
  useEffect(() => {
    if (reduced) return;
    t.set(withDelay(delay, withRepeat(withTiming(1, { duration, easing: Easing.in(Easing.quad) }), -1, false)));
  }, [t, duration, delay, reduced]);
  const anim = useAnimatedStyle(() => ({
    transform: [{ translateY: -size * 2 + t.get() * (height + size * 4) }, { rotate: `${t.get() * spin}deg` }],
  }));
  return (
    <Animated.View pointerEvents="none" style={[{ position: 'absolute', left: x, top: 0 }, anim]}>
      <SugarCube size={size} />
    </Animated.View>
  );
}

/** Sugar cubes falling past at different speeds, sizes and spins. */
export function SugarRain({ width, height, count = 16 }: { width: number; height: number; count?: number }) {
  const cubes = Array.from({ length: count }, (_, i) => {
    // A fixed scatter, so the rain looks the same every time and never clumps.
    const r = (n: number) => ((Math.sin((i + 1) * n) + 1) / 2) % 1;
    return {
      x: r(12.9898) * (width - 40) + 4,
      size: 18 + Math.round(r(78.233) * 22),
      duration: 2400 + Math.round(r(37.719) * 2600),
      delay: Math.round(r(93.989) * 2200),
      spin: (r(4.1414) - 0.5) * 540,
    };
  });
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: 0, top: 0, width, height, overflow: 'hidden' }}>
      {cubes.map((c, i) => (
        <Falling key={i} {...c} height={height} />
      ))}
    </View>
  );
}

/** Coins drifting slowly upwards. */
function Rising({ x, size, duration, delay, height }: { x: number; size: number; duration: number; delay: number; height: number }) {
  const reduced = useReducedMotion();
  const t = useSharedValue(reduced ? 0.5 : 0);
  useEffect(() => {
    if (reduced) return;
    t.set(withDelay(delay, withRepeat(withTiming(1, { duration, easing: Easing.linear }), -1, false)));
  }, [t, duration, delay, reduced]);
  const anim = useAnimatedStyle(() => ({
    opacity: t.get() < 0.1 ? t.get() * 10 : t.get() > 0.85 ? (1 - t.get()) / 0.15 : 1,
    // A coin flip without the mirrored back face: the width breathes between edge-on and full.
    transform: [{ translateY: height + size - t.get() * (height + size * 3) }, { scaleX: Math.max(0.12, Math.abs(Math.cos(t.get() * Math.PI * 4))) }],
  }));
  return (
    <Animated.View pointerEvents="none" style={[{ position: 'absolute', left: x, top: 0 }, anim]}>
      <View
        style={{
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: palette.sun,
          borderWidth: size * 0.1,
          borderColor: '#F0A92B',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text style={{ fontSize: size * 0.42, fontWeight: '800', color: '#B9741A' }} allowFontScaling={false}>
          Ft
        </Text>
      </View>
    </Animated.View>
  );
}

export function CoinRise({ width, height, count = 9 }: { width: number; height: number; count?: number }) {
  const coins = Array.from({ length: count }, (_, i) => {
    const r = (n: number) => ((Math.sin((i + 3) * n) + 1) / 2) % 1;
    return {
      x: r(12.9898) * (width - 50) + 6,
      size: 26 + Math.round(r(78.233) * 22),
      duration: 4200 + Math.round(r(37.719) * 3000),
      delay: Math.round(r(93.989) * 3000),
    };
  });
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: 0, top: 0, width, height, overflow: 'hidden' }}>
      {coins.map((c, i) => (
        <Rising key={i} {...c} height={height} />
      ))}
    </View>
  );
}
