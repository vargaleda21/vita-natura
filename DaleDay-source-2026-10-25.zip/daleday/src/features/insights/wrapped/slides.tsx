import type { ReactNode } from 'react';
import { Text, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, FadeInUp, ZoomIn } from 'react-native-reanimated';

import { CRITERIA, getProduct } from '@/data/api';
import type { Insights, Lang, ScanEntry } from '@/data/types';
import { formatHuf, useT, useTr } from '@/i18n';
import { font, palette, radius, space } from '@/theme/tokens';
import { Icon, PackArt, Txt } from '@/ui';
import { capitalise, hufUnit, MONTHS, num, WEEKDAY_EVERY } from '../format';
import { PERSONAS, strings, type PersonaKey } from '../strings';
import { useCountUp } from '../useCountUp';
import { CoinRise, Floaters, SugarRain, type Floater } from './Fx';

export type SlideKey = 'intro' | 'count' | 'avoid' | 'sugar' | 'money' | 'swap' | 'persona' | 'empty';

export type SlideDef = {
  key: SlideKey;
  colors: readonly [string, string, ...string[]];
  /** 'dark' = a dark background with light text. */
  tone: 'light' | 'dark';
};

export type SlideProps = {
  width: number;
  height: number;
  stats: Insights;
  entries: ScanEntry[];
  lang: Lang;
  month: number;
  reduced: boolean;
  /** Space kept free at the top (progress bars) and bottom (buttons). */
  top: number;
  bottom: number;
};

export function pickPersona(s: Insights): PersonaKey {
  if (s.scans === 0) return 'beginner';
  if (s.swaps >= 10) return 'swapper';
  if (s.sugarSpoons >= 150) return 'sugar';
  if (s.palmFreeShare >= 0.9 && s.scans >= 10) return 'rainforest';
  if (s.streakDays >= 10) return 'streak';
  if (s.scans >= 25) return 'detective';
  return s.scans >= 10 ? 'detective' : 'beginner';
}

export function buildSlides(s: Insights): SlideDef[] {
  const list: SlideDef[] = [{ key: 'intro', colors: [palette.forest, palette.ink], tone: 'dark' }];
  if (s.scans === 0) {
    list.push({ key: 'empty', colors: [palette.lilac, palette.sky], tone: 'light' });
    return list;
  }
  list.push({ key: 'count', colors: [palette.sun, palette.tangerine], tone: 'light' });
  if (s.topHit) list.push({ key: 'avoid', colors: [palette.lilac, palette.sky], tone: 'light' });
  if (s.sugarSpoons > 0) list.push({ key: 'sugar', colors: [palette.coral, palette.tangerine], tone: 'light' });
  if (s.savedHuf > 0) list.push({ key: 'money', colors: [palette.lime, palette.mint], tone: 'light' });
  if (s.bestSwap) list.push({ key: 'swap', colors: [palette.night3, palette.ink], tone: 'dark' });
  list.push({ key: 'persona', colors: [palette.sky, palette.lilac], tone: 'light' });
  return list;
}

// ── Building blocks ─────────────────────────────────────────────────────────

function Kicker({ children, color, delay = 80 }: { children: string; color: string; delay?: number }) {
  return (
    <Animated.View entering={FadeInDown.delay(delay).duration(450)}>
      <Txt variant="tiny" upper color={color} style={{ letterSpacing: 1.6, opacity: 0.85 }}>
        {children}
      </Txt>
    </Animated.View>
  );
}

/** A huge display number that counts up; it shrinks to fit long values. */
function Huge({ value, unit, unitBefore, lang, color, width, max = 156, delay = 250, reduced }: {
  value: number;
  unit?: string;
  unitBefore?: boolean;
  lang: Lang;
  color: string;
  width: number;
  max?: number;
  delay?: number;
  reduced: boolean;
}) {
  const n = useCountUp(value, { delay, duration: 1400, reduced });
  const text = num(n, lang);
  const finalLen = num(value, lang).length + (unit ? unit.length * 0.45 + 0.3 : 0);
  const size = Math.min(max, Math.floor((width - space.xl * 2) / (finalLen * 0.64)));
  const u = (
    <Text allowFontScaling={false} style={{ fontFamily: font.display, fontSize: size * 0.42, lineHeight: size * 0.5, color }}>
      {unit}
    </Text>
  );
  return (
    <Animated.View
      entering={reduced ? undefined : ZoomIn.delay(delay - 100).springify().damping(12)}
      style={{ alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'baseline', gap: 6 }}
    >
      {unit && unitBefore ? u : null}
      <Text
        allowFontScaling={false}
        accessibilityLabel={unit ? (unitBefore ? `${unit} ${num(value, lang)}` : `${num(value, lang)} ${unit}`) : num(value, lang)}
        style={{ fontFamily: font.display, fontSize: size, lineHeight: size * 1.02, letterSpacing: -size * 0.045, color }}
      >
        {text}
      </Text>
      {unit && !unitBefore ? u : null}
    </Animated.View>
  );
}

function Line({ children, color, size = 26, delay = 450 }: { children: ReactNode; color: string; size?: number; delay?: number }) {
  return (
    <Animated.View entering={FadeInUp.delay(delay).duration(500)}>
      <Text allowFontScaling={false} style={{ fontFamily: font.displayBold, fontSize: size, lineHeight: size * 1.15, letterSpacing: -0.5, color }}>
        {children}
      </Text>
    </Animated.View>
  );
}

function Sub({ children, color, delay = 700 }: { children: ReactNode; color: string; delay?: number }) {
  return (
    <Animated.View entering={FadeIn.delay(delay).duration(600)}>
      <Txt variant="body" color={color} style={{ opacity: 0.85, fontSize: 17, lineHeight: 24 }}>
        {children}
      </Txt>
    </Animated.View>
  );
}

function Body({ top, bottom, children, center }: { top: number; bottom: number; children: ReactNode; center?: boolean }) {
  return (
    <View
      pointerEvents="box-none"
      style={{ flex: 1, paddingTop: top, paddingBottom: bottom, paddingHorizontal: space.xxl, justifyContent: center ? 'center' : 'flex-end', gap: space.md }}
    >
      {children}
    </View>
  );
}

const INK = palette.ink;
const LIGHT = '#F7F4EC';

// ── Slides ──────────────────────────────────────────────────────────────────

function Intro({ width, height, lang, month, top, bottom }: SlideProps) {
  const t = useT(strings).w;
  const name = capitalise(MONTHS[lang][month]);
  const title = lang === 'hu' ? name : t.introTitle(name);
  // One line each at any phone width: a long month ("Szeptember") or "a DaleDay-jel" shrinks instead of wrapping.
  const textW = width - space.xl * 2;
  const titleSize = Math.min(84, Math.floor(textW / (title.length * 0.58)));
  const withSize = Math.min(52, Math.floor(textW / (t.introWith.length * 0.52)));
  const items: Floater[] = [
    { kind: 'circle', x: 0.88, y: 0.2, size: 150, color: palette.lime, period: 5200, dy: 18, opacity: 0.95 },
    { kind: 'ring', x: 0.12, y: 0.3, size: 90, color: palette.sun, period: 3600, dy: 26, dx: 10 },
    { kind: 'square', x: 0.7, y: 0.42, size: 44, color: palette.lilac, period: 2800, dy: 22, spin: 40 },
    { kind: 'pill', x: 0.22, y: 0.12, size: 30, color: palette.tangerine, period: 4400, dx: 18, dy: 8, spin: 12 },
    { kind: 'spark', x: 0.5, y: 0.22, size: 34, color: palette.mint, period: 2200, dy: 12, spin: 90 },
    { kind: 'spark', x: 0.86, y: 0.52, size: 22, color: palette.sun, period: 3000, dy: 16, spin: -90 },
  ];
  return (
    <>
      <Floaters items={items} width={width} height={height} />
      <Body top={top} bottom={bottom}>
        <Kicker color={palette.lime}>{t.introKicker}</Kicker>
        <Animated.View entering={FadeInDown.delay(200).springify().damping(14)}>
          <Text allowFontScaling={false} numberOfLines={1} style={{ fontFamily: font.display, fontSize: titleSize, lineHeight: titleSize + 2, letterSpacing: -titleSize * 0.042, color: LIGHT }}>
            {title}
          </Text>
        </Animated.View>
        <Animated.View entering={FadeInDown.delay(380).springify().damping(14)}>
          <Text allowFontScaling={false} numberOfLines={1} style={{ fontFamily: font.display, fontSize: withSize, lineHeight: withSize + 4, letterSpacing: -withSize * 0.038, color: palette.lime }}>
            {t.introWith}
          </Text>
        </Animated.View>
        <Sub color={LIGHT}>{t.introSub}</Sub>
        <Animated.View entering={FadeIn.delay(1200).duration(600)} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: space.lg }}>
          <View style={{ width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: 'rgba(247,244,236,0.6)' }} />
          <Txt variant="small" color="rgba(247,244,236,0.7)">
            {t.hint}
          </Txt>
        </Animated.View>
      </Body>
    </>
  );
}

function busiestDay(entries: ScanEntry[]): number | null {
  const counts = [0, 0, 0, 0, 0, 0, 0];
  for (const e of entries) counts[new Date(e.at).getDay()] += 1;
  const max = Math.max(...counts);
  return max > 0 ? counts.indexOf(max) : null;
}

function Count({ width, height, stats, entries, lang, month, reduced, top, bottom }: SlideProps) {
  const t = useT(strings).w;
  const day = busiestDay(entries);
  const daysCovered = new Set(entries.map((e) => new Date(e.at).toDateString())).size;
  const perDay = daysCovered > 0 ? stats.scans / daysCovered : 0;
  const perDayText = (Math.round(perDay * 10) / 10).toString().replace('.', lang === 'hu' ? ',' : '.');
  const items: Floater[] = [
    { kind: 'emoji', emoji: '🍓', x: 0.18, y: 0.16, size: 44, period: 3000, dy: 18, spin: 20 },
    { kind: 'emoji', emoji: '🥛', x: 0.78, y: 0.12, size: 50, period: 4200, dy: 24, spin: -14 },
    { kind: 'emoji', emoji: '🍫', x: 0.55, y: 0.3, size: 36, period: 2600, dy: 14, spin: 30 },
    { kind: 'emoji', emoji: '🥤', x: 0.88, y: 0.38, size: 40, period: 3600, dy: 20, spin: -24 },
    { kind: 'emoji', emoji: '🌭', x: 0.24, y: 0.4, size: 38, period: 5000, dy: 26, spin: 16 },
    { kind: 'ring', x: 0.5, y: 0.08, size: 70, color: 'rgba(255,255,255,0.5)', period: 4800, dy: 10 },
    { kind: 'circle', x: 0.02, y: 0.6, size: 120, color: 'rgba(255,255,255,0.25)', period: 5600, dy: 20 },
  ];
  return (
    <>
      <Floaters items={items} width={width} height={height} />
      <Body top={top} bottom={bottom}>
        <Kicker color={INK}>{capitalise(MONTHS[lang][month])}</Kicker>
        <Huge value={stats.scans} lang={lang} color={INK} width={width} reduced={reduced} />
        <Line color={INK} size={32}>
          {t.countLine}
        </Line>
        {day !== null ? <Sub color={INK}>{t.countBusiest(WEEKDAY_EVERY[lang][day])}</Sub> : null}
        <Sub color={INK} delay={900}>
          {t.countPerDay(perDayText)}
        </Sub>
      </Body>
    </>
  );
}

function Avoid({ width, height, stats, reduced, top, bottom }: SlideProps) {
  const t = useT(strings).w;
  const tr = useTr();
  const key = stats.topHit;
  if (!key) return null;
  const cr = CRITERIA[key];
  const count = stats.topHits?.[0]?.count ?? 0;
  const items: Floater[] = [
    { kind: 'ring', x: 0.82, y: 0.14, size: 110, color: 'rgba(255,255,255,0.55)', period: 4400, dy: 16 },
    { kind: 'square', x: 0.14, y: 0.2, size: 50, color: 'rgba(255,255,255,0.4)', period: 3200, dy: 22, spin: 50 },
    { kind: 'spark', x: 0.64, y: 0.5, size: 30, color: palette.white, period: 2400, dy: 12, spin: 120 },
    { kind: 'circle', x: 0.92, y: 0.62, size: 70, color: 'rgba(16,35,28,0.08)', period: 5200, dy: 18 },
  ];
  return (
    <>
      <Floaters items={items} width={width} height={height} />
      <Body top={top} bottom={bottom}>
        <Kicker color={INK}>{t.avoidKicker}</Kicker>
        <Animated.View entering={reduced ? undefined : ZoomIn.delay(150).springify().damping(9)} style={{ alignSelf: 'flex-start', marginVertical: space.md }}>
          <View
            style={{
              width: 168,
              height: 168,
              borderRadius: 84,
              backgroundColor: 'rgba(255,255,255,0.55)',
              borderWidth: 2,
              borderColor: 'rgba(255,255,255,0.85)',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Icon name={cr.icon} size={92} color={INK} strokeWidth={1.8} />
          </View>
        </Animated.View>
        <Line color={INK} size={44} delay={350}>
          {tr(cr.label)}
        </Line>
        <Line color={INK} size={22} delay={550}>
          {t.avoidLine(count)}
        </Line>
        <Animated.View
          entering={FadeIn.delay(900).duration(600)}
          style={{ marginTop: space.sm, backgroundColor: 'rgba(255,255,255,0.45)', borderRadius: radius.md, padding: space.md, borderWidth: 1, borderColor: 'rgba(255,255,255,0.7)' }}
        >
          <Txt variant="small" color={INK}>
            {tr(cr.short)}
          </Txt>
          <Txt variant="tiny" color={INK} style={{ opacity: 0.6, marginTop: 4 }}>
            {cr.source.name}
          </Txt>
        </Animated.View>
      </Body>
    </>
  );
}

function Sugar({ width, height, stats, lang, reduced, top, bottom }: SlideProps) {
  const t = useT(strings).w;
  return (
    <>
      <SugarRain width={width} height={height} count={reduced ? 0 : 16} />
      <Body top={top} bottom={bottom}>
        <Kicker color={INK}>{t.sugarKicker}</Kicker>
        <Huge value={stats.sugarSpoons} lang={lang} color={INK} width={width} reduced={reduced} />
        <Line color={INK} size={32}>
          {t.sugarLine}
        </Line>
        <Sub color={INK}>{t.sugarSub(stats.sugarSpoons * 4)}</Sub>
      </Body>
    </>
  );
}

function Money({ width, height, stats, lang, reduced, top, bottom }: SlideProps) {
  const t = useT(strings).w;
  const money = hufUnit(lang);
  return (
    <>
      {reduced ? null : <CoinRise width={width} height={height} />}
      <Body top={top} bottom={bottom}>
        <Kicker color={INK}>{t.moneyKicker}</Kicker>
        <Huge value={stats.savedHuf} unit={money.unit} unitBefore={money.before} lang={lang} color={INK} width={width} reduced={reduced} />
        <Line color={INK} size={30}>
          {t.moneyLine(stats.swaps)}
        </Line>
        <Sub color={INK}>{t.moneySub}</Sub>
      </Body>
    </>
  );
}

function Swap({ width, height, stats, lang, top, bottom }: SlideProps) {
  const t = useT(strings).w;
  const tr = useTr();
  const best = stats.bestSwap;
  const from = best ? getProduct(best.from) : undefined;
  const to = best ? getProduct(best.to) : undefined;
  if (!best || !from || !to) return null;
  const items: Floater[] = [
    { kind: 'circle', x: 0.85, y: 0.18, size: 160, color: 'rgba(198,243,107,0.10)', period: 5000, dy: 16 },
    { kind: 'ring', x: 0.08, y: 0.3, size: 120, color: 'rgba(198,243,107,0.18)', period: 4200, dy: 20 },
    { kind: 'spark', x: 0.78, y: 0.56, size: 26, color: palette.lime, period: 2200, dy: 12, spin: 120 },
    { kind: 'spark', x: 0.42, y: 0.16, size: 18, color: palette.mint, period: 3000, dy: 10, spin: -120 },
  ];
  return (
    <>
      <Floaters items={items} width={width} height={height} />
      <Body top={top} bottom={bottom}>
        <Kicker color={palette.lime}>{t.swapKicker}</Kicker>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginVertical: space.lg }}>
          <Animated.View entering={FadeIn.delay(150).duration(500)} style={{ width: '36%' }}>
            <View style={{ alignItems: 'center', opacity: 0.6, transform: [{ rotate: '-8deg' }] }}>
              <PackArt art={from.art} size={104} />
            </View>
          </Animated.View>
          <Animated.View entering={FadeIn.delay(500).duration(400)}>
            <Icon name="arrow-right" size={40} color={palette.lime} strokeWidth={2.6} />
          </Animated.View>
          <Animated.View entering={ZoomIn.delay(700).springify().damping(8)} style={{ alignItems: 'center', width: '40%' }}>
            <View style={{ position: 'absolute', top: 6, width: 150, height: 150, borderRadius: 75, backgroundColor: 'rgba(198,243,107,0.16)' }} />
            <PackArt art={to.art} size={150} />
          </Animated.View>
        </View>
        <Animated.View entering={FadeInUp.delay(450).duration(500)}>
          <Txt variant="small" color="rgba(247,244,236,0.6)" style={{ textDecorationLine: 'line-through' }} numberOfLines={1}>
            {tr(from.name)}
          </Txt>
        </Animated.View>
        <Line color={LIGHT} size={30} delay={800}>
          {tr(to.name)}
        </Line>
        <Animated.View entering={FadeInUp.delay(1100).duration(500)} style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm, marginTop: space.sm }}>
          {best.savedHuf > 0 ? (
            <View style={{ backgroundColor: palette.lime, borderRadius: radius.pill, paddingHorizontal: 14, paddingVertical: 8 }}>
              <Txt variant="bodyStrong" color={INK}>
                {t.swapSaved(formatHuf(best.savedHuf, lang))}
              </Txt>
            </View>
          ) : null}
          {best.sugarSpoons > 0 ? (
            <View style={{ backgroundColor: 'rgba(247,244,236,0.12)', borderRadius: radius.pill, paddingHorizontal: 14, paddingVertical: 8, borderWidth: 1, borderColor: 'rgba(247,244,236,0.2)' }}>
              <Txt variant="bodyStrong" color={LIGHT}>
                {t.swapSugar(best.sugarSpoons)}
              </Txt>
            </View>
          ) : null}
        </Animated.View>
      </Body>
    </>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <View style={{ width: '50%', paddingVertical: space.sm }}>
      <Text allowFontScaling={false} style={{ fontFamily: font.display, fontSize: 28, lineHeight: 30, letterSpacing: -0.8, color: INK }}>
        {value}
      </Text>
      <Txt variant="small" color="rgba(16,35,28,0.65)">
        {label}
      </Txt>
    </View>
  );
}

function Persona({ width, height, stats, lang, month, top, bottom }: SlideProps) {
  const t = useT(strings).w;
  const key = pickPersona(stats);
  const p = PERSONAS[key];
  const items: Floater[] = [
    { kind: 'circle', x: 0.9, y: 0.1, size: 130, color: 'rgba(255,255,255,0.35)', period: 5000, dy: 18 },
    { kind: 'ring', x: 0.1, y: 0.8, size: 80, color: palette.sun, period: 3400, dy: 22 },
    { kind: 'spark', x: 0.55, y: 0.8, size: 30, color: palette.white, period: 2400, dy: 12, spin: 120 },
    { kind: 'square', x: 0.88, y: 0.77, size: 40, color: palette.lime, period: 3000, dy: 18, spin: 45 },
  ];
  return (
    <>
      <Floaters items={items} width={width} height={height} />
      <Body top={top} bottom={bottom} center>
        <Kicker color={INK}>{t.personaKicker}</Kicker>
        <Animated.View
          entering={ZoomIn.delay(150).springify().damping(13)}
          style={{
            backgroundColor: palette.oat,
            borderRadius: radius.xl,
            padding: space.xl,
            marginTop: space.sm,
            shadowColor: INK,
            shadowOpacity: 0.25,
            shadowRadius: 30,
            shadowOffset: { width: 0, height: 16 },
            elevation: 10,
          }}
        >
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text allowFontScaling={false} style={{ fontFamily: font.display, fontSize: 24, letterSpacing: -1, color: INK }}>
              DaleDay
            </Text>
            <View style={{ backgroundColor: INK, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 4 }}>
              <Txt variant="tiny" color={palette.lime}>
                {capitalise(MONTHS[lang][month])}
              </Txt>
            </View>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg, marginTop: space.xl }}>
            <View style={{ width: 76, height: 76, borderRadius: 38, backgroundColor: palette.lime, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ fontSize: 40 }}>{p.emoji}</Text>
            </View>
            <Text
              allowFontScaling={false}
              style={{ flex: 1, fontFamily: font.display, fontSize: 30, lineHeight: 32, letterSpacing: -1, color: INK }}
            >
              {p[lang].name}
            </Text>
          </View>
          <Txt variant="body" color="rgba(16,35,28,0.75)" style={{ marginTop: space.md }}>
            {p[lang].line}
          </Txt>
          <View style={{ height: 1, backgroundColor: 'rgba(16,35,28,0.1)', marginVertical: space.lg }} />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            <Stat value={num(stats.scans, lang)} label={t.statScans} />
            <Stat value={num(stats.swaps, lang)} label={t.statSwaps} />
            <Stat value={num(stats.sugarSpoons, lang)} label={t.statSugar} />
            <Stat value={formatHuf(stats.savedHuf, lang)} label={t.statSaved} />
          </View>
        </Animated.View>
      </Body>
    </>
  );
}

function Empty({ width, height, top, bottom }: SlideProps) {
  const t = useT(strings).w;
  const items: Floater[] = [
    { kind: 'emoji', emoji: '🧺', x: 0.5, y: 0.3, size: 90, period: 3200, dy: 16, spin: 8 },
    { kind: 'spark', x: 0.2, y: 0.2, size: 30, color: palette.white, period: 2400, dy: 12, spin: 120 },
  ];
  return (
    <>
      <Floaters items={items} width={width} height={height} />
      <Body top={top} bottom={bottom}>
        <Line color={INK} size={40}>
          {t.emptyTitle}
        </Line>
        <Sub color={INK}>{t.emptyBody}</Sub>
      </Body>
    </>
  );
}

export function Slide({ def, ...props }: SlideProps & { def: SlideDef }) {
  switch (def.key) {
    case 'intro':
      return <Intro {...props} />;
    case 'count':
      return <Count {...props} />;
    case 'avoid':
      return <Avoid {...props} />;
    case 'sugar':
      return <Sugar {...props} />;
    case 'money':
      return <Money {...props} />;
    case 'swap':
      return <Swap {...props} />;
    case 'persona':
      return <Persona {...props} />;
    default:
      return <Empty {...props} />;
  }
}
