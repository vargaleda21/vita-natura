import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useEffect, useMemo, useRef, useState } from 'react';
import { PanResponder, Platform, Pressable, Share, useWindowDimensions, View, type GestureResponderEvent } from 'react-native';
import Animated, {
  cancelAnimation,
  Easing,
  FadeIn,
  FadeOut,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withSpring,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useLang, useT } from '@/i18n';
import { palette, radius, space, springs } from '@/theme/tokens';
import { Icon, PressableScale, Txt } from '@/ui';
import { capitalise, MONTHS } from './format';
import { usePeriod } from './period';
import { PERSONAS, strings } from './strings';
import { buildSlides, pickPersona, Slide } from './wrapped/slides';

const DURATION = 5000;
const MAX_W = 480;
const HOLD_MS = 220;

function Segment({ state, progress, width, color, track }: {
  state: 'done' | 'active' | 'todo';
  progress: SharedValue<number>;
  width: number;
  color: string;
  track: string;
}) {
  const anim = useAnimatedStyle(() => {
    const p = state === 'done' ? 1 : state === 'active' ? progress.get() : 0;
    return { transform: [{ translateX: (p - 1) * width }] };
  });
  return (
    <View style={{ width, height: 3, borderRadius: 2, backgroundColor: track, overflow: 'hidden' }}>
      <Animated.View style={[{ width, height: 3, borderRadius: 2, backgroundColor: color }, anim]} />
    </View>
  );
}

type WebNavigator = {
  share?: (data: { title?: string; text?: string }) => Promise<void>;
  clipboard?: { writeText: (text: string) => Promise<void> };
};

async function shareText(text: string): Promise<'shared' | 'copied' | 'none'> {
  if (Platform.OS !== 'web') {
    await Share.share({ message: text });
    return 'shared';
  }
  const nav = (globalThis as { navigator?: WebNavigator }).navigator;
  if (nav?.share) {
    try {
      await nav.share({ title: 'DaleDay', text });
      return 'shared';
    } catch {
      return 'none';
    }
  }
  if (nav?.clipboard) {
    try {
      await nav.clipboard.writeText(text);
      return 'copied';
    } catch {
      return 'none';
    }
  }
  return 'none';
}

export function WrappedScreen() {
  const t = useT(strings).w;
  const lang = useLang();
  const insets = useSafeAreaInsets();
  const { width: winW, height } = useWindowDimensions();
  const reduced = useReducedMotion();
  const { stats, entries, month } = usePeriod();
  const slides = useMemo(() => buildSlides(stats), [stats]);
  const last = slides.length - 1;

  const width = Math.min(winW, MAX_W);
  const [index, setIndex] = useState(0);
  const [held, setHeld] = useState(false);
  const [copied, setCopied] = useState(false);
  const progress = useSharedValue(0);
  const drag = useSharedValue(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const close = () => {
    if (router.canGoBack()) router.back();
    else router.replace('/insights');
  };

  const stopClock = () => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    cancelAnimation(progress);
  };

  const runFrom = (p: number) => {
    stopClock();
    const remaining = Math.max(0, (1 - p) * DURATION);
    progress.set(p);
    progress.set(withTiming(1, { duration: remaining, easing: Easing.linear }));
    timer.current = setTimeout(() => setIndex((i) => Math.min(i + 1, last)), remaining);
  };

  // Every new slide starts its own clock.
  useEffect(() => {
    runFrom(0);
    return stopClock;
    // runFrom/stopClock are stable in behaviour; the clock restarts only when the slide changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index]);

  const next = () => {
    if (index < last) setIndex(index + 1);
    else runFrom(progress.get());
  };
  const prev = () => {
    if (index > 0) setIndex(index - 1);
    else runFrom(0);
  };

  // Keyboard on a desktop browser: arrows, space to pause, Esc to close.
  useEffect(() => {
    if (Platform.OS !== 'web' || typeof document === 'undefined') return;
    let paused = false;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') setIndex((i) => Math.min(i + 1, last));
      else if (e.key === 'ArrowLeft') setIndex((i) => Math.max(i - 1, 0));
      else if (e.key === 'Escape') close();
      else if (e.key === ' ') {
        e.preventDefault();
        paused = !paused;
        if (paused) stopClock();
        else runFrom(progress.get());
        setHeld(paused);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [last]);

  // Tap = step (onPress, which also fires for a very quick tap), hold = pause (onLongPress), letting go = play on.
  const onPressIn = () => {
    stopClock();
  };
  const onLongPress = () => {
    setHeld(true);
  };
  const onPressOut = () => {
    setHeld(false);
    runFrom(progress.get());
  };
  const onPress = (e: GestureResponderEvent) => {
    const left = (winW - width) / 2;
    if (e.nativeEvent.pageX - left < width * 0.3) prev();
    else next();
  };

  // Swipe down to close: the story follows the finger, then lets go.
  const pan = useMemo(
    () =>
      PanResponder.create({
        onMoveShouldSetPanResponderCapture: (_, g) => g.dy > 14 && Math.abs(g.dy) > Math.abs(g.dx) * 1.4,
        onPanResponderMove: (_, g) => drag.set(Math.max(0, g.dy)),
        onPanResponderRelease: (_, g) => {
          if (g.dy > 120 || g.vy > 1.1) {
            drag.set(withTiming(height, { duration: 220 }));
            setTimeout(close, 200);
          } else {
            drag.set(withSpring(0, springs.snappy));
          }
        },
        onPanResponderTerminate: () => drag.set(withSpring(0, springs.snappy)),
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [height],
  );
  const dragStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: drag.get() }, { scale: 1 - Math.min(drag.get(), 400) / 2400 }],
  }));

  const def = slides[Math.min(index, last)];
  const dark = def.tone === 'dark';
  const chrome = dark ? '#F7F4EC' : palette.ink;
  const track = dark ? 'rgba(247,244,236,0.28)' : 'rgba(16,35,28,0.2)';
  const top = insets.top + 64;
  const isFinal = def.key === 'persona';
  const bottom = Math.max(insets.bottom, 16) + (isFinal ? 84 : 40);
  const gap = 4;
  const segW = (width - space.lg * 2 - gap * (slides.length - 1)) / slides.length;
  const monthName = capitalise(MONTHS[lang][month]);
  const persona = PERSONAS[pickPersona(stats)][lang].name;

  const onShare = async () => {
    const res = await shareText(t.shareText(monthName, stats.scans, stats.swaps, stats.sugarSpoons, persona));
    if (res === 'copied') {
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: palette.night }}>
      <Animated.View
        {...pan.panHandlers}
        style={[{ flex: 1, width, alignSelf: 'center', overflow: 'hidden', backgroundColor: def.colors[1] }, dragStyle]}
      >
        {/* Background and slide content: a fresh mount per slide, so every entrance plays. */}
        <Animated.View key={`bg-${def.key}`} entering={reduced ? undefined : FadeIn.duration(320)} style={{ position: 'absolute', inset: 0 }}>
          <LinearGradient colors={def.colors} start={{ x: 0.1, y: 0 }} end={{ x: 0.9, y: 1 }} style={{ flex: 1 }} />
        </Animated.View>
        <View key={`slide-${def.key}`} pointerEvents="box-none" style={{ position: 'absolute', inset: 0 }}>
          <Slide def={def} width={width} height={height} stats={stats} entries={entries} lang={lang} month={month} reduced={reduced} top={top} bottom={bottom} />
        </View>

        {/* A soft fade under the progress bars, so falling shapes never muddle them. */}
        <LinearGradient
          pointerEvents="none"
          colors={[def.colors[0], `${def.colors[0]}00`]}
          style={{ position: 'absolute', left: 0, right: 0, top: 0, height: insets.top + 120 }}
        />

        {/* Tap left/right to step, hold to pause. */}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t.next}
          onPress={onPress}
          onPressIn={onPressIn}
          onPressOut={onPressOut}
          onLongPress={onLongPress}
          delayLongPress={HOLD_MS}
          style={{ position: 'absolute', inset: 0 }}
        />

        {/* Progress bars and the close button. */}
        <View pointerEvents="box-none" style={{ position: 'absolute', left: 0, right: 0, top: insets.top + 8, paddingHorizontal: space.lg }}>
          <View style={{ flexDirection: 'row', gap }}>
            {slides.map((s, i) => (
              <Segment
                key={s.key}
                state={i < index ? 'done' : i === index ? 'active' : 'todo'}
                progress={progress}
                width={segW}
                color={chrome}
                track={track}
              />
            ))}
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: space.md }}>
            <Txt variant="small" color={chrome} style={{ opacity: 0.85 }}>
              DaleDay · {monthName}
            </Txt>
            <PressableScale
              accessibilityRole="button"
              accessibilityLabel={t.close}
              onPress={close}
              hitSlop={8}
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: dark ? 'rgba(247,244,236,0.14)' : 'rgba(16,35,28,0.1)',
              }}
            >
              <Icon name="x" size={22} color={chrome} strokeWidth={2.4} />
            </PressableScale>
          </View>
        </View>

        {held ? (
          <Animated.View
            entering={FadeIn.duration(150)}
            exiting={FadeOut.duration(150)}
            pointerEvents="none"
            style={{ position: 'absolute', top: insets.top + 70, alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(16,35,28,0.7)', borderRadius: radius.pill, paddingHorizontal: 14, paddingVertical: 6 }}
          >
            <View style={{ flexDirection: 'row', gap: 3 }}>
              <View style={{ width: 3, height: 11, borderRadius: 1, backgroundColor: '#F7F4EC' }} />
              <View style={{ width: 3, height: 11, borderRadius: 1, backgroundColor: '#F7F4EC' }} />
            </View>
            <Txt variant="tiny" color="#F7F4EC">
              {t.paused}
            </Txt>
          </Animated.View>
        ) : null}

        {/* The final card's actions sit above the tap layer. */}
        {isFinal ? (
          <Animated.View
            entering={reduced ? undefined : FadeIn.delay(900).duration(400)}
            pointerEvents="box-none"
            style={{ position: 'absolute', left: space.xxl, right: space.xxl, bottom: Math.max(insets.bottom, 16) + 16, flexDirection: 'row', gap: space.md }}
          >
            <PressableScale
              haptic="medium"
              accessibilityRole="button"
              accessibilityLabel={t.share}
              onPress={() => void onShare()}
              style={{ flex: 1, height: 54, borderRadius: radius.pill, backgroundColor: palette.ink, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 }}
            >
              <Icon name="share-2" size={19} color={palette.lime} />
              <Txt variant="bodyStrong" color={palette.lime}>
                {copied ? t.copied : t.share}
              </Txt>
            </PressableScale>
            <PressableScale
              accessibilityRole="button"
              accessibilityLabel={t.replay}
              onPress={() => setIndex(0)}
              style={{ height: 54, paddingHorizontal: space.xl, borderRadius: radius.pill, borderWidth: 2, borderColor: palette.ink, flexDirection: 'row', alignItems: 'center', gap: 6 }}
            >
              <Icon name="refresh-cw" size={17} color={palette.ink} />
              <Txt variant="bodyStrong" color={palette.ink}>
                {t.replay}
              </Txt>
            </PressableScale>
          </Animated.View>
        ) : null}
      </Animated.View>
    </View>
  );
}
