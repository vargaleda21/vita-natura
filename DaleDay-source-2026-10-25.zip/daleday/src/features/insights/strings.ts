// The basket tab ("Kosaram") and the monthly story. Hungarian first, informal "te".

import { groupDigits } from '@/i18n';
import { MONTHS, monthIn } from './format';

/** Counts in copy: "1 220" in Hungarian (no-break spaces), "1,220" in English. */
const h = (n: number) => groupDigits(n, '\u00A0');
const e = (n: number) => groupDigits(n, ',');

/** "októbered": the month as yours, for "Az októbered képekben". */
const MONTH_YOURS = ['januárod', 'februárod', 'márciusod', 'áprilisod', 'májusod', 'júniusod', 'júliusod', 'augusztusod', 'szeptembered', 'októbered', 'novembered', 'decembered'];

const hu = {
  title: 'Kosaram',
  // Hero
  heroMonth: (month: number) => `terméket ellenőrzött neked a\u00A0DaleDay ${monthIn(month)}`,
  hero30: 'terméket ellenőrzött neked a\u00A0DaleDay az elmúlt 30 napban',
  heroPill30: 'Az elmúlt 30 nap',
  // Bento
  savedLine: 'maradt nálad a\u00A0cserékkel',
  savedFoot: (n: number) => `${h(n)} cseréből`,
  swapsUnit: 'csere',
  swapsLine: 'jobb termékre váltottál',
  sugarLine: 'kiskanál cukor maradt a\u00A0polcon',
  sugarKey: (per: number) => (per === 1 ? '1 kocka = 1 kiskanál' : `1 kocka = ${per} kiskanál`),
  sugarNone: 'Az első cukros csere után itt gyűlnek a kockák.',
  palmLine: 'pálmaolajmentes volt abból, amit hazavittél',
  streakUnit: 'nap',
  streakLine: 'egymás után szkenneltél',
  streakNone: 'Szkennelj ma, és indul egy új sorozat.',
  // Story card
  storyKicker: 'Új',
  storyTitle: 'A hónapod története',
  storySub: (month: number) => `${/^[aáeéiíoóöőuúüű]/.test(MONTH_YOURS[month]) ? 'Az' : 'A'} ${MONTH_YOURS[month]} képekben: cukor, cserék, spórolás.`,
  storyPlay: 'Lejátszás',
  // Week
  weekTitle: 'Az elmúlt 7 nap',
  weekSub: 'Szkennelt termékek naponta',
  today: 'ma',
  weekA11y: (day: string, n: number) => `${day}: ${h(n)} termék`,
  // Donut
  donutTitle: 'Mennyire illettek hozzád?',
  donutSub: 'A beállításaid szerint, a szkennelés pillanatában',
  donutCenter: 'termék',
  // Top hits
  topTitle: 'Amit a leggyakrabban kerültél',
  topSub: 'Ennyi termékben bukkant fel abból, amit kerülsz',
  topCount: (n: number) => `${h(n)} termékben`,
  topNone: 'Eddig semmi sem bukkant fel a listádról. Szép!',
  // Recent
  recentTitle: 'Legutóbb nézted',
  showAll: (n: number) => `Mind a ${h(n)} mutatása`,
  showLess: 'Kevesebb mutatása',
  swapped: 'Lecserélted',
  // Empty
  emptyTitle: 'Itt lesz a kosarad története',
  emptyBody: 'Szkennelj be pár terméket, és megmutatjuk, mit kerültél, mit cseréltél és mennyit spóroltál.',
  emptyCta: 'Szkennelés',

  // ── Wrapped ──
  w: {
    close: 'Bezárás',
    next: 'Következő',
    prev: 'Előző',
    paused: 'Megállítva',
    hint: 'Koppints a továbblépéshez, tartsd lenyomva a megállításhoz',
    introKicker: 'A hónapod története',
    introTitle: (month: string) => month,
    introWith: 'a DaleDay-jel',
    introSub: 'Nézzük, mi került a kosaradba.',
    countLine: 'terméket néztél meg',
    countBusiest: (every: string) => `A legtöbbet ${every} szkenneltél.`,
    countPerDay: (n: string) => `Ez átlagosan napi ${n} termék.`,
    avoidKicker: 'Amit a leggyakrabban kerültél',
    avoidLine: (n: number) => `${h(n)} termékben bukkant fel`,
    sugarKicker: 'A polcon maradt',
    sugarLine: 'kiskanál cukor',
    sugarSub: (grams: number) =>
      grams >= 1000
        ? `Ez több mint ${Math.floor(grams / 1000)} kiló kockacukor.`
        : grams >= 500
          ? 'Ez több mint fél kiló kockacukor.'
          : grams >= 400
            ? 'Ez majdnem fél kiló kockacukor.'
            : `Ez nagyjából ${grams} gramm kockacukor.`,
    moneyKicker: 'A pénztárcádban maradt',
    moneyLine: (swaps: number) => `${h(swaps)} jobb cserével`,
    moneySub: 'Jobbat vettél, és még olcsóbb is volt.',
    swapKicker: 'A hónap cseréje',
    swapSaved: (amount: string) => `−${amount}`,
    swapSugar: (n: number) => `${h(n)} kiskanál cukorral kevesebb`,
    personaKicker: 'Te ilyen vásárló vagy:',
    statScans: 'termék',
    statSwaps: 'csere',
    statSugar: 'kiskanál cukor',
    statSaved: 'megspórolva',
    share: 'Megosztom',
    replay: 'Újra',
    done: 'Kész',
    copied: 'Kimásoltuk a szöveget',
    shareText: (month: string, scans: number, swaps: number, spoons: number, persona: string) =>
      `${month} a DaleDay-jel: ${h(scans)} terméket néztem meg, ${h(swaps)} terméket cseréltem jobbra, és ${h(spoons)} kiskanál cukor maradt a polcon. ${persona} vagyok. Tudd, mi van benne!`,
    emptyTitle: 'Még üres a történeted',
    emptyBody: 'Szkennelj be pár terméket, és a hónap végén itt vár a történeted.',
  },
};

type Strings = typeof hu;

const en: Strings = {
  title: 'My basket',
  heroMonth: (month) => `products checked with DaleDay in ${MONTHS.en[month]}`,
  hero30: 'products checked with DaleDay in the last 30 days',
  heroPill30: 'Last 30 days',
  savedLine: 'saved by swapping',
  savedFoot: (n) => (n === 1 ? 'from 1 swap' : `from ${e(n)} swaps`),
  swapsUnit: 'swaps',
  swapsLine: 'for a better product',
  sugarLine: 'teaspoons of sugar left on the shelf',
  sugarKey: (per) => (per === 1 ? '1 cube = 1 teaspoon' : `1 cube = ${per} teaspoons`),
  sugarNone: 'Your first sugary swap starts the pile.',
  palmLine: 'of what you took home had no palm oil',
  streakUnit: 'days',
  streakLine: 'in a row with a scan',
  streakNone: 'Scan something today to start a new streak.',
  storyKicker: 'New',
  storyTitle: 'Your month in a story',
  storySub: (month) => `Your ${MONTHS.en[month]} in pictures: sugar, swaps, savings.`,
  storyPlay: 'Play',
  weekTitle: 'The last 7 days',
  weekSub: 'Products scanned per day',
  today: 'today',
  weekA11y: (day, n) => `${day}: ${e(n)} products`,
  donutTitle: 'How well did they fit you?',
  donutSub: 'By your settings at the time of scanning',
  donutCenter: 'products',
  topTitle: 'What you avoided most',
  topSub: 'How many products it turned up in',
  topCount: (n) => `in ${e(n)} products`,
  topNone: 'Nothing on your list has turned up yet. Nice!',
  recentTitle: 'Recently checked',
  showAll: (n) => `Show all ${e(n)}`,
  showLess: 'Show less',
  swapped: 'Swapped',
  emptyTitle: 'Your basket story starts here',
  emptyBody: 'Scan a few products and we’ll show you what you avoided, what you swapped and how much you saved.',
  emptyCta: 'Scan',
  w: {
    close: 'Close',
    next: 'Next',
    prev: 'Previous',
    paused: 'Paused',
    hint: 'Tap to continue, hold to pause',
    introKicker: 'Your month in a story',
    introTitle: (month) => `Your ${month}`,
    introWith: 'with DaleDay',
    introSub: 'Let’s see what went into your basket.',
    countLine: 'products checked',
    countBusiest: (every) => `You scanned most on ${every}.`,
    countPerDay: (n) => `That’s ${n} products a day on average.`,
    avoidKicker: 'What you avoided most',
    avoidLine: (n) => `It turned up in ${e(n)} products`,
    sugarKicker: 'Left on the shelf',
    sugarLine: 'teaspoons of sugar',
    sugarSub: (grams) =>
      grams >= 1000
        ? `That’s more than ${Math.floor(grams / 1000)}\u00A0kg of sugar cubes.`
        : grams >= 500
          ? 'That’s more than half a kilo of sugar cubes.'
          : grams >= 400
            ? 'That’s almost half a kilo of sugar cubes.'
            : `That’s about ${grams}\u00A0g of sugar cubes.`,
    moneyKicker: 'Stayed in your wallet',
    moneyLine: (swaps) => (swaps === 1 ? 'with 1 better swap' : `with ${e(swaps)} better swaps`),
    moneySub: 'You bought better, and it cost less.',
    swapKicker: 'Swap of the month',
    swapSaved: (amount) => `−${amount}`,
    swapSugar: (n) => (n === 1 ? '1 teaspoon less sugar' : `${e(n)} fewer teaspoons of sugar`),
    personaKicker: 'Your shopper type:',
    statScans: 'products',
    statSwaps: 'swaps',
    statSugar: 'tsp of sugar',
    statSaved: 'saved',
    share: 'Share',
    replay: 'Replay',
    done: 'Done',
    copied: 'Copied to the clipboard',
    shareText: (month, scans, swaps, spoons, persona) =>
      `My ${month} with DaleDay: ${e(scans)} products checked, ${e(swaps)} swaps, and ${e(spoons)} teaspoons of sugar left on the shelf. I’m a ${persona.charAt(0).toLowerCase()}${persona.slice(1)}. Know what’s inside!`,
    emptyTitle: 'Your story is still empty',
    emptyBody: 'Scan a few products and your story will be waiting here at the end of the month.',
  },
};

export const strings = { hu, en };

export type PersonaKey = 'swapper' | 'sugar' | 'rainforest' | 'streak' | 'detective' | 'beginner';

export const PERSONAS: Record<PersonaKey, { emoji: string; hu: { name: string; line: string }; en: { name: string; line: string } }> = {
  swapper: {
    emoji: '🔁',
    hu: { name: 'Cserebajnok', line: 'Ha van jobb a polcon, te megtalálod.' },
    en: { name: 'Swap champion', line: 'If there’s a better one on the shelf, you’ll find it.' },
  },
  sugar: {
    emoji: '🍬',
    hu: { name: 'Cukorvadász', line: 'A rejtett cukor sem bújhat el előled.' },
    en: { name: 'Sugar hunter', line: 'Even hidden sugar can’t hide from you.' },
  },
  rainforest: {
    emoji: '🌴',
    hu: { name: 'Esőerdőbarát', line: 'A kosaradba alig jutott pálmaolaj.' },
    en: { name: 'Rainforest friend', line: 'Hardly any palm oil made it into your basket.' },
  },
  streak: {
    emoji: '🔥',
    hu: { name: 'Kitartó felfedező', line: 'Nap mint nap ránézel arra, amit veszel.' },
    en: { name: 'Steady explorer', line: 'Day after day, you check what you buy.' },
  },
  detective: {
    emoji: '🔎',
    hu: { name: 'Címkeolvasó detektív', line: 'Egy címke sem úszta meg. Te tudod, mi van benne.' },
    en: { name: 'Label detective', line: 'No label got past you. You know what’s inside.' },
  },
  beginner: {
    emoji: '🌱',
    hu: { name: 'Kíváncsi kezdő', line: 'Jó kezdés! Jövő hónapban még többet mutatunk.' },
    en: { name: 'Curious beginner', line: 'A great start! Next month there’s even more to see.' },
  },
};
