import { useId } from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import Svg, { Defs, RadialGradient, Rect, Stop } from 'react-native-svg';

type Props = {
  width: number;
  height?: number;
  color: string;
  /** Opacity in the middle; it fades to nothing at the edge. */
  opacity?: number;
  style?: StyleProp<ViewStyle>;
};

/**
 * A soft round glow made of a radial gradient. This is how DaleDay draws big blurry light:
 * never with a blur filter, which a phone pays for on every frame.
 */
export function Glow({ width, height = width, color, opacity = 1, style }: Props) {
  const id = `glow${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  return (
    <Svg width={width} height={height} style={style} pointerEvents="none">
      <Defs>
        <RadialGradient id={id} cx="50%" cy="50%" rx="50%" ry="50%" fx="50%" fy="50%">
          <Stop offset="0" stopColor={color} stopOpacity={opacity} />
          <Stop offset="0.45" stopColor={color} stopOpacity={opacity * 0.55} />
          <Stop offset="0.75" stopColor={color} stopOpacity={opacity * 0.16} />
          <Stop offset="1" stopColor={color} stopOpacity={0} />
        </RadialGradient>
      </Defs>
      <Rect x={0} y={0} width={width} height={height} fill={`url(#${id})`} />
    </Svg>
  );
}
