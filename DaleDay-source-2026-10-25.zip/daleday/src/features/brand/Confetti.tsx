import { useEffect, useMemo } from 'react';
import { View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';

import { palette } from '@/theme/tokens';

const COLORS = [palette.lime, palette.sun, palette.tangerine, palette.lilac, palette.sky, palette.mint, palette.coral];

type Bit = { angle: number; speed: number; spin: number; flips: number; w: number; h: number; r: number; color: string; drift: number };

/** A small seeded random, so the burst looks the same on every render. */
function seeded(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

function makeBits(count: number, seed: number): Bit[] {
  const rnd = seeded(seed);
  return Array.from({ length: count }, (_, i) => {
    const kind = i % 3;
    return {
      // Mostly upwards, a little to every side.
      angle: -Math.PI / 2 + (rnd() - 0.5) * Math.PI * 1.35,
      speed: 150 + rnd() * 210,
      spin: (rnd() - 0.5) * 900,
      flips: 1 + rnd() * 3,
      w: kind === 0 ? 7 : kind === 1 ? 9 : 6,
      h: kind === 0 ? 14 : kind === 1 ? 9 : 10,
      r: kind === 1 ? 5 : 2,
      color: COLORS[i % COLORS.length],
      drift: (rnd() - 0.5) * 60,
    };
  });
}

function Piece({ bit, p }: { bit: Bit; p: SharedValue<number> }) {
  const style = useAnimatedStyle(() => {
    const t = p.get();
    const out = 1 - (1 - t) * (1 - t) * (1 - t);
    const x = Math.cos(bit.angle) * bit.speed * out + bit.drift * t;
    const y = Math.sin(bit.angle) * bit.speed * out + 260 * t * t;
    return {
      opacity: t <= 0 ? 0 : t < 0.72 ? 1 : Math.max(0, (1 - t) / 0.28),
      transform: [
        { translateX: x },
        { translateY: y },
        { rotate: `${bit.spin * t}deg` },
        { scaleY: Math.cos(t * bit.flips * Math.PI * 2) },
      ],
    };
  });
  return (
    <Animated.View
      style={[
        { position: 'absolute', left: -bit.w / 2, top: -bit.h / 2, width: bit.w, height: bit.h, borderRadius: bit.r, backgroundColor: bit.color },
        style,
      ]}
    />
  );
}

type Props = {
  /** Fires a burst each time this turns true (or changes to a new non-zero number). */
  fire: boolean | number;
  count?: number;
  /** Where the burst starts, inside the parent. */
  x: number;
  y: number;
  duration?: number;
};

/** A burst of paper confetti, transforms and opacity only. Silent when the user asked for reduced motion. */
export function Confetti({ fire, count = 40, x, y, duration = 1900 }: Props) {
  const reduced = useReducedMotion();
  const p = useSharedValue(0);
  const bits = useMemo(() => makeBits(count, 7), [count]);

  useEffect(() => {
    if (!fire || reduced) return;
    p.set(0);
    p.set(withTiming(1, { duration, easing: Easing.linear }));
  }, [fire, reduced, duration, p]);

  if (reduced) return null;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: x, top: y, width: 0, height: 0 }}>
      {bits.map((b, i) => (
        <Piece key={i} bit={b} p={p} />
      ))}
    </View>
  );
}
