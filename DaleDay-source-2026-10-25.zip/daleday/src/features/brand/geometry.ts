// The DaleDay mark: a barcode whose tallest bar grows into a sprout.
// One source of truth for the app (Logo.tsx) and the icon renderer (tools/make-icons.mjs, which imports
// this file with Node's type stripping, so keep it plain: no imports, only erasable TypeScript).
// Everything lives in a 100 × 100 box.

export const VIEWBOX = 100;

/** Where every bar stands. */
export const BASELINE = 84;

/** A barcode bar: left edge, width, top. Shorter towards the edges, like a small hill. */
export type Bar = { x: number; w: number; top: number };

export const BARS: Bar[] = [
  { x: 12, w: 7, top: 60 },
  { x: 22.5, w: 3.5, top: 57 },
  { x: 29.5, w: 7, top: 54 },
  { x: 39.5, w: 3, top: 52 },
  { x: 57.5, w: 3, top: 52 },
  { x: 64, w: 7, top: 54 },
  { x: 74.5, w: 3.5, top: 57 },
  { x: 81, w: 7, top: 60 },
];

/** Fewer, bolder bars for tiny sizes (favicons, ≤ 28 px), where thin bars would blur together. */
export const BARS_SMALL: Bar[] = [
  { x: 10, w: 8, top: 60 },
  { x: 22, w: 6, top: 56 },
  { x: 33, w: 8, top: 52 },
  { x: 59, w: 8, top: 52 },
  { x: 72, w: 6, top: 56 },
  { x: 82, w: 8, top: 60 },
];

/** The tallest bar: the sprout's stem. */
export const STEM: Bar = { x: 46, w: 8, top: 46 };

export const BAR_RADIUS = 1.5;

/** The big leaf, reaching up to the right, with its midrib cut out (fill-rule evenodd). */
export const LEAF_BIG =
  'M46 48 C46.5 31 63 17.5 89 15 C88 36 73 48.5 54 48.5 Z M55.5 41.5 Q65 28.5 84 20 Q69 33 55.5 41.5 Z';

/** The small leaf on the left. */
export const LEAF_SMALL = 'M50 45 C45 37.5 37 33 26 33.5 C28.5 42 36 48 47 48.5 Z';

/** Both leaves unfurl around this point, the top of the stem. */
export const LEAF_PIVOT = { x: 50, y: 47 };

export const BRAND = {
  ink: '#10231C',
  forest: '#1E4D3A',
  lime: '#C6F36B',
  oat: '#F7F4EC',
} as const;

/** The mark as SVG markup for a 100 × 100 viewBox (for the icon renderer and favicon.svg). */
export function markSvg(color: string, small = false): string {
  const bars = [...(small ? BARS_SMALL : BARS), STEM]
    .map((b) => `<rect x="${b.x}" y="${b.top}" width="${b.w}" height="${BASELINE - b.top}" rx="${BAR_RADIUS}"/>`)
    .join('');
  return `<g fill="${color}">${bars}<path fill-rule="evenodd" d="${LEAF_BIG}"/><path d="${LEAF_SMALL}"/></g>`;
}
