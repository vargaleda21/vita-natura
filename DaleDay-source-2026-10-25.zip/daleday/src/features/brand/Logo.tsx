import { useEffect } from 'react';
import { Text, View, type StyleProp, type ViewStyle } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withDelay,
  withSpring,
  type SharedValue,
} from 'react-native-reanimated';
import Svg, { Path, Rect } from 'react-native-svg';

import { font, palette, springs } from '@/theme/tokens';
import { BAR_RADIUS, BARS, BASELINE, LEAF_BIG, LEAF_PIVOT, LEAF_SMALL, STEM, VIEWBOX, type Bar } from './geometry';

export type LogoTone = 'ink' | 'lime' | 'cream';

const TONE: Record<LogoTone, string> = { ink: palette.ink, lime: palette.lime, cream: palette.oat };
/** The tile colour behind the mark when `badge` is on. */
const BADGE: Record<LogoTone, string> = { ink: palette.lime, lime: palette.ink, cream: palette.forest };

type LogoProps = {
  /** Height of the mark in px. */
  size?: number;
  variant?: 'mark' | 'full';
  tone?: LogoTone;
  /** Put the mark on a rounded tile, like the app icon. */
  badge?: boolean;
  style?: StyleProp<ViewStyle>;
};

function MarkSvg({ size, color }: { size: number; color: string }) {
  return (
    <Svg width={size} height={size} viewBox={`0 0 ${VIEWBOX} ${VIEWBOX}`}>
      {[...BARS, STEM].map((b) => (
        <Rect key={b.x} x={b.x} y={b.top} width={b.w} height={BASELINE - b.top} rx={BAR_RADIUS} fill={color} />
      ))}
      <Path d={LEAF_BIG} fill={color} fillRule="evenodd" />
      <Path d={LEAF_SMALL} fill={color} />
    </Svg>
  );
}

/** A rounded tile like the app icon, or nothing. */
function Tile({ size, tone, badge, children }: { size: number; tone: LogoTone; badge?: boolean; children: React.ReactNode }) {
  if (!badge) return <View style={{ width: size, height: size }}>{children}</View>;
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.28,
        backgroundColor: BADGE[tone],
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
      }}
    >
      {children}
    </View>
  );
}

/** The "DaleDay" wordmark in Bricolage Grotesque 800. `size` matches the mark it sits next to. */
export function Wordmark({ size = 40, tone = 'ink', color }: { size?: number; tone?: LogoTone; color?: string }) {
  const fontSize = size * 0.74;
  return (
    <Text
      accessibilityElementsHidden
      importantForAccessibility="no"
      style={{
        fontFamily: font.display,
        fontSize,
        lineHeight: fontSize * 1.02,
        letterSpacing: -fontSize * 0.045,
        color: color ?? TONE[tone],
        includeFontPadding: false,
      }}
    >
      DaleDay
    </Text>
  );
}

/** The DaleDay mark: a barcode whose tallest bar grows into a sprout. */
export function Logo({ size = 40, variant = 'mark', tone = 'ink', badge, style }: LogoProps) {
  const inner = badge ? size * 0.84 : size;
  const mark = (
    <Tile size={size} tone={tone} badge={badge}>
      <MarkSvg size={inner} color={TONE[tone]} />
    </Tile>
  );
  if (variant === 'mark') {
    return (
      <View accessibilityRole="image" accessibilityLabel="DaleDay" style={style}>
        {mark}
      </View>
    );
  }
  return (
    <View
      accessibilityRole="image"
      accessibilityLabel="DaleDay"
      style={[{ flexDirection: 'row', alignItems: 'center', gap: size * 0.16 }, style]}
    >
      {mark}
      <View style={{ marginTop: size * 0.06 }}>
        <Wordmark size={size} tone={badge ? (tone === 'lime' ? 'ink' : tone) : tone} />
      </View>
    </View>
  );
}

// ——— The animated mark ———————————————————————————————————————————————————————————

const C = VIEWBOX / 2;

/** One part of the mark on its own layer, so it can move on its own (transforms only). */
type AnimatedViewStyle = React.ComponentProps<typeof Animated.View>['style'];

function Layer({ size, style, children }: { size: number; style: AnimatedViewStyle; children: React.ReactNode }) {
  return (
    <Animated.View pointerEvents="none" style={[{ position: 'absolute', left: 0, top: 0, width: size, height: size }, style]}>
      <Svg width={size} height={size} viewBox={`0 0 ${VIEWBOX} ${VIEWBOX}`}>
        {children}
      </Svg>
    </Animated.View>
  );
}

function RisingBar({ b, size, p, color }: { b: Bar; size: number; p: SharedValue<number>; color: string }) {
  // Grow from the baseline: scale about a point below the centre.
  const y0 = ((BASELINE - C) / VIEWBOX) * size;
  const anim = useAnimatedStyle(() => {
    const v = p.get();
    return {
      opacity: Math.min(1, v * 5),
      transform: [{ translateY: y0 * (1 - v) }, { scaleY: Math.max(v, 0.001) }],
    };
  });
  return (
    <Layer size={size} style={anim}>
      <Rect x={b.x} y={b.top} width={b.w} height={BASELINE - b.top} rx={BAR_RADIUS} fill={color} />
    </Layer>
  );
}

function Leaf({
  d,
  evenOdd,
  from,
  size,
  p,
  color,
}: {
  d: string;
  evenOdd?: boolean;
  from: number;
  size: number;
  p: SharedValue<number>;
  color: string;
}) {
  const dx = ((LEAF_PIVOT.x - C) / VIEWBOX) * size;
  const dy = ((LEAF_PIVOT.y - C) / VIEWBOX) * size;
  const anim = useAnimatedStyle(() => {
    const v = p.get();
    return {
      opacity: Math.min(1, v * 4),
      transform: [
        { translateX: dx },
        { translateY: dy },
        { rotate: `${from * (1 - v)}deg` },
        { scale: Math.max(v, 0.001) },
        { translateX: -dx },
        { translateY: -dy },
      ],
    };
  });
  return (
    <Layer size={size} style={anim}>
      <Path d={d} fill={color} fillRule={evenOdd ? 'evenodd' : 'nonzero'} />
    </Layer>
  );
}

type AnimatedProps = {
  size?: number;
  tone?: LogoTone;
  /** Wait before the first bar rises, in ms. */
  delay?: number;
};

/** The mark building itself: the bars rise one by one, the stem shoots up, then the leaves unfurl. */
export function AnimatedLogo({ size = 120, tone = 'lime', delay = 150 }: AnimatedProps) {
  const reduced = useReducedMotion();
  const color = TONE[tone];
  const start = reduced ? 1 : 0;
  const b0 = useSharedValue(start);
  const b1 = useSharedValue(start);
  const b2 = useSharedValue(start);
  const b3 = useSharedValue(start);
  const b4 = useSharedValue(start);
  const b5 = useSharedValue(start);
  const b6 = useSharedValue(start);
  const b7 = useSharedValue(start);
  const stem = useSharedValue(start);
  const big = useSharedValue(start);
  const small = useSharedValue(start);
  const bars = [b0, b1, b2, b3, b4, b5, b6, b7];

  useEffect(() => {
    if (reduced) return;
    const step = 70;
    bars.forEach((sv, i) => sv.set(withDelay(delay + i * step, withSpring(1, springs.bouncy))));
    const stemAt = delay + bars.length * step + 40;
    stem.set(withDelay(stemAt, withSpring(1, { damping: 11, stiffness: 140, mass: 0.9 })));
    big.set(withDelay(stemAt + 220, withSpring(1, { damping: 10, stiffness: 120, mass: 0.9 })));
    small.set(withDelay(stemAt + 300, withSpring(1, { damping: 10, stiffness: 130, mass: 0.8 })));
    // Plays once on mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <View accessibilityRole="image" accessibilityLabel="DaleDay" style={{ width: size, height: size }}>
      {BARS.map((b, i) => (
        <RisingBar key={b.x} b={b} size={size} p={bars[i]} color={color} />
      ))}
      <Leaf d={LEAF_SMALL} from={55} size={size} p={small} color={color} />
      <Leaf d={LEAF_BIG} evenOdd from={-60} size={size} p={big} color={color} />
      <RisingBar b={STEM} size={size} p={stem} color={color} />
    </View>
  );
}
