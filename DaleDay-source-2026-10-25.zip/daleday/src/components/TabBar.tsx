import { LinearGradient } from 'expo-linear-gradient';
import type { BottomTabBarProps } from 'expo-router/tabs';
import { router } from 'expo-router';
import { useEffect } from 'react';
import { useWindowDimensions, View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useLang } from '@/i18n';
import { palette, radius, shadow, springs } from '@/theme/tokens';
import { Icon, type IconName, PressableScale, Txt, useTheme } from '@/ui';

const TABS: Record<string, { icon: IconName; hu: string; en: string }> = {
  index: { icon: 'house', hu: 'Főoldal', en: 'Home' },
  discover: { icon: 'sparkles', hu: 'Felfedezés', en: 'Discover' },
  insights: { icon: 'chart-pie', hu: 'Kosaram', en: 'My basket' },
  profile: { icon: 'user-round', hu: 'Profil', en: 'Profile' },
};

const BAR_H = 68;
const PAD = 8;
const GAP = 92; // room for the scan button
const PILL_W = 62;
const PILL_H = 52;
const SCAN = 70;

function TabItem({ name, focused, onPress, lang, tint }: { name: string; focused: boolean; onPress: () => void; lang: 'hu' | 'en'; tint: string }) {
  const t = TABS[name] ?? TABS.index;
  const pop = useSharedValue(1);
  useEffect(() => {
    if (focused) pop.set(withSequence(withTiming(0.82, { duration: 90 }), withSpring(1, springs.bouncy)));
  }, [focused, pop]);
  const icon = useAnimatedStyle(() => ({ transform: [{ scale: pop.get() }] }));
  const color = focused ? palette.lime : tint;
  return (
    <PressableScale
      accessibilityRole="tab"
      accessibilityLabel={t[lang]}
      accessibilityState={{ selected: focused }}
      onPress={onPress}
      style={{ flex: 1, height: BAR_H, alignItems: 'center', justifyContent: 'center', gap: 3 }}
    >
      <Animated.View style={icon}>
        <Icon name={t.icon} size={22} color={color} strokeWidth={focused ? 2.3 : 1.9} />
      </Animated.View>
      <Txt variant="tiny" color={color} numberOfLines={1} style={{ letterSpacing: 0.1, opacity: focused ? 1 : 0.8 }}>
        {t[lang]}
      </Txt>
    </PressableScale>
  );
}

/** Two soft lime rings that keep rippling out of the scan button. */
function Pulse() {
  const reduced = useReducedMotion();
  const a = useSharedValue(0);
  const b = useSharedValue(0);
  useEffect(() => {
    if (reduced) return;
    const loop = () => withRepeat(withTiming(1, { duration: 2600, easing: Easing.out(Easing.quad) }), -1, false);
    a.set(loop());
    b.set(withDelay(1300, loop()));
  }, [reduced, a, b]);
  const ra = useAnimatedStyle(() => ({ opacity: 0.4 * (1 - a.get()), transform: [{ scale: 1 + a.get() * 0.5 }] }));
  const rb = useAnimatedStyle(() => ({ opacity: 0.4 * (1 - b.get()), transform: [{ scale: 1 + b.get() * 0.5 }] }));
  if (reduced) return null;
  const ring = { position: 'absolute' as const, left: 0, top: 0, width: SCAN, height: SCAN, borderRadius: SCAN / 2, borderWidth: 2, borderColor: palette.lime };
  return (
    <>
      <Animated.View pointerEvents="none" style={[ring, ra]} />
      <Animated.View pointerEvents="none" style={[ring, rb]} />
    </>
  );
}

/** A floating ink pill: two tabs, the raised lime scan button, two tabs. A lime pill slides to the active tab. */
export function TabBar({ state, navigateToTab }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();
  const { c, isDark } = useTheme();
  const lang = useLang();
  const win = useWindowDimensions();
  const barW = Math.min(win.width, 480) - 32;
  const routes = state.routes;
  const split = Math.ceil(routes.length / 2);
  const slots = Math.max(routes.length, 1);
  const slotW = (barW - PAD * 2 - GAP) / slots;
  const centerOf = (i: number) => PAD + slotW * (i + 0.5) + (i >= split ? GAP : 0);

  const x = useSharedValue(centerOf(state.index));
  const target = centerOf(state.index);
  useEffect(() => {
    x.set(withSpring(target, springs.snappy));
  }, [target, x]);
  const pill = useAnimatedStyle(() => ({ transform: [{ translateX: x.get() - PILL_W / 2 }] }));

  const item = (route: (typeof routes)[number], i: number) => (
    <TabItem
      key={route.key}
      name={route.name}
      lang={lang}
      tint={c.tabBarText}
      focused={state.index === i}
      onPress={() => {
        if (state.index !== i) navigateToTab(route.key);
      }}
    />
  );

  return (
    <View pointerEvents="box-none" style={{ position: 'absolute', left: 0, right: 0, bottom: Math.max(insets.bottom, 12), alignItems: 'center' }}>
      <View pointerEvents="box-none" style={{ width: barW }}>
        <View
          style={[
            {
              height: BAR_H,
              borderRadius: radius.pill,
              backgroundColor: c.tabBar,
              borderWidth: 1,
              borderColor: isDark ? 'rgba(238,246,239,0.08)' : 'rgba(255,255,255,0.04)',
            },
            shadow.float,
          ]}
        >
          <View style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, borderRadius: radius.pill, overflow: 'hidden' }}>
            <LinearGradient
              colors={['rgba(255,255,255,0.09)', 'rgba(255,255,255,0)']}
              style={{ position: 'absolute', left: 0, right: 0, top: 0, height: BAR_H / 2 }}
            />
            <Animated.View
              style={[
                {
                  position: 'absolute',
                  left: 0,
                  top: (BAR_H - PILL_H) / 2 - 1,
                  width: PILL_W,
                  height: PILL_H,
                  borderRadius: PILL_H / 2,
                  backgroundColor: 'rgba(198,243,107,0.13)',
                },
                pill,
              ]}
            />
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: PAD }}>
            {routes.slice(0, split).map((r, i) => item(r, i))}
            <View style={{ width: GAP }} />
            {routes.slice(split).map((r, i) => item(r, i + split))}
          </View>
        </View>

        <View pointerEvents="box-none" style={{ position: 'absolute', top: -24, left: barW / 2 - SCAN / 2, width: SCAN, height: SCAN }}>
          <Pulse />
          <PressableScale
            haptic="medium"
            scaleTo={0.9}
            accessibilityRole="button"
            accessibilityLabel={lang === 'hu' ? 'Szkennelés' : 'Scan'}
            onPress={() => router.push('/scan')}
            style={[
              {
                width: SCAN,
                height: SCAN,
                borderRadius: SCAN / 2,
                backgroundColor: palette.lime,
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: 5,
                borderColor: c.bg,
              },
              shadow.float,
            ]}
          >
            <Icon name="scan-barcode" size={30} color={palette.ink} strokeWidth={2.2} />
          </PressableScale>
        </View>
      </View>
    </View>
  );
}
