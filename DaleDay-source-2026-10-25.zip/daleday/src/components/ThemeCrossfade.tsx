import { useEffect, useRef, useState } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import Animated, { FadeOut, ZoomIn, useReducedMotion } from 'react-native-reanimated';

import { colors, palette, type Scheme } from '@/theme/tokens';
import { Icon, useTheme } from '@/ui';

/**
 * When the theme flips (the auto day/night switch, or a tap in the profile), the old background
 * stays on top for a moment with a sun or moon, then fades away. Opacity only: cheap on a phone.
 */
export function ThemeCrossfade() {
  const { scheme, c } = useTheme();
  const reduced = useReducedMotion();
  const prev = useRef<Scheme>(scheme);
  const [flash, setFlash] = useState<{ from: Scheme; to: Scheme; n: number } | null>(null);

  useEffect(() => {
    if (Platform.OS === 'web' && typeof document !== 'undefined') {
      document.documentElement.style.background = c.bg;
      document.body.style.background = c.bg;
      document.querySelector('meta[name="theme-color"]')?.setAttribute('content', c.bg);
    }
    if (prev.current !== scheme) {
      const from = prev.current;
      prev.current = scheme;
      if (!reduced) setFlash((f) => ({ from, to: scheme, n: (f?.n ?? 0) + 1 }));
    }
  }, [scheme, c.bg, reduced]);

  useEffect(() => {
    if (!flash) return;
    const t = setTimeout(() => setFlash(null), 450);
    return () => clearTimeout(t);
  }, [flash]);

  if (!flash) return null;
  return (
    <Animated.View
      key={flash.n}
      pointerEvents="none"
      exiting={FadeOut.duration(650)}
      style={[StyleSheet.absoluteFill, { backgroundColor: colors[flash.from].bg, alignItems: 'center', justifyContent: 'center' }]}
    >
      <Animated.View entering={ZoomIn.springify().damping(12)}>
        <View
          style={{
            width: 96,
            height: 96,
            borderRadius: 48,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: flash.to === 'dark' ? palette.ink : palette.sun,
          }}
        >
          <Icon name={flash.to === 'dark' ? 'moon' : 'sun'} size={44} color={flash.to === 'dark' ? palette.lime : palette.ink} />
        </View>
      </Animated.View>
    </Animated.View>
  );
}
