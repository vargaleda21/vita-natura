// One shared minute clock for time-of-day features (auto theme, greetings).
import { useSyncExternalStore } from 'react';

let now = new Date();
const listeners = new Set<() => void>();
let timer: ReturnType<typeof setInterval> | null = null;

function subscribe(l: () => void) {
  listeners.add(l);
  if (!timer) {
    timer = setInterval(() => {
      const next = new Date();
      if (next.getHours() !== now.getHours() || next.getMinutes() !== now.getMinutes()) {
        now = next;
        for (const f of listeners) f();
      }
    }, 30_000);
  }
  return () => {
    listeners.delete(l);
    if (listeners.size === 0 && timer) {
      clearInterval(timer);
      timer = null;
    }
  };
}

/** The current hour (0–23), updated within half a minute. */
export function useHour(): number {
  return useSyncExternalStore(subscribe, () => now.getHours(), () => now.getHours());
}

/** Night is 19:00–06:59: the auto theme turns dark. */
export function isNightHour(hour: number): boolean {
  return hour >= 19 || hour < 7;
}
