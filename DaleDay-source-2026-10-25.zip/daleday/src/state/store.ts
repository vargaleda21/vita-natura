// App state with no backend: settings and scan history, kept on the device.
// A tiny store on useSyncExternalStore, persisted to AsyncStorage (localStorage on the web).

import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSyncExternalStore } from 'react';

import type { AvoidKey, Member, ScanEntry, Settings } from '@/data/types';

type State = { settings: Settings; history: ScanEntry[]; hydrated: boolean };

const KEY = 'tuda.v1';

export const DEFAULT_SETTINGS: Settings = {
  lang: 'hu',
  theme: 'auto',
  avoid: ['palm_oil', 'added_sugar'],
  members: [],
  onboarded: false,
};

let state: State = { settings: DEFAULT_SETTINGS, history: [], hydrated: false };
const listeners = new Set<() => void>();

function emit(next: State) {
  state = next;
  for (const l of listeners) l();
  if (next.hydrated) {
    void AsyncStorage.setItem(KEY, JSON.stringify({ settings: next.settings, history: next.history }));
  }
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

export async function hydrate(): Promise<void> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (raw) {
      const saved = JSON.parse(raw) as Partial<Pick<State, 'settings' | 'history'>>;
      emit({
        settings: { ...DEFAULT_SETTINGS, ...saved.settings },
        history: saved.history ?? [],
        hydrated: true,
      });
      return;
    }
  } catch {
    // A broken saved state starts fresh.
  }
  emit({ ...state, hydrated: true });
}

export function useAppState<T>(select: (s: State) => T): T {
  return useSyncExternalStore(
    subscribe,
    () => select(state),
    () => select(state),
  );
}

export const useSettings = () => useAppState((s) => s.settings);
export const useHistory = () => useAppState((s) => s.history);
export const useHydrated = () => useAppState((s) => s.hydrated);
export const getSettings = () => state.settings;
export const getHistory = () => state.history;

export function updateSettings(patch: Partial<Settings>) {
  emit({ ...state, settings: { ...state.settings, ...patch } });
}

export function toggleAvoid(key: AvoidKey) {
  const avoid = state.settings.avoid.includes(key)
    ? state.settings.avoid.filter((k) => k !== key)
    : [...state.settings.avoid, key];
  updateSettings({ avoid });
}

export function upsertMember(member: Member) {
  const others = state.settings.members.filter((m) => m.id !== member.id);
  updateSettings({ members: [...others, member] });
}

export function removeMember(id: string) {
  updateSettings({ members: state.settings.members.filter((m) => m.id !== id) });
}

export function addScan(entry: ScanEntry) {
  emit({ ...state, history: [entry, ...state.history].slice(0, 200) });
}

/** Records a swap on the scan it started from: the newest entry, if that is this product and holds no swap
 *  yet. Opened from the history or Discover, or swapped a second time, it is logged as a new entry, so every
 *  swap counts, today. */
export function markSwapped(from: Pick<ScanEntry, 'ean' | 'verdict' | 'score'>, swappedTo: string) {
  const [top, ...rest] = state.history;
  if (top?.ean === from.ean && !top.swapped) {
    emit({ ...state, history: [{ ...top, swapped: true, swappedTo }, ...rest] });
    return;
  }
  addScan({ ...from, at: new Date().toISOString(), swapped: true, swappedTo });
}

export function replaceHistory(history: ScanEntry[]) {
  emit({ ...state, history });
}

export function resetAll() {
  emit({ settings: DEFAULT_SETTINGS, history: [], hydrated: true });
}
