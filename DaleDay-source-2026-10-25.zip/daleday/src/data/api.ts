// The data API. Screens import ONLY from here and from ./types.
// The data agent owns this file and may rewrite the bodies; the signatures stay.

import { formatHuf, groupDigits } from '@/i18n';
import { CRITERIA, CRITERIA_ORDER } from './criteria';
import { candidateCategories, realPrices, realProduct } from './lookup';
import { PRODUCTS } from './products';
import { STORES } from './stores';
import type {
  Alternative,
  AvoidKey,
  CategoryKey,
  ChainPrice,
  Hit,
  Ingredient,
  Insights,
  L10n,
  Lang,
  MatchResult,
  Nutrition,
  Product,
  ScanEntry,
  Settings,
  Store,
  StoreKey,
  StorePrice,
  Verdict,
} from './types';

export { CRITERIA, CRITERIA_ORDER, STORES };

// The real-product lookup (open databases by barcode). Pure TypeScript in ./lookup.
export {
  canonical,
  configureLookup,
  emptyProgress,
  ensureChainPrices,
  countryFromIso,
  fetchAlternativeCandidates,
  filterMakerProducts,
  findMaker,
  makerEligible,
  gs1Info,
  hydrateLookupCache,
  isValidCode,
  lookupCode,
  lookupVersion,
  lookupEnded,
  makeConfirmer,
  offProductUrl,
  pricePending,
  pricesFresh,
  realPrices,
  realProduct,
  refreshPrices,
  SOURCE_ORDER,
  subscribeLookup,
} from './lookup';
export type { Candidates, Gs1Info, LookupOutcome, Maker, MakerProduct, Progress, SourceKey, SourceStatus } from './lookup';

const NBSP = '\u00a0';

export function allProducts(): Product[] {
  return PRODUCTS;
}

const remembered = new Map<string, Product>();

/** Keep a product made at run time (an AI-read label) so getProduct finds it this session. */
export function rememberProduct(product: Product): void {
  remembered.set(product.ean, product);
}

/** A demo product, an AI-read one, or a real one looked up by its barcode (also from the device cache). */
export function getProduct(ean: string): Product | undefined {
  return PRODUCTS.find((p) => p.ean === ean) ?? remembered.get(ean) ?? realProduct(ean);
}

/** The lowest GVH Árfigyelő price of a real product, if it is listed there. */
export function lowestChainPrice(ean: string): ChainPrice | undefined {
  return realPrices(ean)?.arfigyelo?.chains[0];
}

/** A pack size in the reader's language: "1,5 l" in Hungarian, "1.5 l" in English. */
export function localSize(size: string, lang: Lang): string {
  return lang === 'hu' ? size.replace(/(\d)\.(\d)/g, '$1,$2') : size.replace(/(\d),(\d)/g, '$1.$2');
}

/** The scanner's "mystery product": the one code that shows the (mock) AI label reading. It is an
 *  in-store code, so it never reaches the real lookup, and a real code never reaches aiReadLabel. */
export const MYSTERY_EAN = '2000000007700';

/** The codes the scanner offers as "try a demo product" chips. */
export function demoProducts(): Product[] {
  return PRODUCTS.slice(0, 6);
}

export function getStore(key: StoreKey): Store {
  return STORES.find((s) => s.key === key) ?? STORES[0];
}

export function cheapestPrice(product: Product): StorePrice | undefined {
  return [...product.prices].sort((a, b) => a.priceHuf - b.priceHuf)[0];
}

/** Every avoid key that applies: the owner's and every member's. */
export function activeKeys(settings: Settings): AvoidKey[] {
  const all = new Set<AvoidKey>(settings.avoid);
  for (const m of settings.members) for (const k of m.avoid) all.add(k);
  return CRITERIA_ORDER.filter((k) => all.has(k));
}

// ── Scoring ─────────────────────────────────────────────────────────────────
// The verdict is personal: it only looks at what this household chose to avoid.
//  · an allergen, or a flagged ingredient that is the MAIN ingredient (e.g. sugar first on the list),
//    weighs 2; "softer" criteria (E numbers, NOVA 4) weigh 0.75; a "may contain" trace weighs 1;
//    anything else weighs 1.
//  · no hits → great; total weight ≥ 2 → avoid; otherwise okay.
//  · Real products: a criterion no source lets us check (no ingredient list, no NOVA group, no salt
//    value) is "unknown", never a pass. No hits but something unknown → okay, never great.
// The 0–100 score orders products inside a verdict: hits cost more the more people they affect,
// NOVA 4 and high sugar or salt take a little off, positives add a little.

const SOFT: ReadonlySet<AvoidKey> = new Set<AvoidKey>(['additives', 'ultra_processed']);
const SALT_HIGH = 1.5;
const BAND: Record<Verdict, [number, number]> = { great: [72, 99], okay: [45, 69], avoid: [4, 44] };
const VERDICT_RANK: Record<Verdict, number> = { avoid: 0, okay: 1, great: 2 };

function isWater(i: Ingredient): boolean {
  return !i.flags?.length && /water/i.test(i.name.en) && !/juice/i.test(i.name.en);
}

/** Every ingredient, with the parts of compound ones after them (margarine, then its palm oil …). */
function allIngredients(list: Ingredient[]): Ingredient[] {
  const out: Ingredient[] = [];
  for (const i of list) {
    out.push(i);
    if (i.sub?.length) out.push(...allIngredients(i.sub));
  }
  return out;
}

/** The first ingredient that is not plain water: the biggest one by weight. */
function mainIngredient(product: Product): Ingredient | undefined {
  return product.ingredients.find((i) => !isWater(i));
}

function sugarIsHigh(product: Product): boolean {
  const g = product.nutrition.sugarG;
  if (g === undefined) return false;
  return product.category === 'drinks' ? g >= 5 : g >= 22.5;
}

function decimal(n: number, lang: Lang): string {
  const s = String(Math.round(n * 10) / 10);
  return lang === 'hu' ? s.replace('.', ',') : s;
}

type Trigger = { ingredients: L10n[]; trace?: boolean };

/** The ingredients (or the reason) behind one criterion, or null if the product passes it. */
function triggers(product: Product, key: AvoidKey): Trigger | null {
  const found: L10n[] = [];
  const seen = new Set<string>();
  for (const i of allIngredients(product.ingredients)) {
    if (!i.flags?.includes(key) || seen.has(i.name.hu)) continue;
    seen.add(i.name.hu);
    // Honey counts as added sugar because the WHO counts it as a free sugar: the reason says so.
    const honey = key === 'added_sugar' && /^(honey|méz)\b/i.test(i.name.en || i.name.hu);
    found.push(honey ? { hu: `${i.name.hu} (a WHO szerint szabad cukor)`, en: `${i.name.en} (a free sugar, says the WHO)` } : i.name);
  }
  if (key === 'ultra_processed' && product.nova === 4) {
    return { ingredients: [{ hu: 'NOVA 4-es feldolgozottság', en: 'NOVA group 4 processing' }] };
  }
  const salt = product.nutrition.saltG;
  if (key === 'high_salt' && salt !== undefined && salt >= SALT_HIGH) {
    return { ingredients: [{ hu: `${decimal(salt, 'hu')}${NBSP}g só 100${NBSP}g-ban`, en: `${decimal(salt, 'en')}${NBSP}g salt per 100${NBSP}g` }] };
  }
  if (found.length > 0) return { ingredients: found };
  // Real products: what the source declares for the whole product (an allergen, an additive, a trace).
  const flags = product.flags?.filter((f) => f.key === key) ?? [];
  const firm = flags.filter((f) => !f.trace);
  if (firm.length > 0) return { ingredients: firm.map((f) => f.reason) };
  if (flags.length > 0) return { ingredients: flags.map((f) => f.reason), trace: true };
  return null;
}

function hitWeight(product: Product, key: AvoidKey, trace = false): number {
  if (trace) return 1;
  if (CRITERIA[key].group === 'allergy') return 2;
  if (SOFT.has(key)) return 0.75;
  const main = mainIngredient(product);
  if (!main) return 1;
  return main.flags?.includes(key) || allIngredients(main.sub ?? []).some((i) => i.flags?.includes(key)) ? 2 : 1;
}

/** Real products: the criteria no source lets us check. Demo products are always fully known. */
function unknownKeys(product: Product, keys: AvoidKey[], hit: ReadonlySet<AvoidKey>): AvoidKey[] {
  const real = product.real;
  if (!real) return [];
  return keys.filter((k) => {
    if (hit.has(k)) return false;
    if (k === 'ultra_processed') return product.nova === undefined;
    if (k === 'high_salt') return product.nutrition.saltG === undefined;
    return !real.ingredientsKnown;
  });
}

export function evaluate(product: Product, settings: Settings): MatchResult {
  const keys = activeKeys(settings);
  const hits: Hit[] = [];
  let weight = 0;
  let penalty = 0;
  for (const key of keys) {
    const t = triggers(product, key);
    if (!t) continue;
    const who = [
      ...(settings.avoid.includes(key) ? ['me'] : []),
      ...settings.members.filter((m) => m.avoid.includes(key)).map((m) => m.id),
    ];
    const w = hitWeight(product, key, t.trace);
    weight += w;
    penalty += 26 * w * (1 + 0.25 * Math.max(0, who.length - 1));
    const hit: Hit = { key, ingredients: t.ingredients, who };
    if (t.trace) hit.trace = true;
    hits.push(hit);
  }

  const hitKeys = new Set(hits.map((h) => h.key));
  const unknown = unknownKeys(product, keys, hitKeys);
  const verdict: Verdict = hits.length === 0 ? (unknown.length > 0 ? 'okay' : 'great') : weight >= 2 ? 'avoid' : 'okay';
  const positives = product.positives ?? [];
  let raw = 90 - penalty;
  if (product.nova === 4) raw -= 5;
  if (product.nova === 1) raw += 3;
  if (!hitKeys.has('added_sugar') && sugarIsHigh(product)) raw -= 4;
  if (!hitKeys.has('high_salt') && (product.nutrition.saltG ?? 0) >= SALT_HIGH) raw -= 3;
  raw += Math.min(2, positives.length) * 2;
  const [lo, hi] = BAND[verdict];
  // Below an "avoid" band's top the score eases towards a floor instead of hitting it: one avoided
  // ingredient lands in the 30s, a pile of them in the teens, and the order between them survives.
  const eased = verdict === 'avoid' && raw < hi ? 12 + (hi - 12) * Math.exp((raw - hi) / 40) : raw;
  const score = Math.round(Math.max(lo, Math.min(hi, eased)));

  const total = Math.max(keys.length, 1);
  const result: MatchResult = { verdict, score, hits, matched: Math.max(0, total - hits.length - unknown.length), total, positives };
  if (unknown.length > 0) result.unknown = unknown;
  return result;
}

/** True when nothing on the person's list could be checked (no ingredients, not food …): no verdict then. */
export function cannotJudge(result: MatchResult): boolean {
  return result.hits.length === 0 && (result.unknown?.length ?? 0) > 0 && (result.unknown?.length ?? 0) >= result.total;
}

// ── Alternatives ────────────────────────────────────────────────────────────

/** "in the shop" for each fictional chain, with the right Hungarian suffix. */
const STORE_IN: Record<StoreKey, string> = {
  sarok: 'a Sarokboltban',
  megapiac: 'a MegaPiacon',
  zoldkosar: 'a Zöldkosárban',
  napfeny: 'a Napfény ABC-ben',
  kosarka: 'a Kosárka webshopban',
};

/** How "without X" reads in each language. Nouns join as "X és Y nélkül"; the rest are adjectives.
 *  `lessHu`: the singular after "Kevesebb" ("Kevesebb E-szám"), when it differs. */
const WITHOUT: Record<AvoidKey, { hu: string; en: string; noun: boolean; lessHu?: string }> = {
  palm_oil: { hu: 'pálmaolaj', en: 'palm oil', noun: true },
  added_sugar: { hu: 'hozzáadott cukor', en: 'added sugar', noun: true },
  sweeteners: { hu: 'édesítőszer', en: 'sweeteners', noun: true },
  additives: { hu: 'E-számok', en: 'E numbers', noun: true, lessHu: 'E-szám' },
  nitrites: { hu: 'nitrit', en: 'nitrites', noun: true },
  artificial_colors: { hu: 'mesterséges színezék', en: 'artificial colours', noun: true },
  ultra_processed: { hu: 'kevésbé feldolgozott', en: 'less processed', noun: false },
  high_salt: { hu: 'kevesebb sóval', en: 'less salt', noun: false },
  lactose: { hu: 'laktózmentes', en: 'lactose-free', noun: false },
  gluten: { hu: 'gluténmentes', en: 'gluten-free', noun: false },
  nuts: { hu: 'dió és mogyoró', en: 'nuts', noun: true },
  egg: { hu: 'tojás', en: 'egg', noun: true },
  soy: { hu: 'szója', en: 'soya', noun: true },
  caffeine: { hu: 'koffeinmentes', en: 'caffeine-free', noun: false },
};

function listJoin(items: string[], and: string): string {
  if (items.length <= 1) return items[0] ?? '';
  return `${items.slice(0, -1).join(', ')} ${and} ${items[items.length - 1]}`;
}

function capitalise(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function whatChanged(removed: AvoidKey[], weakened: AvoidKey[], alt: Product): L10n {
  if (removed.length === 0) {
    const less = weakened.find((k) => WITHOUT[k].noun);
    if (less) return { hu: `Kevesebb ${WITHOUT[less].lessHu ?? WITHOUT[less].hu}`, en: `Less ${WITHOUT[less].en}` };
    const first = alt.positives?.[0];
    return first ?? { hu: 'Jobban illik a beállításaidhoz', en: 'A better match for your settings' };
  }
  const nouns = removed.filter((k) => WITHOUT[k].noun);
  const adjs = removed.filter((k) => !WITHOUT[k].noun);
  const hu: string[] = [];
  const en: string[] = [];
  if (nouns.length) {
    hu.push(`${listJoin(nouns.map((k) => WITHOUT[k].hu), 'és')} nélkül`);
    en.push(`no ${listJoin(nouns.map((k) => WITHOUT[k].en), 'or')}`);
  }
  for (const k of adjs) {
    hu.push(WITHOUT[k].hu);
    en.push(WITHOUT[k].en);
  }
  return { hu: capitalise(hu.join(', ')), en: capitalise(en.join(', ')) };
}

type PriceCompare =
  | { kind: 'cheaper'; store: StoreKey; diff: number }
  | { kind: 'same'; store: StoreKey }
  | { kind: 'dearer'; store: StoreKey; diff: number }
  | { kind: 'elsewhere'; store: StoreKey }
  | { kind: 'none' };

function comparePrices(scanned: Product, alt: Product): PriceCompare {
  let best: { store: StoreKey; diff: number } | null = null;
  for (const ap of alt.prices) {
    const sp = scanned.prices.find((q) => q.store === ap.store);
    if (!sp) continue;
    const diff = sp.priceHuf - ap.priceHuf;
    if (!best || diff > best.diff) best = { store: ap.store, diff };
  }
  if (best) {
    if (best.diff > 0) return { kind: 'cheaper', ...best };
    if (best.diff === 0) return { kind: 'same', store: best.store };
    return { kind: 'dearer', store: best.store, diff: -best.diff };
  }
  const cheapest = cheapestPrice(alt);
  return cheapest ? { kind: 'elsewhere', store: cheapest.store } : { kind: 'none' };
}

function priceLine(cmp: PriceCompare): L10n | null {
  switch (cmp.kind) {
    case 'cheaper':
      return {
        hu: `és ${STORE_IN[cmp.store]} ${groupDigits(cmp.diff, NBSP)}${NBSP}Ft-tal olcsóbb`,
        en: `and ${formatHuf(cmp.diff, 'en')} cheaper at ${getStore(cmp.store).name}`,
      };
    case 'same':
      return { hu: `és ${STORE_IN[cmp.store]} ugyanannyiba kerül`, en: `and the same price at ${getStore(cmp.store).name}` };
    case 'dearer':
      return {
        hu: `${STORE_IN[cmp.store]} is megvan (+${formatHuf(cmp.diff, 'hu')})`,
        en: `also at ${getStore(cmp.store).name} (+${formatHuf(cmp.diff, 'en')})`,
      };
    case 'elsewhere':
      return { hu: `${STORE_IN[cmp.store]} kapható`, en: `available at ${getStore(cmp.store).name}` };
    default:
      return null;
  }
}

/** Better choices from the demo catalogue. Real products never get demo alternatives: see realAlternativesFor. */
export function alternativesFor(product: Product, settings: Settings): Alternative[] {
  if (product.real) return [];
  const mine = evaluate(product, settings);
  const mineKeys = new Set(mine.hits.map((h) => h.key));
  return PRODUCTS.filter((p) => p.ean !== product.ean && p.category === product.category)
    .map((p) => {
      const result = evaluate(p, settings);
      const theirKeys = new Set(result.hits.map((h) => h.key));
      const removed = CRITERIA_ORDER.filter((k) => mineKeys.has(k) && !theirKeys.has(k));
      const weakened = CRITERIA_ORDER.filter((k) => mineKeys.has(k) && theirKeys.has(k) && hitWeight(product, k) > hitWeight(p, k));
      const cmp = comparePrices(product, p);
      const what = whatChanged(removed, weakened, p);
      const price = priceLine(cmp);
      const reason: L10n = price
        ? { hu: `${what.hu}, ${price.hu}.`, en: `${what.en}, ${price.en}.` }
        : { hu: `${what.hu}.`, en: `${what.en}.` };
      const alt: Alternative = { product: p, result, reason };
      if (cmp.kind === 'cheaper') {
        alt.sameStore = cmp.store;
        alt.savingHuf = cmp.diff;
      }
      return alt;
    })
    .filter((a) => {
      // A better verdict, or (for fair and good products) the same verdict with a clearly higher score.
      const up = VERDICT_RANK[a.result.verdict] - VERDICT_RANK[mine.verdict];
      return up > 0 || (up === 0 && mine.verdict !== 'avoid' && a.result.score >= mine.score + 5);
    })
    .sort((a, b) => {
      const byVerdict = VERDICT_RANK[b.result.verdict] - VERDICT_RANK[a.result.verdict];
      if (byVerdict !== 0) return byVerdict;
      // Same verdict: being cheaper in the same shop counts a little. A commission never does.
      const bonus = (x: Alternative) => (x.savingHuf ? 3 + Math.min(3, x.savingHuf / 100) : 0);
      return b.result.score + bonus(b) - (a.result.score + bonus(a));
    });
}

const NUTRI_RANK = { a: 0, b: 1, c: 2, d: 3, e: 4 } as const;

function soldInHungary(p: Product): boolean {
  return !!p.real?.countries.some((c) => c.iso2 === 'HU');
}

/** "a C" but "az A" / "az E": the Hungarian article before a spoken letter. */
function letterArticle(l: string): string {
  return l === 'A' || l === 'E' ? 'az' : 'a';
}

/**
 * Better choices for a real product, from real candidates only (an Open Food Facts search in the same
 * category, see fetchAlternativeCandidates). A candidate qualifies when it fits the person's list with
 * nothing unknown and its Nutri-Score is no worse (strictly better when the scanned one fits already).
 * The same shelf comes first (the most specific shared category), then products sold in Hungary;
 * GVH Árfigyelő prices are added when the chains list them.
 */
export function realAlternativesFor(product: Product, settings: Settings, candidates: Product[]): Alternative[] {
  const mine = evaluate(product, settings);
  const mineKeys = CRITERIA_ORDER.filter((k) => mine.hits.some((h) => h.key === k));
  const myGrade = product.real?.nutriscore;
  const myRank = myGrade ? NUTRI_RANK[myGrade] : undefined;
  const fits = mine.verdict === 'great';
  const myChains = realPrices(product.ean)?.arfigyelo?.chains ?? [];
  const shelves = candidateCategories(product);
  const shelf = (p: Product) => {
    const i = shelves.findIndex((c) => p.real?.categoryTags.includes(c));
    return i < 0 ? shelves.length : i;
  };
  const seen = new Set<string>();
  const picked: Alternative[] = [];
  for (const c of candidates) {
    if (c.ean === product.ean || !c.real || seen.has(c.ean)) continue;
    seen.add(c.ean);
    const grade = c.real.nutriscore;
    if (!grade) continue;
    const rank = NUTRI_RANK[grade];
    const better =
      myRank === undefined
        ? rank <= (fits ? 1 : 2)
        : fits
          ? rank < myRank || (rank === myRank && c.nova !== undefined && product.nova !== undefined && c.nova < product.nova)
          : rank <= myRank;
    if (!better) continue;
    const result = evaluate(c, settings);
    if (result.verdict !== 'great' || result.unknown?.length) continue;

    const what = mineKeys.length > 0 ? whatChanged(mineKeys, [], c) : null;
    const g = grade.toUpperCase();
    const was = myGrade?.toUpperCase();
    const grades: L10n =
      was && myRank !== undefined && rank < myRank
        ? { hu: `Nutri-Score ${g} ${letterArticle(was)} ${was} helyett`, en: `Nutri-Score ${g} instead of ${was}` }
        : { hu: `Nutri-Score ${g}`, en: `Nutri-Score ${g}` };
    const reason: L10n = what
      ? { hu: `${what.hu}, ${grades.hu}.`, en: `${what.en}, ${grades.en}.` }
      : { hu: `${grades.hu}.`, en: `${grades.en}.` };
    const alt: Alternative = { product: c, result, reason };

    const theirs = realPrices(c.ean)?.arfigyelo?.chains ?? [];
    if (theirs[0]) alt.chainPrice = { chain: theirs[0].chain, priceHuf: theirs[0].priceHuf };
    let best: { chain: string; savingHuf: number } | undefined;
    for (const t of theirs) {
      const m = myChains.find((x) => x.chain === t.chain);
      if (!m) continue;
      const saving = m.priceHuf - t.priceHuf;
      if (saving > 0 && (!best || saving > best.savingHuf)) best = { chain: t.chain, savingHuf: saving };
    }
    if (best) alt.chainSaving = best;
    picked.push(alt);
  }
  const gradeOf = (a: Alternative) => NUTRI_RANK[a.product.real?.nutriscore ?? 'e'];
  return picked
    .sort(
      (a, b) =>
        shelf(a.product) - shelf(b.product) ||
        Number(soldInHungary(b.product)) - Number(soldInHungary(a.product)) ||
        Number(!!b.chainPrice) - Number(!!a.chainPrice) ||
        gradeOf(a) - gradeOf(b) ||
        (a.product.nova ?? 5) - (b.product.nova ?? 5) ||
        b.result.score - a.result.score,
    )
    .slice(0, 6);
}

// ── AI label reading (mocked) ───────────────────────────────────────────────

type LabelTemplate = {
  category: CategoryKey;
  name: (flavour: L10n) => L10n;
  flavours: L10n[];
  sizes: string[];
  art: Product['art'][];
  ingredients: (flavour: L10n) => Ingredient[];
  nutrition: Required<Nutrition>;
  nova: Product['nova'];
  basePrice: number;
};

const LABEL_BRANDS = ['Dombvidék', 'Szélmalom', 'Pacsirta', 'Kisrét', 'Holdfény', 'Tavaszmező', 'Kerekdomb'];

const LABELS: LabelTemplate[] = [
  {
    category: 'sweets',
    name: (f) => ({ hu: `${f.hu} omlós keksz`, en: `${f.en} shortbread biscuits` }),
    flavours: [
      { hu: 'Kakaós', en: 'Cocoa' },
      { hu: 'Vaníliás', en: 'Vanilla' },
      { hu: 'Citromos', en: 'Lemon' },
      { hu: 'Zabpelyhes', en: 'Oat' },
    ],
    sizes: ['150 g', '200 g', '250 g'],
    art: [
      { colors: ['#8A5A2B', '#F2C88C'], emoji: '🍪', shape: 'box' },
      { colors: ['#C48A2C', '#FFE6A8'], emoji: '🍪', shape: 'box' },
    ],
    ingredients: (f) => [
      { name: { hu: 'búzaliszt', en: 'wheat flour' }, flags: ['gluten'] },
      { name: { hu: 'cukor', en: 'sugar' }, flags: ['added_sugar'] },
      { name: { hu: 'pálmazsír', en: 'palm fat' }, flags: ['palm_oil'] },
      { name: { hu: `${f.hu.toLowerCase()} ízesítés`, en: `${f.en.toLowerCase()} flavouring` }, percent: 4 },
      { name: { hu: 'glükóz-fruktóz szirup', en: 'glucose-fructose syrup' }, flags: ['added_sugar'] },
      { name: { hu: 'térfogatnövelő szer: nátrium-karbonátok', en: 'raising agent: sodium carbonates' }, flags: ['additives'], eNumber: 'E500' },
      { name: { hu: 'só', en: 'salt' } },
      { name: { hu: 'emulgeálószer: szójalecitin', en: 'emulsifier: soya lecithin' }, flags: ['soy', 'additives'], eNumber: 'E322' },
    ],
    nutrition: { energyKcal: 472, sugarG: 26, satFatG: 9.2, saltG: 0.6, fiberG: 2.5, proteinG: 6.4 },
    nova: 4,
    basePrice: 429,
  },
  {
    category: 'ready_meals',
    // A noun joins "ízű" in one word (csirkeízű), an adjective stays apart (zöldséges ízű).
    name: (f) => ({ hu: `Instant tésztaleves, ${/s$/.test(f.hu) ? `${f.hu.toLowerCase()} ízű` : `${f.hu.toLowerCase()}ízű`}`, en: `Instant noodle soup, ${f.en.toLowerCase()}` }),
    flavours: [
      { hu: 'Csirke', en: 'Chicken' },
      { hu: 'Marha', en: 'Beef' },
      { hu: 'Zöldséges', en: 'Vegetable' },
    ],
    sizes: ['60 g', '65 g', '70 g'],
    art: [
      { colors: ['#D9502A', '#FFD08A'], emoji: '🍜', shape: 'bag' },
      { colors: ['#B8402A', '#FFC93D'], emoji: '🍜', shape: 'cup' },
    ],
    ingredients: (f) => [
      { name: { hu: 'tészta (búzaliszt, pálmaolaj, só)', en: 'noodles (wheat flour, palm oil, salt)' }, flags: ['gluten', 'palm_oil'], percent: 88 },
      { name: { hu: 'só', en: 'salt' } },
      { name: { hu: 'ízfokozó: mononátrium-glutamát', en: 'flavour enhancer: monosodium glutamate' }, flags: ['additives'], eNumber: 'E621' },
      { name: { hu: 'cukor', en: 'sugar' }, flags: ['added_sugar'] },
      { name: { hu: `${f.hu.toLowerCase()} aroma`, en: `${f.en.toLowerCase()} flavouring` } },
      { name: { hu: 'szárított zöldségek', en: 'dried vegetables' }, percent: 1.5 },
    ],
    nutrition: { energyKcal: 452, sugarG: 2.4, satFatG: 8.1, saltG: 4.6, fiberG: 2.2, proteinG: 9.1 },
    nova: 4,
    basePrice: 189,
  },
  {
    category: 'drinks',
    name: (f) => ({ hu: `100% ${f.hu.toLowerCase()}lé`, en: `100% ${f.en.toLowerCase()} juice` }),
    flavours: [
      { hu: 'Alma', en: 'Apple' },
      { hu: 'Narancs', en: 'Orange' },
      { hu: 'Meggy', en: 'Sour cherry' },
    ],
    sizes: ['1 l', '0,33 l'],
    art: [
      { colors: ['#E0A020', '#FFF0B8'], emoji: '🧃', shape: 'box' },
      { colors: ['#C8323C', '#FFC2C2'], emoji: '🧃', shape: 'bottle' },
    ],
    ingredients: (f) => [
      { name: { hu: `${f.hu.toLowerCase()}lé sűrítményből`, en: `${f.en.toLowerCase()} juice from concentrate` }, percent: 100 },
    ],
    nutrition: { energyKcal: 46, sugarG: 10.2, satFatG: 0, saltG: 0.01, fiberG: 0.2, proteinG: 0.3 },
    nova: 1,
    basePrice: 549,
  },
  {
    category: 'snacks',
    name: (f) => ({ hu: `${f.hu} müzliszelet`, en: `${f.en} cereal bar` }),
    flavours: [
      { hu: 'Csokis', en: 'Chocolate' },
      { hu: 'Áfonyás', en: 'Cranberry' },
      { hu: 'Mogyorós', en: 'Hazelnut' },
    ],
    sizes: ['25 g', '30 g', '6 × 25 g'],
    art: [
      { colors: ['#6B8E23', '#E6F5A8'], emoji: '🌾', shape: 'bar' },
      { colors: ['#9B4D96', '#F0C8EE'], emoji: '🌾', shape: 'bar' },
    ],
    ingredients: (f) => [
      { name: { hu: 'zabpehely', en: 'oat flakes' }, flags: ['gluten'], percent: 38 },
      { name: { hu: 'glükózszirup', en: 'glucose syrup' }, flags: ['added_sugar'] },
      { name: { hu: 'cukor', en: 'sugar' }, flags: ['added_sugar'] },
      { name: { hu: 'pálmazsír', en: 'palm fat' }, flags: ['palm_oil'] },
      { name: { hu: `${f.hu.toLowerCase()} darabkák`, en: `${f.en.toLowerCase()} pieces` }, percent: 8 },
      { name: { hu: 'rizspehely', en: 'rice crisps' } },
      { name: { hu: 'emulgeálószer: szójalecitin', en: 'emulsifier: soya lecithin' }, flags: ['soy', 'additives'], eNumber: 'E322' },
    ],
    nutrition: { energyKcal: 418, sugarG: 29, satFatG: 7.4, saltG: 0.4, fiberG: 4.1, proteinG: 5.8 },
    nova: 4,
    basePrice: 149,
  },
  {
    category: 'dairy',
    name: (f) => ({ hu: `${f.hu} puding`, en: `${f.en} pudding` }),
    flavours: [
      { hu: 'Vaníliás', en: 'Vanilla' },
      { hu: 'Csokoládés', en: 'Chocolate' },
      { hu: 'Karamellás', en: 'Caramel' },
    ],
    sizes: ['125 g', '4 × 125 g'],
    art: [
      { colors: ['#E8B923', '#FFF3C4'], emoji: '🍮', shape: 'cup' },
      { colors: ['#7A4A2A', '#E8C9A8'], emoji: '🍮', shape: 'cup' },
    ],
    ingredients: (f) => [
      { name: { hu: 'tej', en: 'milk' }, flags: ['lactose'], percent: 78 },
      { name: { hu: 'cukor', en: 'sugar' }, flags: ['added_sugar'] },
      { name: { hu: 'módosított keményítő', en: 'modified starch' }, flags: ['additives'], eNumber: 'E1442' },
      { name: { hu: 'sűrítőanyag: karragén', en: 'thickener: carrageenan' }, flags: ['additives'], eNumber: 'E407' },
      { name: { hu: `${f.hu.toLowerCase()} aroma`, en: `${f.en.toLowerCase()} flavouring` } },
      { name: { hu: 'színezék: béta-karotin', en: 'colour: beta-carotene' }, flags: ['additives'], eNumber: 'E160a' },
    ],
    nutrition: { energyKcal: 112, sugarG: 15.5, satFatG: 1.8, saltG: 0.15, fiberG: 0.3, proteinG: 3.1 },
    nova: 4,
    basePrice: 229,
  },
  {
    category: 'bakery',
    name: (f) => ({ hu: `Szeletelt ${f.hu.toLowerCase()} kenyér`, en: `Sliced ${f.en.toLowerCase()} bread` }),
    flavours: [
      { hu: 'Rozsos', en: 'Rye' },
      { hu: 'Magvas', en: 'Seeded' },
      { hu: 'Tönkölyös', en: 'Spelt' },
    ],
    sizes: ['500 g', '750 g'],
    art: [
      { colors: ['#9A6A3A', '#F4D7A1'], emoji: '🍞', shape: 'bag' },
      { colors: ['#6E4B2A', '#E8C9A0'], emoji: '🍞', shape: 'bag' },
    ],
    ingredients: (f) => [
      { name: { hu: 'búzaliszt', en: 'wheat flour' }, flags: ['gluten'] },
      { name: { hu: 'víz', en: 'water' } },
      { name: { hu: `${f.hu.toLowerCase()} őrlemény`, en: `${f.en.toLowerCase()} flour` }, flags: ['gluten'], percent: 20 },
      { name: { hu: 'napraforgómag', en: 'sunflower seeds' }, percent: 4 },
      { name: { hu: 'élesztő', en: 'yeast' } },
      { name: { hu: 'só', en: 'salt' } },
    ],
    nutrition: { energyKcal: 248, sugarG: 2.6, satFatG: 0.6, saltG: 1.2, fiberG: 6.8, proteinG: 8.9 },
    nova: 3,
    basePrice: 699,
  },
];

/** A mock of "photograph the label, AI reads it" for codes we do not know. The same code always gives the same product. */
export async function aiReadLabel(ean: string): Promise<Product> {
  await new Promise((r) => setTimeout(r, 1800));
  const digits = ean.replace(/\D/g, '').split('').map(Number);
  let seed = 7;
  for (const d of digits) seed = (seed * 31 + d) % 100_003;
  const pick = <T,>(list: T[], salt: number): T => list[(seed + salt * 7919) % list.length];
  const t = pick(LABELS, 0);
  const flavour = pick(t.flavours, 1);
  const wobble = ((seed % 9) - 4) / 100; // ±4%, so two unknown biscuits are not identical
  const n = t.nutrition;
  const round1 = (x: number) => Math.round(x * (1 + wobble) * 10) / 10;
  const shops = STORES.filter((s) => !s.online);
  const price = Math.round((t.basePrice * (1 + wobble * 2)) / 10) * 10 - 1;
  return {
    ean,
    name: t.name(flavour),
    brand: pick(LABEL_BRANDS, 2),
    category: t.category,
    size: pick(t.sizes, 3),
    art: pick(t.art, 4),
    ingredients: t.ingredients(flavour),
    nutrition: {
      energyKcal: Math.round(n.energyKcal * (1 + wobble)),
      sugarG: round1(n.sugarG),
      satFatG: round1(n.satFatG),
      saltG: round1(n.saltG),
      fiberG: round1(n.fiberG),
      proteinG: round1(n.proteinG),
    },
    nova: t.nova,
    prices: [
      { store: shops[seed % shops.length].key, priceHuf: price },
      { store: shops[(seed + 2) % shops.length].key, priceHuf: price + 40 },
    ],
    dataSource: { kind: 'ai_label', updated: new Date().toISOString().slice(0, 10) },
  };
}

// ── Insights ────────────────────────────────────────────────────────────────

/** Grams (or ml) in a pack: "400 g", "1,5 l", "4 × 125 g". */
function packGrams(size: string): number {
  const m = size.replace(',', '.').match(/(?:(\d+)\s*[×x]\s*)?(\d+(?:\.\d+)?)\s*(kg|g|ml|l)\b/i);
  if (!m) return 100;
  const count = m[1] ? Number(m[1]) : 1;
  const unit = m[3].toLowerCase();
  const n = Number(m[2]) * (unit === 'kg' || unit === 'l' ? 1000 : 1);
  return count * n;
}

/** A rough "added sugar per 100 g": all sugar if sugar was added, minus milk's own lactose. */
function addedSugarPer100(p: Product): number {
  const added = p.ingredients.some((i) => i.flags?.includes('added_sugar'));
  if (!added) return 0;
  return Math.max(0, (p.nutrition.sugarG ?? 0) - (p.category === 'dairy' ? 4.7 : 0));
}

function hasPalm(p: Product): boolean {
  return p.ingredients.some((i) => i.flags?.includes('palm_oil'));
}

function dayKey(d: Date): string {
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

function swapTarget(entry: ScanEntry, product: Product, settings: Settings): Product | undefined {
  if (entry.swappedTo) return getProduct(entry.swappedTo);
  return alternativesFor(product, settings)[0]?.product;
}

function swapSaving(from: Product, to: Product): number {
  const cmp = comparePrices(from, to);
  if (cmp.kind === 'cheaper') return cmp.diff;
  if (cmp.kind === 'elsewhere') {
    const a = cheapestPrice(from)?.priceHuf ?? 0;
    const b = cheapestPrice(to)?.priceHuf ?? 0;
    return Math.max(0, a - b);
  }
  return 0;
}

export function insights(history: ScanEntry[], settings: Settings): Insights {
  const byVerdict: Record<Verdict, number> = { great: 0, okay: 0, avoid: 0 };
  const hitCount = new Map<AvoidKey, number>();
  const days = new Set<string>();
  let swaps = 0;
  let savedHuf = 0;
  let sugarGrams = 0;
  let basket = 0;
  let palmFree = 0;
  let bestSwap: Insights['bestSwap'];
  let bestImpact = -1;

  for (const entry of history) {
    byVerdict[entry.verdict] += 1;
    days.add(dayKey(new Date(entry.at)));
    const product = getProduct(entry.ean);
    if (!product) continue;

    for (const h of evaluate(product, settings).hits) hitCount.set(h.key, (hitCount.get(h.key) ?? 0) + 1);

    let took = product;
    if (entry.swapped) {
      swaps += 1;
      const to = swapTarget(entry, product, settings);
      if (to) {
        took = to;
        const saved = swapSaving(product, to);
        const grams = Math.max(0, addedSugarPer100(product) - addedSugarPer100(to)) * (packGrams(product.size) / 100);
        savedHuf += saved;
        sugarGrams += grams;
        const spoons = Math.round(grams / 4);
        const impact = saved + spoons * 25;
        if (impact > bestImpact) {
          bestImpact = impact;
          bestSwap = { from: product.ean, to: to.ean, savedHuf: saved, sugarSpoons: spoons };
        }
      }
    }
    basket += 1;
    if (!hasPalm(took)) palmFree += 1;
  }

  // Streak: consecutive days with a scan, ending today (or yesterday, if today has none yet).
  const now = new Date();
  const cursor = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (!days.has(dayKey(cursor))) cursor.setDate(cursor.getDate() - 1);
  let streakDays = 0;
  while (days.has(dayKey(cursor))) {
    streakDays += 1;
    cursor.setDate(cursor.getDate() - 1);
  }

  const weekly: number[] = [];
  for (let i = 6; i >= 0; i -= 1) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
    const k = dayKey(d);
    weekly.push(history.filter((h) => dayKey(new Date(h.at)) === k).length);
  }

  const topHits = [...hitCount.entries()]
    .map(([key, count]) => ({ key, count }))
    .sort((a, b) => b.count - a.count || CRITERIA_ORDER.indexOf(a.key) - CRITERIA_ORDER.indexOf(b.key));

  return {
    scans: history.length,
    avoided: byVerdict.avoid,
    swaps,
    savedHuf: Math.round(savedHuf),
    topHit: topHits[0]?.key ?? null,
    sugarSpoons: Math.round(sugarGrams / 4),
    palmFreeShare: basket > 0 ? palmFree / basket : 0,
    streakDays,
    byVerdict,
    weekly,
    topHits,
    bestSwap,
  };
}
