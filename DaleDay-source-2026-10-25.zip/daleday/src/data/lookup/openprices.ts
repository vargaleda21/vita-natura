// Open Prices (Open Food Facts): prices people photographed in shops and shared. CORS allowed.

import type { PriceSighting } from '../types';
import { getJson, qs, type FetchError } from './http';

type OpItem = {
  price?: number;
  currency?: string;
  date?: string;
  price_is_discounted?: boolean;
  location?: {
    osm_name?: string;
    osm_address_city?: string;
    osm_address_country?: string;
    osm_address_country_code?: string;
  } | null;
};

export type OpLookup = { kind: 'found'; sightings: PriceSighting[] } | { kind: 'missing' } | { kind: 'error'; error: FetchError };

export async function fetchOpenPrices(code: string, signal?: AbortSignal): Promise<OpLookup> {
  const url = `https://prices.openfoodfacts.org/api/v1/prices?${qs({ product_code: code, order_by: '-date', size: 20, app_name: 'DaleDay' })}`;
  const r = await getJson<{ items?: OpItem[] }>(url, { signal });
  if (!r.ok) return r.status === 404 ? { kind: 'missing' } : { kind: 'error', error: r.error };
  const sightings: PriceSighting[] = [];
  for (const it of r.data.items ?? []) {
    if (typeof it.price !== 'number' || !it.currency || !it.date) continue;
    const loc = it.location ?? undefined;
    sightings.push({
      price: it.price,
      currency: it.currency,
      date: it.date.slice(0, 10),
      discounted: it.price_is_discounted === true,
      shop: loc?.osm_name || undefined,
      city: loc?.osm_address_city || undefined,
      country: loc?.osm_address_country || undefined,
      iso2: loc?.osm_address_country_code?.toUpperCase() || undefined,
    });
  }
  sightings.sort((a, b) => b.date.localeCompare(a.date));
  return sightings.length > 0 ? { kind: 'found', sightings } : { kind: 'missing' };
}
