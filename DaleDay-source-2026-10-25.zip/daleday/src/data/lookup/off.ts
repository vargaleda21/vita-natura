// Open Food Facts and its sister databases (same API, CORS *): product by barcode, taxonomy names, search.
// Browsers cannot set a User-Agent, so every call names the app with app_name=DaleDay.

import { getJson, proxyUrl, qs, type FetchError } from './http';

export type OffFlavor = 'food' | 'beauty' | 'product' | 'petfood';

export const OFF_HOSTS: Record<OffFlavor, string> = {
  food: 'https://world.openfoodfacts.org',
  beauty: 'https://world.openbeautyfacts.org',
  product: 'https://world.openproductsfacts.org',
  petfood: 'https://world.openpetfoodfacts.org',
};

export type OffIngredient = {
  id?: string;
  text?: string;
  percent?: number;
  percent_estimate?: number;
  from_palm_oil?: string;
  is_in_taxonomy?: number;
  ingredients?: OffIngredient[];
};

/** Names in other Latin-script languages, for a product whose Hungarian and English names are missing
 *  or written in another script (someone saved a Ukrainian name as the English one). */
export const OTHER_NAME_LANGS = ['de', 'fr', 'it', 'es', 'pl', 'cs', 'sk', 'ro', 'nl', 'pt', 'hr', 'sl'] as const;
const OTHER_NAME_FIELDS = OTHER_NAME_LANGS.map((l) => `product_name_${l}`);
/** Every field a name can come from. */
export const NAME_FIELDS = [
  'product_name',
  'product_name_hu',
  'product_name_en',
  ...OTHER_NAME_FIELDS,
  'abbreviated_product_name',
  'generic_name',
  'generic_name_hu',
  'generic_name_en',
];

export type OffProduct = {
  [name: `product_name_${string}`]: string | undefined;
  code?: string;
  product_name?: string;
  abbreviated_product_name?: string;
  product_name_hu?: string;
  product_name_en?: string;
  generic_name?: string;
  generic_name_hu?: string;
  generic_name_en?: string;
  brands?: string;
  quantity?: string;
  categories_tags?: string[];
  compared_to_category?: string;
  countries_tags?: string[];
  stores?: string;
  ingredients?: OffIngredient[];
  ingredients_text?: string;
  ingredients_text_hu?: string;
  ingredients_text_en?: string;
  ingredients_lc?: string;
  ingredients_analysis_tags?: string[];
  allergens_tags?: string[];
  traces_tags?: string[];
  additives_tags?: string[];
  nova_group?: number | string;
  nutriscore_grade?: string;
  nutriments?: Record<string, number | string | undefined>;
  labels_tags?: string[];
  image_front_url?: string;
  image_front_small_url?: string;
  image_url?: string;
  image_small_url?: string;
  last_modified_t?: number;
  product_type?: string;
  lang?: string;
  /** Uploaded photos ("1", "2" …) and the ones chosen for a slot ("front_hu": { imgid, rev }). */
  images?: Record<string, { imgid?: number | string; rev?: number | string } | undefined>;
};

const FIELDS = [
  'code',
  'product_name',
  'product_name_hu',
  'product_name_en',
  ...OTHER_NAME_FIELDS,
  'abbreviated_product_name',
  'generic_name',
  'generic_name_hu',
  'generic_name_en',
  'brands',
  'quantity',
  'categories_tags',
  'compared_to_category',
  'countries_tags',
  'stores',
  'ingredients',
  'ingredients_text',
  'ingredients_text_hu',
  'ingredients_text_en',
  'ingredients_lc',
  'ingredients_analysis_tags',
  'allergens_tags',
  'traces_tags',
  'additives_tags',
  'nova_group',
  'nutriscore_grade',
  'nutriments',
  'labels_tags',
  'image_front_url',
  'image_front_small_url',
  'image_url',
  'image_small_url',
  'last_modified_t',
  'product_type',
  'lang',
  'images',
].join(',');

export type OffLookup =
  | { kind: 'found'; flavor: OffFlavor; product: OffProduct }
  /** Not in this database. `elsewhere`: the shared index says another database has it. */
  | { kind: 'missing'; elsewhere?: OffFlavor }
  | { kind: 'error'; error: FetchError };

type OffResponse = { status?: number; status_verbose?: string; product?: OffProduct };

const OTHER_TYPE = /different product type:\s*(food|beauty|product|petfood)/;

export async function fetchOffProduct(flavor: OffFlavor, code: string, signal?: AbortSignal): Promise<OffLookup> {
  const url = `${OFF_HOSTS[flavor]}/api/v2/product/${code}.json?${qs({ fields: FIELDS, app_name: 'DaleDay' })}`;
  const r = await getJson<OffResponse>(url, { signal });
  const body = (r.ok ? r.data : (r.data as OffResponse | undefined)) ?? {};
  if (r.ok && body.status === 1 && body.product) return { kind: 'found', flavor, product: body.product };
  if (r.ok || r.status === 404) {
    const m = OTHER_TYPE.exec(body.status_verbose ?? '');
    const elsewhere = m ? (m[1] as OffFlavor) : undefined;
    return { kind: 'missing', elsewhere: elsewhere && elsewhere !== flavor ? elsewhere : undefined };
  }
  return { kind: 'error', error: r.ok ? 'parse' : r.error };
}

/** The page of a product on its database. */
export function offProductUrl(flavor: OffFlavor, code: string): string {
  return `${OFF_HOSTS[flavor]}/product/${code}`;
}

export type TaxonomyNames = Record<string, { hu?: string; en?: string }>;

const taxonomyMemo = new Map<string, { hu?: string; en?: string }>();

/** Hungarian and English names for taxonomy tags (ingredients, additives, labels …), memoised. */
export async function fetchTaxonomyNames(
  tagtype: 'ingredients' | 'additives' | 'labels' | 'allergens' | 'countries' | 'categories',
  tags: string[],
  signal?: AbortSignal,
): Promise<TaxonomyNames> {
  const out: TaxonomyNames = {};
  const missing: string[] = [];
  for (const tag of new Set(tags)) {
    const known = taxonomyMemo.get(`${tagtype}|${tag}`);
    if (known) out[tag] = known;
    else if (/^[a-z]{2}:/.test(tag)) missing.push(tag);
  }
  for (let i = 0; i < missing.length; i += 50) {
    const chunk = missing.slice(i, i + 50);
    const url = `${OFF_HOSTS.food}/api/v2/taxonomy?${qs({ tagtype, tags: chunk.join(','), lc: 'hu,en', fields: 'name', app_name: 'DaleDay' })}`;
    const r = await getJson<Record<string, { name?: { hu?: string; en?: string } }>>(url, { signal, timeoutMs: 3500 });
    if (!r.ok) continue;
    for (const tag of chunk) {
      const name = r.data[tag]?.name ?? {};
      const entry = { hu: name.hu?.trim() || undefined, en: name.en?.trim() || undefined };
      taxonomyMemo.set(`${tagtype}|${tag}`, entry);
      out[tag] = entry;
    }
  }
  return out;
}

export const SEARCH_FIELDS = [
  'code',
  'product_name',
  'product_name_hu',
  'product_name_en',
  ...OTHER_NAME_FIELDS,
  'abbreviated_product_name',
  'generic_name',
  'generic_name_hu',
  'generic_name_en',
  'brands',
  'quantity',
  'categories_tags',
  'compared_to_category',
  'countries_tags',
  'ingredients',
  'ingredients_lc',
  'ingredients_analysis_tags',
  'allergens_tags',
  'traces_tags',
  'additives_tags',
  'nova_group',
  'nutriscore_grade',
  'nutriments',
  'labels_tags',
  'image_front_url',
  'image_front_small_url',
  'last_modified_t',
  'product_type',
].join(',');

export type OffSearch = { ok: true; products: OffProduct[]; count: number } | { ok: false; error: FetchError };

/**
 * Popular products in one category, optionally only those sold in one country (about 10 calls a minute).
 * Through our proxy (/api/off/search): browsers often get a 503 without CORS from the search, the server does not.
 */
export async function searchOff(category: string, country: string | undefined, signal?: AbortSignal): Promise<OffSearch> {
  const quick = await searchOffIndex(category, country, signal);
  if (signal?.aborted) return quick;
  // The index often answers without ingredient lists, and a candidate we cannot check is no candidate:
  // then the classic search is asked too, and the index answer is kept only if that one fails.
  const checkable = quick.ok && (quick.products.length === 0 || quick.products.some((p) => p.ingredients?.length));
  if (checkable) return quick;
  const url = `${proxyUrl('/api/off/search')}?${qs({
    categories_tags: category,
    countries_tags: country,
    fields: SEARCH_FIELDS,
    page_size: 40,
    sort_by: 'popularity_key',
    app_name: 'DaleDay',
  })}`;
  const r = await getJson<{ products?: OffProduct[]; count?: number }>(url, { signal, timeoutMs: 9000 });
  if (!r.ok) return quick.ok ? quick : { ok: false, error: r.error };
  return { ok: true, products: r.data.products ?? [], count: r.data.count ?? 0 };
}

/**
 * The same search on OFF's search index (search.openfoodfacts.org), through /api/off/sal. It answers in about
 * 0.1 s and is not limited at peak times the way the classic search is, so it goes first.
 */
async function searchOffIndex(category: string, country: string | undefined, signal?: AbortSignal): Promise<OffSearch> {
  const q = `categories_tags:"${category}"` + (country ? ` AND countries_tags:"${country}"` : '');
  const url = `${proxyUrl('/api/off/sal')}?${qs({ q, fields: SEARCH_FIELDS, page_size: 40, sort_by: '-unique_scans_n' })}`;
  const r = await getJson<{ hits?: IndexHit[]; count?: number }>(url, { signal, timeoutMs: 6000 });
  if (!r.ok) return { ok: false, error: r.error };
  return { ok: true, products: (r.data.hits ?? []).map(fromIndex), count: r.data.count ?? 0 };
}

/** A search index hit: like a product, but brands and stores come as lists. */
export type IndexHit = Omit<OffProduct, 'brands' | 'stores'> & { brands?: string | string[]; stores?: string | string[]; unique_scans_n?: number };

/** The index's lists as the product API's comma-separated text, so one mapper reads both. */
export function fromIndex(h: IndexHit): OffProduct {
  const text = (v: string | string[] | undefined) => (Array.isArray(v) ? v.map((x) => x.trim()).filter(Boolean).join(', ') : v);
  return { ...h, brands: text(h.brands), stores: text(h.stores) };
}
