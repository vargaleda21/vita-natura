// The likely maker of a code no database knows. The first 7–9 digits of an EAN-13 are one company's own
// prefix (from GS1), so the products in Open Food Facts that start the same way show whose code it is,
// by their brand. Only a clear majority names a maker; the screen still says "likely".

import type { L10n } from '../types';
import { canonical } from './ean';
import { gs1Info } from './gs1';
import { getJson, proxyUrl, qs } from './http';
import { normaliseQuantity, pickName } from './map';
import { fromIndex, NAME_FIELDS, type IndexHit, type OffProduct } from './off';

export type MakerProduct = { code: string; name: L10n; quantity: string; imageUrl?: string };

export type Maker = {
  /** The brand most of the prefix's products carry, as written. */
  brand: string;
  /** The company prefix we matched on (7 to 9 digits). */
  prefix: string;
  /** How many products Open Food Facts knows with that prefix … */
  count: number;
  /** … or at least that many (only the 100 most scanned of a longer list were read). */
  atLeast: boolean;
  /** How many of those read carry the brand. */
  branded: number;
  /** The brand's own products among them, the most scanned first, each with a name. */
  products: MakerProduct[];
};

const FIELDS = ['code', 'brands', ...NAME_FIELDS, 'quantity', 'image_front_small_url'].join(',');

function clean(s: string | undefined): string {
  return (s ?? '').replace(/\s+/g, ' ').trim();
}

function brandOf(p: OffProduct): string {
  return clean(p.brands?.split(',')[0]);
}

/** The brand most products carry, its share among the products with a brand, and how many carry it. */
export function dominantBrand(list: OffProduct[]): { brand: string; share: number; n: number } | null {
  const counts = new Map<string, { n: number; forms: Map<string, number> }>();
  let branded = 0;
  for (const p of list) {
    const b = brandOf(p);
    if (!b) continue;
    branded += 1;
    const k = b.toLowerCase();
    const e = counts.get(k) ?? { n: 0, forms: new Map<string, number>() };
    e.n += 1;
    e.forms.set(b, (e.forms.get(b) ?? 0) + 1);
    counts.set(k, e);
  }
  let best: { n: number; forms: Map<string, number> } | null = null;
  for (const e of counts.values()) if (!best || e.n > best.n) best = e;
  if (!best || branded === 0) return null;
  // "Univer" over "UNIVER": the spelling most entries use.
  const brand = [...best.forms.entries()].reduce((a, b) => (b[1] > a[1] ? b : a))[0];
  return { brand, share: best.n / branded, n: best.n };
}

function shared(a: string, b: string): number {
  let i = 0;
  while (i < a.length && a[i] === b[i]) i += 1;
  return i;
}

function toMakerProducts(list: OffProduct[]): MakerProduct[] {
  const out: MakerProduct[] = [];
  for (const p of list) {
    const canon = p.code ? canonical(p.code) : null;
    const picked = pickName({ off: p });
    if (!canon || !picked || picked.foreign) continue;
    const img = p.image_front_small_url;
    out.push({ code: canon.key, name: picked.name, quantity: normaliseQuantity(p.quantity), imageUrl: img && /^https:\/\//.test(img) ? img : undefined });
  }
  return out;
}

const memo = new Map<string, Promise<Maker | null>>();

/** True for a code whose maker we can look for: a 13-digit code with a country prefix. */
export function makerEligible(code: string): boolean {
  const canon = canonical(code);
  return !!canon && canon.key.length === 13 && gs1Info(canon.key).kind === 'country';
}

/** The likely maker of a 13-digit code, or null (not sure, no answer, an in-store or coupon code). */
export function findMaker(code: string, signal?: AbortSignal): Promise<Maker | null> {
  const canon = canonical(code);
  if (!canon || !makerEligible(canon.key)) return Promise.resolve(null);
  const key = canon.key;
  const known = memo.get(key);
  if (known) return known;
  const job = (async (): Promise<Maker | null> => {
    const url = `${proxyUrl('/api/off/sal')}?${qs({ q: `code:${key.slice(0, 7)}*`, fields: FIELDS, page_size: 100, sort_by: '-unique_scans_n' })}`;
    const r = await getJson<{ hits?: IndexHit[]; count?: number }>(url, { signal, timeoutMs: 6000 });
    if (!r.ok) throw new Error(r.error);
    const hits = (r.data.hits ?? []).map(fromIndex).filter((h) => h.code && h.code !== key);
    // The closest codes with a brand (the longest shared start, at least 8 digits) must agree with the majority.
    const branded = hits.filter((h) => brandOf(h));
    const best = Math.max(0, ...branded.map((h) => shared(h.code ?? '', key)));
    const near = best >= 8 ? dominantBrand(branded.filter((h) => shared(h.code ?? '', key) === best)) : null;
    const truncated = (r.data.count ?? 0) > hits.length + 1;
    // The shortest prefix one brand clearly holds is the company's own. Without close codes to confirm
    // it, the majority must be larger.
    for (const len of [7, 8, 9]) {
      const prefix = key.slice(0, len);
      const group = hits.filter((h) => h.code?.startsWith(prefix));
      const top = dominantBrand(group);
      if (!top || top.n < 3 || top.share < (near ? 0.6 : 0.8) || top.n / group.length < 0.5) continue;
      if (near && near.brand.toLowerCase() !== top.brand.toLowerCase()) continue;
      const own = group.filter((h) => brandOf(h).toLowerCase() === top.brand.toLowerCase());
      return {
        brand: top.brand,
        prefix,
        count: len === 7 ? Math.max(r.data.count ?? 0, group.length) : group.length,
        atLeast: len !== 7 && truncated,
        branded: top.n,
        products: toMakerProducts(own),
      };
    }
    return null;
  })();
  // A failed search is not remembered as "no maker".
  const safe = job.catch(() => {
    memo.delete(key);
    return null;
  });
  memo.set(key, safe);
  return safe;
}

/** Lower case, no accents: "Majonéz" and "majonez" match. */
function fold(s: string): string {
  return s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

/** The maker's products whose name has every typed word in it (in either language). */
export function filterMakerProducts(list: MakerProduct[], text: string): MakerProduct[] {
  const words = fold(text).split(/\s+/).filter(Boolean);
  if (words.length === 0) return list;
  return list.filter((p) => {
    const hay = fold(`${p.name.hu} ${p.name.en}`);
    return words.every((w) => hay.includes(w));
  });
}
