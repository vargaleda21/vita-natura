// Candidates for "a better choice" for a real product: popular products in the same Open Food Facts
// category, sold in Hungary first. Scoring against the person's settings happens in api.ts, where
// evaluate() lives; mock products never mix in.

import type { Product } from '../types';
import { putPreviews } from './cache';
import { canonical } from './ean';
import { buildProduct } from './map';
import { searchOff, type OffProduct } from './off';

/** Categories so broad that "the same shelf" means little. */
const TOO_BROAD = new Set([
  'en:foods',
  'en:groceries',
  'en:plant-based-foods-and-beverages',
  'en:plant-based-foods',
  'en:beverages-and-beverages-preparations',
  'en:snacks',
  'en:sweet-snacks',
  'en:salty-snacks',
  'en:dairies',
  'en:meats-and-their-products',
  'en:fats',
  'en:cereals-and-potatoes',
  'en:cereals-and-their-products',
  'en:condiments',
  'en:fruits-and-vegetables-based-foods',
  'en:frozen-foods',
  'en:canned-foods',
  'en:desserts',
  'en:confectioneries',
  'en:breakfasts',
]);

/** The categories to search, most specific first (also used to rank the results by shelf). */
export function candidateCategories(p: Product): string[] {
  const tags = p.real?.categoryTags ?? [];
  const ordered = [p.real?.comparedTo, ...[...tags].reverse()].filter((t): t is string => !!t && t.startsWith('en:'));
  const out: string[] = [];
  for (const t of ordered) if (!out.includes(t) && !TOO_BROAD.has(t)) out.push(t);
  return out.slice(0, 3);
}

/** Products whose ingredients are known; the rest cannot be checked against anyone's list, so they are
 *  only counted (to tell "nothing better" from "nothing we could check"). */
function toProducts(list: OffProduct[], exclude: string, unchecked: { n: number }): Product[] {
  const out: Product[] = [];
  for (const raw of list) {
    const canon = raw.code ? canonical(raw.code) : null;
    if (!canon || canon.key === exclude) continue;
    if (!raw.ingredients?.length) {
      unchecked.n += 1;
      continue;
    }
    const p = buildProduct({ key: canon.key, off: { flavor: 'food', product: raw }, preview: true });
    if (p) out.push(p);
  }
  return out;
}

export type Candidates = {
  products: Product[];
  /** True when the search did not answer (Open Food Facts limits searches to about 10 a minute). */
  failed: boolean;
  /** True when the search found products but none with an ingredient list: none could be checked. */
  unchecked: boolean;
};

const memo = new Map<string, Promise<Candidates>>();

/** Up to ~120 candidates with known ingredients, also kept as light previews so a tap can open them.
 *  At most three searches: the two most specific categories in Hungary, then the first one anywhere. */
export function fetchAlternativeCandidates(product: Product, signal?: AbortSignal): Promise<Candidates> {
  const known = memo.get(product.ean);
  if (known) return known;
  const job = (async (): Promise<Candidates> => {
    const cats = candidateCategories(product).slice(0, 2);
    if (cats.length === 0) return { products: [], failed: false, unchecked: false };
    const unchecked = { n: 0 };
    const local = await Promise.all(cats.map((c) => searchOff(c, 'en:hungary', signal)));
    const found: Product[] = [];
    const seen = new Set<string>();
    const add = (list: Product[]) => {
      for (const p of list) {
        if (seen.has(p.ean)) continue;
        seen.add(p.ean);
        found.push(p);
      }
    };
    for (const r of local) if (r.ok) add(toProducts(r.products, product.ean, unchecked));
    let wideFailed = false;
    if (found.length < 8) {
      const wide = await searchOff(cats[0], undefined, signal);
      if (wide.ok) add(toProducts(wide.products, product.ean, unchecked));
      else wideFailed = true;
    }
    const products = found.slice(0, 120);
    putPreviews(products);
    const failed = local.every((r) => !r.ok) && (wideFailed || found.length === 0);
    // A failed search must not be remembered as "nothing better".
    if (failed) memo.delete(product.ean);
    return { products, failed, unchecked: !failed && found.length === 0 && unchecked.n > 0 };
  })();
  memo.set(product.ean, job);
  job.catch(() => memo.delete(product.ean));
  return job;
}
