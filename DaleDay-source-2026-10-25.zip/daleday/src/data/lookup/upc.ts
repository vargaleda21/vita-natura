// UPCitemdb's free trial, through our proxy. Its limit is 100 calls a day for the whole server,
// so the orchestrator asks it last, and only when every other source came back empty.

import { getJson, proxyUrl, qs, type FetchError } from './http';

export type UpcItem = {
  title: string;
  brand?: string;
  description?: string;
  category?: string;
  size?: string;
  /** Only https images: the app's CSP (and iOS) block plain http. */
  images: string[];
};

export type UpcLookup = { kind: 'found'; item: UpcItem } | { kind: 'missing' } | { kind: 'error'; error: FetchError };

type UpcResponse = {
  code?: string;
  total?: number;
  items?: { title?: string; brand?: string; description?: string; category?: string; size?: string; images?: string[] }[];
};

export async function fetchUpc(code: string, signal?: AbortSignal): Promise<UpcLookup> {
  // UPCitemdb wants the 12-digit UPC for US codes and the 13-digit EAN for the rest.
  const upc = code.length === 13 && code.startsWith('0') ? code.slice(1) : code;
  const r = await getJson<UpcResponse>(proxyUrl(`/api/upc/lookup?${qs({ upc })}`), { signal });
  if (!r.ok) {
    const body = r.data as UpcResponse | undefined;
    if (r.status === 404 || r.status === 400 || body?.code === 'INVALID_UPC' || body?.code === 'NOT_FOUND') return { kind: 'missing' };
    return { kind: 'error', error: r.error };
  }
  const first = r.data.items?.find((i) => i.title?.trim());
  if (!first?.title) return { kind: 'missing' };
  return {
    kind: 'found',
    item: {
      title: first.title.trim(),
      brand: first.brand?.trim() || undefined,
      description: first.description?.trim() || undefined,
      category: first.category?.trim() || undefined,
      size: first.size?.trim() || undefined,
      images: (first.images ?? []).filter((u) => /^https:\/\//.test(u)),
    },
  };
}
