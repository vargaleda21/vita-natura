// Configuration and a small JSON fetch with a timeout, shared by every source.
// No React and no '@/' aliases, so it runs in plain Node too (the test scripts in tools/).

/** The slice of AsyncStorage (or localStorage, or a Map in tests) the cache needs. */
export type KeyValueStore = {
  getItem: (key: string) => Promise<string | null>;
  setItem: (key: string, value: string) => Promise<void>;
  removeItem: (key: string) => Promise<void>;
  getAllKeys?: () => Promise<readonly string[]>;
  multiGet?: (keys: readonly string[]) => Promise<readonly (readonly [string, string | null])[]>;
};

type Config = {
  /** '' on the web (same-origin proxy), the live site on iOS and Android. */
  proxyBase: string;
  storage: KeyValueStore | null;
  timeoutMs: number;
  fetch: typeof fetch;
};

function defaultProxyBase(): string {
  const loc = (globalThis as { location?: { protocol?: string } }).location;
  return loc?.protocol?.startsWith('http') ? '' : 'https://daleday.digital1.one';
}

const config: Config = {
  proxyBase: defaultProxyBase(),
  storage: null,
  timeoutMs: 6000,
  fetch: (...args) => fetch(...args),
};

export function configureLookup(patch: Partial<Config>): void {
  Object.assign(config, patch);
}

export function lookupConfig(): Readonly<Config> {
  return config;
}

/** Our own read-only proxies (GVH Árfigyelő, UPCitemdb): same origin on the web. */
export function proxyUrl(path: string): string {
  return `${config.proxyBase}${path}`;
}

export type FetchError = 'timeout' | 'network' | 'abort' | 'http' | 'parse' | 'limit';

export type JsonResult<T> =
  | { ok: true; status: number; data: T }
  | { ok: false; status: number; error: FetchError; data?: unknown };

/** GET a JSON document. Never throws: a timeout, an abort or a server error comes back as a value. */
export async function getJson<T>(url: string, opts: { signal?: AbortSignal; timeoutMs?: number } = {}): Promise<JsonResult<T>> {
  const ctrl = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    ctrl.abort();
  }, opts.timeoutMs ?? config.timeoutMs);
  const outer = opts.signal;
  const onAbort = () => ctrl.abort();
  if (outer) {
    if (outer.aborted) ctrl.abort();
    else outer.addEventListener('abort', onAbort);
  }
  try {
    const res = await config.fetch(url, { headers: { accept: 'application/json' }, signal: ctrl.signal });
    let data: unknown;
    try {
      data = await res.json();
    } catch {
      if (timedOut) return { ok: false, status: 0, error: 'timeout' };
      if (outer?.aborted) return { ok: false, status: 0, error: 'abort' };
      return { ok: false, status: res.status, error: res.ok ? 'parse' : res.status === 429 ? 'limit' : 'http' };
    }
    if (res.ok) return { ok: true, status: res.status, data: data as T };
    return { ok: false, status: res.status, error: res.status === 429 ? 'limit' : 'http', data };
  } catch {
    if (timedOut) return { ok: false, status: 0, error: 'timeout' };
    if (outer?.aborted) return { ok: false, status: 0, error: 'abort' };
    return { ok: false, status: 0, error: 'network' };
  } finally {
    clearTimeout(timer);
    outer?.removeEventListener('abort', onAbort);
  }
}

/** A query string from defined values. */
export function qs(params: Record<string, string | number | undefined>): string {
  const parts: string[] = [];
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === '') continue;
    parts.push(`${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`);
  }
  return parts.join('&');
}
