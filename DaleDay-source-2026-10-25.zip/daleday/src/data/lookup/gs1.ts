// Offline GS1 prefix table: the first three digits of a code name the GS1 member organisation that
// issued it. That is where the barcode was REGISTERED, not where the product was made.

import type { L10n } from '../types';

export type Gs1Info =
  | { kind: 'country'; iso2?: string; country: L10n }
  | { kind: 'instore' }
  | { kind: 'coupon' }
  | { kind: 'book' }
  | { kind: 'unknown' };

type Row = [from: number, to: number, info: Gs1Info];

const c = (iso2: string | undefined, hu: string, en: string): Gs1Info => ({ kind: 'country', iso2, country: { hu, en } });

const USA = c('US', 'az USA-ban vagy Kanadában', 'the USA or Canada');

const ROWS: Row[] = [
  [0, 19, USA],
  [20, 29, { kind: 'instore' }],
  [30, 39, USA],
  [40, 49, { kind: 'instore' }],
  [50, 59, { kind: 'coupon' }],
  [60, 139, USA],
  [200, 299, { kind: 'instore' }],
  [300, 379, c('FR', 'Franciaországban', 'France')],
  [380, 380, c('BG', 'Bulgáriában', 'Bulgaria')],
  [383, 383, c('SI', 'Szlovéniában', 'Slovenia')],
  [385, 385, c('HR', 'Horvátországban', 'Croatia')],
  [387, 387, c('BA', 'Bosznia-Hercegovinában', 'Bosnia and Herzegovina')],
  [389, 389, c('ME', 'Montenegróban', 'Montenegro')],
  [390, 390, c('XK', 'Koszovóban', 'Kosovo')],
  [400, 440, c('DE', 'Németországban', 'Germany')],
  [450, 459, c('JP', 'Japánban', 'Japan')],
  [460, 469, c('RU', 'Oroszországban', 'Russia')],
  [471, 471, c('TW', 'Tajvanon', 'Taiwan')],
  [474, 474, c('EE', 'Észtországban', 'Estonia')],
  [475, 475, c('LV', 'Lettországban', 'Latvia')],
  [477, 477, c('LT', 'Litvániában', 'Lithuania')],
  [479, 479, c('LK', 'Srí Lankán', 'Sri Lanka')],
  [480, 480, c('PH', 'a Fülöp-szigeteken', 'the Philippines')],
  [481, 481, c('BY', 'Fehéroroszországban', 'Belarus')],
  [482, 482, c('UA', 'Ukrajnában', 'Ukraine')],
  [484, 484, c('MD', 'Moldovában', 'Moldova')],
  [485, 485, c('AM', 'Örményországban', 'Armenia')],
  [486, 486, c('GE', 'Grúziában', 'Georgia')],
  [487, 487, c('KZ', 'Kazahsztánban', 'Kazakhstan')],
  [489, 489, c('HK', 'Hongkongban', 'Hong Kong')],
  [490, 499, c('JP', 'Japánban', 'Japan')],
  [500, 509, c('GB', 'az Egyesült Királyságban', 'the United Kingdom')],
  [520, 521, c('GR', 'Görögországban', 'Greece')],
  [528, 528, c('LB', 'Libanonban', 'Lebanon')],
  [529, 529, c('CY', 'Cipruson', 'Cyprus')],
  [530, 530, c('AL', 'Albániában', 'Albania')],
  [531, 531, c('MK', 'Észak-Macedóniában', 'North Macedonia')],
  [535, 535, c('MT', 'Máltán', 'Malta')],
  [539, 539, c('IE', 'Írországban', 'Ireland')],
  [540, 549, c('BE', 'Belgiumban vagy Luxemburgban', 'Belgium or Luxembourg')],
  [560, 560, c('PT', 'Portugáliában', 'Portugal')],
  [569, 569, c('IS', 'Izlandon', 'Iceland')],
  [570, 579, c('DK', 'Dániában', 'Denmark')],
  [590, 590, c('PL', 'Lengyelországban', 'Poland')],
  [594, 594, c('RO', 'Romániában', 'Romania')],
  [599, 599, c('HU', 'Magyarországon', 'Hungary')],
  [600, 601, c('ZA', 'a Dél-afrikai Köztársaságban', 'South Africa')],
  [611, 611, c('MA', 'Marokkóban', 'Morocco')],
  [613, 613, c('DZ', 'Algériában', 'Algeria')],
  [616, 616, c('KE', 'Kenyában', 'Kenya')],
  [619, 619, c('TN', 'Tunéziában', 'Tunisia')],
  [622, 622, c('EG', 'Egyiptomban', 'Egypt')],
  [625, 625, c('JO', 'Jordániában', 'Jordan')],
  [626, 626, c('IR', 'Iránban', 'Iran')],
  [628, 628, c('SA', 'Szaúd-Arábiában', 'Saudi Arabia')],
  [629, 629, c('AE', 'az Egyesült Arab Emírségekben', 'the United Arab Emirates')],
  [640, 649, c('FI', 'Finnországban', 'Finland')],
  [690, 699, c('CN', 'Kínában', 'China')],
  [700, 709, c('NO', 'Norvégiában', 'Norway')],
  [729, 729, c('IL', 'Izraelben', 'Israel')],
  [730, 739, c('SE', 'Svédországban', 'Sweden')],
  [750, 750, c('MX', 'Mexikóban', 'Mexico')],
  [754, 755, c('CA', 'Kanadában', 'Canada')],
  [760, 769, c('CH', 'Svájcban vagy Liechtensteinben', 'Switzerland or Liechtenstein')],
  [770, 771, c('CO', 'Kolumbiában', 'Colombia')],
  [773, 773, c('UY', 'Uruguayban', 'Uruguay')],
  [775, 775, c('PE', 'Peruban', 'Peru')],
  [778, 779, c('AR', 'Argentínában', 'Argentina')],
  [780, 780, c('CL', 'Chilében', 'Chile')],
  [786, 786, c('EC', 'Ecuadorban', 'Ecuador')],
  [789, 790, c('BR', 'Brazíliában', 'Brazil')],
  [800, 839, c('IT', 'Olaszországban', 'Italy')],
  [840, 849, c('ES', 'Spanyolországban', 'Spain')],
  [850, 850, c('CU', 'Kubában', 'Cuba')],
  [858, 858, c('SK', 'Szlovákiában', 'Slovakia')],
  [859, 859, c('CZ', 'Csehországban', 'the Czech Republic')],
  [860, 860, c('RS', 'Szerbiában', 'Serbia')],
  [868, 869, c('TR', 'Törökországban', 'Turkey')],
  [870, 879, c('NL', 'Hollandiában', 'the Netherlands')],
  [880, 880, c('KR', 'Dél-Koreában', 'South Korea')],
  [885, 885, c('TH', 'Thaiföldön', 'Thailand')],
  [888, 888, c('SG', 'Szingapúrban', 'Singapore')],
  [890, 890, c('IN', 'Indiában', 'India')],
  [893, 893, c('VN', 'Vietnámban', 'Vietnam')],
  [896, 896, c('PK', 'Pakisztánban', 'Pakistan')],
  [899, 899, c('ID', 'Indonéziában', 'Indonesia')],
  [900, 919, c('AT', 'Ausztriában', 'Austria')],
  [930, 939, c('AU', 'Ausztráliában', 'Australia')],
  [940, 949, c('NZ', 'Új-Zélandon', 'New Zealand')],
  [955, 955, c('MY', 'Malajziában', 'Malaysia')],
  [977, 979, { kind: 'book' }],
  [981, 999, { kind: 'coupon' }],
];

/** Who issued a code, from its canonical key (13 or 8 digits). */
export function gs1Info(key: string): Gs1Info {
  // EAN-8 codes starting with 0 or 2 are for in-store use; the rest share the EAN-13 prefixes.
  if (key.length === 8 && (key[0] === '0' || key[0] === '2')) return { kind: 'instore' };
  const prefix = Number(key.slice(0, 3));
  if (!Number.isFinite(prefix)) return { kind: 'unknown' };
  for (const [from, to, info] of ROWS) if (prefix >= from && prefix <= to) return info;
  return { kind: 'unknown' };
}
