// From Open Food Facts ingredient ids, additive and allergen tags to the app's AvoidKeys.
// Ingredient ids are English taxonomy names ("en:palm-oil"); ids outside the taxonomy keep the
// label's language ("hu:melange tojás"), so those are also matched by their Hungarian words.

import type { AvoidKey } from '../types';

/** "en:palm-kernel-oil" → "palm-kernel-oil". */
function bare(id: string): string {
  return id.replace(/^[a-z]{2}:/, '').toLowerCase();
}

/** "en:e500ii" → "E500ii"; undefined if it is not an E number. */
export function eNumberOf(id: string): string | undefined {
  const m = /^(?:[a-z]{2}:)?e(\d{3,4})([a-z]{0,4})$/i.exec(id.trim());
  return m ? `E${m[1]}${m[2].toLowerCase()}` : undefined;
}

const NITRITES = new Set([249, 250, 251, 252]);
// Synthetic colours (mostly azo dyes and coal-tar colours), not the natural ones like E160a or E162.
const SYNTHETIC_COLOURS = new Set([102, 104, 110, 122, 123, 124, 127, 128, 129, 131, 132, 133, 142, 143, 151, 154, 155, 180]);

function isSweetenerNumber(n: number): boolean {
  return (n >= 950 && n <= 969) || n === 420 || n === 421;
}

/** The criteria an additive (by E number) triggers: always "additives", plus its family. */
export function additiveFlags(id: string): AvoidKey[] {
  const e = eNumberOf(id);
  if (!e) return [];
  const n = Number(/\d+/.exec(e)?.[0]);
  const out: AvoidKey[] = ['additives'];
  if (isSweetenerNumber(n)) out.push('sweeteners');
  if (NITRITES.has(n)) out.push('nitrites');
  if (SYNTHETIC_COLOURS.has(n)) out.push('artificial_colors');
  return out;
}

// ── English ids ────────────────────────────────────────────────────────────

const W = (words: string) => new RegExp(`(^|-)(${words})(-|$)`);

const EN = {
  palm: /(^|-)palm(-kernel)?(-oil|-fat|-stearin|-olein|-oils|-fats)?(-|$)|palmolein|palm-kernel/,
  palmNot: /palm-sugar|palm-heart|heart-of-palm|palmarosa|palm-wine|date/,
  sugar: W('sugars?|sucrose|dextrose|glucose|fructose|maltose|syrups?|molasses|treacle|honey|invert|caramel'),
  sugarNot: /sugar-free|sugar-alcohol|sweetener|lactose|milk-sugar|glucono|gluconate|glucoside|glucosamine|glucan|caramel-colou?r|e150|flavou?ring|aroma/,
  sweetener: /sweetener|aspartame|sucralose|acesulfame|saccharin|cyclamate|steviol|stevia|neotame|advantame|xylitol|erythritol|maltitol|sorbitol|isomalt|lactitol|mannitol|thaumatin/,
  nitrite: /nitrite|nitrate/,
  caffeine: W('caffeine|coffees?|guarana|mate|black-tea|green-tea|tea|cola-nut|kola-nut|kola'),
  caffeineNot: /decaf|herbal|rooibos|fruit-tea|tea-flavou?r|chamomile|peppermint/,
  milk: W(
    'milks?|butter|butterfat|buttermilk|cream|creams|whey|lactose|cheeses?|yogh?urts?|casein|caseinates?|ghee|kefir|quark|curd|lactoserum|milkfat|mascarpone|ricotta|mozzarella|emmental|cheddar|parmesan|gouda|edam|skyr|milk-proteins?',
  ),
  milkNot:
    /coconut-milk|coconut-cream|cocoa-butter|shea-butter|(peanut|nut|almond|cashew|hazelnut|sunflower|seed|mango|apple|soy|soya|oat|rice|plant|vegetable)-(butter|milk|cream|drink)|cream-of-tartar|vegetable-cream|plant-based|non-dairy|cream-substitute/,
  gluten: W('wheat|barley|rye|spelt|oats?|oat-flakes|gluten|semolina|durum|kamut|triticale|malt|bulgur|couscous|einkorn|emmer|farro|seitan'),
  glutenNot: /gluten-free|buckwheat|wheat-glucose|glucose-syrup|maltodextrin|wheat-dextrose|dextrose/,
  egg: W('eggs?|egg-yolks?|egg-whites?|albumen|ovalbumin|lysozyme|whole-eggs?|egg-powder|yolk'),
  nuts: W(
    'nuts?|walnuts?|hazelnuts?|almonds?|cashews?|cashew-nuts?|pistachios?|pecans?|pecan-nuts?|macadamia|macadamia-nuts?|brazil-nuts?|peanuts?|groundnuts?|marzipan|praline|nougat|gianduja',
  ),
  nutsNot: /nutmeg|coconut|nut-free|butternut|doughnut|chestnut|flavou?ring|aroma|tigernut|tiger-nut/,
  soy: W('soy|soya|soybeans?|soyabeans?|tofu|edamame|tempeh|miso|soy-lecithin|soya-lecithin|soy-sauce'),
};

// ── Hungarian words, for ingredients outside the taxonomy ──────────────────

const HU = {
  // "növényi zsírok (pálma, shea)": a bare "pálma" under a fat is palm fat.
  palm: /pálm[aá](olaj|zsír|mag|ból)|^pálma\s*$/,
  sugar: /cukor|cukr|szirup|glükóz|glukóz|fruktóz|dextróz|szőlőcukor|invertcukor|melasz|^méz|\sméz/,
  sugarNot: /cukormentes|tejcukor|édesítő|aroma/,
  sweetener: /édesítő|aszpartám|szukralóz|aceszulfám|szacharin|ciklamát|steviol|sztívia|stevia|xilit|eritrit|maltit|szorbit|izomalt/,
  caffeine: /koffein|kávé|guarana/,
  caffeineNot: /koffeinmentes/,
  milk: /^tej|\stej|tejpor|tejsavó|tejszín|tejföl|tejfehérje|^vaj|\svaj|savópor|laktóz|sajt|túró|joghurt|kefir|író|kazein/,
  // Lactic acid (tejsav, E270) is not milk; whey (tejsavó) is.
  milkNot: /kakaóvaj|shea|kókusz|mogyoróvaj|növényi|szójatej|zabtej|rizstej|mandulatej|tejsav([^óo]|$)/,
  // Suffixes turn a final a into á ("búzából", "szójából"); "zab" only at a word start, not in "szabályozó".
  gluten: /búz[aá]|árp[aá]|rozs|tönköly|(^|[^a-záéíóöőúüű])zab|glutén|malát[aá]|durum|kuszkusz|bulgur/,
  glutenNot: /gluténmentes|hajdina/,
  egg: /tojás/,
  nuts: /dió|mogyoró|mandul[aá]|kesu|pisztáci[aá]|pekán|makadámi[aá]|marcipán|nugát/,
  nutsNot: /kókusz|aroma|szerecsendió|gesztenye/,
  soy: /szój[aá]/,
};

/** A claim on the label ("gluténmentes", "lactose-free", "cukor nélkül"), not an ingredient. */
const CLAIM = /mentes|nélkül|(^|[\s-])free\b|without|\bohne\b|\bsans\b|\bbez\b/;

/** "Glucose syrup" → "glucose-syrup", the shape of an English taxonomy id. */
export function slug(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
}

function englishFlags(b: string, add: (k: AvoidKey) => void) {
  if (EN.palm.test(b) && !EN.palmNot.test(b)) add('palm_oil');
  if (EN.sweetener.test(b)) add('sweeteners');
  else if (EN.sugar.test(b) && !EN.sugarNot.test(b)) add('added_sugar');
  if (EN.nitrite.test(b)) add('nitrites');
  if (EN.caffeine.test(b) && !EN.caffeineNot.test(b)) add('caffeine');
  if (EN.milk.test(b) && !EN.milkNot.test(b)) add('lactose');
  if (EN.gluten.test(b) && !EN.glutenNot.test(b)) add('gluten');
  if (EN.egg.test(b)) add('egg');
  if (EN.nuts.test(b) && !EN.nutsNot.test(b)) add('nuts');
  if (EN.soy.test(b)) add('soy');
}

/** The criteria an ingredient triggers. `palm` is Open Food Facts' own "from palm oil" verdict. */
export function ingredientFlags(id: string | undefined, text: string | undefined, fromPalm?: string, inTaxonomy = true): AvoidKey[] {
  const out = new Set<AvoidKey>();
  const add = (k: AvoidKey) => out.add(k);
  const b = id ? bare(id) : '';
  const english = !!id && id.startsWith('en:');

  if (id) for (const k of additiveFlags(id)) add(k);
  if (fromPalm === 'yes') add('palm_oil');
  if (english) englishFlags(b, add);

  // Outside the taxonomy, read the words on the label: Hungarian (the common case here), and English
  // words that were filed under another language ("sugar" as pl:sugar).
  if (!english || !inTaxonomy) {
    const t = `${text ?? ''} ${english ? '' : b.replace(/-/g, ' ')}`.toLowerCase();
    if (CLAIM.test(t)) return [...out];
    if (HU.palm.test(t)) add('palm_oil');
    if (HU.sweetener.test(t)) add('sweeteners');
    else if (HU.sugar.test(t) && !HU.sugarNot.test(t)) add('added_sugar');
    if (HU.caffeine.test(t) && !HU.caffeineNot.test(t)) add('caffeine');
    if (HU.milk.test(t) && !HU.milkNot.test(t)) add('lactose');
    if (HU.gluten.test(t) && !HU.glutenNot.test(t)) add('gluten');
    if (HU.egg.test(t)) add('egg');
    if (HU.nuts.test(t) && !HU.nutsNot.test(t)) add('nuts');
    if (HU.soy.test(t)) add('soy');
    if (!english) englishFlags(slug(`${text ?? ''}`) || b, add);
  }
  return [...out];
}

/** Allergen tags (en:milk, en:peanuts …) that are avoid criteria. Others (sesame, celery …) return null. */
export function allergenKey(tag: string): AvoidKey | null {
  switch (tag) {
    case 'en:milk':
      return 'lactose';
    case 'en:gluten':
      return 'gluten';
    case 'en:nuts':
    case 'en:peanuts':
      return 'nuts';
    case 'en:eggs':
      return 'egg';
    case 'en:soybeans':
      return 'soy';
    default:
      return null;
  }
}

/** Names for the 14 EU allergens, so the app needs no extra call for them. */
export const ALLERGEN_NAMES: Record<string, { hu: string; en: string }> = {
  'en:milk': { hu: 'tej', en: 'milk' },
  'en:gluten': { hu: 'glutén', en: 'gluten' },
  'en:nuts': { hu: 'diófélék', en: 'nuts' },
  'en:peanuts': { hu: 'földimogyoró', en: 'peanuts' },
  'en:eggs': { hu: 'tojás', en: 'eggs' },
  'en:soybeans': { hu: 'szója', en: 'soya' },
  'en:sesame-seeds': { hu: 'szezámmag', en: 'sesame' },
  'en:celery': { hu: 'zeller', en: 'celery' },
  'en:mustard': { hu: 'mustár', en: 'mustard' },
  'en:fish': { hu: 'hal', en: 'fish' },
  'en:crustaceans': { hu: 'rákfélék', en: 'crustaceans' },
  'en:molluscs': { hu: 'puhatestűek', en: 'molluscs' },
  'en:lupin': { hu: 'csillagfürt', en: 'lupin' },
  'en:sulphur-dioxide-and-sulphites': { hu: 'kén-dioxid és szulfitok', en: 'sulphur dioxide and sulphites' },
};

/** Ids that only group their sub-ingredients ("emulsifiers (…)"): the class itself is not an additive. */
export function isClassId(id: string | undefined): boolean {
  if (!id) return false;
  return /^en:(emulsifiers?|preservatives?|colou?rs?|colou?rings?|acidity-regulators?|acids?|antioxidants?|stabili[sz]ers?|thickeners?|gelling-agents?|raising-agents?|bulking-agents?|flavour-enhancers?|humectants?|anti-caking-agents?|glazing-agents?|firming-agents?|sequestrants?|acidifiers?|leavening-agents?)$/.test(
    id,
  );
}
