// From what the sources returned to the app's Product. Nothing is invented: a value no source knows
// stays unset, and the screens show it as unknown.

import type { AvoidKey, CategoryKey, Ingredient, L10n, Nutrition, PackArt, Product, ProductFlag, RealData, RealSource } from '../types';
import type { ArProduct } from './arfigyelo';
import { countryFromTag } from './countries';
import { ALLERGEN_NAMES, additiveFlags, allergenKey, eNumberOf, ingredientFlags, isClassId } from './flags';
import { gs1Info } from './gs1';
import type { PackText } from './ocr';
import { OTHER_NAME_LANGS, offProductUrl, type OffFlavor, type OffIngredient, type OffProduct, type TaxonomyNames } from './off';
import type { UpcItem } from './upc';

const NBSP = ' ';

export type Names = { ingredients: TaxonomyNames; additives: TaxonomyNames; labels: TaxonomyNames; categories: TaxonomyNames };

const EMPTY_NAMES: Names = { ingredients: {}, additives: {}, labels: {}, categories: {} };

// ── Small helpers ──────────────────────────────────────────────────────────

function clean(s: string | undefined): string {
  return (s ?? '').replace(/\s+/g, ' ').trim();
}

/** Lower-case the first letter, as ingredient lists are written ("Citromsav" → "citromsav"), but not "E471". */
function lowerFirst(s: string): string {
  if (s.length > 1 && s[1] === s[1].toUpperCase() && /[A-Z0-9]/.test(s[1])) return s;
  return s.charAt(0).toLowerCase() + s.slice(1);
}

function words(id: string): string {
  return id.replace(/^[a-z]{2}:/, '').replace(/-/g, ' ');
}

/** Greek, Cyrillic, Armenian, Hebrew, Arabic, Indic, Thai, Georgian, Japanese, Chinese, Korean. */
export const NON_LATIN = /[\u0370-\u03FF\u0400-\u052F\u0530-\u06FF\u0900-\u0DFF\u0E00-\u0E7F\u10A0-\u10FF\u3040-\u30FF\u3400-\u9FFF\uAC00-\uD7AF]/;

/** "235g" → "235 g", "1 L" → "1 l", "6x25g" → "6 × 25 g". Decimals are left as written. */
export function normaliseQuantity(raw: string | undefined): string {
  let s = clean(raw);
  if (!s) return '';
  s = s.replace(/(\d)\s*[xX×]\s*(\d)/g, `$1${NBSP}×${NBSP}$2`);
  s = s.replace(/(\d)\s*(kg|g|mg|ml|cl|dl|l|L|pcs|db)\b/g, (_, d: string, u: string) => `${d}${NBSP}${u === 'L' ? 'l' : u}`);
  return s;
}

// ── Names ──────────────────────────────────────────────────────────────────

type NameSources = { off?: OffProduct; ar?: ArProduct | null; upc?: UpcItem | null };

/** Strip a trailing pack size from an Árfigyelő name: "Magyar Tej ESL tej 2,8% 1 l" → "Magyar Tej ESL tej 2,8%". */
function arName(name: string | undefined): string {
  return clean(name).replace(/\s+\d+(?:[.,]\d+)?\s*(?:kg|g|ml|cl|dl|l|db)\.?$/i, '');
}

/** "Marlenka HONEY NUGGETS" → "Marlenka Honey Nuggets": a word in capitals gets normal capitals, but the
 *  brand stays as written, and so do short acronyms (UHT, ESL, BIO) and words with digits. */
export function fixCaps(name: string, brand: string): string {
  const brandWords = new Map(brand.split(/\s+/).filter(Boolean).map((b) => [b.toLowerCase(), b]));
  return name.replace(/[^\s/()]+/g, (w) => {
    const asBrand = brandWords.get(w.toLowerCase());
    if (asBrand) return asBrand;
    const letters = w.replace(/[^\p{L}]/gu, '');
    if (letters.length <= 3 || /\d/.test(w) || w !== w.toUpperCase()) return w;
    return w.charAt(0) + w.slice(1).toLowerCase();
  });
}

export type PickedName = {
  name: L10n;
  /** Set when every name the sources have is in another script (Cyrillic, Greek …): that name, as written. */
  foreign?: string;
};

/** The best name in each language, in Latin letters. A name that is only the brand is a weak name, used
 *  last; a name in another script only when there is nothing else (and then it says so). */
export function pickName({ off, ar, upc }: NameSources): PickedName | null {
  const brand = clean(off?.brands?.split(',')[0]).toLowerCase();
  const weak = (s: string) => !s || s.toLowerCase() === brand || s.length < 2;
  const rank = (list: (string | undefined)[]) => {
    const latin = list.map(clean).filter((s) => s.length > 0 && !NON_LATIN.test(s));
    return latin.find((s) => !weak(s)) ?? latin[0];
  };
  const a = arName(ar?.name);
  // The name in a third language (German, French …) before the generic names.
  const others = OTHER_NAME_LANGS.map((l) => off?.[`product_name_${l}`]);
  const hu = rank([
    off?.product_name_hu,
    a,
    off?.product_name_en,
    off?.product_name,
    ...others,
    off?.abbreviated_product_name,
    off?.generic_name_hu,
    off?.generic_name_en,
    off?.generic_name,
    upc?.title,
  ]);
  const en = rank([
    off?.product_name_en,
    off?.product_name_hu,
    a,
    off?.product_name,
    ...others,
    off?.abbreviated_product_name,
    off?.generic_name_en,
    off?.generic_name_hu,
    off?.generic_name,
    upc?.title,
  ]);
  if (!hu && !en) {
    const foreign = [off?.product_name, off?.product_name_en, off?.product_name_hu, off?.generic_name, upc?.title].map(clean).find(Boolean);
    return foreign ? { name: { hu: foreign, en: foreign }, foreign } : null;
  }
  const asWritten = clean(off?.brands?.split(',')[0]);
  return { name: { hu: fixCaps(hu ?? en ?? '', asWritten), en: fixCaps(en ?? hu ?? '', asWritten) } };
}

/** True when the product has a name we can show as its title (in Latin letters). */
export function hasTitle(off: OffProduct): boolean {
  const picked = pickName({ off });
  return !!picked && !picked.foreign;
}

const UNNAMED: L10n = { hu: 'Név nélküli termék', en: 'Unnamed product' };

/** The most specific category with a Hungarian or English name ("en:mayonnaises" → "Majonéz"). */
function categoryTitle(tags: string[] | undefined, names: TaxonomyNames): L10n | undefined {
  for (const tag of [...(tags ?? [])].reverse()) {
    const n = names[tag];
    if (n?.hu || n?.en) return { hu: n.hu ?? n.en ?? '', en: n.en ?? n.hu ?? '' };
  }
  return undefined;
}

/** The categories whose names stand in for a missing title: the three most specific. */
export function titleCategoryTags(off: OffProduct): string[] {
  return (off.categories_tags ?? []).filter((t) => t.startsWith('en:')).slice(-3);
}

// ── Categories and the drawn pack ──────────────────────────────────────────

const CATEGORY_RULES: [CategoryKey, RegExp][] = [
  [
    'spreads',
    /^en:(spreads|sweet-spreads|salted-spreads|hazelnut-spreads|cocoa-and-hazelnuts-spreads|chocolate-spreads|jams|marmalades|fruit-preserves|honeys|nut-butters|peanut-butters)$/,
  ],
  ['breakfast', /^en:(breakfast-cereals|mueslis|cereal-flakes|porridge|oat-flakes|rolled-oats|granola)/],
  [
    'dairy',
    /^en:(dairies|milks|cow-milks|yogurts|cheeses|fermented-milk-products|creams|butters|dairy-desserts|eggs|cottage-cheeses|quark|kefir|sour-creams)$/,
  ],
  ['meat', /^en:(meats|prepared-meats|sausages|hams|poultries|salamis|bacons|fishes|seafood|canned-fishes|meat-preparations)$/],
  [
    'drinks',
    /^en:(beverages|waters|juices|fruit-juices|sodas|carbonated-drinks|coffees|teas|plant-based-milk-alternatives|energy-drinks|syrups|alcoholic-beverages|beers|wines)$/,
  ],
  ['bakery', /^en:(breads|sliced-breads|pastries|viennoiseries|bakery-products|crispbreads|rusks|flatbreads|wraps)$/],
  [
    'ready_meals',
    /^en:(meals|prepared-meals|soups|pizzas|instant-noodles|noodle-soups|frozen-ready-meals|sandwiches|salads|canned-meals)$/,
  ],
  [
    'sweets',
    /^en:(sweet-snacks|biscuits-and-cakes|biscuits|cakes|chocolates|confectioneries|candies|desserts|ice-creams|wafers|cereal-bars|chocolate-candies|gummies)$/,
  ],
  ['snacks', /^en:(salty-snacks|snacks|chips-and-fries|crisps|potato-crisps|crackers|appetizers|popcorn|nuts|pretzels)$/],
];

const AR_CATEGORY: [CategoryKey, RegExp][] = [
  ['dairy', /^tejtermek|tojas/],
  ['drinks', /^(ital|uditok|asvanyviz|kave|tea)/],
  ['meat', /^(hus|felvagott|hal)/],
  ['bakery', /^(pekaru|kenyer)/],
  ['sweets', /^(edesseg|csokolade|keksz)/],
  ['breakfast', /^(gabonapehely|muzli|reggeli)/],
];

export function mapCategory(tags: string[] | undefined, arPath: string | undefined, flavor: OffFlavor | undefined): CategoryKey {
  if (flavor && flavor !== 'food') return 'other';
  const list = tags ?? [];
  for (const [key, re] of CATEGORY_RULES) if (list.some((t) => re.test(t))) return key;
  const top = (arPath ?? '').split('/')[0];
  for (const [key, re] of AR_CATEGORY) if (re.test(top)) return key;
  return 'other';
}

const ART: Record<CategoryKey, PackArt> = {
  spreads: { colors: ['#7A4A2A', '#E8C9A0'], emoji: '🫙', shape: 'jar' },
  breakfast: { colors: ['#C48A2C', '#FFE6A8'], emoji: '🥣', shape: 'box' },
  snacks: { colors: ['#D9502A', '#FFD08A'], emoji: '🥨', shape: 'bag' },
  sweets: { colors: ['#9B4D96', '#F0C8EE'], emoji: '🍪', shape: 'box' },
  dairy: { colors: ['#4A90C8', '#DCEEFF'], emoji: '🥛', shape: 'box' },
  drinks: { colors: ['#2E9C8A', '#C8F2E6'], emoji: '🧃', shape: 'bottle' },
  meat: { colors: ['#B8402A', '#FFC2B0'], emoji: '🥓', shape: 'tub' },
  bakery: { colors: ['#9A6A3A', '#F4D7A1'], emoji: '🍞', shape: 'bag' },
  ready_meals: { colors: ['#D9502A', '#FFC93D'], emoji: '🍲', shape: 'cup' },
  other: { colors: ['#55675F', '#D9E2DC'], emoji: '📦', shape: 'box' },
};

export function artFor(category: CategoryKey, quantity: string, kind: RealData['kind']): PackArt {
  if (kind === 'beauty') return { colors: ['#B9A4FF', '#F1EBFF'], emoji: '🧴', shape: 'bottle' };
  if (kind === 'petfood') return { colors: ['#C48A2C', '#FFE6A8'], emoji: '🐾', shape: 'bag' };
  const base = ART[category];
  // A litre of something in the dairy shelf is a carton; in grams it is a cup.
  if (category === 'dairy' && /\d\s*g\b/.test(quantity) && !/kg/.test(quantity)) return { ...base, emoji: '🥄', shape: 'cup' };
  return base;
}

// ── Ingredients ────────────────────────────────────────────────────────────

type IngCtx = { names: Names; textLang: string | undefined; single: boolean };

function ingredientName(ing: OffIngredient, ctx: IngCtx): { name: L10n; eNumber?: string } {
  const id = ing.id ?? '';
  // Open Food Facts marks allergens with underscores ("_vaj_"); the first word of a list is capitalised.
  const text = lowerFirst(
    clean(ing.text)
      .replace(/_/g, '')
      .replace(/[*†]+$/g, '')
      .trim(),
  );
  const e = eNumberOf(id);
  if (e) {
    const tax = ctx.names.additives[id];
    const strip = (s?: string) => (s ? lowerFirst(s.replace(/^E\d+[a-z]*\s*[-–]\s*/i, '').trim()) : undefined);
    const hu = (ctx.textLang === 'hu' && text ? text : undefined) ?? strip(tax?.hu) ?? text ?? e;
    const en = (ctx.textLang === 'en' && text ? text : undefined) ?? strip(tax?.en) ?? text ?? e;
    return { name: { hu: hu || e, en: en || e }, eNumber: e };
  }
  const tax = ctx.names.ingredients[id];
  const english = id.startsWith('en:') ? words(id) : '';
  const taxHu = tax?.hu ? lowerFirst(tax.hu) : '';
  const taxEn = tax?.en ? lowerFirst(tax.en) : '';
  // As printed on the pack when it is in the right language; else the taxonomy; a label in a third
  // language (Czech, Bulgarian …) only when nothing else is known.
  const hu = (ctx.textLang === 'hu' ? text : '') || taxHu || taxEn || english || text;
  const en = (ctx.textLang === 'en' ? text : '') || taxEn || english || text;
  return { name: { hu: hu || en, en: en || hu } };
}

function mapIngredient(ing: OffIngredient, ctx: IngCtx): Ingredient {
  const { name, eNumber } = ingredientName(ing, ctx);
  let flags = isClassId(ing.id) ? [] : ingredientFlags(ing.id, ing.text, ing.from_palm_oil, ing.is_in_taxonomy !== 0);
  // A jar of honey is not "added" sugar; honey added to a biscuit is.
  if (ctx.single) flags = flags.filter((k) => k !== 'added_sugar');
  const out: Ingredient = { name };
  if (flags.length) out.flags = flags;
  if (eNumber) out.eNumber = eNumber;
  if (typeof ing.percent === 'number' && ing.percent > 0 && ing.percent <= 100) out.percent = Math.round(ing.percent * 10) / 10;
  if (ing.ingredients?.length) out.sub = ing.ingredients.map((s) => mapIngredient(s, { ...ctx, single: false }));
  return out;
}

function walk(list: Ingredient[], fn: (i: Ingredient) => void) {
  for (const i of list) {
    fn(i);
    if (i.sub) walk(i.sub, fn);
  }
}

/** Every id in an ingredient tree. */
export function ingredientIds(list: OffIngredient[] | undefined): string[] {
  const out: string[] = [];
  const go = (l: OffIngredient[]) => {
    for (const i of l) {
      if (i.id) out.push(i.id);
      if (i.ingredients) go(i.ingredients);
    }
  };
  go(list ?? []);
  return out;
}

/** Which language the ingredient texts are in. */
function ingredientsLang(p: OffProduct): string | undefined {
  if (p.ingredients_lc) return p.ingredients_lc;
  const t = clean(p.ingredients_text);
  if (t && t === clean(p.ingredients_text_hu)) return 'hu';
  if (t && t === clean(p.ingredients_text_en)) return 'en';
  return p.lang;
}

// ── Product-level findings ─────────────────────────────────────────────────

function productFlags(p: OffProduct, ingredients: Ingredient[], names: Names): ProductFlag[] {
  const onIngredients = new Set<AvoidKey>();
  const eNumbers = new Set<string>();
  walk(ingredients, (i) => {
    for (const k of i.flags ?? []) onIngredients.add(k);
    if (i.eNumber) eNumbers.add(i.eNumber.toLowerCase());
  });
  const out: ProductFlag[] = [];
  const contains = new Set<AvoidKey>();

  for (const tag of p.allergens_tags ?? []) {
    const key = allergenKey(tag);
    if (!key) continue;
    contains.add(key);
    if (onIngredients.has(key) || out.some((f) => f.key === key && !f.trace)) continue;
    out.push({ key, reason: ALLERGEN_NAMES[tag] ?? { hu: words(tag), en: words(tag) } });
  }
  for (const tag of p.traces_tags ?? []) {
    const key = allergenKey(tag);
    if (!key || contains.has(key) || onIngredients.has(key) || out.some((f) => f.key === key)) continue;
    out.push({
      key,
      reason: ALLERGEN_NAMES[tag] ?? { hu: words(tag), en: words(tag) },
      trace: true,
    });
  }
  if ((p.ingredients_analysis_tags ?? []).includes('en:palm-oil') && !onIngredients.has('palm_oil')) {
    out.push({ key: 'palm_oil', reason: { hu: 'pálmaolaj', en: 'palm oil' } });
  }
  for (const tag of p.additives_tags ?? []) {
    const e = eNumberOf(tag);
    if (!e) continue;
    // "e500" is covered by an ingredient "E500ii", and the other way round.
    const low = e.toLowerCase();
    if ([...eNumbers].some((x) => x.startsWith(low) || low.startsWith(x))) continue;
    const tax = names.additives[tag];
    const label = (s: string | undefined) => (s ? s.replace(/\s+-\s+/, ' – ') : e);
    for (const key of additiveFlags(tag)) {
      if (key !== 'additives' && onIngredients.has(key)) continue;
      out.push({ key, reason: { hu: label(tax?.hu), en: label(tax?.en) } });
    }
  }
  return out;
}

// ── Nutrition, positives, labels ───────────────────────────────────────────

function num(v: number | string | undefined): number | undefined {
  const n = typeof v === 'string' ? Number(v) : v;
  return typeof n === 'number' && Number.isFinite(n) && n >= 0 ? Math.round(n * 100) / 100 : undefined;
}

function nutritionOf(p: OffProduct): Nutrition {
  const n = p.nutriments ?? {};
  const kcal =
    num(n['energy-kcal_100g']) ??
    (num(n['energy-kj_100g']) !== undefined ? Math.round((num(n['energy-kj_100g']) ?? 0) / 4.184) : undefined);
  const out: Nutrition = {};
  if (kcal !== undefined) out.energyKcal = Math.round(kcal);
  const set = (k: keyof Nutrition, v: number | undefined) => {
    if (v !== undefined) out[k] = v;
  };
  set('sugarG', num(n.sugars_100g));
  set('satFatG', num(n['saturated-fat_100g']));
  set('saltG', num(n.salt_100g));
  set('fiberG', num(n.fiber_100g));
  set('proteinG', num(n.proteins_100g));
  return out;
}

function positivesOf(n: Nutrition, labels: string[]): L10n[] {
  const out: L10n[] = [];
  if (labels.some((l) => /^en:(organic|eu-organic|bio)$/.test(l))) out.push({ hu: 'Bio', en: 'Organic' });
  if (n.fiberG !== undefined && n.fiberG >= 6) out.push({ hu: 'Magas rosttartalom', en: 'High in fibre' });
  if (n.proteinG !== undefined && n.energyKcal && (n.proteinG * 4) / n.energyKcal >= 0.12)
    out.push({ hu: 'Fehérjeforrás', en: 'Source of protein' });
  return out.slice(0, 3);
}

// ── The whole product ──────────────────────────────────────────────────────

export type BuildInput = {
  key: string;
  off?: { flavor: OffFlavor; product: OffProduct } | null;
  ar?: ArProduct | null;
  upc?: UpcItem | null;
  names?: Names;
  /** What the photos say, for a product nobody named or listed the ingredients of. */
  pack?: PackText;
  /** True for a light copy made from a search result. */
  preview?: boolean;
};

const SOURCE_OF: Record<OffFlavor, RealSource> = {
  food: 'off',
  beauty: 'obf',
  product: 'opf',
  petfood: 'opff',
};

function isoDay(t: number | undefined): string | undefined {
  return t ? new Date(t * 1000).toISOString().slice(0, 10) : undefined;
}

function nutriscore(g: string | undefined): RealData['nutriscore'] {
  return g === 'a' || g === 'b' || g === 'c' || g === 'd' || g === 'e' ? g : undefined;
}

function novaOf(v: number | string | undefined): Product['nova'] {
  const n = Number(v);
  return n === 1 || n === 2 || n === 3 || n === 4 ? n : undefined;
}

/** UPCitemdb's category is Google's product taxonomy: "Food, Beverages & Tobacco > …", "Electronics > …". */
function upcKind(category: string | undefined): RealData['kind'] {
  if (!category) return 'unknown';
  if (/^food, beverages/i.test(category)) return 'food';
  if (/pet food|animal food/i.test(category)) return 'petfood';
  if (/^health & beauty > personal care/i.test(category)) return 'beauty';
  return 'product';
}

/** The app's Product from whatever the sources returned, or null when no source knows a name. */
export function buildProduct(input: BuildInput): Product | null {
  const names = input.names ?? EMPTY_NAMES;
  const off = input.off?.product;
  const flavor = input.off?.flavor;
  const ar = input.ar ?? undefined;
  const upc = input.upc ?? undefined;
  // A product the database knows but nobody named (or named only in another script) is still shown: under
  // the name on its front photo, else under its category, and the screen says why. A search-result copy
  // without a name is left out instead.
  const picked = pickName({ off, ar, upc });
  const pack = input.pack;
  let name: L10n;
  let nameNote: RealData['nameNote'];
  let nameIsCategory = false;
  if (picked && (!picked.foreign || !off)) name = picked.name;
  else if (off && !input.preview && pack?.name) {
    const read = fixCaps(pack.name, clean(off.brands?.split(',')[0]));
    const title = read.charAt(0).toUpperCase() + read.slice(1);
    name = { hu: title, en: title };
    nameNote = 'photo';
  } else if (off && !input.preview) {
    const cat = categoryTitle(off.categories_tags, names.categories);
    // No category either: a name in another script still beats "Unnamed product".
    name = cat ?? picked?.name ?? UNNAMED;
    nameIsCategory = !!cat;
    nameNote = picked?.foreign ? 'foreign_script' : 'missing';
  } else return null;

  const sources: RealSource[] = [];
  if (flavor) sources.push(SOURCE_OF[flavor]);
  if (ar) sources.push('arfigyelo');
  if (upc) sources.push('upcitemdb');

  const kind: RealData['kind'] = flavor ?? (ar ? 'food' : upcKind(upc?.category));
  const textLang = off ? ingredientsLang(off) : undefined;
  const top = off?.ingredients ?? [];
  const single = top.length === 1 && !top[0].ingredients?.length;
  // Nobody typed the list: the one read off the photo, when it reads as a list.
  const fromPhoto = top.length === 0 && !!pack?.ingredients;
  const ingredients = fromPhoto && pack?.ingredients ? pack.ingredients.ingredients : top.map((i) => mapIngredient(i, { names, textLang, single }));
  const flags = off ? productFlags(off, ingredients, names) : [];
  const nutrition = off ? nutritionOf(off) : {};
  const labelsTags = off?.labels_tags ?? [];
  const quantity =
    normaliseQuantity(off?.quantity) ||
    (ar?.packaging && ar.unit ? normaliseQuantity(`${ar.packaging} ${ar.unit}`) : '') ||
    normaliseQuantity(upc?.size);
  const category = mapCategory(off?.categories_tags, ar?.categoryPath, flavor);

  const image = off?.image_front_url || off?.image_url || ar?.imageUrl || upc?.images[0];
  const imageSmall = off?.image_front_small_url || off?.image_small_url || image;
  const labels = labelsTags.flatMap((t) => {
    const n = names.labels[t];
    if (!n?.hu && !n?.en) return [];
    return [{ hu: n.hu ?? n.en ?? '', en: n.en ?? n.hu ?? '' }];
  });
  const allergens = (off?.allergens_tags ?? [])
    .filter((t) => t.startsWith('en:'))
    .map((t) => ALLERGEN_NAMES[t] ?? { hu: words(t), en: words(t) });
  const traces = (off?.traces_tags ?? [])
    .filter((t) => t.startsWith('en:'))
    .map((t) => ALLERGEN_NAMES[t] ?? { hu: words(t), en: words(t) });
  const gs1 = gs1Info(input.key);

  const real: RealData = {
    kind,
    sources,
    imageUrl: image && /^https:\/\//.test(image) ? image : undefined,
    imageSmallUrl: imageSmall && /^https:\/\//.test(imageSmall) ? imageSmall : undefined,
    nutriscore: nutriscore(off?.nutriscore_grade),
    labels,
    countries: (off?.countries_tags ?? []).filter((t) => t.startsWith('en:')).map(countryFromTag),
    stores: clean(off?.stores)
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    allergens,
    traces,
    ingredientsKnown: ingredients.length > 0,
    categoryTags: (off?.categories_tags ?? []).filter((t) => t.startsWith('en:')),
    comparedTo: off?.compared_to_category || undefined,
    gs1,
    updated: isoDay(off?.last_modified_t),
    fetchedAt: new Date().toISOString(),
    sourceUrl: flavor ? offProductUrl(flavor, input.key) : undefined,
    description: !off && upc?.description ? clean(upc.description) : undefined,
    preview: input.preview || undefined,
  };
  if (nameNote) {
    real.nameNote = nameNote;
    if (nameNote === 'foreign_script' && picked?.foreign) real.nameOriginal = picked.foreign;
    if (nameIsCategory) real.nameIsCategory = true;
  }
  if (fromPhoto && pack?.ingredientsPhoto) real.ingredientsPhoto = pack.ingredientsPhoto;

  const brand = clean(off?.brands?.split(',')[0]) || upc?.brand || '';
  const product: Product = {
    ean: input.key,
    name,
    brand,
    category,
    size: quantity,
    art: artFor(category, quantity, kind),
    ingredients,
    nutrition,
    nova: novaOf(off?.nova_group),
    prices: [],
    dataSource: { kind: 'open_data', updated: real.updated ?? real.fetchedAt.slice(0, 10) },
    positives: positivesOf(nutrition, labelsTags),
    real,
  };
  if (flags.length) product.flags = flags;
  return product;
}

/** The tags whose names we ask the taxonomy for. */
export function taxonomyTags(p: OffProduct): {
  ingredients: string[];
  additives: string[];
  labels: string[];
} {
  const ids = ingredientIds(p.ingredients).filter((id) => id.startsWith('en:'));
  return {
    ingredients: ids.filter((id) => !eNumberOf(id)),
    additives: [...ids.filter((id) => eNumberOf(id)), ...(p.additives_tags ?? [])],
    labels: (p.labels_tags ?? []).filter((t) => t.startsWith('en:')),
  };
}
