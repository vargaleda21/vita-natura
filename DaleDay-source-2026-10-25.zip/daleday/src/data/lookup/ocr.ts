// What Open Food Facts' text recognition read off a product's photos. Every photo uploaded there goes
// through Google Cloud Vision, and the result is published next to the photo (CORS *). For a product
// nobody has typed a name or an ingredient list for yet, that text is the next best thing. It is machine
// reading: the screens say so, and a name or a list that does not look right is left out, not shown.

import type { AvoidKey, Ingredient } from '../types';
import { additiveFlags, eNumberOf, ingredientFlags, slug } from './flags';
import { getJson } from './http';
import { NON_LATIN } from './map';
import type { OffProduct } from './off';

const IMAGES = 'https://images.openfoodfacts.org/images/products';

/** "5993330000176" → "599/333/000/0176": where Open Food Facts files a product's photos. */
export function imageFolder(code: string): string {
  if (code.length <= 8) return code;
  const c = code.padStart(13, '0');
  return `${c.slice(0, 3)}/${c.slice(3, 6)}/${c.slice(6, 9)}/${c.slice(9)}`;
}

/** Lower case without accents, one character for one, so an index in the folded text is an index in the original. */
function fold(s: string): string {
  let out = '';
  for (let i = 0; i < s.length; i++) out += s[i].toLowerCase().normalize('NFD').charAt(0);
  return out;
}

function clean(s: string): string {
  return s.replace(/\s+/g, ' ').trim();
}

// ── The Vision answer ──────────────────────────────────────────────────────

type Vertex = { x?: number; y?: number };
type VisionSymbol = { text?: string; property?: { detectedBreak?: { type?: string } } };
type VisionWord = { symbols?: VisionSymbol[]; boundingBox?: { vertices?: Vertex[] } };
export type VisionText = {
  text?: string;
  pages?: { blocks?: { paragraphs?: { words?: VisionWord[] }[] }[] }[];
};
type VisionFile = { responses?: { fullTextAnnotation?: VisionText }[] };

export type Line = { text: string; height: number };

/** The height of a word's letters. Vision lists the corners in reading order even on a turned photo,
 *  so the left edge (first corner to last) is the height whichever way the pack lay. */
function wordHeight(w: VisionWord): number {
  const v = w.boundingBox?.vertices ?? [];
  if (v.length < 4) return 0;
  return Math.hypot((v[3].x ?? 0) - (v[0].x ?? 0), (v[3].y ?? 0) - (v[0].y ?? 0));
}

function median(list: number[]): number {
  if (!list.length) return 0;
  const s = [...list].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)];
}

/** The photo's lines of text, each with the height of its letters. */
export function linesOf(v: VisionText): Line[] {
  const out: Line[] = [];
  for (const page of v.pages ?? [])
    for (const block of page.blocks ?? [])
      for (const par of block.paragraphs ?? []) {
        let text = '';
        let heights: number[] = [];
        const flush = () => {
          const t = clean(text);
          if (t) out.push({ text: t, height: median(heights) });
          text = '';
          heights = [];
        };
        for (const w of par.words ?? []) {
          const symbols = w.symbols ?? [];
          if (/\p{L}/u.test(symbols.map((s) => s.text ?? '').join(''))) heights.push(wordHeight(w));
          for (const s of symbols) {
            text += s.text ?? '';
            const br = s.property?.detectedBreak?.type;
            if (br === 'SPACE' || br === 'SURE_SPACE') text += ' ';
            else if (br === 'EOL_SURE_SPACE' || br === 'LINE_BREAK') flush();
            else if (br === 'HYPHEN') {
              text += '-';
              flush();
            }
          }
        }
        flush();
      }
  return out;
}

// ── The name, from the front of the pack ───────────────────────────────────

/** Lines that are not the name: addresses, nutrition, weights, ingredient lists, trademarks. */
const NOT_NAME = /www\.|https?:|@|\bkcal\b|\bkj\b|%|osszetev|ingredient|\be\s?\d{3}\b|^\d+([.,]\d+)?\s*(g|kg|ml|cl|dl|l|db)\b|:$|\.$/;

/**
 * The name printed biggest on the front: the three largest lines, in reading order, up to 32 characters,
 * none under a fifth of the largest. "Coca-Cola" (332 px) and "ZÉRO CUKOR" (80 px) make the name;
 * "ZÉRÓ KALÓRIA" (45 px) is small print.
 */
export function nameFromLines(lines: Line[]): string | undefined {
  const ok = lines
    .map((l, i) => ({ ...l, i }))
    .filter((l) => {
      const letters = (l.text.match(/\p{L}/gu) ?? []).length;
      const digits = (l.text.match(/\d/g) ?? []).length;
      return letters >= 3 && letters >= digits * 2 && l.text.length <= 40 && l.height > 0 && !NOT_NAME.test(fold(l.text)) && !NON_LATIN.test(l.text);
    });
  if (!ok.length) return undefined;
  const top = Math.max(...ok.map((l) => l.height));
  const chosen: typeof ok = [];
  let length = 0;
  for (const l of [...ok].sort((a, b) => b.height - a.height)) {
    if (chosen.length === 3 || l.height < top * 0.22 || length + l.text.length > 32) break;
    chosen.push(l);
    length += l.text.length + 1;
  }
  const name = chosen
    .sort((a, b) => a.i - b.i)
    .map((l) => l.text)
    .join(' ');
  return (name.match(/\p{L}/gu) ?? []).length >= 3 ? name : undefined;
}

// ── The ingredient list, from the back ─────────────────────────────────────

export type ListLang = 'hu' | 'en';

/** Where a list starts, in the folded text: "Összetevők:" (also as OCR misreads it), "Ingredients:". */
const START: { lang: ListLang; re: RegExp }[] = [
  { lang: 'hu', re: /osszetev[o0]k?\s*([:;.]|\n)\s*/g },
  // Not "Ingrediente:" (Romanian) or "Ingredienti:".
  { lang: 'en', re: /\bingredients?\b\s*[:;.]\s*/g },
];

/** What comes after a list: nutrition, dates, storage, the maker, "may contain". */
const AFTER =
  /energia|\bkj\b|\bkcal\b|tapertek|tapanyag|minoseget megorzi|fogyaszthato|felhasznalhato|\bnetto\b|forgalmaz|gyartja|gyarto|eloallit|tarolas|tarolja|taroland|tartalmazhat|nyomokban|allergen|nutrition|best before|\bstore\b|may contain|www\./;

/** The additive classes a label names before the additive ("színezék: …", "sweeteners: …"). */
const CLASS =
  /szinezek|edesitoszer|etkezesi sav|savanyusagot szabalyozo|savanyito|tartositoszer|emulgealoszer|emulgeloszer|stabilizator|suritoanyag|antioxidans|izfokozo|terfogatnovelo|csomosodast gatlo|fenyezoanyag|zselesito|nedvesitoszer|allagjavito|colou?r|sweetener|acidity regulator|preservative|emulsifier|stabili[sz]er|thickener|antioxidant|flavou?r enhancer|raising agent|gelling agent/;

/** Common additives written by name, not by number (folded words, Hungarian and English). */
const ADDITIVES: [RegExp, string][] = [
  [/szulfitos[- ]?ammonias karamell|sulphite ammonia caramel/, 'e150d'],
  [/foszforsav|phosphoric acid/, 'e338'],
  [/citromsav|citric acid/, 'e330'],
  [/natrium[- ]citrat|sodium citrate/, 'e331'],
  [/aceszulfam|acesulfame/, 'e950'],
  [/aszpartam|aspartame/, 'e951'],
  [/ciklamat|cyclamate/, 'e952'],
  [/szacharin|saccharin/, 'e954'],
  [/szukraloz|sucralose/, 'e955'],
  [/szteviol[- ]?glikozid|steviol glycoside/, 'e960'],
  [/szorbinsav|sorbic acid/, 'e200'],
  [/kalium[- ]szorbat|potassium sorbate/, 'e202'],
  [/benzoesav|benzoic acid/, 'e210'],
  [/natrium[- ]benzoat|sodium benzoate/, 'e211'],
  [/natrium[- ]nitrit|sodium nitrite/, 'e250'],
  [/kalium[- ]nitrat|potassium nitrate/, 'e252'],
  [/aszkorbinsav|ascorbic acid/, 'e300'],
  [/natrium[- ]aszkorbat|sodium ascorbate/, 'e301'],
  [/lecitin|lecithin/, 'e322'],
  [/karragen|carrageenan/, 'e407'],
  [/szentjanoskenyer|locust bean/, 'e410'],
  [/guar ?gumi|guar gum/, 'e412'],
  [/xantan|xanthan/, 'e415'],
  [/pektin|pectin/, 'e440'],
  [/mono- (es|and) digliceri|mono- and diglyceride/, 'e471'],
  [/glutamat|glutamate/, 'e621'],
];

/** Split at the commas and semicolons outside brackets, and at "és" ("and") between two items
 *  ("aceszulfám K és aszpartám"), but not in "mono- és digliceridek" or "2,8%". */
function splitTop(s: string, lang: ListLang): string[] {
  const out: string[] = [];
  let depth = 0;
  let cur = '';
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === '(' || ch === '[') depth++;
    else if ((ch === ')' || ch === ']') && depth > 0) depth--;
    const decimal = ch === ',' && /\d/.test(s[i - 1] ?? '') && /\d/.test(s[i + 1] ?? '');
    if (depth === 0 && (ch === ',' || ch === ';') && !decimal) {
      out.push(cur);
      cur = '';
    } else cur += ch;
  }
  out.push(cur);
  return out
    .flatMap((p) => p.replace(lang === 'hu' ? /([^-])\s+és\s+(?![^(]*\))/g : /([^-])\s+and\s+(?![^(]*\))/g, '$1\u0000').split('\u0000'))
    .map(clean)
    .filter(Boolean);
}

function lowerFirst(s: string): string {
  if (s.length > 1 && /[A-Z0-9]/.test(s[1]) && s[1] === s[1].toUpperCase()) return s;
  return s.charAt(0).toLowerCase() + s.slice(1);
}

function parseItem(raw: string, lang: ListLang, depth = 0): Ingredient | null {
  let text = raw.replace(/^[\s*•·–—-]+/, '').replace(/[\s*.:;,]+$/, '');
  let sub: Ingredient[] | undefined;
  const open = text.search(/[([]/);
  if (open > 0 && depth < 2) {
    const close = Math.max(text.lastIndexOf(')'), text.lastIndexOf(']'));
    const inner = text.slice(open + 1, close > open ? close : undefined);
    // "(12%)" and "(E330)" are details of the item; words in brackets are its parts.
    if (/\p{L}{3}/u.test(inner.replace(/\bE\s?\d{3,4}[a-z]?\b/gi, ''))) {
      const parts = splitTop(inner, lang)
        .map((p) => parseItem(p, lang, depth + 1))
        .filter((p): p is Ingredient => p !== null);
      if (parts.length) {
        sub = parts;
        text = clean(`${text.slice(0, open)} ${close > open ? text.slice(close + 1) : ''}`);
      }
    }
  }

  let percent: number | undefined;
  const pm = /\(?\s*(\d{1,3}(?:[.,]\d+)?)\s*%\s*\)?/.exec(text);
  if (pm) {
    const n = Number(pm[1].replace(',', '.'));
    if (n > 0 && n <= 100) percent = n;
    text = clean(text.replace(pm[0], ' '));
  }
  const name = lowerFirst(clean(text.replace(/\(\s*\)/g, '')));
  // "E150d", "E 330", "E500ii"; a letter after a space is the next word.
  const written = /\bE\s?-?(\d{3,4})(iv|i{1,3}|v|[a-f])?\b/i.exec(name);
  // A bare "E250" is an item; a stray "3" or "g" is not.
  if (!written && (name.match(/\p{L}/gu) ?? []).length < 2) return null;

  const f = fold(name);
  const out: Ingredient = { name: { hu: name, en: name } };
  // A claim ("nátrium-glutamát nélkül", "gluten free") names what is not in it.
  if (/mentes|nelkul|\bfree\b|without/.test(f)) return sub ? { ...out, sub } : out;
  const eId = written ? `en:e${written[1]}${(written[2] ?? '').toLowerCase()}` : ADDITIVES.find(([re]) => re.test(f))?.[1];
  const eNumber = eId ? eNumberOf(eId.startsWith('en:') ? eId : `en:${eId}`) : undefined;

  const flags = new Set<AvoidKey>(lang === 'hu' ? ingredientFlags(undefined, name, undefined, false) : ingredientFlags(`en:${slug(name)}`, name));
  if (eNumber) for (const k of additiveFlags(`en:${eNumber.toLowerCase()}`)) flags.add(k);
  const cls = CLASS.exec(f);
  if (cls) {
    flags.add('additives');
    if (/edesito|sweetener/.test(cls[0])) flags.add('sweeteners');
  }

  if (flags.size) out.flags = [...flags];
  if (eNumber) out.eNumber = eNumber;
  if (percent !== undefined) out.percent = percent;
  if (sub) out.sub = sub;
  return out;
}

export type ReadList = { lang: ListLang; text: string; ingredients: Ingredient[] };

/**
 * The ingredient list in a photo's text: from "Összetevők:" (or "Ingredients:") to the end of its sentence,
 * split into items with the criteria each one triggers. Hungarian first, then English; a list in another
 * language is not read, because our words for the criteria would miss it and call it "all clear".
 */
export function ingredientsFromText(full: string): ReadList | undefined {
  const folded = fold(full);
  for (const { lang, re } of START) {
    re.lastIndex = 0;
    for (let m = re.exec(folded); m; m = re.exec(folded)) {
      const from = m.index + m[0].length;
      const rest = full.slice(from, from + 700);
      const text = rest
        .slice(0, listEnd(rest))
        .replace(/-\n(?=\p{Ll})/gu, '-')
        .replace(/\s*\n\s*/g, ' ');
      const list = readList(text, lang);
      if (list) return list;
    }
  }
  return undefined;
}

/** Where the list ends: the first full stop before a capital, or the first word of what follows a list,
 *  outside brackets ("TEJFEHÉRJE (LAKTÓZT tartalmazhat), étkezési só" goes on). */
function listEnd(text: string): number {
  const folded = fold(text);
  const ends: number[] = [];
  const sentence = /\.\s+(?=\p{Lu})/gu;
  for (let m = sentence.exec(text); m; m = sentence.exec(text)) ends.push(m.index);
  const after = new RegExp(AFTER.source, 'g');
  for (let m = after.exec(folded); m; m = after.exec(folded)) ends.push(m.index);
  let depth = 0;
  let at = 0;
  for (const end of ends.sort((a, b) => a - b)) {
    for (; at < end; at++) {
      if (text[at] === '(' || text[at] === '[') depth++;
      else if ((text[at] === ')' || text[at] === ']') && depth > 0) depth--;
    }
    if (depth === 0) return end;
  }
  return text.length;
}

/** "étkezési sav: foszforsav" names a class; "rek: szulfitos" or "Zsír: 0 g" is two columns read across. */
function badColon(name: string): boolean {
  const parts = fold(name).split(':');
  return parts.slice(0, -1).some((left) => {
    const words = left.trim().split(/\s+/);
    return words.length > 3 || !/^[a-z][a-z -]*$/.test(left.trim()) || left.replace(/[^a-z]/g, '').length < 5;
  });
}

function readList(text: string, lang: ListLang): ReadList | undefined {
  const t = clean(text).replace(/[\s.,;:]+$/, '');
  const chars = t.replace(/\s/g, '');
  const letters = (t.match(/\p{L}/gu) ?? []).length;
  // Garbled text (a table, a barcode, two columns read across) is mostly not letters.
  if (letters < 3 || letters < chars.length * 0.7) return undefined;
  const items = splitTop(t, lang)
    .map((s) => parseItem(s, lang))
    .filter((i): i is Ingredient => i !== null);
  const all: Ingredient[] = [];
  const collect = (list: Ingredient[]) => {
    for (const i of list) {
      all.push(i);
      if (i.sub) collect(i.sub);
    }
  };
  collect(items);
  if (!items.length || all.some((i) => i.name.hu.length > 90 || badColon(i.name.hu))) return undefined;
  // A jar of honey is not "added" sugar: the same rule as for typed lists.
  if (items.length === 1 && !items[0].sub && items[0].flags) {
    const flags = items[0].flags.filter((k) => k !== 'added_sugar');
    if (flags.length) items[0].flags = flags;
    else delete items[0].flags;
  }
  return { lang, text: t, ingredients: items };
}

// ── Fetching ───────────────────────────────────────────────────────────────

export type PackText = {
  /** The name printed biggest on the front photo, as read. */
  name?: string;
  ingredients?: ReadList;
  /** The photo the ingredients were read from, to check them against. */
  ingredientsPhoto?: string;
};

type Photo = { id: string; url: string };

/** The photos chosen for a slot ("front_hu", "ingredients_en" …), Hungarian first, then English, the
 *  product's own language and the rest. */
function chosen(p: OffProduct, folder: string, slot: 'front' | 'ingredients'): Photo[] {
  const images = p.images ?? {};
  const langs = Object.keys(images)
    .filter((k) => k.startsWith(`${slot}_`))
    .map((k) => k.slice(slot.length + 1));
  const order = [...new Set(['hu', 'en', p.lang ?? '', ...langs])].filter((l) => langs.includes(l));
  const out: Photo[] = [];
  for (const l of order) {
    const ref = images[`${slot}_${l}`];
    const id = ref?.imgid !== undefined ? String(ref.imgid) : '';
    if (!/^\d+$/.test(id) || out.some((x) => x.id === id)) continue;
    const rev = ref?.rev !== undefined ? String(ref.rev) : '';
    out.push({ id, url: /^\d+$/.test(rev) ? `${IMAGES}/${folder}/${slot}_${l}.${rev}.full.jpg` : `${IMAGES}/${folder}/${id}.jpg` });
  }
  return out;
}

/** Every uploaded photo, oldest first. */
function uploaded(p: OffProduct, folder: string): Photo[] {
  return Object.keys(p.images ?? {})
    .filter((k) => /^\d+$/.test(k))
    .sort((a, b) => Number(a) - Number(b))
    .map((id) => ({ id, url: `${IMAGES}/${folder}/${id}.jpg` }));
}

const MAX_PHOTOS = 3;

async function visionText(folder: string, id: string, signal?: AbortSignal): Promise<VisionText | undefined> {
  const r = await getJson<VisionFile>(`${IMAGES}/${folder}/${id}.json`, { signal, timeoutMs: 6000 });
  return r.ok ? r.data.responses?.[0]?.fullTextAnnotation : undefined;
}

/**
 * Read the name off the front photo and the ingredients off the back, as far as asked. Never throws;
 * what cannot be read stays unset. The ingredients come from the photo chosen for them, or, when nobody
 * chose one, from the first uploaded photo that has a readable list.
 */
export async function readPack(
  code: string,
  p: OffProduct,
  want: { name: boolean; ingredients: boolean },
  signal?: AbortSignal,
): Promise<PackText | undefined> {
  const folder = imageFolder(code);
  const front = want.name ? chosen(p, folder, 'front')[0] : undefined;
  let backs = want.ingredients ? chosen(p, folder, 'ingredients') : [];
  if (want.ingredients && !backs.length) backs = uploaded(p, folder).filter((x) => x.id !== chosen(p, folder, 'front')[0]?.id);
  backs = backs.slice(0, MAX_PHOTOS);
  if (!front && !backs.length) return undefined;

  const [frontText, ...backTexts] = await Promise.all([
    front ? visionText(folder, front.id, signal) : Promise.resolve(undefined),
    ...backs.map((b) => visionText(folder, b.id, signal)),
  ]);
  const out: PackText = {};
  const name = frontText ? nameFromLines(linesOf(frontText)) : undefined;
  if (name) out.name = name;
  for (let i = 0; i < backs.length; i++) {
    const text = backTexts[i]?.text;
    const list = text ? ingredientsFromText(text) : undefined;
    if (list) {
      out.ingredients = list;
      out.ingredientsPhoto = backs[i].url;
      break;
    }
  }
  return out.name || out.ingredients ? out : undefined;
}
