// Barcode maths for real codes: the GS1 check digit, UPC-E expansion, and one canonical key per product.
// Pure TypeScript (no React, no '@/' aliases), so the lookup can be tested with plain Node.

export type CodeKind = 'ean13' | 'ean8' | 'upca' | 'upce';

export type Canonical = {
  /** The key we store and look up by: 13 digits for EAN-13, UPC-A and UPC-E; 8 for EAN-8. */
  key: string;
  kind: CodeKind;
  /** Every spelling a source may use for the same product (Open Food Facts pads UPC-A with a 0). */
  variants: string[];
};

/** The GS1 check digit for a code body (every digit but the last). */
export function gs1CheckDigit(body: string): number {
  let sum = 0;
  for (let i = 0; i < body.length; i++) {
    const d = body.charCodeAt(body.length - 1 - i) - 48;
    sum += d * (i % 2 === 0 ? 3 : 1);
  }
  return (10 - (sum % 10)) % 10;
}

function checks(code: string): boolean {
  return gs1CheckDigit(code.slice(0, -1)) === code.charCodeAt(code.length - 1) - 48;
}

/** UPC-E (8 digits: number system, 6 digits, check) to UPC-A (12 digits), or null. */
export function expandUpcE(code: string): string | null {
  if (!/^[01]\d{7}$/.test(code)) return null;
  const ns = code[0];
  const d = code.slice(1, 7);
  const check = code[7];
  const last = d[5];
  let body: string;
  if (last === '0' || last === '1' || last === '2') body = `${d[0]}${d[1]}${last}0000${d[2]}${d[3]}${d[4]}`;
  else if (last === '3') body = `${d[0]}${d[1]}${d[2]}00000${d[3]}${d[4]}`;
  else if (last === '4') body = `${d[0]}${d[1]}${d[2]}${d[3]}00000${d[4]}`;
  else body = `${d[0]}${d[1]}${d[2]}${d[3]}${d[4]}0000${last}`;
  const upca = `${ns}${body}${check}`;
  return checks(upca) ? upca : null;
}

/** Only digits, as typed or scanned ("5 998200 557682" → "5998200557682"). */
export function digitsOnly(raw: string): string {
  return raw.replace(/\D/g, '');
}

/**
 * The canonical form of a scanned or typed code, or null if it is not a complete code with a valid
 * check digit. An 8-digit code is an EAN-8 when its own check digit fits, else a UPC-E.
 */
export function canonical(raw: string): Canonical | null {
  const code = digitsOnly(raw);
  if (code.length === 13 && checks(code)) {
    const variants = [code];
    if (code.startsWith('0')) variants.push(code.slice(1));
    return { key: code, kind: 'ean13', variants };
  }
  if (code.length === 12 && checks(code)) {
    return { key: `0${code}`, kind: 'upca', variants: [`0${code}`, code] };
  }
  if (code.length === 14 && code.startsWith('0') && checks(code)) {
    return canonical(code.slice(1));
  }
  if (code.length === 8) {
    if (checks(code)) return { key: code, kind: 'ean8', variants: [code] };
    const upca = expandUpcE(code);
    if (upca) return { key: `0${upca}`, kind: 'upce', variants: [`0${upca}`, upca, code] };
  }
  return null;
}

export function isValidCode(raw: string): boolean {
  return canonical(raw) !== null;
}

/**
 * A camera read is trusted only when the same valid code comes twice in a row. A different code in
 * between, or a long pause, starts over. Returns a function that answers "accept this read now?".
 */
export function makeConfirmer(windowMs = 2000): (code: string, now?: number) => boolean {
  let last: { code: string; at: number } | null = null;
  return (code, now = Date.now()) => {
    if (!isValidCode(code)) {
      last = null;
      return false;
    }
    if (last && last.code === code && now - last.at <= windowMs) {
      last = null;
      return true;
    }
    last = { code, at: now };
    return false;
  };
}
