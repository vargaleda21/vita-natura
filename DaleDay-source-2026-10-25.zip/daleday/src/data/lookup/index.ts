// The real-product lookup: pure TypeScript (no React, no '@/' aliases), so Node can run it in tests.

export { configureLookup, lookupConfig, type KeyValueStore } from './http';
export { canonical, isValidCode, makeConfirmer, expandUpcE, gs1CheckDigit, type Canonical, type CodeKind } from './ean';
export { gs1Info, type Gs1Info } from './gs1';
export {
  hydrateLookupCache,
  subscribeLookup,
  lookupVersion,
  realProduct,
  realPrices,
  pricesFresh,
  lookupEnded,
  pricePending,
  productAge,
  IDENTITY_TTL,
  PRICES_TTL,
} from './cache';
export {
  lookupCode,
  refreshPrices,
  ensureChainPrices,
  emptyProgress,
  SOURCE_ORDER,
  type SourceKey,
  type SourceStatus,
  type Progress,
  type LookupOutcome,
  type LookupOptions,
} from './lookup';
export { fetchAlternativeCandidates, candidateCategories, type Candidates } from './alternatives';
export { offProductUrl } from './off';
export { findMaker, filterMakerProducts, makerEligible, type Maker, type MakerProduct } from './maker';
export { countryFromIso } from './countries';
