// Country names in Hungarian and English, by ISO code and by Open Food Facts country tag.

import type { L10n } from '../types';

// [iso2, Open Food Facts tag (without "en:"), hu, en]
const ROWS: [string, string, string, string][] = [
  ['HU', 'hungary', 'Magyarország', 'Hungary'],
  ['AT', 'austria', 'Ausztria', 'Austria'],
  ['SK', 'slovakia', 'Szlovákia', 'Slovakia'],
  ['CZ', 'czech-republic', 'Csehország', 'Czech Republic'],
  ['PL', 'poland', 'Lengyelország', 'Poland'],
  ['RO', 'romania', 'Románia', 'Romania'],
  ['HR', 'croatia', 'Horvátország', 'Croatia'],
  ['SI', 'slovenia', 'Szlovénia', 'Slovenia'],
  ['RS', 'serbia', 'Szerbia', 'Serbia'],
  ['UA', 'ukraine', 'Ukrajna', 'Ukraine'],
  ['DE', 'germany', 'Németország', 'Germany'],
  ['FR', 'france', 'Franciaország', 'France'],
  ['IT', 'italy', 'Olaszország', 'Italy'],
  ['ES', 'spain', 'Spanyolország', 'Spain'],
  ['PT', 'portugal', 'Portugália', 'Portugal'],
  ['BE', 'belgium', 'Belgium', 'Belgium'],
  ['NL', 'netherlands', 'Hollandia', 'the Netherlands'],
  ['LU', 'luxembourg', 'Luxemburg', 'Luxembourg'],
  ['CH', 'switzerland', 'Svájc', 'Switzerland'],
  ['GB', 'united-kingdom', 'Egyesült Királyság', 'United Kingdom'],
  ['IE', 'ireland', 'Írország', 'Ireland'],
  ['DK', 'denmark', 'Dánia', 'Denmark'],
  ['SE', 'sweden', 'Svédország', 'Sweden'],
  ['NO', 'norway', 'Norvégia', 'Norway'],
  ['FI', 'finland', 'Finnország', 'Finland'],
  ['IS', 'iceland', 'Izland', 'Iceland'],
  ['EE', 'estonia', 'Észtország', 'Estonia'],
  ['LV', 'latvia', 'Lettország', 'Latvia'],
  ['LT', 'lithuania', 'Litvánia', 'Lithuania'],
  ['BG', 'bulgaria', 'Bulgária', 'Bulgaria'],
  ['GR', 'greece', 'Görögország', 'Greece'],
  ['CY', 'cyprus', 'Ciprus', 'Cyprus'],
  ['MT', 'malta', 'Málta', 'Malta'],
  ['BA', 'bosnia-and-herzegovina', 'Bosznia-Hercegovina', 'Bosnia and Herzegovina'],
  ['MK', 'north-macedonia', 'Észak-Macedónia', 'North Macedonia'],
  ['ME', 'montenegro', 'Montenegró', 'Montenegro'],
  ['AL', 'albania', 'Albánia', 'Albania'],
  ['MD', 'moldova', 'Moldova', 'Moldova'],
  ['TR', 'turkey', 'Törökország', 'Turkey'],
  ['RU', 'russia', 'Oroszország', 'Russia'],
  ['US', 'united-states', 'Egyesült Államok', 'United States'],
  ['CA', 'canada', 'Kanada', 'Canada'],
  ['MX', 'mexico', 'Mexikó', 'Mexico'],
  ['BR', 'brazil', 'Brazília', 'Brazil'],
  ['AR', 'argentina', 'Argentína', 'Argentina'],
  ['AU', 'australia', 'Ausztrália', 'Australia'],
  ['NZ', 'new-zealand', 'Új-Zéland', 'New Zealand'],
  ['JP', 'japan', 'Japán', 'Japan'],
  ['CN', 'china', 'Kína', 'China'],
  ['KR', 'south-korea', 'Dél-Korea', 'South Korea'],
  ['IN', 'india', 'India', 'India'],
  ['TH', 'thailand', 'Thaiföld', 'Thailand'],
  ['IL', 'israel', 'Izrael', 'Israel'],
  ['MA', 'morocco', 'Marokkó', 'Morocco'],
  ['TN', 'tunisia', 'Tunézia', 'Tunisia'],
  ['ZA', 'south-africa', 'Dél-afrikai Köztársaság', 'South Africa'],
];

const BY_ISO = new Map(ROWS.map(([iso, , hu, en]) => [iso, { iso2: iso, name: { hu, en } }]));
const BY_TAG = new Map(ROWS.map(([iso, tag, hu, en]) => [`en:${tag}`, { iso2: iso, name: { hu, en } }]));

function words(tag: string): string {
  const s = tag.replace(/^[a-z]{2}:/, '').replace(/-/g, ' ');
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** "en:czech-republic" → { iso2: 'CZ', name: { hu: 'Csehország', en: 'Czech Republic' } }. */
export function countryFromTag(tag: string): { iso2?: string; name: L10n } {
  const known = BY_TAG.get(tag);
  if (known) return known;
  const w = words(tag);
  return { name: { hu: w, en: w } };
}

/** "NO" → Norvégia / Norway; falls back to the name the source gave. */
export function countryFromIso(iso2: string | undefined, fallback?: string): { iso2?: string; name: L10n } | undefined {
  const known = iso2 ? BY_ISO.get(iso2.toUpperCase()) : undefined;
  if (known) return known;
  if (!fallback) return undefined;
  return { iso2, name: { hu: fallback, en: fallback } };
}
