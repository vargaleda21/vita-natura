// GVH Árfigyelő: the Hungarian Competition Authority's official price monitor. Its product ids are
// EANs. It has no CORS, so we call it through our own read-only proxy (/api/arfigyelo/…).

import type { ChainPrice } from '../types';
import { getJson, proxyUrl, qs, type FetchError } from './http';

type ArPrice = { type?: string; amount?: number; unitAmount?: number };
type ArChain = {
  name?: string;
  prices?: ArPrice[];
  pricesMax?: ArPrice[];
  priceSameEverywhere?: boolean;
  availableInShops?: string[];
};
export type ArProduct = {
  id?: string;
  name?: string;
  imageUrl?: string;
  unit?: string;
  unitTitle?: string;
  packaging?: string;
  categoryPath?: string;
  chainStores?: ArChain[];
};

export type ArLookup = { kind: 'found'; product: ArProduct; chains: ChainPrice[] } | { kind: 'missing' } | { kind: 'error'; error: FetchError };

function lowest(prices: ArPrice[] | undefined): { amount: number; unit?: number; discounted: boolean; regular?: number } | null {
  const valid = (prices ?? []).filter((p) => typeof p.amount === 'number' && p.amount > 0);
  if (valid.length === 0) return null;
  const best = valid.reduce((a, b) => ((b.amount ?? 0) < (a.amount ?? 0) ? b : a));
  const regular = valid.find((p) => p.type === 'NORMAL')?.amount;
  const discounted = best.type === 'DISCOUNTED';
  return {
    amount: best.amount ?? 0,
    unit: best.unitAmount,
    discounted,
    regular: discounted && regular && regular > (best.amount ?? 0) ? regular : undefined,
  };
}

/** The chains' current prices, lowest first. */
export function chainPrices(product: ArProduct): ChainPrice[] {
  const packaging = Number(String(product.packaging ?? '').replace(',', '.'));
  const out: ChainPrice[] = [];
  for (const ch of product.chainStores ?? []) {
    const low = lowest(ch.prices);
    if (!ch.name || !low) continue;
    const high = lowest(ch.pricesMax);
    const showUnit = low.unit !== undefined && product.unit && Number.isFinite(packaging) && packaging > 0 && packaging !== 1;
    out.push({
      chain: ch.name,
      priceHuf: low.amount,
      regularHuf: low.regular,
      discounted: low.discounted,
      maxHuf: high && high.amount > low.amount ? high.amount : undefined,
      sameEverywhere: ch.priceSameEverywhere !== false,
      shops: ch.availableInShops?.length ?? 0,
      unitPriceHuf: showUnit ? low.unit : undefined,
      unit: showUnit ? product.unit : undefined,
    });
  }
  return out.sort((a, b) => a.priceHuf - b.priceHuf);
}

export async function fetchArfigyelo(ean: string, signal?: AbortSignal): Promise<ArLookup> {
  // Árfigyelő keys products by the 13-digit EAN (or the 8-digit one).
  const r = await getJson<ArProduct & { code?: string }>(proxyUrl(`/api/arfigyelo/product/${ean}`), { signal });
  if (r.ok && r.data.id) return { kind: 'found', product: r.data, chains: chainPrices(r.data) };
  if (r.ok || r.status === 404) return { kind: 'missing' };
  return { kind: 'error', error: r.error };
}

type ArSearchProduct = ArProduct & {
  pricesOfChainStores?: { name?: string; priceSameEverywhere?: boolean; prices?: ArPrice[] }[];
};

/** Free-text search: products with their chain prices (no shop lists). */
export async function searchArfigyelo(q: string, signal?: AbortSignal): Promise<{ id: string; name: string; chains: ChainPrice[] }[] | null> {
  const r = await getJson<{ products?: ArSearchProduct[] }>(proxyUrl(`/api/arfigyelo/search?${qs({ q })}`), { signal });
  if (!r.ok) return null;
  return (r.data.products ?? []).flatMap((p) =>
    p.id && p.name
      ? [{ id: p.id, name: p.name, chains: chainPrices({ ...p, chainStores: (p.pricesOfChainStores ?? []).map((c) => ({ ...c, availableInShops: [] })) }) }]
      : [],
  );
}
