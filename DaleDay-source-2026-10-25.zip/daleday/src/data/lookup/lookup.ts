// The lookup: one barcode, five open sources, in parallel, each with a timeout.
// Identity first (Open Food Facts and its sisters, GVH Árfigyelő, then UPCitemdb as a last resort);
// prices (Árfigyelő, Open Prices) keep loading after the product is shown.

import type { Product, RealPrices } from '../types';
import {
  IDENTITY_TTL,
  type PricePart,
  pricePending,
  productAge,
  pricesFresh,
  putPrices,
  putProduct,
  realProduct,
  setLookupRunning,
  setPricePending,
} from './cache';
import { canonical } from './ean';
import { fetchArfigyelo, type ArLookup } from './arfigyelo';
import { buildProduct, hasTitle, taxonomyTags, titleCategoryTags, type Names } from './map';
import { readPack, type PackText } from './ocr';
import { fetchOffProduct, fetchTaxonomyNames, type OffFlavor, type OffLookup, type OffProduct } from './off';
import { fetchOpenPrices, type OpLookup } from './openprices';
import { fetchUpc, type UpcLookup } from './upc';

export type SourceKey = 'off' | 'sisters' | 'arfigyelo' | 'open_prices' | 'upcitemdb';
export const SOURCE_ORDER: SourceKey[] = ['off', 'sisters', 'arfigyelo', 'open_prices', 'upcitemdb'];

/** waiting → checking → found | none (checked, not there) | skipped (not needed) | error (no answer). */
export type SourceStatus = 'waiting' | 'checking' | 'found' | 'none' | 'skipped' | 'error';
export type Progress = Record<SourceKey, SourceStatus>;

export type LookupOutcome =
  | { kind: 'found'; product: Product; progress: Progress; cached: boolean }
  | { kind: 'not_found'; key: string; progress: Progress; unreachable: SourceKey[] }
  | { kind: 'invalid' }
  | { kind: 'aborted' };

export type LookupOptions = {
  signal?: AbortSignal;
  onProgress?: (progress: Progress) => void;
  /** Skip the device cache (the "try again" button, a stale product). */
  force?: boolean;
};

export function emptyProgress(): Progress {
  return { off: 'waiting', sisters: 'waiting', arfigyelo: 'waiting', open_prices: 'waiting', upcitemdb: 'waiting' };
}

function progressFromCache(p: Product): Progress {
  const s = p.real?.sources ?? [];
  const has = (x: string) => s.includes(x as never);
  const prices = pricesFresh(p.ean);
  return {
    off: has('off') ? 'found' : 'none',
    sisters: has('obf') || has('opf') || has('opff') ? 'found' : has('off') ? 'skipped' : 'none',
    arfigyelo: has('arfigyelo') ? 'found' : 'none',
    open_prices: prices.openPrices ? 'found' : 'skipped',
    upcitemdb: has('upcitemdb') ? 'found' : 'skipped',
  };
}

const status = (r: { kind: string }): SourceStatus => (r.kind === 'found' ? 'found' : r.kind === 'missing' ? 'none' : 'error');

const SISTERS: OffFlavor[] = ['beauty', 'product', 'petfood'];

async function sisters(off: OffLookup, key: string, signal?: AbortSignal): Promise<OffLookup> {
  if (off.kind === 'missing' && off.elsewhere) return fetchOffProduct(off.elsewhere, key, signal);
  // Open Food Facts said "not found" (or did not answer): ask the three sisters at once.
  const all = await Promise.all(SISTERS.map((f) => fetchOffProduct(f, key, signal)));
  const found = all.find((r) => r.kind === 'found');
  if (found) return found;
  if (all.every((r) => r.kind === 'error')) return all[0];
  return { kind: 'missing' };
}

async function namesFor(off: OffLookup, signal?: AbortSignal): Promise<Names | undefined> {
  if (off.kind !== 'found' || off.flavor !== 'food') return undefined;
  const tags = taxonomyTags(off.product);
  // A product without a usable name is titled by its category: then the category names are needed too.
  const cats = hasTitle(off.product) ? [] : titleCategoryTags(off.product);
  const [ingredients, additives, labels, categories] = await Promise.all([
    fetchTaxonomyNames('ingredients', tags.ingredients, signal),
    fetchTaxonomyNames('additives', tags.additives, signal),
    fetchTaxonomyNames('labels', tags.labels, signal),
    fetchTaxonomyNames('categories', cats, signal),
  ]);
  return { ingredients, additives, labels, categories };
}

/** A found product nobody named, or (food) whose ingredients nobody typed: what its photos say. */
function packFor(off: { flavor: OffFlavor; product: OffProduct } | null, key: string, signal?: AbortSignal): Promise<PackText | undefined> {
  if (!off) return Promise.resolve(undefined);
  const want = { name: !hasTitle(off.product), ingredients: off.flavor === 'food' && !off.product.ingredients?.length };
  return want.name || want.ingredients ? readPack(key, off.product, want, signal) : Promise.resolve(undefined);
}

function arPrices(r: ArLookup): RealPrices['arfigyelo'] {
  if (r.kind === 'found') return { chains: r.chains, name: r.product.name };
  return r.kind === 'missing' ? null : undefined;
}

function opPrices(r: OpLookup): RealPrices['openPrices'] {
  if (r.kind === 'found') return r.sightings;
  return r.kind === 'missing' ? null : undefined;
}

/** Run one price fetch with its "loading" mark set. */
function tracked<T>(key: string, part: PricePart, job: () => Promise<T>): Promise<T> {
  setPricePending(key, part, true);
  return job().finally(() => setPricePending(key, part, false));
}

const inflight = new Map<string, Promise<LookupOutcome>>();

/** Look a code up. Calls onProgress whenever a source changes state (also after the promise resolves,
 *  while Open Prices is still loading). */
export function lookupCode(raw: string, opts: LookupOptions = {}): Promise<LookupOutcome> {
  const canon = canonical(raw);
  if (!canon) return Promise.resolve({ kind: 'invalid' });
  const key = canon.key;

  if (!opts.force) {
    const cached = realProduct(key);
    if (cached && !cached.real?.preview && productAge(key) < IDENTITY_TTL) {
      const fresh = pricesFresh(key);
      if (!fresh.arfigyelo || !fresh.openPrices) void refreshPrices(key);
      const progress = progressFromCache(cached);
      opts.onProgress?.(progress);
      return Promise.resolve({ kind: 'found', product: cached, progress, cached: true });
    }
  }
  const running = inflight.get(key);
  if (running && !opts.onProgress) return running;

  const job = run(key, opts).finally(() => {
    if (inflight.get(key) === job) {
      inflight.delete(key);
      setLookupRunning(key, false);
    }
  });
  inflight.set(key, job);
  setLookupRunning(key, true);
  return job;
}

async function run(key: string, { signal, onProgress }: LookupOptions): Promise<LookupOutcome> {
  const progress = emptyProgress();
  const set = (k: SourceKey, s: SourceStatus) => {
    progress[k] = s;
    onProgress?.({ ...progress });
  };

  set('off', 'checking');
  set('arfigyelo', 'checking');
  set('open_prices', 'checking');

  const offP = fetchOffProduct('food', key, signal);
  const arP = tracked(key, 'arfigyelo', () => fetchArfigyelo(key, signal)).then((r) => {
    set('arfigyelo', status(r));
    putPrices(key, { arfigyelo: arPrices(r) });
    return r;
  });
  // Prices from Open Prices are not needed to show the product: they arrive when they arrive.
  void tracked(key, 'openPrices', () => fetchOpenPrices(key, signal)).then((r) => {
    if (r.kind === 'error' && r.error === 'abort') return;
    set('open_prices', status(r));
    putPrices(key, { openPrices: opPrices(r) });
  });

  const off = await offP;
  set('off', status(off));
  let identity: OffLookup = off;
  if (off.kind === 'found') {
    set('sisters', 'skipped');
  } else {
    set('sisters', 'checking');
    identity = await sisters(off, key, signal);
    set('sisters', status(identity));
  }

  const offFound = identity.kind === 'found' ? identity : null;
  // The photos' text loads while the names, Árfigyelő and UPCitemdb answer.
  const packP = packFor(offFound, key, signal);
  const [ar, names] = await Promise.all([arP, namesFor(identity, signal)]);
  if (signal?.aborted) return { kind: 'aborted' };

  let upc: UpcLookup | null = null;
  // Found but unnamed (a Coca-Cola can nobody named): UPCitemdb may know its name.
  const named = offFound ? hasTitle(offFound.product) : false;
  if (!named && ar.kind !== 'found') {
    set('upcitemdb', 'checking');
    upc = await fetchUpc(key, signal);
    if (signal?.aborted) return { kind: 'aborted' };
    set('upcitemdb', status(upc));
  } else {
    set('upcitemdb', 'skipped');
  }
  const pack = await packP;
  if (signal?.aborted) return { kind: 'aborted' };

  const product = buildProduct({
    key,
    off: offFound,
    ar: ar.kind === 'found' ? ar.product : null,
    upc: upc?.kind === 'found' ? upc.item : null,
    names,
    pack,
  });
  if (!product) {
    const unreachable = (Object.keys(progress) as SourceKey[]).filter((k) => progress[k] === 'error');
    return { kind: 'not_found', key, progress: { ...progress }, unreachable };
  }
  putProduct(product);
  return { kind: 'found', product, progress: { ...progress }, cached: false };
}

const pricing = new Map<string, Promise<void>>();

/** Fetch both price sources again (the product screen calls it when they are older than an hour). */
export function refreshPrices(key: string, signal?: AbortSignal): Promise<void> {
  const running = pricing.get(key);
  if (running) return running;
  const job = Promise.all([
    tracked(key, 'arfigyelo', () => fetchArfigyelo(key, signal)).then((ar) => putPrices(key, { arfigyelo: arPrices(ar) })),
    tracked(key, 'openPrices', () => fetchOpenPrices(key, signal)).then((op) => putPrices(key, { openPrices: opPrices(op) })),
  ])
    .then(() => undefined)
    .finally(() => pricing.delete(key));
  pricing.set(key, job);
  return job;
}

/** Only the Árfigyelő price (for alternatives), unless it is fresh already. */
export async function ensureChainPrices(keys: string[], signal?: AbortSignal): Promise<void> {
  await Promise.all(
    keys
      .filter((k) => !pricesFresh(k).arfigyelo)
      .filter((k) => !pricePending(k, 'arfigyelo'))
      .map(async (k) => {
        const r = await tracked(k, 'arfigyelo', () => fetchArfigyelo(k, signal));
        putPrices(k, { arfigyelo: arPrices(r) });
      }),
  );
}
