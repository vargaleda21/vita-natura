// Real products and prices, kept in memory for synchronous reads (getProduct, history, insights) and
// persisted to the device: identity for about 7 days, prices for about an hour. Stale data is still
// shown (and refreshed in the background), so a reload never loses a product from the history.

import type { Product, RealPrices } from '../types';
import { lookupConfig } from './http';

export const IDENTITY_TTL = 7 * 24 * 3600_000;
export const PRICES_TTL = 3600_000;
const MAX_PRODUCTS = 150;
// v2: names in other Latin languages, unnamed products under their category (2026-10-24).
// v3: names and ingredients read off the photos when nobody typed them (2026-10-24).
const PREFIX_P = 'daleday.lookup.v3.p:';
/** Products saved by older versions: moved over as stale, so the history keeps them and a new scan fetches them again. */
const OLD_P = ['daleday.lookup.v2.p:', 'daleday.lookup.v1.p:'];
const isOld = (k: string) => OLD_P.some((p) => k.startsWith(p));
const PREFIX_$ = 'daleday.lookup.v1.$:';

type Stamped<T> = { at: number; v: T };

const products = new Map<string, Stamped<Product>>();
const prices = new Map<string, Stamped<RealPrices>>();
const listeners = new Set<() => void>();
let version = 0;

function emit() {
  version += 1;
  for (const l of listeners) l();
}

export function subscribeLookup(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/** Changes whenever a product or a price arrives: a snapshot for useSyncExternalStore. */
export function lookupVersion(): number {
  return version;
}

function persist(key: string, value: unknown) {
  const s = lookupConfig().storage;
  if (!s) return;
  void s.setItem(key, JSON.stringify(value)).catch(() => undefined);
}

function forget(key: string) {
  const s = lookupConfig().storage;
  if (!s) return;
  void s.removeItem(key).catch(() => undefined);
}

export function realProduct(ean: string): Product | undefined {
  return products.get(ean)?.v;
}

export function productAge(ean: string): number {
  const e = products.get(ean);
  return e ? Date.now() - e.at : Infinity;
}

export function putProduct(product: Product, opts: { persist?: boolean } = {}): void {
  const existing = products.get(product.ean)?.v;
  // A light search-result copy never replaces a full product.
  if (product.real?.preview && existing && !existing.real?.preview) return;
  products.set(product.ean, { at: Date.now(), v: product });
  if (opts.persist !== false && !product.real?.preview) {
    persist(PREFIX_P + product.ean, products.get(product.ean));
    evict();
  }
  emit();
}

/** Light copies from a search (alternatives): kept in memory only, so a tap can open them at once. */
export function putPreviews(list: Product[]): void {
  let changed = false;
  for (const p of list) {
    const existing = products.get(p.ean)?.v;
    if (existing) continue;
    products.set(p.ean, { at: Date.now(), v: p });
    changed = true;
  }
  if (changed) emit();
}

function evict() {
  const full = [...products.entries()].filter(([, e]) => !e.v.real?.preview);
  if (full.length <= MAX_PRODUCTS) return;
  full.sort((a, b) => a[1].at - b[1].at);
  for (const [ean] of full.slice(0, full.length - MAX_PRODUCTS)) {
    products.delete(ean);
    prices.delete(ean);
    forget(PREFIX_P + ean);
    forget(PREFIX_$ + ean);
  }
}

export function realPrices(ean: string): RealPrices | undefined {
  return prices.get(ean)?.v;
}

/** Merge new price data in. A part that failed to load (undefined) keeps the older value. */
export function putPrices(ean: string, patch: RealPrices): void {
  const old = prices.get(ean)?.v ?? {};
  const next: RealPrices = { ...old };
  if (patch.arfigyelo !== undefined) {
    next.arfigyelo = patch.arfigyelo;
    next.arfigyeloAt = patch.arfigyeloAt ?? Date.now();
  }
  if (patch.openPrices !== undefined) {
    next.openPrices = patch.openPrices;
    next.openPricesAt = patch.openPricesAt ?? Date.now();
  }
  const stamped = { at: Date.now(), v: next };
  prices.set(ean, stamped);
  if (products.has(ean) && !products.get(ean)?.v.real?.preview) persist(PREFIX_$ + ean, stamped);
  emit();
}

export type PricePart = 'arfigyelo' | 'openPrices';

const pending = new Set<string>();

/** Marks a price source as loading for a product, so the screen can tell "loading" from "no answer". */
export function setPricePending(ean: string, part: PricePart, on: boolean): void {
  const k = `${ean}|${part}`;
  if (on === pending.has(k)) return;
  if (on) pending.add(k);
  else pending.delete(k);
  emit();
}

export function pricePending(ean: string, part: PricePart): boolean {
  return pending.has(`${ean}|${part}`);
}

const ended = new Set<string>();

/** Marks a full lookup for a code as running or ended, so a preview on screen can tell "its prices are
 *  coming" from "the lookup that would bring them has ended" (it failed, or found nothing more). */
export function setLookupRunning(ean: string, on: boolean): void {
  if (on !== ended.has(ean)) return;
  if (on) ended.delete(ean);
  else ended.add(ean);
  emit();
}

export function lookupEnded(ean: string): boolean {
  return ended.has(ean);
}

export function pricesFresh(ean: string): { arfigyelo: boolean; openPrices: boolean } {
  const p = prices.get(ean)?.v;
  const now = Date.now();
  return {
    arfigyelo: p?.arfigyelo !== undefined && now - (p.arfigyeloAt ?? 0) < PRICES_TTL,
    openPrices: p?.openPrices !== undefined && now - (p.openPricesAt ?? 0) < PRICES_TTL,
  };
}

let hydrated: Promise<void> | null = null;

/** Load everything saved on the device into memory. Call once at start-up, before the first screen. */
export function hydrateLookupCache(): Promise<void> {
  hydrated ??= (async () => {
    const s = lookupConfig().storage;
    if (!s?.getAllKeys) return;
    try {
      const keys = (await s.getAllKeys()).filter((k) => k.startsWith(PREFIX_P) || k.startsWith(PREFIX_$) || isOld(k));
      const old: Product[] = [];
      const pairs = s.multiGet ? await s.multiGet(keys) : await Promise.all(keys.map(async (k) => [k, await s.getItem(k)] as const));
      for (const [k, raw] of pairs) {
        if (!raw) continue;
        try {
          const e = JSON.parse(raw) as Stamped<unknown>;
          if (typeof e?.at !== 'number' || !e.v) continue;
          if (k.startsWith(PREFIX_P)) {
            const p = e.v as Product;
            if (p.ean && p.real) products.set(p.ean, { at: e.at, v: p });
          } else if (isOld(k)) {
            const p = e.v as Product;
            if (p.ean && p.real) old.push(p);
          } else {
            prices.set(k.slice(PREFIX_$.length), e as Stamped<RealPrices>);
          }
        } catch {
          // A broken entry is skipped.
        }
      }
      for (const p of old) {
        if (products.has(p.ean)) continue;
        products.set(p.ean, { at: 0, v: p });
        persist(PREFIX_P + p.ean, products.get(p.ean));
      }
      for (const k of keys) if (isOld(k)) forget(k);
    } catch {
      // No storage: start empty.
    }
    emit();
  })();
  return hydrated;
}
