import { evaluate, getProduct } from './api';
import type { ScanEntry, Settings } from './types';

// The past a first visit starts with: 36 scans over the last three weeks, mostly in the
// afternoon shop run, a six-day streak that ends today, and eight swaps that saved money and sugar.
// Verdicts are computed with the default settings (palm oil + added sugar), as at scan time.

const DEMO_SETTINGS: Settings = { lang: 'hu', theme: 'system', avoid: ['palm_oil', 'added_sugar'], members: [], onboarded: true };

/** [days ago, hour, minute, code, swapped to]. For today, hour/minute mean "this many minutes ago". */
type Row = [number, number, number, string, string?];

const ROWS: Row[] = [
  [0, 0, 25, '2033610001288'],
  [0, 3, 10, '2055400000165', '2066120000489'],
  [1, 18, 40, '2045120001146', '2045120001078'],
  [1, 18, 32, '2077050000135'],
  [1, 12, 15, '2029180000547'],
  [2, 17, 55, '2000000000015', '2000000000022'],
  [2, 17, 48, '2066120000311'],
  [3, 19, 20, '2017330000257'],
  [3, 19, 12, '2091400000644'],
  [3, 11, 5, '2088230000593'],
  [3, 10, 58, '2011880000415'],
  [4, 8, 40, '2000000000046'],
  [5, 16, 30, '2000000000039', '2000000000046'],
  [5, 16, 22, '2033610001356'],
  [5, 16, 20, '2055400000233'],
  [7, 13, 10, '2041900000361'],
  [7, 13, 2, '2029180000479', '2029180000547'],
  [8, 18, 5, '2022450000155', '2011880000415'],
  [8, 17, 58, '2011880000583'],
  [8, 9, 20, '2045120001078'],
  [10, 7, 50, '2091400000712'],
  [10, 7, 45, '2077050000203', '2091400000712'],
  [11, 19, 30, '2022450000223', '2017330000325'],
  [11, 19, 25, '2017330000325'],
  [11, 12, 40, '2000000000022'],
  [13, 15, 15, '2066120000489'],
  [13, 15, 10, '2055400000165'],
  [14, 10, 30, '2045120001146'],
  [16, 17, 40, '2033610001288'],
  [16, 17, 35, '2000000000015'],
  [16, 17, 31, '2029180000479'],
  [18, 12, 0, '2088230000593'],
  [18, 11, 52, '2041900000361'],
  [20, 18, 20, '2000000000046'],
  [20, 18, 14, '2017330000257'],
  [20, 18, 10, '2033610001356'],
];

/** The history a first visit starts with, relative to now and newest first. */
export function demoHistory(now: Date = new Date()): ScanEntry[] {
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const entries: ScanEntry[] = [];
  for (const [daysAgo, h, m, ean, swappedTo] of ROWS) {
    const product = getProduct(ean);
    if (!product) continue;
    let at: Date;
    if (daysAgo === 0) {
      // Earlier today, but never before midnight, so the streak still counts today.
      const t = now.getTime() - (h * 60 + m) * 60_000;
      at = new Date(Math.max(t, startOfToday.getTime() + (h * 60 + m) * 1000));
    } else {
      at = new Date(now.getFullYear(), now.getMonth(), now.getDate() - daysAgo, h, m);
    }
    const { verdict, score } = evaluate(product, DEMO_SETTINGS);
    const entry: ScanEntry = { ean, at: at.toISOString(), verdict, score };
    if (swappedTo) {
      entry.swapped = true;
      entry.swappedTo = swappedTo;
    }
    entries.push(entry);
  }
  return entries.sort((a, b) => b.at.localeCompare(a.at));
}
