// The data contract every screen builds on. Add fields if you need them; never rename or remove one.
// All products, brands, stores and prices in this demo are fictional.

export type Lang = 'hu' | 'en';
export type L10n = { hu: string; en: string };

/** Things a person can choose to avoid. */
export type AvoidKey =
  | 'palm_oil'
  | 'added_sugar'
  | 'sweeteners'
  | 'additives'
  | 'nitrites'
  | 'artificial_colors'
  | 'ultra_processed'
  | 'high_salt'
  | 'lactose'
  | 'gluten'
  | 'nuts'
  | 'egg'
  | 'soy'
  | 'caffeine';

export type CriterionGroup = 'diet' | 'additive' | 'allergy' | 'planet';

export type Criterion = {
  key: AvoidKey;
  group: CriterionGroup;
  label: L10n;
  /** One calm sentence: what it is and why someone may avoid it. No fear words. */
  short: L10n;
  /** Lucide icon name in kebab-case, e.g. 'candy', 'wheat-off'. */
  icon: string;
  /** Where the explanation comes from. */
  source: { name: string; url?: string };
};

export type Ingredient = {
  name: L10n;
  /** The criteria this ingredient triggers. */
  flags?: AvoidKey[];
  eNumber?: string;
  percent?: number;
  /** The parts of a compound ingredient, e.g. margarine (palm oil, water, …). Real products only. */
  sub?: Ingredient[];
};

/** Per 100 g or 100 ml. A missing value is unknown (real products), never zero. */
export type Nutrition = {
  energyKcal?: number;
  sugarG?: number;
  satFatG?: number;
  saltG?: number;
  fiberG?: number;
  proteinG?: number;
};

export type PackShape = 'jar' | 'box' | 'bottle' | 'bar' | 'bag' | 'cup' | 'can' | 'tub';

/** How the pack is drawn: we never show real brand photos. */
export type PackArt = { colors: [string, string]; emoji: string; shape: PackShape };

export type CategoryKey =
  | 'spreads'
  | 'breakfast'
  | 'snacks'
  | 'sweets'
  | 'dairy'
  | 'drinks'
  | 'meat'
  | 'bakery'
  | 'ready_meals'
  /** Real products we cannot place in a food shelf (or that are not food at all). */
  | 'other';

export type StoreKey = 'sarok' | 'megapiac' | 'zoldkosar' | 'napfeny' | 'kosarka';

export type Store = { key: StoreKey; name: string; color: string; online?: boolean };

/** A shelf price, as the GVH Árfigyelő would report it (mocked here). */
export type StorePrice = { store: StoreKey; priceHuf: number; promo?: boolean };

export type RecipeChangeKind = 'size_down' | 'recipe_worse' | 'recipe_better' | 'price_up';

export type RecipeChange = {
  /** ISO date. */
  date: string;
  kind: RecipeChangeKind;
  text: L10n;
  /** Before and after, when they read the same in both languages: a pack size ("450 g" → "400 g"). */
  before?: string;
  after?: string;
  /** Before and after in each language, for words, decimals and prices ("napraforgóolaj" / "sunflower oil").
   *  Shown instead of `before`/`after` when set. */
  values?: { before: L10n; after: L10n };
};

export type DualQuality = {
  country: 'AT' | 'DE' | 'SK' | 'CZ';
  verdict: 'same' | 'different' | 'worse_here' | 'better_here';
  diffs: L10n[];
};

export type Product = {
  ean: string;
  name: L10n;
  brand: string;
  category: CategoryKey;
  /** e.g. "400 g". */
  size: string;
  art: PackArt;
  ingredients: Ingredient[];
  nutrition: Nutrition;
  /** NOVA processing group: 4 = ultra-processed. Unknown for some real products. */
  nova?: 1 | 2 | 3 | 4;
  prices: StorePrice[];
  history?: RecipeChange[];
  dualQuality?: DualQuality;
  /** A shop that pays a commission. NEVER changes the ranking. */
  affiliate?: { store: StoreKey; url: string };
  /** Where the data came from and when it was last checked (ISO date). */
  dataSource: { kind: 'community' | 'brand' | 'ai_label' | 'open_data'; updated: string };
  /** Short positive notes, e.g. "high fibre". */
  positives?: L10n[];
  /** Findings not tied to one ingredient: a declared allergen, a "may contain" trace, an additive tag. */
  flags?: ProductFlag[];
  /** Set only for products looked up in real open databases by their barcode. */
  real?: RealData;
};

export type ProductFlag = {
  key: AvoidKey;
  /** What the source said, e.g. "tojás" (an allergen) or "E322 – lecitinek" (an additive). */
  reason: L10n;
  /** "May contain": a trace, not an ingredient. */
  trace?: boolean;
};

// ── Real products ──────────────────────────────────────────────────────────
// Looked up by barcode in open sources. Nothing here is invented: what no source knows stays unset.

export type RealSource = 'off' | 'obf' | 'opf' | 'opff' | 'arfigyelo' | 'open_prices' | 'upcitemdb';

export type RealData = {
  /** What kind of product the sources say it is. */
  kind: 'food' | 'beauty' | 'product' | 'petfood' | 'unknown';
  /** The identity sources that answered, in the order we trust them. */
  sources: RealSource[];
  imageUrl?: string;
  imageSmallUrl?: string;
  nutriscore?: 'a' | 'b' | 'c' | 'd' | 'e';
  labels: L10n[];
  /** Countries where Open Food Facts contributors saw it on sale. */
  countries: { iso2?: string; name: L10n }[];
  /** Shops named on Open Food Facts (free text, as entered). */
  stores: string[];
  /** Every declared allergen, also the ones that are not avoid criteria (e.g. sesame). */
  allergens: L10n[];
  /** "May contain" traces. */
  traces: L10n[];
  /** False when no source lists the ingredients: then nothing ingredient-based is judged. */
  ingredientsKnown: boolean;
  /** Open Food Facts category tags, most general first, and the one it compares the product with. */
  categoryTags: string[];
  comparedTo?: string;
  /** Where the barcode was registered (GS1 prefix). Not where it was made. */
  gs1: { kind: 'country'; iso2?: string; country: L10n } | { kind: 'instore' | 'coupon' | 'book' | 'unknown' };
  /** When the main source last changed the product (ISO date). */
  updated?: string;
  /** When we fetched it (ISO date-time). */
  fetchedAt: string;
  /** The product's page on Open Food Facts (or a sister database). */
  sourceUrl?: string;
  /** A short description, from UPCitemdb, for non-food products. */
  description?: string;
  /** A lightweight copy from a search result: open it to load everything. */
  preview?: boolean;
  /** Why the title is not a name someone typed: nobody entered one, only in another script, or it was
   *  read off the front photo by machine ('photo'). */
  nameNote?: 'missing' | 'foreign_script' | 'photo';
  /** The name in another script, as the database has it. */
  nameOriginal?: string;
  /** The title shown is the product's category (else a plain "Unnamed product"). */
  nameIsCategory?: boolean;
  /** Set when nobody typed the ingredients and they were read off this photo of the pack by machine. */
  ingredientsPhoto?: string;
};

/** One chain's price in the GVH Árfigyelő (official prices reported by the chains). */
export type ChainPrice = {
  chain: string;
  /** The lowest current price, in HUF. */
  priceHuf: number;
  /** The regular price when the lowest one is a discount. */
  regularHuf?: number;
  discounted: boolean;
  /** The highest price when shops differ. */
  maxHuf?: number;
  sameEverywhere: boolean;
  /** How many of the chain's shops list it. */
  shops: number;
  /** Price per unit (kg, l …), when the pack is not exactly one unit. */
  unitPriceHuf?: number;
  unit?: string;
};

/** One price someone photographed and shared on Open Prices. */
export type PriceSighting = {
  price: number;
  currency: string;
  /** ISO date. */
  date: string;
  discounted: boolean;
  shop?: string;
  city?: string;
  country?: string;
  iso2?: string;
};

export type RealPrices = {
  /** undefined: not checked or the source did not answer; null: checked, not listed. */
  arfigyelo?: { chains: ChainPrice[]; name?: string } | null;
  openPrices?: PriceSighting[] | null;
  /** When each part was fetched (epoch ms). */
  arfigyeloAt?: number;
  openPricesAt?: number;
};

export type Verdict = 'great' | 'okay' | 'avoid';

export type Member = {
  id: string;
  name: string;
  /** One emoji. */
  avatar: string;
  color: string;
  avoid: AvoidKey[];
};

/** 'auto' follows the time of day (dark 19:00–07:00); 'system' follows the phone. */
export type ThemePref = 'auto' | 'system' | 'light' | 'dark';

export type Settings = {
  lang: Lang;
  theme: ThemePref;
  /** The phone owner's own avoid list. */
  avoid: AvoidKey[];
  /** Family members checked on every scan. */
  members: Member[];
  onboarded: boolean;
  /** The owner's own display name, if given. */
  name?: string;
};

export type Hit = {
  key: AvoidKey;
  /** The ingredients that triggered it. */
  ingredients: L10n[];
  /** 'me' for the phone owner, else member ids. */
  who: string[];
  /** Only a "may contain" trace, not an ingredient. */
  trace?: boolean;
};

export type MatchResult = {
  verdict: Verdict;
  /** 0–100, higher is better for YOU. */
  score: number;
  hits: Hit[];
  /** Criteria the product passes, out of `total` checked. */
  matched: number;
  total: number;
  positives: L10n[];
  /** Criteria we could not check, because no source knows that part (real products). */
  unknown?: AvoidKey[];
};

export type Alternative = {
  product: Product;
  result: MatchResult;
  /** The store where both are sold and this one is cheaper, if any. */
  sameStore?: StoreKey;
  /** Positive = cheaper than the scanned product there. */
  savingHuf?: number;
  reason: L10n;
  /** Real products: the lowest GVH Árfigyelő price, and the saving in a chain that sells both. */
  chainPrice?: { chain: string; priceHuf: number };
  chainSaving?: { chain: string; savingHuf: number };
};

export type ScanEntry = {
  ean: string;
  at: string;
  verdict: Verdict;
  score: number;
  swapped?: boolean;
  /** The alternative that was picked instead, if known. Without it, the best alternative is assumed. */
  swappedTo?: string;
};

export type Insights = {
  scans: number;
  avoided: number;
  swaps: number;
  savedHuf: number;
  topHit: AvoidKey | null;
  /** Teaspoons of added sugar skipped by swaps (4 g each). */
  sugarSpoons: number;
  /** 0–1. */
  palmFreeShare: number;
  streakDays: number;
  byVerdict: Record<Verdict, number>;
  /** Scans per day for the last 7 days, oldest first. */
  weekly: number[];
  /** Every criterion that came up, most frequent first. */
  topHits?: { key: AvoidKey; count: number }[];
  /** The swap that did the most good (product codes). */
  bestSwap?: { from: string; to: string; savedHuf: number; sugarSpoons: number };
};
