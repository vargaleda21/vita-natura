import type { Store } from './types';

/** Fictional chains. The real product would read the GVH Árfigyelő's daily prices. */
export const STORES: Store[] = [
  { key: 'sarok', name: 'Sarokbolt', color: '#FF8A3D' },
  { key: 'megapiac', name: 'MegaPiac', color: '#7FD3FF' },
  { key: 'zoldkosar', name: 'Zöldkosár', color: '#2FCB74' },
  { key: 'napfeny', name: 'Napfény ABC', color: '#FFC93D' },
  { key: 'kosarka', name: 'Kosárka online', color: '#B9A4FF', online: true },
];
