// Every feature keeps its own strings file: `export const strings = { hu: {...}, en: {...} }`.
// Hungarian copy says "AI", never "MI".

import type { L10n, Lang } from '@/data/types';
import { useSettings } from '@/state/store';

export function useLang(): Lang {
  return useSettings().lang;
}

/** Pick a feature's dictionary for the current language. */
export function useT<T>(dict: { hu: T; en: T }): T {
  return dict[useLang()];
}

/** Translate a data value. */
export function tr(value: L10n, lang: Lang): string {
  return value[lang];
}

export function useTr(): (value: L10n) => string {
  const lang = useLang();
  return (value) => value[lang];
}

const NBSP = ' ';

/** Group thousands by hand: CLDR leaves 4-digit Hungarian numbers ungrouped ("1220"), we want "1 220". */
export function groupDigits(n: number, sep: string): string {
  const r = Math.round(n);
  const s = Math.abs(r).toString().replace(/\B(?=(\d{3})+(?!\d))/g, sep);
  return r < 0 ? `−${s}` : s;
}

/** "1 220 Ft" in Hungarian, "HUF 1,220" in English. No-break spaces, so a price never splits. */
export function formatHuf(n: number, lang: Lang): string {
  return lang === 'hu' ? `${groupDigits(n, NBSP)}${NBSP}Ft` : `HUF${NBSP}${groupDigits(n, ',')}`;
}
