// Expo's ambient types (CSS imports, assets), also in a fresh copy: expo-env.d.ts says the same,
// but it is gitignored and only appears after the first `npx expo start`.
/// <reference types="expo/types" />
