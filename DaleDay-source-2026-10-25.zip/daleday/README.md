# DaleDay — Tudd, mi van benne.

A demo of Léda's idea: scan a product's barcode in the shop and see at once whether it suits what *you*
chose to avoid (palm oil, added sugar, allergens …), with a better and often cheaper alternative from the
same shop. React Native (Expo SDK 58) with a web-first build. No backend and no login. Two modes: fictional demo
products that show the full idea, and a live lookup of any real barcode in open databases (Open Food Facts,
GVH Árfigyelő, Open Prices, UPCitemdb).

**New here (or Claude Code)? Read [HANDOFF.md](HANDOFF.md) first:** what was built, where things are, the
rules, the known limits and the next steps.

Live (temporary): https://daleday.digital1.one

## What it shows

- A personal verdict, not a global "bad product" score: "fits your settings: 3/4".
- One scan checks the whole family (a child's milk allergy, grandma's sugar).
- Better and cheaper in the same shop (for real barcodes: the GVH Árfigyelő daily prices).
- Dual quality: the same brand with a different recipe in Austria or Germany.
- Recipe history: "got smaller, same price", "palm oil replaced sunflower oil".
- An unknown barcode → photograph the label → AI reads the ingredients (mocked).
- A monthly, Wrapped-style story of your basket.
- Honest money: partner shops may pay a commission, and that never changes the ranking.
- Hungarian and English; an automatic day/night theme.

## Commands

```bash
npm install
npx expo start             # dev server (web: press w)
npx tsc --noEmit           # typecheck
node scripts/build-web.mjs # web build into dist/ with the phone/PWA head tags
scripts/deploy.sh          # build and deploy to daleday.digital1.one (needs DEPLOY_HOST and DEPLOY_KEY)
```

Checks: `node tools/serve.mjs dist 8787` (with the API proxies; `CSP=1` sends the production CSP) and
`node tools/shot.mjs <path> <out.png>` for a 390×844 phone screenshot with console errors.

The build brief for contributors and agents is [docs/BRIEF.md](docs/BRIEF.md).
