// Renders the DaleDay mark into every icon the app and the web build need: node tools/make-icons.mjs
// The mark comes from src/features/brand/geometry.ts (Node strips the types), so the icons always match the app.
// Every PNG is re-encoded bare (only IHDR, IDAT and IEND): iOS ignores icons with some ancillary chunks.
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { deflateSync, inflateSync } from 'node:zlib';

import { chromium } from 'playwright-core';

process.removeAllListeners('warning'); // Node notes that the .ts file is parsed as an ES module; that is fine.
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const { BRAND, markSvg } = await import(join(root, 'src/features/brand/geometry.ts'));

// ——— PNG: decode Chromium's output, encode a bare RGB or RGBA file ————————————————————

const SIG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

function chunks(buf) {
  const out = [];
  let o = 8;
  while (o < buf.length) {
    const len = buf.readUInt32BE(o);
    out.push({ type: buf.toString('latin1', o + 4, o + 8), data: buf.subarray(o + 8, o + 8 + len) });
    o += 12 + len;
  }
  return out;
}

function decode(buf) {
  const cs = chunks(buf);
  const ihdr = cs.find((c) => c.type === 'IHDR').data;
  const w = ihdr.readUInt32BE(0);
  const h = ihdr.readUInt32BE(4);
  const depth = ihdr[8];
  const ctype = ihdr[9];
  if (depth !== 8 || (ctype !== 2 && ctype !== 6) || ihdr[12] !== 0) throw new Error(`unexpected PNG: depth ${depth} type ${ctype}`);
  const bpp = ctype === 6 ? 4 : 3;
  const raw = inflateSync(Buffer.concat(cs.filter((c) => c.type === 'IDAT').map((c) => c.data)));
  const stride = w * bpp;
  const px = Buffer.alloc(w * h * 4);
  let prev = Buffer.alloc(stride);
  for (let y = 0; y < h; y++) {
    const f = raw[y * (stride + 1)];
    const line = Buffer.from(raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1)));
    for (let i = 0; i < stride; i++) {
      const a = i >= bpp ? line[i - bpp] : 0;
      const b = prev[i];
      const c = i >= bpp ? prev[i - bpp] : 0;
      let add = 0;
      if (f === 1) add = a;
      else if (f === 2) add = b;
      else if (f === 3) add = (a + b) >> 1;
      else if (f === 4) {
        const p = a + b - c;
        const pa = Math.abs(p - a);
        const pb = Math.abs(p - b);
        const pc = Math.abs(p - c);
        add = pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
      }
      line[i] = (line[i] + add) & 0xff;
    }
    for (let x = 0; x < w; x++) {
      const s = x * bpp;
      const d = (y * w + x) * 4;
      px[d] = line[s];
      px[d + 1] = line[s + 1];
      px[d + 2] = line[s + 2];
      px[d + 3] = bpp === 4 ? line[s + 3] : 255;
    }
    prev = line;
  }
  return { w, h, px };
}

const CRC_TABLE = Array.from({ length: 256 }, (_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
function crc32(buf) {
  let c = 0xffffffff;
  for (const b of buf) c = CRC_TABLE[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, 'latin1'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}

/** A bare PNG: IHDR, one IDAT, IEND. `opaque` drops the alpha channel (RGB), as iOS wants for touch icons. */
function encode({ w, h, px }, opaque) {
  const bpp = opaque ? 3 : 4;
  const raw = Buffer.alloc(h * (w * bpp + 1));
  let o = 0;
  for (let y = 0; y < h; y++) {
    raw[o++] = 0;
    for (let x = 0; x < w; x++) {
      const s = (y * w + x) * 4;
      raw[o++] = px[s];
      raw[o++] = px[s + 1];
      raw[o++] = px[s + 2];
      if (!opaque) raw[o++] = px[s + 3];
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;
  ihdr[9] = opaque ? 2 : 6;
  return Buffer.concat([SIG, chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

// ——— Artwork ——————————————————————————————————————————————————————————————————————

const { ink, forest, lime, oat } = BRAND;

/** The mark, `scale` of the canvas wide, centred; optional background (a colour or 'glow'). */
function iconSvg(size, { scale, bg, color = lime, radius = 0, small = false }) {
  const m = size * scale;
  const off = (size - m) / 2;
  const glow =
    bg === 'glow'
      ? `<defs><radialGradient id="g" cx="50%" cy="38%" r="70%"><stop offset="0" stop-color="${forest}"/><stop offset="0.55" stop-color="#15322A"/><stop offset="1" stop-color="${ink}"/></radialGradient></defs>`
      : '';
  const fill = bg === 'glow' ? 'url(#g)' : bg;
  const back = bg ? `<rect width="${size}" height="${size}" rx="${radius * size}" fill="${fill}"/>` : '';
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${glow}${back}<g transform="translate(${off} ${off}) scale(${m / 100})">${markSvg(color, small)}</g></svg>`;
}

const fontFace = (family, weight, file) =>
  `@font-face{font-family:'${family}';font-weight:${weight};src:url(data:font/ttf;base64,${readFileSync(join(root, 'node_modules/@expo-google-fonts', file)).toString('base64')}) format('truetype');}`;

function ogHtml() {
  const fonts =
    fontFace('Bricolage', 800, 'bricolage-grotesque/800ExtraBold/BricolageGrotesque_800ExtraBold.ttf') +
    fontFace('Inter', 500, 'inter/500Medium/Inter_500Medium.ttf') +
    fontFace('Inter', 700, 'inter/700Bold/Inter_700Bold.ttf');
  const pack = ({ x, y, w, h, r, c1, c2, emoji, lid, rot, label, pill, pillBg }) => `
    <div style="position:absolute;left:${x}px;top:${y}px;width:${w}px;transform:rotate(${rot}deg)">
      ${lid ? `<div style="margin:0 auto -4px;width:${w * 0.84}px;height:${h * 0.11}px;border-radius:${h * 0.05}px ${h * 0.05}px 6px 6px;background:${c1};filter:brightness(0.92)"></div>` : ''}
      <div style="position:relative;height:${h}px;border-radius:${r}px;background:linear-gradient(160deg,${c2},${c1});box-shadow:0 22px 40px rgba(16,35,28,.18), inset 0 2px 0 rgba(255,255,255,.35), inset -10px -14px 30px rgba(0,0,0,.10);overflow:hidden;display:flex;align-items:center;justify-content:center">
        <div style="position:absolute;left:14%;top:0;bottom:0;width:12%;background:rgba(255,255,255,.24)"></div>
        <div style="width:72%;padding:10px 0;border-radius:14px;background:rgba(255,255,255,.88);text-align:center;font:700 15px Inter;color:${ink}">
          <div style="font-size:40px;line-height:46px">${emoji}</div>${label}</div>
      </div>
      <div style="position:absolute;left:50%;bottom:-18px;transform:translateX(-50%);white-space:nowrap;padding:8px 14px;border-radius:999px;background:${pillBg};font:700 15px Inter;color:${ink};box-shadow:0 8px 18px rgba(16,35,28,.16)">${pill}</div>
    </div>`;
  return `<!doctype html><html><head><meta charset="utf-8"><style>${fonts}
    *{box-sizing:border-box;margin:0}
    body{width:1200px;height:630px;overflow:hidden;background:${oat};position:relative;font-family:Inter}
    .aur{position:absolute;inset:0;background:
      radial-gradient(520px 420px at 1010px 120px, rgba(198,243,107,.85), rgba(198,243,107,0) 70%),
      radial-gradient(520px 460px at 760px 560px, rgba(123,224,181,.55), rgba(123,224,181,0) 70%),
      radial-gradient(420px 380px at 1180px 560px, rgba(127,211,255,.55), rgba(127,211,255,0) 70%),
      radial-gradient(480px 360px at 60px 40px, rgba(255,201,61,.28), rgba(255,201,61,0) 70%);}
  </style></head><body>
    <div class="aur"></div>
    <div style="position:absolute;left:84px;top:78px;display:flex;align-items:center;gap:20px">
      ${iconSvg(92, { scale: 0.84, bg: ink, radius: 0.28 })}
      <div style="font:800 76px/1 Bricolage;letter-spacing:-3.4px;color:${ink};margin-top:6px">DaleDay</div>
    </div>
    <div style="position:absolute;left:84px;top:236px;width:560px;font:800 86px/0.98 Bricolage;letter-spacing:-3px;color:${ink}">Tudd, mi van benne.</div>
    <div style="position:absolute;left:86px;top:452px;width:500px;font:500 27px/1.35 Inter;color:#55675F">Szkenneld be a vonalkódot, és megmutatja, illik-e hozzád.</div>
    <div style="position:absolute;left:650px;top:0;width:550px;height:630px">
      <div style="position:absolute;left:24px;right:24px;top:452px;height:18px;border-radius:9px;background:rgba(16,35,28,.08)"></div>
      ${pack({ x: 40, y: 236, w: 150, h: 200, r: 40, c1: '#C98B5A', c2: '#F0C08E', emoji: '🌰', lid: true, rot: -5, label: 'Krém', pill: 'Keress mást', pillBg: '#F2555A' })}
      ${pack({ x: 206, y: 150, w: 156, h: 290, r: 18, c1: '#E0A040', c2: '#FFE08A', emoji: '🥣', lid: false, rot: 2, label: 'Müzli', pill: 'Elmegy · 3/4', pillBg: '#F5B92E' })}
      ${pack({ x: 380, y: 196, w: 128, h: 240, r: 46, c1: '#4E9A6B', c2: '#A7E3B9', emoji: '🥛', lid: true, rot: 4, label: 'Zabital', pill: 'Neked való · 4/4', pillBg: '#2FCB74' })}
      <div style="position:absolute;left:176px;top:214px;width:220px;height:92px;background:linear-gradient(180deg,rgba(198,243,107,0),rgba(198,243,107,.38));border-bottom:0"></div>
      <div style="position:absolute;left:166px;top:303px;width:240px;height:6px;border-radius:3px;background:${lime};box-shadow:0 0 0 2px rgba(198,243,107,.4), 0 0 24px 6px rgba(198,243,107,.7)"></div>
    </div>
  </body></html>`;
}

// ——— Render ——————————————————————————————————————————————————————————————————————

const browser = await chromium.launch({ executablePath: '/snap/bin/chromium' });
const page = await browser.newPage({ deviceScaleFactor: 1 });

async function shoot(html, w, h, transparent) {
  await page.setViewportSize({ width: w, height: h });
  const doc = html.startsWith('<!doctype')
    ? html
    : `<!doctype html><html><head><style>*{margin:0}html,body{width:${w}px;height:${h}px;overflow:hidden;background:transparent}svg{display:block}</style></head><body>${html}</body></html>`;
  await page.setContent(doc);
  await page.evaluate(() => document.fonts.ready);
  return page.screenshot({ type: 'png', omitBackground: transparent, clip: { x: 0, y: 0, width: w, height: h } });
}

async function write(rel, html, size, { opaque = false, height } = {}) {
  const h = height ?? size;
  const shot = await shoot(html, size, h, !opaque);
  const out = encode(decode(shot), opaque);
  const file = join(root, rel);
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, out);
  const types = chunks(out).map((c) => c.type).join(',');
  console.log(`${rel.padEnd(46)} ${size}×${h} ${opaque ? 'RGB ' : 'RGBA'} ${types} ${(out.length / 1024).toFixed(1)} kB`);
}

// App (Expo) icons.
// Android's adaptive icon shows a 66/108 circle for sure; the mark (radius ≈ 0.53 of its box) sits inside it.
await write('assets/images/icon.png', iconSvg(1024, { scale: 0.7, bg: 'glow' }), 1024, { opaque: true });
await write('assets/images/favicon.png', iconSvg(48, { scale: 0.86, bg: ink, radius: 0.24, small: true }), 48);
await write('assets/images/splash-icon.png', iconSvg(512, { scale: 0.96 }), 512);
await write('assets/images/android-icon-foreground.png', iconSvg(1024, { scale: 0.56 }), 1024);
await write('assets/images/android-icon-background.png', iconSvg(1024, { scale: 0, bg: 'glow' }), 1024, { opaque: true });
await write('assets/images/android-icon-monochrome.png', iconSvg(1024, { scale: 0.56, color: '#FFFFFF' }), 1024);

// Web / PWA icons. Versioned names, so a changed icon is a new URL for every cache.
await write('public/icons/favicon-32.v1.png', iconSvg(32, { scale: 0.88, bg: ink, radius: 0.24, small: true }), 32);
await write('public/icons/apple-touch-icon.v1.png', iconSvg(180, { scale: 0.7, bg: 'glow' }), 180, { opaque: true });
await write('public/apple-touch-icon.png', iconSvg(180, { scale: 0.7, bg: 'glow' }), 180, { opaque: true });
await write('public/apple-touch-icon-precomposed.png', iconSvg(180, { scale: 0.7, bg: 'glow' }), 180, { opaque: true });
await write('public/icons/icon-192.v1.png', iconSvg(192, { scale: 0.72, bg: 'glow' }), 192, { opaque: true });
await write('public/icons/icon-512.v1.png', iconSvg(512, { scale: 0.72, bg: 'glow' }), 512, { opaque: true });
// Maskable: the safe zone is a circle of radius 0.4; the mark's radius at scale 0.7 is ≈ 0.37.
await write('public/icons/maskable-512.v1.png', iconSvg(512, { scale: 0.7, bg: 'glow' }), 512, { opaque: true });
await write('public/og.v2.png', ogHtml(), 1200, { opaque: true, height: 630 });

await browser.close();

// favicon.svg: the tile with the mark, crisp at any size.
writeFileSync(join(root, 'public/favicon.svg'), iconSvg(64, { scale: 0.86, bg: ink, radius: 0.24, small: true }).replace(/(\d+\.\d{3})\d+/g, '$1') + '\n');
console.log('public/favicon.svg');

const manifest = {
  name: 'DaleDay – Tudd, mi van benne',
  short_name: 'DaleDay',
  description: 'Szkenneld be egy termék vonalkódját, és a DaleDay megmutatja, illik-e hozzád. Te döntöd el, mit kerülsz.',
  id: '/',
  start_url: '/',
  scope: '/',
  display: 'standalone',
  orientation: 'portrait',
  lang: 'hu',
  background_color: '#F7F4EC',
  theme_color: '#10231C',
  icons: [
    { src: '/icons/icon-192.v1.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
    { src: '/icons/icon-512.v1.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
    { src: '/icons/maskable-512.v1.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
  ],
};
writeFileSync(join(root, 'public/manifest.webmanifest'), JSON.stringify(manifest, null, 2) + '\n');
console.log('public/manifest.webmanifest');
