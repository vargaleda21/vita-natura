// Look real barcodes up against the live open sources, from Node 22 (type stripping), and print
// what the app would show: node tools/lookup-test.mjs [codes…] [--proxy http://127.0.0.1:8792] [--no-eval]
// The Árfigyelő and UPCitemdb calls go through a DaleDay proxy: start one with
//   node tools/serve.mjs /tmp/empty 8792
// or pass --proxy https://daleday.digital1.one (that spends the server's UPCitemdb quota of 100 a day).
// Codes: the owner's test set when none are given.
import { existsSync } from 'node:fs';
import { registerHooks } from 'node:module';
import { dirname, join, resolve as resolvePath } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = resolvePath(dirname(fileURLToPath(import.meta.url)), '..');
const src = join(root, 'src');

const STUBS = {
  // The store persists through AsyncStorage; in Node it only needs to exist.
  '@react-native-async-storage/async-storage':
    'export default { getItem: async () => null, setItem: async () => {}, removeItem: async () => {}, getAllKeys: async () => [], multiGet: async () => [] };',
};

function withExtension(base) {
  for (const ext of ['', '.ts', '.tsx', '/index.ts']) {
    const f = base + ext;
    if (existsSync(f) && (ext !== '' || /\.[cm]?[jt]sx?$/.test(f))) return f;
  }
  return null;
}

registerHooks({
  resolve(specifier, context, next) {
    if (STUBS[specifier]) return { url: `data:text/javascript,${encodeURIComponent(STUBS[specifier])}`, shortCircuit: true, format: 'module' };
    if (specifier.startsWith('@/')) {
      const f = withExtension(join(src, specifier.slice(2)));
      if (f) return { url: pathToFileURL(f).href, shortCircuit: true };
    }
    if ((specifier.startsWith('./') || specifier.startsWith('../')) && context.parentURL?.startsWith('file:')) {
      const parent = fileURLToPath(context.parentURL);
      if (parent.startsWith(src)) {
        const f = withExtension(resolvePath(dirname(parent), specifier));
        if (f) return { url: pathToFileURL(f).href, shortCircuit: true };
      }
    }
    return next(specifier, context);
  },
});

const args = process.argv.slice(2);
const flag = (name) => args.includes(name);
const opt = (name, fallback) => {
  const i = args.indexOf(name);
  return i >= 0 ? args[i + 1] : fallback;
};
const proxy = opt('--proxy', 'http://127.0.0.1:8792');
const codes = args.filter((a, i) => /^\d{6,14}$/.test(a) && args[i - 1] !== '--proxy' && args[i - 1] !== '--find');

const L = await import(pathToFileURL(join(src, 'data/lookup/index.ts')).href);
L.configureLookup({ proxyBase: proxy });

function unknownCode() {
  // A valid EAN-13 (correct check digit) in the Hungarian range that no database should know.
  const body = '599987654321';
  return body + L.gs1CheckDigit(body);
}

const list = codes.length ? codes : ['8594071650292', '5998200557682', '0885909950805', unknownCode()];

let api = null;
if (!flag('--no-eval')) {
  try {
    api = await import(pathToFileURL(join(src, 'data/api.ts')).href);
  } catch (e) {
    console.log(`(no verdict: api.ts did not load in Node: ${e.message.split('\n')[0]})`);
  }
}
const SETTINGS = { avoid: ['palm_oil', 'added_sugar'], members: [], lang: 'hu', theme: 'light', onboarded: true };

const hu = (v) => (v && typeof v === 'object' ? v.hu : v);
const ingredientLine = (i) => `${hu(i.name)}${i.percent !== undefined ? ` ${i.percent}%` : ''}${i.flags?.length ? ` [${i.flags.join(',')}]` : ''}${i.sub?.length ? ` (${i.sub.map(ingredientLine).join(', ')})` : ''}`;

for (const code of list) {
  const t0 = Date.now();
  const marks = [];
  console.log(`\n━━ ${code} ━━`);
  const out = await L.lookupCode(code, {
    force: true,
    onProgress: (p) => marks.push(`${Date.now() - t0}ms ${Object.entries(p).map(([k, v]) => `${k}:${v}`).join(' ')}`),
  });
  for (const m of marks) console.log(`  · ${m}`);
  console.log(`  → ${out.kind} in ${Date.now() - t0} ms`);
  if (out.kind === 'not_found') {
    console.log(`  unreachable: ${out.unreachable.join(', ') || 'none'}; gs1: ${JSON.stringify(L.gs1Info(out.key))}`);
    const maker = await L.findMaker(out.key);
    console.log(`  maker: ${maker ? `${maker.brand} (prefix ${maker.prefix}, ${maker.count} products; first: ${maker.products.slice(0, 4).map((m) => m.name.hu).join(' | ')})` : '—'}`);
    if (maker && opt('--find')) console.log(`  "${opt('--find')}": ${L.filterMakerProducts(maker.products, opt('--find')).map((m) => `${m.code} ${m.name.hu} ${m.quantity}`).join(' | ') || 'none'}`);
    continue;
  }
  if (out.kind !== 'found') continue;
  const p = out.product;
  console.log(`  name: ${p.name.hu} | en: ${p.name.en}${p.real.nameNote ? ` (note: ${p.real.nameNote}${p.real.nameOriginal ? ` „${p.real.nameOriginal}”` : ''})` : ''}`);
  console.log(`  brand: ${p.brand} | size: ${p.size} | category: ${p.category} | nova: ${p.nova ?? '?'} | nutriscore: ${p.real.nutriscore ?? '?'}`);
  console.log(`  sources: ${p.real.sources.join(', ')} | kind: ${p.real.kind} | gs1: ${JSON.stringify(p.real.gs1)}`);
  console.log(`  image: ${p.real.imageUrl ?? '—'}`);
  console.log(`  ingredients (${p.ingredients.length}${p.real.ingredientsPhoto ? `, read off ${p.real.ingredientsPhoto}` : ''}): ${p.ingredients.map(ingredientLine).join(', ') || '—'}`);
  console.log(`  flags: ${(p.flags ?? []).map((f) => `${f.key}${f.trace ? '(trace)' : ''}:${hu(f.reason)}`).join('; ') || '—'}`);
  console.log(`  allergens: ${p.real.allergens.map(hu).join(', ') || '—'} | traces: ${p.real.traces.map(hu).join(', ') || '—'}`);
  console.log(`  nutrition: ${JSON.stringify(p.nutrition)}`);
  console.log(`  labels: ${p.real.labels.map(hu).join(', ') || '—'} | countries: ${p.real.countries.map((c) => c.name.hu).join(', ') || '—'} | stores: ${p.real.stores.join(', ') || '—'}`);
  console.log(`  categories: ${p.real.categoryTags.slice(-3).join(', ')} | comparedTo: ${p.real.comparedTo ?? '—'}`);
  if (p.real.description) console.log(`  description: ${p.real.description.slice(0, 120)}`);
  // Open Prices finishes in the background: give it a moment.
  for (let i = 0; i < 40 && !L.pricesFresh(p.ean).openPrices; i++) await new Promise((r) => setTimeout(r, 200));
  const prices = L.realPrices(p.ean) ?? {};
  const chains = prices.arfigyelo?.chains ?? [];
  console.log(`  árfigyelő: ${prices.arfigyelo === null ? 'not listed' : chains.map((c) => `${c.chain} ${c.priceHuf}${c.discounted ? '*' : ''}${c.sameEverywhere ? '=' : ''} (${c.shops})`).join(', ') || '—'}`);
  console.log(`  open prices: ${prices.openPrices === null ? 'none' : (prices.openPrices ?? []).map((s) => `${s.price} ${s.currency} ${s.date} ${s.shop ?? ''} ${s.city ?? ''} ${s.iso2 ?? ''}`).join(' | ') || '—'}`);
  if (api?.evaluate) {
    const m = api.evaluate(p, { ...SETTINGS });
    console.log(`  verdict: ${m.verdict} ${m.score} | hits: ${m.hits.map((h) => `${h.key}${h.trace ? "(trace)" : ""}:${h.ingredients.map(hu).join(",")}`).join("; ") || "—"} | unknown: ${(m.unknown ?? []).join(',') || '—'}`);
  }
  if (api?.realAlternativesFor && !flag('--no-alts')) {
    const t1 = Date.now();
    const cands = await L.fetchAlternativeCandidates(p);
    const alts = api.realAlternativesFor(p, { ...SETTINGS }, cands.products);
    console.log(`  alternatives (${cands.failed ? 'SEARCH FAILED, ' : ''}${cands.products.length} candidates, ${Date.now() - t1} ms): ${alts.map((a) => `${a.product.name.hu} [${a.product.real?.nutriscore ?? '?'}]`).join(' | ') || 'none qualifies'}`);
    if (flag('--debug-alts')) {
      for (const a of alts) console.log(`    ${a.product.ean} ${a.product.name.hu} · ${a.product.brand} · ${hu(a.reason)}\n      ${a.product.ingredients.map(ingredientLine).join(', ')}`);
    }
  }
}
