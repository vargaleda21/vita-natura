// Serve a web export with the SPA fallback: node tools/serve.mjs [dir] [port]
// CSP=1 sends the production Content-Security-Policy, so violations show up locally.
// /api/arfigyelo/*, /api/upc/lookup and /api/off/{search,sal} are proxied like the nginx vhost does (same paths, GET only, no client headers).
import { createReadStream, existsSync, readFileSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import { extname, join, normalize } from 'node:path';

const dir = process.argv[2] ?? 'dist';
const port = Number(process.argv[3] ?? 8787);
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.ttf': 'font/ttf', '.webmanifest': 'application/manifest+json', '.wasm': 'application/wasm' };
const csp = process.env.CSP === '1'
  ? readFileSync(new URL('../infra/nginx/daleday.digital1.one-security-headers.conf', import.meta.url), 'utf8').match(/Content-Security-Policy "([^"]+)"/)?.[1]
  : undefined;
const UA = 'DaleDay demo (+https://daleday.digital1.one)';
/** The upstream URL for an allowed proxy path, or null. Mirrors infra/nginx/daleday.digital1.one.conf. */
function upstream(url) {
  const [path, query = ''] = url.split('?');
  const q = query ? `?${query}` : '';
  const m = path.match(/^\/api\/arfigyelo\/(product\/[0-9A-Za-z-]{1,40}|search|shops|chain-stores)$/);
  if (m) return `https://arfigyelo.gvh.hu/api/${m[1]}${q}`;
  if (path === '/api/upc/lookup') return `https://api.upcitemdb.com/prod/trial/lookup${q}`;
  if (path === '/api/off/search') return `https://world.openfoodfacts.org/api/v2/search${q}`;
  if (path === '/api/off/sal') return `https://search.openfoodfacts.org/search${q}`;
  return null;
}

createServer(async (req, res) => {
  if (csp) res.setHeader('content-security-policy', csp);
  if ((req.url ?? '').startsWith('/api/')) {
    const target = req.method === 'GET' ? upstream(req.url ?? '') : null;
    if (!target) {
      res.statusCode = 404;
      res.end();
      return;
    }
    try {
      const r = await fetch(target, { headers: { accept: 'application/json', 'user-agent': UA }, signal: AbortSignal.timeout(10_000) });
      res.statusCode = r.status;
      res.setHeader('content-type', r.headers.get('content-type') ?? 'application/json');
      res.end(Buffer.from(await r.arrayBuffer()));
    } catch {
      res.statusCode = 502;
      res.end();
    }
    return;
  }
  const path = normalize(decodeURIComponent((req.url ?? '/').split('?')[0])).replace(/^(\.\.[/\\])+/, '');
  let file = join(dir, path);
  if (!existsSync(file) || statSync(file).isDirectory()) file = join(dir, 'index.html');
  res.setHeader('content-type', types[extname(file)] ?? 'application/octet-stream');
  createReadStream(file).pipe(res);
}).listen(port, '127.0.0.1', () => console.log(`serving ${dir} on http://127.0.0.1:${port}`));
