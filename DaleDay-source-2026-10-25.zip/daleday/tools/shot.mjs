// Phone screenshots of the web build.
// node tools/shot.mjs <url-path> <out.png> [--dark] [--wait ms] [--scroll px] [--click "text"] [--base http://127.0.0.1:8787] [--full]
// Prints console errors and page errors, so a broken screen is visible without the picture.
import { chromium } from 'playwright-core';

const args = process.argv.slice(2);
const flag = (n, d) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : d; };
const has = (n) => args.includes(n);
const [path = '/', out = '/tmp/tuda-shot.png'] = args.filter((a, i) => !a.startsWith('--') && !(i > 0 && args[i - 1].startsWith('--') && !['--dark', '--full'].includes(args[i - 1])));
const base = flag('--base', 'http://127.0.0.1:8787');
const browser = await chromium.launch({ executablePath: '/snap/bin/chromium', args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'] });
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: has('--dark') ? 'dark' : 'light', locale: 'hu-HU' });
const seed = flag('--seed', null);
if (seed) await ctx.addInitScript((s) => { localStorage.setItem('tuda.v1', s); }, seed);
const page = await ctx.newPage();
page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') console.log(`[${m.type()}] ${m.text().slice(0, 300)}`); });
page.on('pageerror', (e) => console.log(`[pageerror] ${e.message.slice(0, 500)}`));
await page.goto(base + path, { waitUntil: 'networkidle' });
await page.waitForTimeout(Number(flag('--wait', '1500')));
const click = flag('--click', null);
if (click) { await page.getByText(click, { exact: false }).first().click(); await page.waitForTimeout(1200); }
const scroll = Number(flag('--scroll', '0'));
if (scroll) { await page.mouse.move(195, 500); await page.mouse.wheel(0, scroll); await page.waitForTimeout(900); }
await page.screenshot({ path: out, fullPage: has('--full') });
console.log(`saved ${out} (${page.url()})`);
await browser.close();
