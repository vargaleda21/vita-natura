# DaleDay — Claude Code context

@HANDOFF.md
@AGENTS.md

Design language, copy rules and the quality bar: `docs/BRIEF.md`.
